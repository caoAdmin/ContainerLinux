/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,ts,tsx,js,jsx}'],
  theme: {
    extend: {
      colors: {
        // macOS 系统色板
        accent: '#0A84FF',
        'traffic-red': '#FF5F57',
        'traffic-yellow': '#FEBC2E',
        'traffic-green': '#28C840',
        // 玻璃层背景
        'glass-light': 'rgba(255,255,255,0.55)',
        'glass-dark': 'rgba(30,30,32,0.55)',
        // 文字色
        'text-primary': 'rgba(0,0,0,0.88)',
        'text-secondary': 'rgba(0,0,0,0.55)',
        'text-dark-primary': 'rgba(255,255,255,0.92)',
        'text-dark-secondary': 'rgba(255,255,255,0.65)'
      },
      borderRadius: {
        window: '10px',
        card: '8px',
        dock: '20px'
      },
      fontFamily: {
        sf: ['-apple-system', 'BlinkMacSystemFont', '"SF Pro Text"', '"SF Pro Display"', '"PingFang SC"', '"Helvetica Neue"', 'Arial', 'sans-serif'],
        mono: ['"SF Mono"', '"Menlo"', 'Monaco', 'Consolas', 'monospace']
      },
      fontSize: {
        // 菜单栏/正文/窗口标题统一 13px
        sys: ['13px', '1.4'],
        title: ['13px', { lineHeight: '1.3', fontWeight: '500' }]
      },
      boxShadow: {
        'window-active': '0 20px 40px rgba(0,0,0,0.28), 0 0 0 0.5px rgba(0,0,0,0.15)',
        'window-inactive': '0 8px 20px rgba(0,0,0,0.14), 0 0 0 0.5px rgba(0,0,0,0.1)',
        'menu-popover': '0 10px 30px rgba(0,0,0,0.25), 0 0 0 0.5px rgba(0,0,0,0.15)',
        'dock': '0 10px 30px rgba(0,0,0,0.35)',
        hdr: '0 0 12px rgba(255,255,255,0.4)'
      },
      transitionTimingFunction: {
        spring: 'cubic-bezier(0.25, 0.1, 0.25, 1)',
        'spring-bounce': 'cubic-bezier(0.34, 1.56, 0.64, 1)'
      },
      backdropBlur: {
        glass: '20px'
      },
      keyframes: {
        'dock-bounce': {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-18px)' }
        },
        'genie-in': {
          '0%': { transform: 'scale(1)', opacity: '1' },
          '100%': { transform: 'scale(0.1) translateY(500px)', opacity: '0' }
        },
        'scale-in': {
          '0%': { transform: 'scale(0.3)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' }
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' }
        },
        'slide-down': {
          '0%': { transform: 'translateY(-8px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' }
        },
        'slide-right': {
          '0%': { transform: 'translateX(20px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' }
        },
        blink: {
          '0%,50%': { opacity: '1' },
          '51%,100%': { opacity: '0' }
        }
      },
      animation: {
        'dock-bounce': 'dock-bounce 0.6s ease-in-out',
        'genie-in': 'genie-in 0.35s cubic-bezier(0.25,0.1,0.25,1) forwards',
        'scale-in': 'scale-in 0.28s cubic-bezier(0.25,0.1,0.25,1)',
        'fade-in': 'fade-in 0.2s ease-out',
        'slide-down': 'slide-down 0.15s cubic-bezier(0.25,0.1,0.25,1)',
        'slide-right': 'slide-right 0.25s cubic-bezier(0.25,0.1,0.25,1)',
        blink: 'blink 1s step-end infinite'
      }
    }
  },
  plugins: []
}
