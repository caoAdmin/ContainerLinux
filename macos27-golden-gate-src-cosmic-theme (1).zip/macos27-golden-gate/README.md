# macOS 27 "Golden Gate" — Web 复刻

纯前端 1:1 复刻 Apple 2026 年 9 月发布的 **macOS 27 "Golden Gate"** 桌面操作系统。
打开页面即进入可操作的桌面，无任何后端。

## 技术栈
- Vue 3 + TypeScript + Vite
- Tailwind CSS v4
- Pinia 状态管理（持久化到 localStorage）
- 所有组件手写，无 UI 组件库
- 图标全部内联 SVG 手绘，壁纸用 Canvas 程序化绘制，字体走系统回退栈

## 启动方式

```bash
cd macos27-golden-gate
npm install
npm run dev
```

默认在 http://localhost:5173 打开（端口占用时自动顺延）。

## 目录结构

```
src/
├── App.vue                       # 根组件
├── main.ts                       # 入口
├── assets/styles/global.css      # 全局样式：Liquid Glass、窗口、按钮、红绿灯、滚动条等
├── composables/
│   └── useGlobalShortcuts.ts     # 全局快捷键
├── stores/
│   ├── system.ts                 # 系统设置（外观/壁纸/玻璃透明度/Dock/音量亮度/HDR）
│   ├── ui.ts                     # UI 浮层状态（面板/Spotlight/Launchpad/通知中心/右键菜单）
│   ├── windows.ts                # 窗口管理（创建/关闭/最小化/缩放/层级/分屏/调度中心）
│   └── dock.ts                   # Dock 图标、运行状态、拖拽排序、自动隐藏
├── types/index.ts                # 全局类型
├── utils/
│   ├── index.ts                  # cn/uid/clamp/rafThrottle/formatDateTime/storage/magnifyScale 等
│   └── appRegistry.ts            # 所有可打开 App 的注册表
└── components/
    ├── common/
    │   └── Icon.vue              # 统一 SVG 图标集（40+ 手绘图标）
    ├── desktop/
    │   ├── Wallpaper.vue         # Canvas 程序化绘制 Golden Gate Day/Evening 壁纸
    │   ├── DesktopIcon.vue       # 桌面图标
    │   └── Desktop.vue           # 桌面容器（框选/拖拽/网格/右键菜单）
    ├── menubar/
    │   ├── MenuBar.vue           # 顶部 24px 菜单栏
    │   ├── MenubarDropdown.vue   # 下拉菜单
    │   └── MenubarPopovers.vue   # 右侧各面板聚合（含控制中心、Wi-Fi、电池等）
    ├── dock/
    │   └── Dock.vue              # 底部玻璃 Dock（磁吸放大/拖拽排序/弹跳/运行指示点/自动隐藏）
    ├── windows/
    │   ├── WindowBase.vue        # 通用窗口（拖动/八向缩放/红绿灯/入场/关闭动画）
    │   ├── WindowManager.vue     # 窗口容器（动态挂载 App）
    │   ├── MissionControl.vue    # 调度中心 F3
    │   └── TilingPreview.vue     # Option 拖拽分屏吸附预览
    ├── controlcenter/
    │   ├── ControlCenterPopover.vue
    │   └── NotificationCenter.vue
    ├── spotlight/
    │   └── SpotlightPanel.vue    # Spotlight + Siri "Search or Ask"
    ├── launchpad/
    │   └── Launchpad.vue         # 启动台
    └── apps/
        ├── FinderApp.vue         # 访达：edge-to-edge 侧边栏 + 4 种视图 + 面包屑
        ├── SafariApp.vue         # Safari：标签页/地址栏/书签栏/起始页
        ├── NotesApp.vue          # 备忘录：真实可输入 + localStorage 持久化
        ├── SettingsApp.vue       # 系统设置：含 Liquid Glass 滑块核心功能 + Clarus 彩蛋
        ├── CalculatorApp.vue     # 计算器
        ├── TerminalApp.vue       # 终端（ls/pwd/whoami/echo/date/neofetch/clear）
        ├── MailApp.vue           # 邮件
        ├── MessagesApp.vue       # 信息
        ├── MapsApp.vue           # 地图
        ├── PhotosApp.vue         # 照片
        ├── MusicApp.vue          # 音乐
        ├── CalendarApp.vue       # 日历
        ├── PreviewApp.vue        # 预览
        └── TrashApp.vue          # 废纸篓
```

## 快捷键

| 快捷键            | 功能                                  |
| ----------------- | ------------------------------------- |
| `Cmd + Space`     | 呼出 Spotlight（可切换到 Siri）       |
| `Cmd + Q`         | 关闭当前激活窗口                      |
| `Cmd + W`         | 关闭窗口                              |
| `Cmd + M`         | 最小化当前窗口                        |
| `Cmd + ,`         | 打开系统设置                          |
| `F3` / `Ctrl + ↑` | 调度中心 Mission Control              |
| `Ctrl + Option + ←/→` | 当前窗口拼铺到左/右半屏            |
| `Ctrl + Option + ↑`   | 当前窗口全屏                       |
| `Esc`             | 关闭浮层（Spotlight/Launchpad/弹窗）  |
| `Option + 拖拽`   | 显示分屏吸附预览，松开自动贴靠        |
| `双击标题栏`      | 窗口缩放                              |

## 已实现的 Golden Gate 专有特征

- **Liquid Glass 2.0**：控制中心/菜单栏/Dock/窗口工具栏均为半透明玻璃层，`backdrop-filter: blur + saturate`，1px 高光内描边，边缘折射。
- **Liquid Glass 透明度滑块**（系统设置 → 外观）：0-100% 连续可调，三档吸附（最通透/中等/最不透明），全局实时生效；滚动到底继续下拉触发 **Clarus the Dogcow** 彩蛋（Moof!）。
- **窗口圆角统一 10px**，工具栏底部明确分隔线。
- **Edge-to-edge 侧边栏**（访达、备忘录、设置、Safari 标签栏）。
- **菜单栏 24px 薄而克制**，图标过多时按宽度自动折叠。
- **红绿灯 Liquid Glass 风格**：默认半透明灰点，悬停整组显红黄绿 + 内符号。
- **图标 SVG 重绘**，图标/玻璃高光带 HDR 辉光（可调）。
- **Golden Gate Day / Evening** 两张 Canvas 程序化壁纸（金橙/蓝金渐变 + 山脊 + 桥塔悬索 + 太阳反光 + 云层飘动），右键桌面可切换。
- **窗口管理**：拖动移动、八向缩放、genie 动画（从 Dock 图标放大/缩回）、点击置顶激活、非激活窗口降饱和/浅阴影、Option 拖拽吸附分屏、快捷键左右/全屏拼铺、调度中心平铺所有窗口。
- **Spotlight "Search or Ask"**：同一输入框既能搜文件/App，也能切到 Siri 对话（气泡问答、打字指示器、预设回复）。

## 功能清单

- 桌面：动态壁纸、桌面图标（单击/双击/框选/拖拽/网格吸附/右键菜单/新建文件夹/换壁纸）
- 菜单栏：Apple 菜单、当前 App 菜单、文件/编辑/视图/窗口/帮助、控制中心/Wi-Fi/蓝牙/音量/电池/Siri/Spotlight/输入法/通知中心/用户头像、日期时间实时更新
- Dock：13+ 图标、磁吸抛物线放大（余弦衰减）、运行小圆点、弹跳开启动画、拖拽排序、拖出删除、右键菜单、自动隐藏
- 窗口系统：拖动、八向缩放、最小化/最大化/关闭/缩放、层级管理、入场出场动画、多窗口重叠
- 启动台：模糊背景、应用网格（7 列）、搜索、分页圆点、点击打开、Esc 关闭
- 控制中心：Wi-Fi/蓝牙/AirDrop/专注开关、音乐控制、亮度/音量滑块、深色模式切换
- 通知中心：日期大字、天气卡片、日程、通知列表可清除
- Spotlight：实时搜索 App/文件、键盘导航、Siri 对话模式
- 系统设置：外观（Light/Dark/Auto、Liquid Glass 滑块、HDR、强调色）、桌面与程序坞（大小/放大/自动隐藏）、墙纸（两张缩略图切换）、其他分类占位
- 内置 App：访达、Safari、备忘录、系统设置（可完整交互），邮件/信息/地图/照片/音乐/日历/计算器/终端/预览/废纸篓（高还原度展示）
- 快捷键系统、Pinia 全局状态、localStorage 持久化（笔记/桌面图标/Dock/设置）
- HDR 辉光、requestAnimationFrame 拖动、自适应分辨率（1366×768 到 2560×1440）
