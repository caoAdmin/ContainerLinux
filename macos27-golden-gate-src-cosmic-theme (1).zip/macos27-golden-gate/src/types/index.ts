/**
 * 全局类型定义
 * macOS 27 Golden Gate 复刻工程
 */

// ============ 窗口 ============
export interface WindowPosition {
  x: number
  y: number
}

export interface WindowSize {
  width: number
  height: number
}

export interface WindowState {
  id: string
  appId: string
  title: string
  icon: string // 图标 id，对应 DockIcons 映射
  x: number
  y: number
  width: number
  height: number
  minWidth: number
  minHeight: number
  zIndex: number
  // 状态
  minimized: boolean
  maximized: boolean
  fullscreen: boolean
  closed: boolean // 软关闭，保留状态可恢复
  focused: boolean
  resizable: boolean
  // 最大化/分屏前的位置记忆
  prev?: {
    x: number
    y: number
    width: number
    height: number
  }
  // 初始动画来源（Dock 图标位置）
  originRect?: { x: number; y: number; size: number }
  // 关闭动画
  closing?: boolean
}

// title / icon 可选：未传时由 openWindow 依据 appRegistry 自动补齐
export type CreateWindowOptions = Partial<Omit<WindowState, 'id' | 'zIndex'>> & {
  appId: string
}

// ============ Dock ============
export interface DockItem {
  id: string
  appId: string // 关联 app
  name: string
  icon: string // svg id
  isPersistent: boolean // 常驻图标
  isRunning: boolean
  isSystem?: boolean
}

// ============ App 定义 ============
export interface AppDefinition {
  id: string
  name: string
  icon: string
  defaultWidth: number
  defaultHeight: number
  minWidth: number
  minHeight: number
  singleton: boolean // 单例
  component: string // 组件名
}

// ============ 外观模式 ============
export type AppearanceMode = 'light' | 'dark' | 'auto'
export type WallpaperType = 'golden-gate-day' | 'golden-gate-evening'
export type DockPosition = 'bottom' | 'left' | 'right'

// ============ 系统设置 ============
export interface SystemSettings {
  appearance: AppearanceMode
  wallpaper: WallpaperType
  // Liquid Glass 透明度 0-1
  glassOpacity: number
  // HDR 泛光 0-1
  hdrGlow: number
  // Dock
  dockSize: number // 48-72
  dockMagnification: boolean
  dockMagnificationLevel: number // 1-2
  dockPosition: DockPosition
  dockAutoHide: boolean
  // 菜单栏
  menubarAutoHide: boolean
  // 控制中心开关
  wifiEnabled: boolean
  bluetoothEnabled: boolean
  airdropEnabled: boolean
  focusEnabled: boolean
  darkMode: boolean // 深色模式快捷开关
  brightness: number // 0-1
  volume: number // 0-1
}

// ============ 桌面图标 ============
export interface DesktopIcon {
  id: string
  name: string
  icon: string
  kind: 'folder' | 'file' | 'drive'
  appId?: string
  x: number
  y: number
}

// ============ 菜单栏下拉面板类型 ============
export type MenubarPanel =
  | null
  | 'apple'
  | 'app'
  | 'control-center'
  | 'wifi'
  | 'battery'
  | 'bluetooth'
  | 'volume'
  | 'spotlight'
  | 'siri'
  | 'input'
  | 'datetime'
  | 'user'

// ============ 笔记 ============
export interface Note {
  id: string
  title: string
  content: string
  createdAt: number
  updatedAt: number
}

// ============ Finder 文件 ============
export interface FileNode {
  id: string
  name: string
  kind: 'folder' | 'file' | 'drive'
  icon?: string
  children?: FileNode[]
  size?: string
  modified?: string
  content?: string
}

// ============ Siri 消息 ============
export interface SiriMessage {
  id: string
  role: 'user' | 'assistant'
  text: string
  timestamp: number
}

// ============ 键盘修饰键 ============
export interface KeyModifiers {
  cmd: boolean
  option: boolean
  ctrl: boolean
  shift: boolean
}

// ============ 图标主题 ============
/**
 * 图标主题 id
 * crule-dark：KDE Crule 深色（默认）  crule：Crule 浅色  linuxfx：之前的位图图标包
 */
export type IconThemeId = 'fluent' | 'crule-dark' | 'crule' | 'linuxfx'
