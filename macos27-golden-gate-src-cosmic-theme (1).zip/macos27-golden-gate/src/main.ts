/**
 * 应用入口
 * 挂载 Vue、Pinia、全局样式，并初始化 shuding/liquid-glass 边缘折射。
 */
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { initPerfTier } from './utils/perfTier'
import { useSystemStore } from './stores/system'
import App from './App.vue'
import './assets/styles/global.css'
import './assets/styles/cosmic.css'
import './assets/styles/island.css'
import { initLiquidGlass } from './utils/liquidGlassInit'

/* 渲染档位必须在首帧之前定下来：晚一帧就会先画一屏完整液态玻璃再切走 */
initPerfTier()

/* 发布版本标记：改动此值会改变 JS 内容哈希 → 生成新的资源文件名，
   浏览器/CDN 缓存的旧资源不再被引用，避免「发布了但页面没变」。 */
;(window as unknown as { __GG_BUILD__: string }).__GG_BUILD__ = '20261115-m3e-theme-47'

const app = createApp(App)
const pinia = createPinia()
app.use(pinia)

/* 外观类必须在首帧之前锁定。
   system store 原先由控制中心 / 菜单栏懒加载：第一次打开控制中心才实例化，
   immediate watch 这时才把 <html> 从「无类」改成 light（默认 appearance），
   全站 --glass-bg / --window-toolbar-bg 等变量同一帧翻色 —— 用户看到的就是
   「文件管理开着，再开控制中心，AppBar 突然变白」。启动期主动实例化一次，
   类在挂载前就写定，控制中心不再有翻色副作用。 */
useSystemStore(pinia)

app.mount('#app')

// 等 DOM 挂载后再注入共享 SVG 滤镜（body 必须存在）
requestAnimationFrame(() => {
  /* 省电档不做光源跟随：每帧写根 CSS 变量会让整棵样式树重算，
     手机触摸拖动时这笔开销直接压在滚动/动画的同一帧上。 */
  if (document.documentElement.dataset.perf !== 'high') return
  try {
    initLiquidGlass()
  } catch (e) {
    console.warn('[LiquidGlass] init failed, fallback to plain blur:', e)
  }
})
