/**
 * 壁纸：样式映射 + 供 WebGL 玻璃采样的纹理画布
 *
 * 桌面背景、设置页预览、玻璃着色器三处必须同源，否则会出现
 * 「换了壁纸但玻璃还在折射旧图」的问题。
 */
import ubuntuUrl from '@/assets/wallpapers/ubuntu.jpg'
import prismUrl from '@/assets/wallpapers/prism.png'
import axisUrl from '@/assets/wallpapers/axis.png'
import cityDuskUrl from '@/assets/wallpapers/city-dusk.jpg'

export interface WallpaperState {
  current: string
  mode: 'image' | 'solid' | 'gradient'
  solidColor: string
  gradientFrom: string
  gradientTo: string
  fill: string
  blur: number
  darken: number
}

/** 内置壁纸的渐变定义（没有实拍图的那几张用渐变代替） */
export const WALLPAPER_GRADIENTS: Record<string, string> = {
  nebula: 'linear-gradient(140deg, #2b1b4d, #6b3fa0 55%, #c76bd1)',
  ubuntu: 'linear-gradient(140deg, #2b1020, #7a2547 55%, #e95420)',
  ocean: 'linear-gradient(140deg, #08213d, #1c5c8a 55%, #4fb8c9)',
  forest: 'linear-gradient(140deg, #0f2418, #2c6b45 55%, #8fd18c)',
  sunset: 'linear-gradient(140deg, #3b1030, #a83a56 55%, #f2a65a)',
  mono: 'linear-gradient(140deg, #141416, #33333a 55%, #6b6b78)',
  aurora: 'linear-gradient(140deg, #062421, #1f7a6b 55%, #7ce0b8)',
  flare: 'linear-gradient(140deg, #3a1a08, #c9622a 55%, #f5c26b)',
  violet: 'linear-gradient(140deg, #1d1338, #5b3fa8 55%, #b39cf5)',
  ice: 'linear-gradient(140deg, #0a2333, #4a7fa8 55%, #bfe3f5)',
  ember: 'linear-gradient(140deg, #2a0f08, #8c3b2a 55%, #e08a63)',
  void: 'linear-gradient(140deg, #0c0c0f, #1d1d22 60%, #3a3a45)'
}

/** 位图壁纸：id → 资源 URL（其余是渐变） */
export const WALLPAPER_PHOTOS: Record<string, string> = {
  ubuntu: ubuntuUrl,
  /** 棱镜网格：专门用来看边缘折射 / 磨砂是否成立（均匀渐变上是看不出来的） */
  prism: prismUrl,
  /** 标尺：等距粗线，用来定量核对玻璃采样与壁纸是否严格对齐 */
  axis: axisUrl,
  /** 城市暮色：细节丰富的实拍图，液态玻璃折射效果最佳 */
  city: cityDuskUrl
}

/** 填充方式 → background-size */
const FILL_SIZE: Record<string, string> = {
  填充: 'cover',
  适应: 'contain',
  拉伸: '100% 100%',
  平铺: 'auto',
  居中: 'auto',
  跨屏: 'cover'
}

/** 桌面背景的 CSS（DotfilesDesktop 用） */
export function wallpaperStyle(w: WallpaperState) {
  const base = {
    backgroundPosition: 'center',
    backgroundRepeat: w.mode === 'image' && w.fill === '平铺' ? 'repeat' : 'no-repeat',
    filter: w.blur > 0 ? `blur(${w.blur}px)` : undefined,
    // 虚化会露出边缘，轻微放大盖住
    transform: w.blur > 0 ? 'scale(1.06)' : undefined
  }
  if (w.mode === 'solid') {
    return { ...base, backgroundColor: w.solidColor, backgroundImage: 'none' as const }
  }
  if (w.mode === 'gradient') {
    return {
      ...base,
      backgroundImage: `linear-gradient(140deg, ${w.gradientFrom}, ${w.gradientTo})`
    }
  }
  // image 模式
  const photoUrl = WALLPAPER_PHOTOS[w.current]
  return {
    ...base,
    backgroundImage: photoUrl
      ? `url(${photoUrl})`
      : WALLPAPER_GRADIENTS[w.current] ?? WALLPAPER_GRADIENTS.nebula,
    backgroundSize: FILL_SIZE[w.fill] ?? 'cover'
  }
}

/** 参与纹理生成的字段签名：变了就重建纹理 */
export function wallpaperKey(w: WallpaperState): string {
  return [w.mode, w.current, w.solidColor, w.gradientFrom, w.gradientTo, w.blur, w.darken, w.fill].join('|')
}

/* ── 供 WebGL 采样的画布 ── */

const TEX_W = 1920
const TEX_H = 1080
let cacheKey = ''
let cacheCanvas: HTMLCanvasElement | null = null
const photoCache = new Map<string, Promise<HTMLImageElement>>()

function loadPhoto(url: string): Promise<HTMLImageElement> {
  let p = photoCache.get(url)
  if (!p) {
    const img = new Image()
    img.src = url
    p = (img.decode
      ? img.decode()
      : new Promise<void>((res) => {
          img.onload = () => res()
          img.onerror = () => res()
        })
    )
      .then(() => img)
      .catch(() => img)
    photoCache.set(url, p)
  }
  return p
}

/** 把 140deg 的 CSS 渐变近似成画布线性渐变（取对角线方向） */
function paintGradient(ctx: CanvasRenderingContext2D, css: string) {
  // 从 "linear-gradient(140deg, c1, c2 55%, c3)" 里取出颜色
  const colors = css.match(/#[0-9a-fA-F]{3,8}/g) ?? ['#2b1b4d', '#6b3fa0']
  const rad = ((140 - 90) * Math.PI) / 180
  const cx = TEX_W / 2
  const cy = TEX_H / 2
  const len = Math.abs(TEX_W * Math.cos(rad)) + Math.abs(TEX_H * Math.sin(rad))
  const g = ctx.createLinearGradient(
    cx - (Math.cos(rad) * len) / 2,
    cy - (Math.sin(rad) * len) / 2,
    cx + (Math.cos(rad) * len) / 2,
    cy + (Math.sin(rad) * len) / 2
  )
  colors.forEach((c, i) => g.addColorStop(colors.length === 1 ? 0 : i / (colors.length - 1), c))
  ctx.fillStyle = g
  ctx.fillRect(0, 0, TEX_W, TEX_H)
}

/** 生成与当前壁纸一致的纹理画布（模糊/暗化也在里面烘好） */
export async function getWallpaperCanvas(w: WallpaperState): Promise<HTMLCanvasElement> {
  const key = wallpaperKey(w)
  if (cacheCanvas && cacheKey === key) return cacheCanvas

  const canvas = document.createElement('canvas')
  canvas.width = TEX_W
  canvas.height = TEX_H
  const ctx = canvas.getContext('2d')!
  if (w.blur > 0) ctx.filter = `blur(${w.blur * 1.5}px)`

  if (w.mode === 'solid') {
    ctx.fillStyle = w.solidColor
    ctx.fillRect(0, 0, TEX_W, TEX_H)
  } else if (w.mode === 'gradient') {
    paintGradient(ctx, `linear-gradient(140deg, ${w.gradientFrom}, ${w.gradientTo})`)
  } else if (WALLPAPER_PHOTOS[w.current]) {
    const img = await loadPhoto(WALLPAPER_PHOTOS[w.current])
    const scale = Math.max(TEX_W / (img.naturalWidth || TEX_W), TEX_H / (img.naturalHeight || TEX_H))
    const dw = (img.naturalWidth || TEX_W) * scale
    const dh = (img.naturalHeight || TEX_H) * scale
    ctx.drawImage(img, (TEX_W - dw) / 2, (TEX_H - dh) / 2, dw, dh)
  } else {
    paintGradient(ctx, WALLPAPER_GRADIENTS[w.current] ?? WALLPAPER_GRADIENTS.nebula)
  }

  ctx.filter = 'none'
  if (w.darken > 0) {
    ctx.fillStyle = `rgba(0,0,0,${w.darken})`
    ctx.fillRect(0, 0, TEX_W, TEX_H)
  }

  cacheCanvas = canvas
  cacheKey = key
  return canvas
}
