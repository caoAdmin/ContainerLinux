/**
 * COSMIC 主题引擎 —— 移植自 System76 COSMIC Desktop 的 cosmic-theme / libcosmic
 * （MPL-2.0，https://github.com/pop-os/cosmic-theme、https://github.com/pop-os/libcosmic）
 *
 * 移植范围与上游一一对应：
 *   · steps.rs      → oklchSteps / colorIndex / getSurfaceColor / getText / getSmallWidgetColor
 *   · model/corner.rs  → CornerRadii / Roundness
 *   · model/spacing.rs → Spacing
 *   · model/theme.rs   → Theme / Container / Component / ThemeBuilder.build()
 *   · theme_provider   → ThemeProvider（内置主题 + 用户主题目录 + 变更订阅）
 *
 * 核心思想（这就是「主题作用于整个界面」的原因）：
 *   一切颜色都从 gray_1（底色）的 100 级 OKLCH 明度阶梯上按 index 偏移取值，
 *   文字色按反差自动求解，hover/pressed 是带透明度的 overlay 而非独立颜色 ——
 *   任何容器换色，整套界面（容器/组件/文字/描边/交互态）自动重算。
 */

/* ══════════════════ OKLCH 色彩数学（palette crate 等价实现） ══════════════════ */

export type RGBA = { r: number; g: number; b: number; a: number } // 0..1
export type Oklch = { l: number; c: number; h: number; a: number } // l/c/h 按上游 crate 语义

const clamp01 = (v: number) => Math.min(1, Math.max(0, v))
const lin = (v: number) => (v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4))
const gam = (v: number) => (v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055)

export function hexToRgba(hex: string, a = 1): RGBA | null {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return null
  const n = parseInt(m[1], 16)
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255, a }
}

export function rgbaToHex(c: RGBA): string {
  const to = (v: number) => Math.round(clamp01(v) * 255).toString(16).padStart(2, '0').toUpperCase()
  return `#${to(c.r)}${to(c.g)}${to(c.b)}`
}

/** 输出 CSS 可用的 rgba() 字符串（透明 overlay 用） */
export function rgbaToCss(c: RGBA): string {
  return `rgba(${Math.round(clamp01(c.r) * 255)}, ${Math.round(clamp01(c.g) * 255)}, ${Math.round(clamp01(c.b) * 255)}, ${Number(c.a.toFixed(3))})`
}

/* —— sRGB ↔ OKLab（Björn Ottosson 标准矩阵）—— */
function srgbToOklab(c: RGBA): [number, number, number] {
  const r = lin(c.r), g = lin(c.g), b = lin(c.b)
  const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b)
  const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b)
  const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b)
  return [
    0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s
  ]
}

function oklabToSrgb(L: number, a: number, b: number): [number, number, number] | null {
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b
  const s_ = L - 0.0894841775 * a - 1.291485548 * b
  const l = l_ * l_ * l_, m = m_ * m_ * m_, s = s_ * s_ * s_
  const R = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
  const G = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
  const B = -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s
  if (R < -0.002 || R > 1.002 || G < -0.002 || G > 1.002 || B < -0.002 || B > 1.002) return null
  return [clamp01(gam(R)), clamp01(gam(G)), clamp01(gam(B))]
}

export function srgbToOklch(c: RGBA): Oklch {
  const [L, a, b] = srgbToOklab(c)
  const C = Math.hypot(a, b)
  let h = (Math.atan2(b, a) * 180) / Math.PI
  if (h < 0) h += 360
  return { l: L, c: C, h, a: c.a }
}

/** 色域外收敛：二分找最近的合法 chroma（上游 oklch_to_srgba_nearest_chroma） */
function oklchToSrgbNearestChroma(c: Oklch): RGBA {
  const rad = (c.h * Math.PI) / 180
  const tryConvert = (chroma: number) => {
    const rgb = oklabToSrgb(c.l, chroma * Math.cos(rad), chroma * Math.sin(rad))
    return rgb ? ({ r: rgb[0], g: rgb[1], b: rgb[2], a: c.a } as RGBA) : null
  }
  const direct = tryConvert(c.c)
  if (direct) return direct
  let lo = 0, hi = c.c
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2
    if (tryConvert(mid)) lo = mid
    else hi = mid
  }
  return tryConvert(lo) ?? { r: clamp01(c.l), g: clamp01(c.l), b: clamp01(c.l), a: c.a }
}

/** α 合成（composite.rs 的 over） */
export function over(fg: RGBA, bg: RGBA): RGBA {
  const a = fg.a + bg.a * (1 - fg.a)
  if (a === 0) return { r: 0, g: 0, b: 0, a: 0 }
  const mix = (f: number, b: number) => (f * fg.a + b * bg.a * (1 - fg.a)) / a
  return { r: mix(fg.r, bg.r), g: mix(fg.g, bg.g), b: mix(fg.b, bg.b), a }
}

/* ══════════════════ steps.rs：100 级明度阶梯 ══════════════════ */

/** 与输入同色相/彩度、明度铺满 0..1 的 100 色阶梯（上游 steps(c, 100)） */
export function oklchSteps(c: RGBA, len = 100): RGBA[] {
  const oc = srgbToOklch(c)
  const out: RGBA[] = []
  for (let i = 0; i < len; i++) {
    const l = i / (len - 1)
    out.push(oklchToSrgbNearestChroma({ l, c: oc.c, h: oc.h, a: oc.a }))
  }
  return out
}

/** 颜色在阶梯上的 index（= OKLCH L×100） */
export function colorIndex(c: RGBA, len = 100): number {
  return Math.min(len - 1, Math.max(0, Math.round(srgbToOklch(c).l * len)))
}

function getIndex(base: number, steps: number, len: number, isDark: boolean): number | null {
  const i = isDark ? base + steps : base - steps
  return i >= 0 && i < len ? i : null
}

/** 表面色：从底色 index 偏移 steps 级（上游 get_surface_color） */
export function getSurfaceColor(base: number, steps: number, arr: RGBA[], isDark: boolean, fallback: RGBA): RGBA {
  const dark = isDark || base < 91
  return arr[getIndex(base, steps, arr.length, dark) ?? -1] ?? fallback
}

/** 文字色：70 级反差（不够退 50 级，再不够顶到端点）（上游 get_text） */
export function getText(base: number, arr: RGBA[], fallback: RGBA, alpha = 1): RGBA {
  const isDark = base < 60
  const extra = alpha < 1 ? Math.round((1 - alpha) * 100) : 0
  const idx =
    getIndex(base, 70 + extra, arr.length, isDark) ??
    getIndex(base, 50 + extra, arr.length, isDark) ??
    (isDark ? 99 : 0)
  const hit = arr[idx] ?? fallback
  return alpha < 1 ? { ...hit, a: hit.a * alpha } : hit
}

/** 描边/分隔线色：低偏移 + 彩度压到 max 的 3%（上游 get_small_widget_color） */
export function getSmallWidgetColor(base: number, steps: number, arr: RGBA[], fallback: RGBA): RGBA {
  const isDark = base <= 40 || (base > 51 && base < 65)
  let res = arr[getIndex(base, steps, arr.length, isDark) ?? -1] ?? fallback
  const oc = srgbToOklch(res)
  const maxC = 0.33 // OKLCH 全域近似最大彩度（palette::Lch::max_chroma ≈ 0.33）
  if (oc.c / maxC > 0.03) {
    res = oklchToSrgbNearestChroma({ ...oc, c: 0.03 * maxC })
  }
  return res
}

/** WCAG 相对亮度与对比度（上游 relative_contrast） */
function relativeLuminance(c: RGBA): number {
  const r = lin(c.r), g = lin(c.g), b = lin(c.b)
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}
function relativeContrast(a: RGBA, b: RGBA): number {
  const l1 = relativeLuminance(a), l2 = relativeLuminance(b)
  const [hi, lo] = l1 > l2 ? [l1, l2] : [l2, l1]
  return (hi + 0.05) / (lo + 0.05)
}

/* ══════════════════ Palette（model/light.ron · dark.ron 官方值） ══════════════════ */

export type CosmicPalette = {
  name: string
  gray1: string; gray2: string
  neutral0: string; neutral1: string; neutral2: string; neutral3: string; neutral4: string
  neutral5: string; neutral6: string; neutral7: string; neutral8: string; neutral9: string; neutral10: string
  accentBlue: string
  brightRed: string; brightGreen: string; brightOrange: string
}

/** COSMIC Dark（dark.ron 原值） */
export const COSMIC_DARK: CosmicPalette = {
  name: 'COSMIC Dark',
  gray1: '#1B1B1B', gray2: '#262626',
  neutral0: '#000000', neutral1: '#030303', neutral2: '#161616', neutral3: '#2E2E2E', neutral4: '#484848',
  neutral5: '#636363', neutral6: '#808080', neutral7: '#9E9E9E', neutral8: '#BEBEBE', neutral9: '#DEDEDE', neutral10: '#FFFFFF',
  accentBlue: '#63D0DF',
  brightRed: '#FFA09A', brightGreen: '#5EDB8C', brightOrange: '#FFA37D'
}

/** COSMIC Light（light.ron 原值） */
export const COSMIC_LIGHT: CosmicPalette = {
  name: 'COSMIC Light',
  gray1: '#D7D7D7', gray2: '#E4E4E4',
  neutral0: '#FFFFFF', neutral1: '#DEDEDE', neutral2: '#BEBEBE', neutral3: '#9E9E9E', neutral4: '#808080',
  neutral5: '#636363', neutral6: '#484848', neutral7: '#2E2E2E', neutral8: '#161616', neutral9: '#030303', neutral10: '#000000',
  accentBlue: '#00525A',
  brightRed: '#890418', brightGreen: '#00572C', brightOrange: '#792C00'
}

/** 高对比度变体：中性色向端点外推（对齐上游 highcontrast ron 的观感） */
function highContrastPalette(p: CosmicPalette, dark: boolean): CosmicPalette {
  if (dark) return { ...p, name: 'COSMIC Dark HighContrast', gray1: '#0D0D0D', gray2: '#1A1A1A', neutral10: '#FFFFFF' }
  return { ...p, name: 'COSMIC Light HighContrast', gray1: '#EDEDED', gray2: '#F4F4F4', neutral0: '#FFFFFF', neutral10: '#000000' }
}

/* ══════════════════ Theme 数据模型（model/theme.rs · derivation.rs） ══════════════════ */

/** 上游 Component：一个 widget 的全部交互态颜色 */
export type ThemeComponent = {
  base: string; hover: string; pressed: string
  selected: string; selectedText: string; focus: string
  divider: string; on: string; disabled: string; onDisabled: string
}

/** 上游 Container：一个表面层（底 + 组件 + 分隔线 + 文字） */
export type ThemeContainer = {
  base: string; divider: string; on: string
  component: ThemeComponent
}

export type Roundness = 'round' | 'slightlyRound' | 'square'

/** 上游 CornerRadii：radius_0/xs/s/m/l/xl 六级圆角刻度 */
export type CornerRadii = { r0: number; xs: number; s: number; m: number; l: number; xl: number }

export function cornerRadiiOf(roundness: Roundness): CornerRadii {
  if (roundness === 'slightlyRound') return { r0: 0, xs: 2, s: 8, m: 8, l: 8, xl: 8 }
  if (roundness === 'square') return { r0: 0, xs: 2, s: 2, m: 2, l: 2, xl: 2 }
  return { r0: 0, xs: 4, s: 8, m: 16, l: 32, xl: 160 } // Round（默认）
}

/** 上游 Spacing：从 none 到 xxxl 的十级间距刻度 */
export type Spacing = { none: number; xxxs: number; xxs: number; xs: number; s: number; m: number; l: number; xl: number; xxl: number; xxxl: number }
export const SPACING: Spacing = { none: 0, xxxs: 4, xxs: 8, xs: 12, s: 16, m: 24, l: 32, xl: 48, xxl: 64, xxxl: 128 }

/** 上游 Theme 完整结构 */
export type CosmicTheme = {
  name: string
  background: ThemeContainer
  primary: ThemeContainer
  secondary: ThemeContainer
  accent: ThemeComponent
  accentButton: ThemeComponent
  success: ThemeComponent
  destructive: ThemeComponent
  warning: ThemeComponent
  /** 辅助按钮变体（icon/link/text/list：透明底） */
  iconButton: ThemeComponent
  linkButton: ThemeComponent
  isDark: boolean
  isHighContrast: boolean
  cornerRadii: CornerRadii
  spacing: Spacing
  /** cosmic-comp 窗口间隙（outer, inner） */
  gaps: [number, number]
  /** 活动窗口描边宽 */
  activeHint: number
  /** 对话框 shade */
  shade: string
  accentText: string
}

/* —— Component 派生（model/theme.rs 现代签名：base + 预构建 hover overlay）—— */

function buildComponent(
  base: RGBA, hoverOverlayColor: RGBA, accent: RGBA, on: RGBA, isHighContrast: boolean
): ThemeComponent {
  const ov10: RGBA = { ...hoverOverlayColor, a: 0.1 }
  const ov20: RGBA = { ...hoverOverlayColor, a: 0.2 }
  const base50: RGBA = { ...base, a: 0.5 }
  const on20: RGBA = { ...on, a: 0.2 }
  const on50: RGBA = { ...on, a: 0.5 }
  const hx = (c: RGBA) => rgbaToHex(c)
  return {
    base: hx(base),
    hover: hx(over(ov10, base)),
    pressed: hx(over(ov20, base)),
    selected: hx(over(ov10, base)),
    selectedText: hx(accent),
    focus: hx(accent),
    divider: isHighContrast ? hx(on50) : hx(on20),
    on: hx(on),
    disabled: hx(base50),
    onDisabled: hx(on50)
  }
}

/** 有色组件（accent / success / destructive / warning 用） */
function coloredComponent(base: RGBA, neutral: RGBA, accent: RGBA): ThemeComponent {
  const n10: RGBA = { ...neutral, a: 0.1 }
  const n20: RGBA = { ...neutral, a: 0.2 }
  const base50: RGBA = { ...base, a: 0.5 }
  const on50: RGBA = { ...neutral, a: 0.5 }
  const hx = (c: RGBA) => rgbaToHex(c)
  return {
    base: hx(base),
    hover: hx(over(n10, base)),
    pressed: hx(over(n20, base)),
    selected: hx(over(n10, base)),
    selectedText: hx(accent),
    divider: hx(n20),
    on: hx(neutral),
    disabled: hx(base50),
    onDisabled: hx(on50),
    focus: hx(accent)
  }
}

/* ══════════════════ ThemeBuilder（model/theme.rs build() 移植） ══════════════════ */

export type ThemeBuilderOptions = {
  palette: CosmicPalette
  /** 明确指定明暗（自定义色板时必填；官方色板按引用判定） */
  isDark?: boolean
  /** 覆盖底色（如 M3E 的 surface tone） */
  bgColor?: string
  /** 覆盖 primary 容器底 */
  primaryContainerBg?: string
  /** 覆盖 secondary 容器底 */
  secondaryContainerBg?: string
  /** 覆盖 accent（用户强调色） */
  accent?: string
  success?: string
  warning?: string
  destructive?: string
  roundness?: Roundness
  highContrast?: boolean
}

function darkMode(p: CosmicPalette, hc: boolean): CosmicPalette {
  return hc ? highContrastPalette(p, true) : p
}
function lightMode(p: CosmicPalette, hc: boolean): CosmicPalette {
  return hc ? highContrastPalette(p, false) : p
}

/** 把 builder 选项组装成完整 Theme（上游 ThemeBuilder::build 的忠实移植） */
export function buildTheme(opts: ThemeBuilderOptions): CosmicTheme {
  const hc = !!opts.highContrast
  // 官方色板按引用判定明暗；自定义色板必须显式给 isDark
  const isDark =
    opts.isDark ??
    (opts.palette === COSMIC_LIGHT || opts.palette.name.includes('Light') ? false : true)
  const pal = isDark ? darkMode(opts.palette, hc) : lightMode(opts.palette, hc)

  const P = (hex: string) => hexToRgba(hex) as RGBA

  // 底色与各级阶梯
  const bg = (opts.bgColor ? hexToRgba(opts.bgColor) : null) ?? P(pal.gray1)
  const controlSteps = oklchSteps(P(pal.neutral2), 11)
  if (!isDark) controlSteps.reverse() // 上游：浅色模式反转控制色阶梯
  const bgSteps = oklchSteps(bg, 100)
  const bgIndex = colorIndex(bg, 100)
  const neutralSteps = oklchSteps({ r: 0, g: 0, b: 0, a: 1 }, 100)

  // accent / 语义色（builder 覆盖优先，否则用色板内置）
  const accent = (opts.accent ? hexToRgba(opts.accent) : null) ?? P(pal.accentBlue)
  const success = (opts.success ? hexToRgba(opts.success) : null) ?? P(pal.brightGreen)
  const warning = (opts.warning ? hexToRgba(opts.warning) : null) ?? P(pal.brightOrange)
  const destructive = (opts.destructive ? hexToRgba(opts.destructive) : null) ?? P(pal.brightRed)

  // 交互态 overlay（上游：control[10] 或 control[0]，取决于明暗）
  const hoverColor = bgIndex < 91 ? controlSteps[10] : controlSteps[0]
  // 按钮级 overlay（上游 button_hovered/pressed_overlay）
  const buttonHoverOv: RGBA = { ...controlSteps[5], a: 0.2 }
  const buttonPressedOv: RGBA = { ...controlSteps[2], a: 0.5 }

  const hx = (c: RGBA) => rgbaToHex(c)

  /** 上游 Component::colored_button：有色按钮（accent/destructive/success 按钮） */
  const coloredButton = (base: RGBA, neutral: RGBA, on: RGBA): ThemeComponent => ({
    base: hx(base),
    hover: hx(over(buttonHoverOv, base)),
    pressed: hx(over(buttonPressedOv, base)),
    selected: hx(over(buttonHoverOv, base)),
    selectedText: hx(neutral),
    divider: hx({ ...neutral, a: 0.2 }),
    on: hx(on),
    disabled: hx({ ...base, a: 0.5 }),
    onDisabled: hx({ ...neutral, a: 0.5 }),
    focus: hx(accent)
  })

  // background 容器
  const bgComponent = getSurfaceColor(bgIndex, 8, bgSteps, isDark, P(pal.neutral2))
  const onBgComponent = getText(colorIndex(bgComponent, 100), bgSteps, controlSteps[8])
  const background: ThemeContainer = {
    base: hx(bg),
    on: hx(getText(bgIndex, bgSteps, controlSteps[8])),
    divider: rgbaToHex(getSmallWidgetColor(bgIndex, 5, neutralSteps, controlSteps[6])),
    component: buildComponent(bgComponent, hoverColor, accent, onBgComponent, hc)
  }

  // primary 容器（窗口底）
  const primaryBg = (opts.primaryContainerBg ? hexToRgba(opts.primaryContainerBg) : null)
    ?? getSurfaceColor(bgIndex, 5, bgSteps, isDark, controlSteps[1])
  const pSteps = oklchSteps(primaryBg, 100)
  const pIndex = colorIndex(primaryBg, 100)
  const primaryComponent = getSurfaceColor(pIndex, 6, pSteps, isDark, controlSteps[3])
  const onPrimary = getText(colorIndex(primaryComponent, 100), pSteps, controlSteps[8])
  const primary: ThemeContainer = {
    base: hx(primaryBg),
    on: hx(getText(pIndex, pSteps, controlSteps[8])),
    divider: rgbaToHex(getSmallWidgetColor(pIndex, 5, neutralSteps, controlSteps[6])),
    component: buildComponent(primaryComponent, hoverColor, accent, onPrimary, hc)
  }

  // secondary 容器（卡片）
  const secondaryBg = (opts.secondaryContainerBg ? hexToRgba(opts.secondaryContainerBg) : null)
    ?? getSurfaceColor(bgIndex, 10, bgSteps, isDark, controlSteps[2])
  const sSteps = oklchSteps(secondaryBg, 100)
  const sIndex = colorIndex(secondaryBg, 100)
  const secondaryComponent = getSurfaceColor(sIndex, 3, sSteps, isDark, controlSteps[4])
  const onSecondary = getText(colorIndex(secondaryComponent, 100), sSteps, controlSteps[8])
  const secondary: ThemeContainer = {
    base: hx(secondaryBg),
    on: hx(getText(sIndex, sSteps, controlSteps[8])),
    divider: rgbaToHex(getSmallWidgetColor(sIndex, 5, neutralSteps, controlSteps[6])),
    component: buildComponent(secondaryComponent, hoverColor, accent, onSecondary, hc)
  }

  // accent 文字色：反差不足 4 时从 accent 阶梯求解（上游 accent_text 逻辑）
  const accentTextHex = (() => {
    const lumBg = relativeLuminance(bg)
    const lumPrimary = relativeLuminance(primaryBg)
    const darkest = isDark ? primaryBg : lumBg < lumPrimary ? bg : primaryBg
    if (relativeContrast(darkest, accent) >= 4) return hx(accent)
    const aSteps = oklchSteps(accent, 100)
    const aIndex = colorIndex(darkest, 100)
    const cand = getSurfaceColor(aIndex, hc ? 60 : 50, aSteps, isDark, { r: 1, g: 1, b: 1, a: 1 })
    if (relativeContrast(darkest, cand) < 4) return isDark ? '#FFFFFF' : '#000000'
    return hx(cand)
  })()

  const theme: CosmicTheme = {
    name: pal.name,
    background,
    primary,
    secondary,
    accent: coloredComponent(accent, controlSteps[0], accent),
    accentButton: coloredButton(
      accent,
      controlSteps[1],
      getText(colorIndex(accent, 100), oklchSteps(accent, 100), controlSteps[0])
    ),
    success: coloredComponent(success, controlSteps[0], accent),
    destructive: coloredComponent(destructive, controlSteps[0], accent),
    warning: coloredComponent(warning, controlSteps[0], accent),
    iconButton: buildComponent({ r: 0, g: 0, b: 0, a: 0 }, hoverColor, accent, onBgComponent, hc),
    linkButton: buildComponent({ r: 0, g: 0, b: 0, a: 0 }, hoverColor, accent, hexToRgba(accentTextHex) as RGBA, hc),
    isDark,
    isHighContrast: hc,
    cornerRadii: cornerRadiiOf(opts.roundness ?? 'round'),
    spacing: SPACING,
    gaps: [4, 4],
    activeHint: 3,
    shade: isDark ? 'rgba(0, 0, 0, 0.32)' : 'rgba(0, 0, 0, 0.08)',
    accentText: accentTextHex
  }
  return theme
}

/* ══════════════════ Theme → CSS 变量（libcosmic 的 widget 取色等价物） ══════════════════
 * libcosmic 里每个 widget 样式函数读 theme.cosmic() 自取颜色；CSS 里等价做法
 * 是把 Theme 的全部角色铺成 --c-* 变量，桌面所有组件只认变量不认具体色值。 */

const rgbaOf = (hex: string, a: number): string => {
  const c = hexToRgba(hex)
  return c ? rgbaToCss({ ...c, a }) : 'rgba(0,0,0,0)'
}
const mixOf = (hex: string, a: number): string => rgbaOf(hex, a)

export function themeToVars(t: CosmicTheme, userRadius: number): Record<string, string> {
  const r = t.cornerRadii
  // 用户圆角设置作为 COSMIC 刻度的缩放基准（COSMIC 默认 radius_m = 16）
  const k = Math.max(0.35, userRadius / 16)
  const sc = (v: number) => `${Math.round(v * k)}px`
  const on = t.primary.on
  return {
    /* 容器层（上游 Container.base/on/divider/component） */
    '--c-bg': t.background.base,
    '--c-surface': t.primary.base,
    '--c-surface-2': t.secondary.base,
    '--c-surface-3': t.background.component.base,
    '--c-header': t.primary.component.base,
    '--c-sidebar': t.background.component.base,
    '--c-text': t.primary.on,
    '--c-text-dim': mixOf(on, 0.74),
    '--c-text-mute': mixOf(on, 0.52),
    '--c-border': t.primary.divider,
    '--c-border-strong': mixOf(on, 0.3),
    /* 交互态（上游 Component.hover/pressed/selected/focus/disabled） */
    '--c-hover': mixOf(on, 0.07),
    '--c-active': mixOf(on, 0.15),
    '--c-selected': t.primary.component.selected,
    '--c-selected-text': t.primary.component.selectedText,
    '--c-focus': t.accent.focus,
    '--c-disabled': t.background.component.disabled,
    /* accent（上游 accent / accent_button 组件） */
    '--c-accent': t.accent.base,
    '--c-accent-soft': rgbaOf(t.accent.base, t.isDark ? 0.22 : 0.14),
    '--c-accent-hover': rgbaOf(t.accent.base, t.isDark ? 0.36 : 0.24),
    '--c-on-accent': t.accentButton.on,
    '--c-accent-text': t.accentText,
    /* 语义色（上游 success/destructive/warning 组件） */
    '--c-success': t.success.base,
    '--c-success-soft': rgbaOf(t.success.base, 0.14),
    '--c-warning': t.warning.base,
    '--c-warning-soft': rgbaOf(t.warning.base, 0.14),
    '--c-error': t.destructive.base,
    '--c-error-soft': rgbaOf(t.destructive.base, 0.14),
    '--c-on-error': t.destructive.on,
    /* 形状轴：CornerRadii 六级刻度（用户圆角设置整体缩放） */
    '--c-radius': `${userRadius}px`,
    '--c-radius-xs': sc(r.xs),
    '--c-radius-s': sc(r.s),
    '--c-radius-m': sc(r.m),
    '--c-radius-l': sc(r.l),
    '--c-radius-xl': sc(Math.min(r.xl, 64)),
    /* 间距刻度（上游 Spacing） */
    '--c-space-xxs': `${SPACING.xxs}px`,
    '--c-space-xs': `${SPACING.xs}px`,
    '--c-space-s': `${SPACING.s}px`,
    '--c-space-m': `${SPACING.m}px`,
    /* 光影 */
    '--c-shadow': t.isDark ? 'rgba(0, 0, 0, 0.6)' : 'rgba(0, 0, 0, 0.18)',
    '--c-shade': t.shade,
    /* 提供给 JS 的明暗标记 */
    '--c-is-dark': t.isDark ? '1' : '0'
  }
}

/* ══════════════════ ThemeProvider（theme_provider 移植） ══════════════════
 * 上游把主题以 .ron 文件存在 ~/.config/cosmic/com.system76.CosmicTheme/ 下，
 * ThemeProvider 负责按名字加载、监听 dark preference / accent 变化并通知订阅者。
 * 浏览器里「配置目录」= localStorage，「文件」= JSON 条目，「通知」= 订阅回调。 */

export type ThemeEntry = {
  name: string
  /** RON 等价物：构建参数序列化（重建主题用） */
  builder: Omit<ThemeBuilderOptions, 'palette'> & { palette: 'cosmic-dark' | 'cosmic-light' | 'custom'; customPalette?: CosmicPalette }
}

const THEME_DIR_KEY = 'cosmic.theme.dir.v1'

/** 内置主题（上游 /usr/share/cosmic/themes 的等价物） */
export const BUILTIN_THEMES = ['cosmic-dark', 'cosmic-light', 'cosmic-dark-highcontrast', 'cosmic-light-highcontrast'] as const
export type BuiltinThemeName = (typeof BUILTIN_THEMES)[number]

export function builtinBuilder(name: BuiltinThemeName): ThemeBuilderOptions {
  const hc = name.endsWith('highcontrast')
  const dark = name.includes('dark')
  return {
    palette: dark ? COSMIC_DARK : COSMIC_LIGHT,
    highContrast: hc,
    roundness: 'round'
  }
}

function readDir(): Record<string, ThemeEntry> {
  try {
    return JSON.parse(localStorage.getItem(THEME_DIR_KEY) ?? '{}') as Record<string, ThemeEntry>
  } catch {
    return {}
  }
}
function writeDir(dir: Record<string, ThemeEntry>) {
  try {
    localStorage.setItem(THEME_DIR_KEY, JSON.stringify(dir))
  } catch { /* 隐私模式忽略 */ }
}

/** 解析一个主题名为完整 Theme。'auto' 跟随深浅模式（上游 preferred_theme 语义） */
export function resolveTheme(
  name: string,
  mode: 'dark' | 'light',
  overrides: Partial<ThemeBuilderOptions> = {}
): CosmicTheme {
  if (name === 'auto' || BUILTIN_THEMES.includes(name as BuiltinThemeName)) {
    const bname: BuiltinThemeName =
      name !== 'auto' ? (name as BuiltinThemeName) : mode === 'dark' ? 'cosmic-dark' : 'cosmic-light'
    return buildTheme({ ...builtinBuilder(bname), ...overrides })
  }
  const entry = readDir()[name]
  if (!entry) return resolveTheme('auto', mode, overrides)
  const pal = entry.builder.palette === 'custom' && entry.builder.customPalette
    ? entry.builder.customPalette
    : entry.builder.palette === 'cosmic-light' ? COSMIC_LIGHT : COSMIC_DARK
  return buildTheme({ ...entry.builder, palette: pal, ...overrides })
}

/** 保存当前主题到用户主题目录（上游 Theme::save），成功后广播变更 */
export function saveTheme(entry: ThemeEntry): boolean {
  if (!entry.name.trim() || BUILTIN_THEMES.includes(entry.name as BuiltinThemeName)) return false
  const dir = readDir()
  dir[entry.name] = entry
  writeDir(dir)
  notifyTheme()
  return true
}

export function deleteTheme(name: string) {
  const dir = readDir()
  delete dir[name]
  writeDir(dir)
  notifyTheme()
}

export function listUserThemes(): ThemeEntry[] {
  return Object.values(readDir())
}

export function getThemeEntry(name: string): ThemeEntry | null {
  if (BUILTIN_THEMES.includes(name as BuiltinThemeName)) {
    const b = builtinBuilder(name as BuiltinThemeName)
    return {
      name,
      builder: {
        highContrast: b.highContrast,
        roundness: b.roundness,
        palette: name.includes('light') ? 'cosmic-light' : 'cosmic-dark'
      }
    }
  }
  return readDir()[name] ?? null
}

/** builder 选项 → 可序列化 entry（palette 用枚举名表示） */
export function builtinToEntry(opts: ThemeBuilderOptions): ThemeEntry | null {
  const { palette, ...rest } = opts
  if (palette !== COSMIC_DARK && palette !== COSMIC_LIGHT) return null
  return {
    name: palette.name,
    builder: {
      ...rest,
      palette: palette === COSMIC_LIGHT ? 'cosmic-light' : 'cosmic-dark'
    }
  }
}

/** 从当前 builder 参数反推可保存的 entry（保存「当前外观」用） */
export function themeToEntry(name: string, opts: ThemeBuilderOptions): ThemeEntry {
  const { palette, ...rest } = opts
  const isBuiltin = palette === COSMIC_DARK || palette === COSMIC_LIGHT
  return {
    name,
    builder: {
      ...rest,
      palette: palette === COSMIC_LIGHT ? 'cosmic-light' : isBuiltin ? 'cosmic-dark' : 'custom',
      customPalette: isBuiltin ? undefined : palette
    }
  }
}

/** 导出 / 导入（cosmic-settings 的主题分享机制） */
export function exportThemeJson(name: string): string | null {
  const e = getThemeEntry(name)
  return e ? JSON.stringify(e, null, 2) : null
}
export function importThemeJson(json: string): ThemeEntry | null {
  try {
    const obj = JSON.parse(json) as ThemeEntry
    if (!obj?.name || !obj?.builder?.palette) return null
    return saveTheme(obj) ? obj : null
  } catch {
    return null
  }
}

/* —— 变更订阅（上游 ThemeProvider 的 Signal 通知）—— */
type ThemeListener = () => void
const listeners = new Set<ThemeListener>()
export function subscribeTheme(fn: ThemeListener): () => void {
  listeners.add(fn)
  return () => listeners.delete(fn)
}
function notifyTheme() {
  listeners.forEach((fn) => fn())
}
