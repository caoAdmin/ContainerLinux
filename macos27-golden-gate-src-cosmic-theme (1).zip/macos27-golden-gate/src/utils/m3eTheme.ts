/**
 * M3E (Material 3 Expressive) 主题引擎 —— 移植自开源项目 m3e-canvas (MIT License)
 * https://github.com/lnkiai/m3e-canvas · 仅移植主题轴（配色 / 对比度 / 形状 / 字体 / 动效），
 * 图标体系不搬。
 *
 * 色彩算法说明（原作者注释）：一颗基准色按 Material HCT 思路生成整套色板 ——
 * 每个角色落在固定色调 (CIE L*) + 基准色色相 + 角色专属 chroma，chroma 超出
 * sRGB 色域时逐步收敛。未实现完整 CAM16，对主题用途足够。
 */

export type Lab = { L: number; a: number; b: number }
export type Lch = { L: number; C: number; h: number }

const clamp01 = (v: number) => Math.min(1, Math.max(0, v))

export function hexToRgb(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return null
  const n = parseInt(m[1], 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

export const rgbToHex = (r: number, g: number, b: number) =>
  '#' + [r, g, b].map((v) => Math.round(clamp01(v / 255) * 255).toString(16).padStart(2, '0')).join('').toUpperCase()

const lin = (c: number) => {
  const v = c / 255
  return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)
}
const gam = (v: number) => (v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055)

const WHITE = [0.95047, 1, 1.08883]
const f = (t: number) => (t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116)
const fInv = (t: number) => (t > 0.2069 ? t * t * t : (t - 16 / 116) / 7.787)

export function rgbToLab(r: number, g: number, b: number): Lab {
  const R = lin(r)
  const G = lin(g)
  const B = lin(b)
  const x = (R * 0.4124 + G * 0.3576 + B * 0.1805) / WHITE[0]
  const y = (R * 0.2126 + G * 0.7152 + B * 0.0722) / WHITE[1]
  const z = (R * 0.0193 + G * 0.1192 + B * 0.9505) / WHITE[2]
  const fx = f(x)
  const fy = f(y)
  const fz = f(z)
  return { L: 116 * fy - 16, a: 500 * (fx - fy), b: 200 * (fy - fz) }
}

/** sRGB 0..255，色域外返回 null */
function labToRgb(lab: Lab): [number, number, number] | null {
  const fy = (lab.L + 16) / 116
  const fx = lab.a / 500 + fy
  const fz = fy - lab.b / 200
  const x = fInv(fx) * WHITE[0]
  const y = fInv(fy) * WHITE[1]
  const z = fInv(fz) * WHITE[2]
  const R = x * 3.2406 + y * -1.5372 + z * -0.4986
  const G = x * -0.9689 + y * 1.8758 + z * 0.0415
  const B = x * 0.0557 + y * -0.204 + z * 1.057
  const out = [R, G, B].map(gam)
  if (out.some((v) => v < -0.002 || v > 1.002)) return null
  return out.map((v) => clamp01(v) * 255) as [number, number, number]
}

export function labToLch(lab: Lab): Lch {
  const C = Math.hypot(lab.a, lab.b)
  let h = (Math.atan2(lab.b, lab.a) * 180) / Math.PI
  if (h < 0) h += 360
  return { L: lab.L, C, h }
}

/** 指定 tone / chroma / hue 取色，chroma 收敛直到落入 sRGB */
export function tone(L: number, C: number, h: number): string {
  const rad = (h * Math.PI) / 180
  let c = C
  for (let i = 0; i < 40; i++) {
    const rgb = labToRgb({ L, a: c * Math.cos(rad), b: c * Math.sin(rad) })
    if (rgb) return rgbToHex(rgb[0], rgb[1], rgb[2])
    c *= 0.88
  }
  const rgb = labToRgb({ L, a: 0, b: 0 }) ?? [128, 128, 128]
  return rgbToHex(rgb[0], rgb[1], rgb[2])
}

export type Contrast = 'standard' | 'medium' | 'high'
export type ShapeScale = 'square' | 'rounded' | 'full'
export type FontKey = 'roboto' | 'robotoFlex' | 'robotoSerif' | 'system'
export type MotionScheme = 'standard' | 'expressive'

export type Palette = {
  key: string
  label: string
  seed?: string
  primary: string
  onPrimary: string
  primaryContainer: string
  onPrimaryContainer: string
  inversePrimary: string
  secondary: string
  secondaryContainer: string
  onSecondaryContainer: string
  tertiaryContainer: string
  onTertiaryContainer: string
  surface: string
  surfaceContainerLow: string
  surfaceContainer: string
  surfaceContainerHigh: string
  surfaceContainerHighest: string
  onSurface: string
  onSurfaceVariant: string
  outline: string
  outlineVariant: string
  inverseSurface: string
  inverseOnSurface: string
  error: string
  onError: string
  errorContainer: string
  onErrorContainer: string
}

export type SchemeOptions = { dark?: boolean; contrast?: Contrast; keepChroma?: boolean }

type RoleKey =
  | 'primary' | 'onPrimary' | 'primaryContainer' | 'onPrimaryContainer' | 'inversePrimary'
  | 'secondary' | 'secondaryContainer' | 'onSecondaryContainer' | 'tertiaryContainer' | 'onTertiaryContainer'
  | 'surface' | 'surfaceContainerLow' | 'surfaceContainer' | 'surfaceContainerHigh' | 'surfaceContainerHighest'
  | 'onSurface' | 'onSurfaceVariant' | 'outline' | 'outlineVariant' | 'inverseSurface' | 'inverseOnSurface'

type Tones = Record<RoleKey, number>

const LIGHT: Tones = {
  primary: 40, onPrimary: 100, primaryContainer: 90, onPrimaryContainer: 10, inversePrimary: 80,
  secondary: 40, secondaryContainer: 90, onSecondaryContainer: 10, tertiaryContainer: 90, onTertiaryContainer: 10,
  surface: 98, surfaceContainerLow: 96, surfaceContainer: 94, surfaceContainerHigh: 92, surfaceContainerHighest: 90,
  onSurface: 10, onSurfaceVariant: 30, outline: 50, outlineVariant: 80, inverseSurface: 20, inverseOnSurface: 95,
}
const DARK: Tones = {
  primary: 80, onPrimary: 20, primaryContainer: 30, onPrimaryContainer: 90, inversePrimary: 40,
  secondary: 80, secondaryContainer: 30, onSecondaryContainer: 90, tertiaryContainer: 30, onTertiaryContainer: 90,
  surface: 6, surfaceContainerLow: 10, surfaceContainer: 12, surfaceContainerHigh: 17, surfaceContainerHighest: 22,
  onSurface: 90, onSurfaceVariant: 80, outline: 60, outlineVariant: 30, inverseSurface: 90, inverseOnSurface: 20,
}

function tonesFor(dark: boolean, contrast: Contrast): Tones {
  const t = { ...(dark ? DARK : LIGHT) }
  if (contrast === 'medium') {
    t.secondary = dark ? 85 : 30
    if (dark) Object.assign(t, { primary: 85, onPrimaryContainer: 95, onSecondaryContainer: 95, onTertiaryContainer: 95, onSurfaceVariant: 85, outline: 70, outlineVariant: 50 })
    else Object.assign(t, { primary: 30, onPrimaryContainer: 20, onSecondaryContainer: 20, onTertiaryContainer: 20, onSurfaceVariant: 25, outline: 40, outlineVariant: 65 })
  } else if (contrast === 'high') {
    t.secondary = dark ? 95 : 20
    if (dark) Object.assign(t, { primary: 95, onPrimary: 0, primaryContainer: 80, onPrimaryContainer: 0, secondaryContainer: 80, onSecondaryContainer: 0, tertiaryContainer: 80, onTertiaryContainer: 0, onSurface: 100, onSurfaceVariant: 95, outline: 90, outlineVariant: 90 })
    else Object.assign(t, { primary: 20, primaryContainer: 30, onPrimaryContainer: 100, secondaryContainer: 30, onSecondaryContainer: 100, tertiaryContainer: 30, onTertiaryContainer: 100, onSurface: 0, onSurfaceVariant: 10, outline: 20, outlineVariant: 20 })
  }
  return t
}

const ERROR_LIGHT = { error: '#B3261E', onError: '#FFFFFF', errorContainer: '#F9DEDC', onErrorContainer: '#410E0B' }
const ERROR_DARK = { error: '#F2B8B5', onError: '#601410', errorContainer: '#8C1D18', onErrorContainer: '#F9DEDC' }

/** 一颗基准色 → 整套 M3 色板（浅色默认，深色与高对比度按需生成） */
export function schemeFromSeed(seedHex: string, label = 'Custom', opts: SchemeOptions = {}): Palette {
  const parsed = hexToRgb(seedHex)
  const rgb = parsed ?? [103, 80, 164]
  const lch = labToLch(rgbToLab(rgb[0], rgb[1], rgb[2]))
  const h = lch.h
  const primaryC = opts.keepChroma ? Math.min(lch.C, 60) : Math.max(36, Math.min(lch.C, 60))
  const secondaryC = primaryC / 3
  const tertiaryH = (h + 60) % 360
  const tertiaryC = primaryC / 2
  const neutralC = 3
  const neutralVarC = 7
  const P = (L: number) => tone(L, primaryC, h)
  const S = (L: number) => tone(L, secondaryC, h)
  const T = (L: number) => tone(L, tertiaryC, tertiaryH)
  const N = (L: number) => tone(L, neutralC, h)
  const NV = (L: number) => tone(L, neutralVarC, h)
  const dark = !!opts.dark
  const k = tonesFor(dark, opts.contrast ?? 'standard')
  return {
    key: 'custom',
    label,
    seed: parsed ? rgbToHex(rgb[0], rgb[1], rgb[2]) : seedHex.toUpperCase(),
    primary: P(k.primary),
    onPrimary: P(k.onPrimary),
    primaryContainer: P(k.primaryContainer),
    onPrimaryContainer: P(k.onPrimaryContainer),
    inversePrimary: P(k.inversePrimary),
    secondary: S(k.secondary),
    secondaryContainer: S(k.secondaryContainer),
    onSecondaryContainer: S(k.onSecondaryContainer),
    tertiaryContainer: T(k.tertiaryContainer),
    onTertiaryContainer: T(k.onTertiaryContainer),
    surface: N(k.surface),
    surfaceContainerLow: N(k.surfaceContainerLow),
    surfaceContainer: N(k.surfaceContainer),
    surfaceContainerHigh: N(k.surfaceContainerHigh),
    surfaceContainerHighest: N(k.surfaceContainerHighest),
    onSurface: N(k.onSurface),
    onSurfaceVariant: NV(k.onSurfaceVariant),
    outline: NV(k.outline),
    outlineVariant: NV(k.outlineVariant),
    inverseSurface: N(k.inverseSurface),
    inverseOnSurface: N(k.inverseOnSurface),
    ...(dark ? ERROR_DARK : ERROR_LIGHT),
  }
}

export const luminance = (hex: string): number => {
  const rgb = hexToRgb(hex) ?? [0, 0, 0]
  return 0.2126 * lin(rgb[0]) + 0.7152 * lin(rgb[1]) + 0.0722 * lin(rgb[2])
}

/* ───────────────── 七套手写预设（浅色 · 标准对比度） ─────────────────
   深色与其它对比度从同一 seed 用 schemeFromSeed 重新生成。 */
type Preset = Omit<Palette, 'secondary' | 'seed'>

const ERROR = {
  error: '#B3261E',
  onError: '#FFFFFF',
  errorContainer: '#F9DEDC',
  onErrorContainer: '#410E0B',
}

const PRESETS: Preset[] = [
  {
    key: 'purple', label: 'Purple',
    primary: '#6750A4', onPrimary: '#FFFFFF', primaryContainer: '#EADDFF', onPrimaryContainer: '#21005D',
    inversePrimary: '#D0BCFF', secondaryContainer: '#E8DEF8', onSecondaryContainer: '#1D192B',
    tertiaryContainer: '#FFD8E4', onTertiaryContainer: '#31111D',
    surface: '#FEF7FF', surfaceContainerLow: '#F7F2FA', surfaceContainer: '#F3EDF7', surfaceContainerHigh: '#ECE6F0', surfaceContainerHighest: '#E6E0E9',
    onSurface: '#1D1B20', onSurfaceVariant: '#49454F', outline: '#79747E', outlineVariant: '#CAC4D0',
    inverseSurface: '#322F35', inverseOnSurface: '#F5EFF7', ...ERROR,
  },
  {
    key: 'blue', label: 'Blue',
    primary: '#0B57D0', onPrimary: '#FFFFFF', primaryContainer: '#D3E3FD', onPrimaryContainer: '#041E49',
    inversePrimary: '#A8C7FA', secondaryContainer: '#DCE2F9', onSecondaryContainer: '#131C2B',
    tertiaryContainer: '#FFD8EE', onTertiaryContainer: '#2E1125',
    surface: '#FAF9FD', surfaceContainerLow: '#F3F3FA', surfaceContainer: '#EEEDF3', surfaceContainerHigh: '#E9E8EF', surfaceContainerHighest: '#E3E2E6',
    onSurface: '#1B1B1F', onSurfaceVariant: '#44474E', outline: '#74777F', outlineVariant: '#C4C6D0',
    inverseSurface: '#303034', inverseOnSurface: '#F2F0F4', ...ERROR,
  },
  {
    key: 'green', label: 'Green',
    primary: '#2E6A45', onPrimary: '#FFFFFF', primaryContainer: '#B0F1C2', onPrimaryContainer: '#00210F',
    inversePrimary: '#95D5A7', secondaryContainer: '#D3E8D8', onSecondaryContainer: '#102016',
    tertiaryContainer: '#C2E8FF', onTertiaryContainer: '#001E2C',
    surface: '#F6FBF4', surfaceContainerLow: '#F0F5EE', surfaceContainer: '#EAF0E8', surfaceContainerHigh: '#E4EAE2', surfaceContainerHighest: '#DEE4DC',
    onSurface: '#181D18', onSurfaceVariant: '#414941', outline: '#707972', outlineVariant: '#BFC9C0',
    inverseSurface: '#2D322D', inverseOnSurface: '#EEF2EB', ...ERROR,
  },
  {
    key: 'coral', label: 'Coral',
    primary: '#984061', onPrimary: '#FFFFFF', primaryContainer: '#FFD9E2', onPrimaryContainer: '#3E001D',
    inversePrimary: '#FFB0C8', secondaryContainer: '#F6DDE4', onSecondaryContainer: '#31101D',
    tertiaryContainer: '#FFDBCA', onTertiaryContainer: '#2C1600',
    surface: '#FFF8F8', surfaceContainerLow: '#FCF0F2', surfaceContainer: '#F6EBED', surfaceContainerHigh: '#F3E5E9', surfaceContainerHighest: '#EEE0E3',
    onSurface: '#201A1B', onSurfaceVariant: '#524346', outline: '#847377', outlineVariant: '#D5C2C6',
    inverseSurface: '#352F30', inverseOnSurface: '#FAEEEF', ...ERROR,
  },
  {
    key: 'amber', label: 'Amber',
    primary: '#8B5000', onPrimary: '#FFFFFF', primaryContainer: '#FFDCC2', onPrimaryContainer: '#2C1600',
    inversePrimary: '#FFB77C', secondaryContainer: '#F6DFC8', onSecondaryContainer: '#271905',
    tertiaryContainer: '#D5EDC0', onTertiaryContainer: '#0E2004',
    surface: '#FFF8F5', surfaceContainerLow: '#FCF1EA', surfaceContainer: '#F7ECE4', surfaceContainerHigh: '#F3E6DE', surfaceContainerHighest: '#EDE0D8',
    onSurface: '#211A14', onSurfaceVariant: '#51443B', outline: '#83746A', outlineVariant: '#D6C3B6',
    inverseSurface: '#362F28', inverseOnSurface: '#FBEEE5', ...ERROR,
  },
  {
    key: 'teal', label: 'Teal',
    primary: '#00696E', onPrimary: '#FFFFFF', primaryContainer: '#9CF1F6', onPrimaryContainer: '#002022',
    inversePrimary: '#80D5DA', secondaryContainer: '#CCE8E9', onSecondaryContainer: '#051F20',
    tertiaryContainer: '#D2E4FF', onTertiaryContainer: '#001C3B',
    surface: '#F4FBFB', surfaceContainerLow: '#EEF5F5', surfaceContainer: '#E8EFEF', surfaceContainerHigh: '#E2EAEA', surfaceContainerHighest: '#DDE4E4',
    onSurface: '#161D1D', onSurfaceVariant: '#3F4948', outline: '#6F7979', outlineVariant: '#BEC8C8',
    inverseSurface: '#2B3232', inverseOnSurface: '#ECF2F2', ...ERROR,
  },
  {
    key: 'mono', label: 'Mono',
    primary: '#4A4459', onPrimary: '#FFFFFF', primaryContainer: '#E6E0F0', onPrimaryContainer: '#1A1626',
    inversePrimary: '#CFC3E0', secondaryContainer: '#E6E1E6', onSecondaryContainer: '#1B1B1F',
    tertiaryContainer: '#E9E0EA', onTertiaryContainer: '#1E1A22',
    surface: '#FCF8FD', surfaceContainerLow: '#F5F1F6', surfaceContainer: '#EFEBF0', surfaceContainerHigh: '#E9E5EA', surfaceContainerHighest: '#E4E0E5',
    onSurface: '#1C1B1F', onSurfaceVariant: '#48454E', outline: '#79747E', outlineVariant: '#CAC4D0',
    inverseSurface: '#313033', inverseOnSurface: '#F4EFF4', ...ERROR,
  },
]

export const PALETTES: Palette[] = PRESETS.map((p) => ({
  ...p,
  seed: p.primary,
  secondary: schemeFromSeed(p.primary, p.label, { keepChroma: true }).secondary,
}))

export const SHAPES: { key: ShapeScale; label: string }[] = [
  { key: 'square', label: 'Square' },
  { key: 'rounded', label: 'Rounded' },
  { key: 'full', label: 'Full' },
]

export const CONTRASTS: { key: Contrast; label: string }[] = [
  { key: 'standard', label: 'Standard' },
  { key: 'medium', label: 'Medium' },
  { key: 'high', label: 'High' },
]

export const FONTS: { key: FontKey; label: string; family: string; google?: string }[] = [
  { key: 'roboto', label: 'Roboto', family: 'Roboto, system-ui, sans-serif' },
  { key: 'robotoFlex', label: 'Roboto Flex', family: "'Roboto Flex', Roboto, system-ui, sans-serif", google: 'Roboto+Flex:opsz,wght@8..144,400..700' },
  { key: 'robotoSerif', label: 'Roboto Serif', family: "'Roboto Serif', Georgia, serif", google: 'Roboto+Serif:wght@400..700' },
  { key: 'system', label: 'System', family: "system-ui, -apple-system, 'Segoe UI', sans-serif" },
]

/* CJK 兜底：中文字形始终走 Noto Sans SC，避免各 OS 默认中文字体不一致 */
const CJK_FACE = "'Noto Sans SC'"
const withCJK = (family: string) => {
  if (family.includes('Noto Sans SC')) return family
  const parts = family.split(',').map((s) => s.trim())
  const at = parts.findIndex((s) => /^(system-ui|-apple-system|Georgia|serif|sans-serif)$/.test(s))
  parts.splice(at < 0 ? parts.length : at, 0, CJK_FACE)
  return parts.join(', ')
}

export const fontFamilyOf = (f: FontKey): string => {
  const hit = FONTS.find((x) => x.key === f)
  if (!hit || f === 'system') return hit?.family ?? FONTS[0].family
  return withCJK(hit.family)
}

/** Google Fonts 按需加载（字体轴），返回 null 表示无需加载 */
export function googleFontHref(f: FontKey): string | null {
  const hit = FONTS.find((x) => x.key === f)
  if (!hit?.google) return null
  const href = `https://fonts.googleapis.com/css2?family=${hit.google}&display=swap`
  // Noto Sans SC 一并拉起，保证 CJK 兜底可用
  return f === 'robotoSerif' ? `${href}&family=Noto+Sans+SC:wght@400..700` : href
}

/* ───────────────── M3E 主题状态（五条轴） ───────────────── */

export type M3ETheme = {
  /** 基准配色 key；custom = 自定义 seed */
  palette: string
  /** 自定义基准色（palette = 'custom' 时生效） */
  seed: string
  contrast: Contrast
  shape: ShapeScale
  font: FontKey
  motion: MotionScheme
}

export const DEFAULT_M3E: M3ETheme = {
  palette: 'purple',
  seed: '#6750A4',
  contrast: 'standard',
  shape: 'rounded',
  font: 'system',
  motion: 'standard',
}

/** 存档里缺失/非法字段回落默认 */
export function normalizeM3E(t: Partial<M3ETheme> | undefined): M3ETheme {
  const d = DEFAULT_M3E
  if (!t) return { ...d }
  return {
    palette: typeof t.palette === 'string' && (t.palette === 'custom' || PALETTES.some((p) => p.key === t.palette)) ? t.palette : d.palette,
    seed: hexToRgb(t.seed ?? '') ? (t.seed as string) : d.seed,
    contrast: CONTRASTS.some((c) => c.key === t.contrast) ? (t.contrast as Contrast) : d.contrast,
    shape: SHAPES.some((c) => c.key === t.shape) ? (t.shape as ShapeScale) : d.shape,
    font: FONTS.some((c) => c.key === t.font) ? (t.font as FontKey) : d.font,
    motion: t.motion === 'expressive' ? 'expressive' : d.motion,
  }
}

/** 当前主题下的整套色板：预设手写浅色 / 深色与高对比度从 seed 重算 */
export function paletteOf(m: M3ETheme, dark: boolean): Palette {
  const base = PALETTES.find((p) => p.key === m.palette)
  const seed = base?.seed ?? m.seed
  const label = base?.label ?? 'Custom'
  // 预设色相/彩度是精心调过的（Mono 近灰），保持原样不提饱和
  return schemeFromSeed(seed, label, { dark, contrast: m.contrast, keepChroma: m.palette !== 'custom' })
}

/** 形状轴缩放系数（scaleR 同款） */
export function shapeFactor(s: ShapeScale): number {
  if (s === 'square') return 0.35
  if (s === 'full') return 1.6
  return 1
}

/** 动效轴 token：expressive = 富表现力弹簧近似曲线 + 稍长的落定时长 */
export function motionTokens(m: MotionScheme): { ease: string; dur: string; durLong: string } {
  if (m === 'expressive')
    return { ease: 'cubic-bezier(0.2, 0, 0, 1)', dur: '320ms', durLong: '520ms' }
  return { ease: 'cubic-bezier(0.25, 0.1, 0.25, 1)', dur: '180ms', durLong: '280ms' }
}

/** 任意底色上的可读文字色（同色相 tone 10 / 100） */
export function onColorFor(hex: string): string {
  const rgb = hexToRgb(hex)
  if (!rgb) return '#000000'
  const lch = labToLch(rgbToLab(rgb[0], rgb[1], rgb[2]))
  return lch.L > 60 ? tone(10, Math.min(lch.C, 30), lch.h) : tone(100, 0, lch.h)
}
