/**
 * COSMIC 应用注册表
 * 仅用于 COSMIC 窗口层（与 macOS 的 appRegistry 相互独立）。
 */

export interface CosmicAppDef {
  id: string
  name: string
  /** Remix 图标名（图标主题里缺这个应用时的兜底） */
  icon: string
  /** 图标底色渐变（同上，兜底用） */
  from: string
  to: string
  component: string
  category: string
  description: string
  width: number
  height: number
  minWidth: number
  minHeight: number
  singleton: boolean
  /** 是否在 Dock 显示（ContainerLinux 系统应用只在启动台出现） */
  dock?: boolean
}

export const cosmicApps: CosmicAppDef[] = [
  {
    id: 'island',
    name: '信息岛',
    icon: 'ri-anchor-line',
    from: '#2a7de0',
    to: '#27c28a',
    component: 'CosmicIsland',
    category: '核心',
    description: '胶囊堆叠 · 待办日程 · 剪贴板 · 消息验证码 · 翻译 · AI 额度',
    width: 900,
    height: 600,
    minWidth: 680,
    minHeight: 440,
    singleton: true
  },
  {
    id: 'files',
    name: 'COSMIC Files',
    icon: 'ri-folders-fill',
    from: '#4a7ddb',
    to: '#6da8f0',
    component: 'CosmicFiles',
    category: '核心',
    description: '轻松管理本地与网络文件',
    width: 940,
    height: 600,
    minWidth: 620,
    minHeight: 400,
    singleton: true
  },
  {
    id: 'terminal',
    name: 'COSMIC Terminal',
    icon: 'ri-terminal-box-fill',
    from: '#2f3440',
    to: '#4a5262',
    component: 'CosmicTerminal',
    category: '核心',
    description: '基于 alacritty_terminal 的终端模拟器',
    width: 860,
    height: 540,
    minWidth: 560,
    minHeight: 360,
    singleton: false
  },
  {
    id: 'edit',
    name: 'COSMIC Edit',
    icon: 'ri-file-edit-fill',
    from: '#2f8f7a',
    to: '#54bfa2',
    component: 'CosmicEdit',
    category: '核心',
    description: '标签页、项目文件夹、Git 管理的文本编辑器',
    width: 900,
    height: 600,
    minWidth: 560,
    minHeight: 380,
    singleton: false
  },
  {
    id: 'store',
    name: 'COSMIC Store',
    icon: 'ri-store-3-fill',
    from: '#d1762f',
    to: '#f0a95e',
    component: 'CosmicStore',
    category: '核心',
    description: '浏览、安装和更新你的全部应用',
    width: 980,
    height: 640,
    minWidth: 640,
    minHeight: 420,
    singleton: true
  },
  {
    id: 'settings',
    name: 'COSMIC Settings',
    icon: 'ri-settings-3-fill',
    from: '#5b6472',
    to: '#8b94a5',
    component: 'CosmicSettings',
    category: '核心',
    description: '配置与自定义桌面的每个角落',
    width: 960,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true
  },
  {
    id: 'player',
    name: 'COSMIC Player',
    icon: 'ri-play-circle-fill',
    from: '#7d4fd1',
    to: '#a97ef0',
    component: 'CosmicPlayer',
    category: '媒体',
    description: '基于 Vulkan 渲染的媒体播放器',
    width: 960,
    height: 620,
    minWidth: 660,
    minHeight: 440,
    singleton: true
  },
  {
    id: 'viewer',
    name: 'COSMIC Viewer',
    icon: 'ri-image-2-fill',
    from: '#b5813a',
    to: '#dcae63',
    component: 'CosmicViewer',
    category: '媒体',
    description: '官方图片与文档查看器',
    width: 860,
    height: 620,
    minWidth: 620,
    minHeight: 440,
    singleton: false
  },
  {
    id: 'monitor',
    name: 'COSMIC Monitor',
    icon: 'ri-dashboard-3-fill',
    from: '#3f6fd0',
    to: '#6f9de8',
    component: 'CosmicMonitor',
    category: '核心',
    description: '系统监视器：进程与资源占用',
    width: 1000,
    height: 660,
    minWidth: 680,
    minHeight: 440,
    singleton: true
  },
  {
    id: 'screenshot',
    name: 'COSMIC Screenshot',
    icon: 'ri-screenshot-2-fill',
    from: '#25c2a0',
    to: '#5fd9be',
    component: 'CosmicScreenshot',
    category: '工具',
    description: '全屏、区域与窗口截图',
    width: 900,
    height: 640,
    minWidth: 640,
    minHeight: 460,
    singleton: true
  },
  {
    id: 'calculator',
    name: 'COSMIC Calculator',
    icon: 'ri-calculator-fill',
    from: '#5a6b8c',
    to: '#8496b8',
    component: 'CosmicCalculator',
    category: '工具',
    description: '支持键盘输入与历史记录的计算器',
    width: 840,
    height: 600,
    minWidth: 640,
    minHeight: 460,
    singleton: true
  },
  {
    id: 'camera',
    name: 'COSMIC Camera',
    icon: 'ri-camera-fill',
    from: '#3b4a5e',
    to: '#6a7d94',
    component: 'CosmicCamera',
    category: '媒体',
    description: '拍照与录制，支持真实摄像头',
    width: 820,
    height: 580,
    minWidth: 620,
    minHeight: 440,
    singleton: true
  },
  {
    id: 'logs',
    name: 'COSMIC Logs',
    icon: 'ri-file-list-3-fill',
    from: '#4a5568',
    to: '#7a889e',
    component: 'CosmicLogs',
    category: '系统',
    description: '按级别过滤的实时系统日志',
    width: 1000,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true
  },
  {
    id: 'disks',
    name: 'COSMIC Disks',
    icon: 'ri-hard-drive-3-fill',
    from: '#4d6b5a',
    to: '#79a68c',
    component: 'CosmicDisks',
    category: '系统',
    description: '卷、容量与挂载管理',
    width: 900,
    height: 620,
    minWidth: 620,
    minHeight: 420,
    singleton: true
  },
  {
    id: 'fonts',
    name: 'COSMIC Fonts',
    icon: 'ri-font-size-2',
    from: '#6b5a8c',
    to: '#9a86bd',
    component: 'CosmicFonts',
    category: '工具',
    description: '字体预览与字符集浏览',
    width: 920,
    height: 640,
    minWidth: 620,
    minHeight: 440,
    singleton: true
  },


  {
    id: 'ct-overview',
    name: '系统总览',
    icon: 'ri-planet-line',
    from: '#3b6fd4',
    to: '#6f9de8',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: '九层模型 · 三平面 · 双运行模式 · CT Runtime 分层',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  },
  {
    id: 'ct-kernel',
    name: '内核管理',
    icon: 'ri-cpu-line',
    from: '#4a5bc4',
    to: '#7d8ce8',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: '双档内核 · governor · EPP · 更新通道 · 四格式分发',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  },
  {
    id: 'ct-distro',
    name: '发行版管理器',
    icon: 'ri-exchange-line',
    from: '#2b7fb8',
    to: '#5fb6e0',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: '双运行模式 · 换装目录 · 状态转换 · 能力边界',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  },
  {
    id: 'ct-plugins',
    name: '组件管理器',
    icon: 'ri-stack-line',
    from: '#c05a3a',
    to: '#e8916b',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: '内核 · 插件 · 原子 · 发行版 · 镜像包 五合一管理',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  },
  {
    id: 'ct-appstore',
    name: 'CT 应用商店',
    icon: 'ri-store-2-line',
    from: '#b5813a',
    to: '#dcae63',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: '策展式分发 · 双模式版本 · 源码优先安装流',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  },
  {
    id: 'ct-swarm',
    name: '蜂群管理',
    icon: 'ri-share-line',
    from: '#2b7fb8',
    to: '#5fb6e0',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: '剪贴板同步 · 键鼠共享 · 应用接续 · P2P 计算池',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  },
  {
    id: 'ct-timetravel',
    name: '时间回溯',
    icon: 'ri-history-line',
    from: '#7d4fd1',
    to: '#a97ef0',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: '时间线回溯 · LogSpace 文件中转 · 操作类型区分',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  },
  {
    id: 'ct-claw',
    name: '小C',
    icon: 'ri-brain-line',
    from: '#7d4fd1',
    to: '#a97ef0',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: '零常驻 · 分层模型路由 · 技能系统 · Agent 底座',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  },
  {
    id: 'ct-installer',
    name: '安装器与工程',
    icon: 'ri-install-line',
    from: '#4a5568',
    to: '#7a889e',
    component: 'CtApp',
    category: 'ContainerLinux',
    description: 'Ubiquity 改造 · 分区实操 · 四轨道里程碑',
    width: 940,
    height: 640,
    minWidth: 700,
    minHeight: 460,
    singleton: true,
    dock: false
  }
]

export function getCosmicApp(id: string): CosmicAppDef | undefined {
  return cosmicApps.find((a) => a.id === id)
}

export function searchCosmicApps(kw: string): CosmicAppDef[] {
  const k = kw.trim().toLowerCase()
  if (!k) return cosmicApps
  return cosmicApps.filter(
    (a) => a.name.toLowerCase().includes(k) || a.description.toLowerCase().includes(k)
  )
}
