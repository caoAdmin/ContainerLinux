/**
 * genie.ts —— macOS「精灵最小化」的网格变形数学（DOM 近似版）
 *
 * 算法来源（逐个核对过源码，不是自己拍脑袋的形状）：
 *   · Chad Etzel / jazzychad《Reverse Engineering the macOS Genie Animation》
 *     —— 用录屏逐帧回放，把 macOS 的神奇效果逆向成「两条巨大的边界轨迹 + 网格形变」，
 *        原版用 Metal distortionShader 实现（MeshWarpEffect）
 *   · fenxer/genie-web 的 src/math.ts（fillGenie / fillVertical）
 *     —— 上面那套网格变形在 Web 端的实现；本文档的公式与默认参数直接抄自这里
 *
 * 原版把窗口切成 cols × rows 的网格、逐顶点位移，因此必须先把窗口截成位图喂给 WebGL。
 * 本项目窗口里是活的 Vue 组件（设置页 22 个子页 + 图标字体 + CSS 变量主题），截图会丢样式，
 * 所以这里改用 DOM 能做的两件事去逼近同一套数学：
 *
 *   1. clip-path 多边形 —— 直接采样网格两条边界轨迹 edge()，
 *      得到真正的「靠 Dock 那端收得最狠、远端几乎不动的内凹曲线漏斗」，
 *      而不是几条直线拼的等腰梯形；
 *   2. transform —— 复刻网格整体的下坠（translate）与朝 Dock 方向的压缩（scale）。
 *
 * 这两点正是之前那版（整体等比缩小 + 直线梯形 + 手动搓的位移曲线）最不像的地方：
 * 旧版不管窗口离 Dock 多远都用同一条曲线，且漏斗的出口永远在窗口正中。
 */

export interface Rect {
  left: number
  top: number
  right: number
  bottom: number
}

/** 主轴：窗口朝 Dock 收敛的那个方向。y = 上下收，x = 左右收 */
export type GenieAxis = 'y' | 'x'

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v))
const lerp = (a: number, b: number, t: number) => a + (b - a) * t

/* ────────────────────────── 缓动 ────────────────────────── */

/** 侧壁缓动（genie-web 的 `curve` 轴）：决定漏斗两条边是直的还是弯的 */
export type CurveEase = 'inOut' | 'in' | 'out' | 'linear' | 'cosine'

function curveEase(t: number, name: CurveEase) {
  if (name === 'in') return t * t
  if (name === 'out') return 1 - (1 - t) * (1 - t)
  if (name === 'linear') return t
  // 余弦缓动：hbi99/genie.js 用的驱动曲线（sin 扫过半个周期 → (1-cos(πu))/2）。
  // 与 quadInOut 同为 S 形、两端一阶导为 0，但曲率分布更圆，侧壁更接近原生。
  if (name === 'cosine') return (1 - Math.cos(Math.PI * t)) / 2
  return t < 0.5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2 // genie-web 默认 inOut
}

/** 时间线缓动（genie-web 的 `easing` 轴）：只影响快慢，不影响漏斗形状 */
export type TimelineEase = 'linear' | 'easeOut' | 'easeInOut'

export function timelineEase(t: number, name: TimelineEase = 'linear') {
  if (name === 'easeOut') return 1 - (1 - t) ** 3
  if (name === 'easeInOut') return t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2
  return t
}

/** 判断该往哪个轴收：取「窗口中心 → Dock 中心」的主分量 */
export function inferAxis(win: Rect, dock: Rect): GenieAxis {
  const dx = (dock.left + dock.right) / 2 - (win.left + win.right) / 2
  const dy = (dock.top + dock.bottom) / 2 - (win.top + win.bottom) / 2
  return Math.abs(dy) >= Math.abs(dx) ? 'y' : 'x'
}

/* ────────────────── 默认参数（同 genie-web/src/config.ts） ────────────────── */

export interface GenieOptions {
  /** 嘴角闭合在时间线的第几成完成（默认 0.5 —— 前一半时间就把嘴收完） */
  slideEnd?: number
  /** 整体开始下坠的进度（默认 0.38，与闭嘴重叠） */
  translateStart?: number
  /** 侧壁曲线缓动（默认 inOut） */
  curve?: CurveEase
  /** 轮廓采样行数：越大越平滑（默认 16 → 34 个点） */
  rows?: number
  /** 开始淡出的进度（默认 0.88 —— 基本只在最后一刻淡出） */
  fadeStart?: number
  /** 应用栏（AppBar）的悬挂几何，与 CosmicAppBar 的 CSS 保持一致：
   *  栏高、栏顶相对窗口顶边的偏移、栏底与顶边的间距 */
  barHeight?: number
  barTop?: number
  barGap?: number
  /** 栏轮廓向下多留的裙边（px）—— 保住胶囊的投影不被 clip-path 裁掉 */
  barSkirt?: number
}

export interface GenieFrame {
  /** 可直接赋给 clip-path 的值 */
  clip: string
  /** 相对原始位置的 transform（要求元素 transform-origin: 0 0） */
  transform: string
  opacity: number
  /** feDisplacementMap 的 scale（px，主轴方向）：驱动「内容跟着横向压缩」，0 = 不压缩 */
  warp: number
  /** 应用栏的 clip-path（坐标系 = 栏自身盒子：x% 相对窗口宽、y% 相对栏高）。
   *  竖向收敛时栏骑着漏斗「远点行」（= 窗口顶边），与窗口一起收窄；
   *  横向收敛时远点是竖边、栏贴不上去 → 空串（栏改用 barY 平移跟进）。 */
  bar: string
  /** 应用栏额外需要的 translateY（px）。仅横向收敛时非零：
   *  让栏顶骑在顶边曲线的中点上，随窗口一起下潜进 Dock。 */
  barY: number
}

/** 位移贴图的 URL。
 *  贴图内容：R = `0.5 − v·(u−0.5)`（u、v 为归一化坐标）。
 *  feDisplacementMap 的语义是「输出点去采样源」—— P'(x,y) = P(x + scale·(R−0.5), y)，
 *  所以右半边必须给**负**位移（去采样左边的像素）才会把内容往中间挤。
 *  代入后 dx = −scale·v·(u−0.5)，等价于每一行朝中心做线性压缩，
 *  压缩率 s(v) = 1/(1 + scale·v/W)：v=0（远离 Dock 那端）不压缩，v=1（靠 Dock）压得最狠。
 *  这正是 hbi99/genie.js 靠 200+ 切片才能做到的事，这里一张贴图就够了。
 *
 *  注意：贴图必须放成静态资源（public/genie-map.png）而不是 data URI ——
 *  并且 feImage 的 width/height 必须给**显式像素值**，写 `100%` 在 Chrome 里不会渲染，
 *  导致 in2 全零、位移恒为 −scale/2，整个窗口会被推出画面（实测踩过这个坑）。 */
export function warpMapUrl(): string {
  return import.meta.env.BASE_URL + 'genie-map.png'
}

/**
 * 采样某一帧的漏斗形状。
 *
 * @param progress 0 = 完整原窗口，1 = 完全收进 Dock 图标
 * @param win      窗口矩形（与元素自身 left/top/width/height 同一坐标系）
 * @param dock     目标 Dock 图标矩形（同一坐标系）
 * @param axis     收敛轴；要求 dock 位于窗口的正方向（右侧 / 下方）
 *
 * 返回的 clip 与 transform 作用于**同一个元素**，且该元素需要
 * `transform-origin: 0 0` + `transition: none`（动画由 rAF 逐帧写）。
 */
export function genieFrame(
  progress: number,
  win: Rect,
  dock: Rect,
  opt: GenieOptions = {},
  axis: GenieAxis = 'y'
): GenieFrame {
  const slideEnd = Math.max(0.05, opt.slideEnd ?? 0.5)
  const translateStart = clamp(opt.translateStart ?? 0.38, 0, 0.95)
  const rows = Math.max(4, Math.round(opt.rows ?? 16))
  const fadeStart = clamp(opt.fadeStart ?? 0.88, 0.5, 0.99)
  const ease = (t: number) => curveEase(t, opt.curve ?? 'inOut')

  const p = clamp(progress, 0, 1)
  // 两条彼此重叠的时间线：先「闭嘴」（slide），稍后整体「平移」（translate）
  const slide = clamp(p / slideEnd, 0, 1)
  const translate = clamp((p - translateStart) / (1 - translateStart), 0, 1)

  const vertical = axis === 'y'
  // 主轴 / 副轴上的「头尾」访问器
  const mainLo = (r: Rect) => (vertical ? r.top : r.left)
  const mainHi = (r: Rect) => (vertical ? r.bottom : r.right)
  const crossLo = (r: Rect) => (vertical ? r.left : r.top)
  const crossHi = (r: Rect) => (vertical ? r.right : r.bottom)

  const mainSize = Math.max(mainHi(win) - mainLo(win), 1)

  // ① 整体平移：窗口朝 Dock 滑过去，靠 Dock 那一端被 Dock 的边界截住 —— 于是被压扁。
  //    「被吸进去」的物理感主要来自这一步。
  const dMain = mainLo(dock) - mainLo(win)
  const start = mainLo(win) + translate * dMain
  const end = Math.min(mainHi(win) + translate * dMain, mainHi(dock))
  const span = Math.max(end - start, 1)

  // ② 漏斗的「嘴」：副轴上的两条边从窗口边插值到 Dock 图标的两条边
  const mouthLo = lerp(crossLo(win), crossLo(dock), slide)
  const mouthHi = lerp(crossHi(win), crossHi(dock), slide)

  // 嘴中心相对窗口副轴中心的偏移。位移贴图总是把内容压向「元素自身的副轴中心」，
  // 所以要靠这个平移把压好的内容对准漏斗（Dock 图标不在窗口正下方时尤其关键）。
  const crossSize = Math.max(crossHi(win) - crossLo(win), 1)
  const shiftCross = (mouthLo + mouthHi) / 2 - (crossLo(win) + crossSize / 2)

  // ③ 侧壁曲线的跨度：窗口起点边 → Dock 起点边
  const curveLen = Math.max(mainLo(dock) - mainLo(win), 1)
  const edge = (m: number, far: number, mouth: number) => {
    if (m <= mainLo(win)) return far // 远端保持原宽
    if (m >= mainLo(dock)) return mouth // 到达 Dock 就只剩嘴宽
    return lerp(far, mouth, ease((m - mainLo(win)) / curveLen)) // 中间按曲线渐变
  }

  // ④ 逐行采样两条侧壁，拼成多边形（一壁顺序、一壁逆序）。
  //    副轴坐标要减掉 shiftCross：clip-path 在元素局部坐标系，而元素带着 translate 一起动，
  //    不减的话漏斗轮廓会和位移后的内容错位。
  const crossBase = vertical ? win.left : win.top
  const wallLo: string[] = []
  const wallHi: string[] = []
  // 远点行（r=0）的副轴范围 —— 应用栏轮廓用它收窄
  let farLo = 0
  let farHi = 0
  // 顶边曲线中点的副轴位置（r=rows/2）—— 横向收敛时应用栏骑在它上面下潜
  let midLo = 0
  for (let r = 0; r <= rows; r++) {
    const t = r / rows
    const m = lerp(start, end, t)
    // 元素被 translate + scale 变换（origin 0 0），所以主轴上的局部位置恰好均分 0..100%
    const mPct = (t * 100).toFixed(2)
    const lo = ((edge(m, crossLo(win), mouthLo) - crossBase - shiftCross) / crossSize) * 100
    const hi = ((edge(m, crossHi(win), mouthHi) - crossBase - shiftCross) / crossSize) * 100
    if (r === 0) {
      farLo = lo
      farHi = hi
    }
    if (r === Math.round(rows / 2)) midLo = lo
    if (vertical) {
      wallLo.push(`${lo.toFixed(2)}% ${mPct}%`)
      wallHi.unshift(`${hi.toFixed(2)}% ${mPct}%`)
    } else {
      wallLo.push(`${mPct}% ${lo.toFixed(2)}%`)
      wallHi.unshift(`${mPct}% ${hi.toFixed(2)}%`)
    }
  }

  // ⑤ 内容仿射：朝 Dock 方向整体平移并压缩
  const shift = start - mainLo(win)
  const ratio = span / mainSize
  const transform = vertical
    ? `translate(${shiftCross.toFixed(2)}px, ${shift.toFixed(2)}px) scaleY(${ratio.toFixed(5)})`
    : `translate(${shift.toFixed(2)}px, ${shiftCross.toFixed(2)}px) scaleX(${ratio.toFixed(5)})`

  // ⑥ 内容逐行横向压缩的强度（feDisplacementMap 的 scale）。
  //    贴图 R = 0.5 − v·(u−0.5)，输出点 x' 的采样源是 x' − scale·v·(x'/crossSize − 0.5)，
  //    即 x_src = (1 − scale·v/crossSize)·x' + …，所以每行内容是被**线性**缩到
  //      s(v) = 1 − scale·v/crossSize
  //    （注意是 1−k 而不是 1/(1+k)：scale 一旦超过 crossSize，s 就变负、内容会翻转）。
  //    要让靠 Dock 那端恰好收到嘴宽 → s(1) = mouthW/crossSize → scale = crossSize − mouthW。
  //    贴图按高度加权，所以只在竖向（Dock 在上下）时启用。
  const mouthW = Math.max(mouthHi - mouthLo, 1)
  const warp = vertical ? clamp(crossSize - mouthW, 0, crossSize) : 0

  // ⑦ 应用栏（AppBar）轮廓 —— 与窗口同一套形变，挂在窗口外侧上方（top: −56、高 46）。
  //    竖向收敛：远点行就是窗口顶边（局部 y=0），栏的上下边分别是顶边 −56 / −10，
  //    换算进栏自身百分比（y% 相对栏高）后恰好是 0% / 100%；x 直接用远点行的收窄范围。
  //    裙边让轮廓再往下多包 30px，胶囊的投影才不会被 clip-path 裁掉。
  //    横向收敛：远点是竖边、栏贴不上去 → 不裁轮廓，只给一个平移量（barY），
  //    让栏顶骑在顶边曲线的中点上，随窗口一起下潜进 Dock。
  const barH = Math.max(opt.barHeight ?? 46, 1)
  const barTop = opt.barTop ?? -56
  const barGap = opt.barGap ?? 10
  const skirtPct = (Math.max(opt.barSkirt ?? 30, 0) / barH) * 100
  let bar = ''
  let barY = 0
  if (vertical) {
    const yTop = 0 // 远点行局部 y=0，栏顶 = 0 + barTop → 栏自身 0%
    const yBot = ((0 - barGap) - barTop) / barH * 100 // 栏底 = 0 − barGap → 栏自身 100%
    const ySkirt = yBot + skirtPct
    bar =
      `polygon(${farLo.toFixed(2)}% ${yTop.toFixed(2)}%, ${farHi.toFixed(2)}% ${yTop.toFixed(2)}%, ` +
      `${farHi.toFixed(2)}% ${ySkirt.toFixed(2)}%, ${farLo.toFixed(2)}% ${ySkirt.toFixed(2)}%)`
  } else {
    barY = (midLo / 100) * crossSize
  }

  return {
    clip: `polygon(${[...wallLo, ...wallHi].join(', ')})`,
    transform,
    warp,
    opacity: p < fadeStart ? 1 : Math.max(0, 1 - (p - fadeStart) / (1 - fadeStart)),
    bar,
    barY
  }
}
