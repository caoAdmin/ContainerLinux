/**
 * 通用工具函数集合
 */

// 合并不重复的 class
export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(' ')
}

// 弹簧抛物线放大系数计算：基于鼠标到图标中心的距离
export function magnifyScale(
  iconCenterX: number,
  mouseX: number,
  _baseSize: number,
  maxScale: number,
  influence: number
): number {
  const distance = Math.abs(mouseX - iconCenterX)
  if (distance >= influence) return 1
  // 余弦衰减
  const t = distance / influence
  const factor = 0.5 * (1 + Math.cos(t * Math.PI))
  return 1 + (maxScale - 1) * factor
}

// 抛物线偏移：相邻图标因放大图标而挤开
export function magnifyOffset(
  iconCenterX: number,
  mouseX: number,
  baseSize: number,
  maxScale: number,
  influence: number
): number {
  const distance = mouseX - iconCenterX
  if (Math.abs(distance) >= influence) return 0
  const t = Math.abs(distance) / influence
  const factor = 0.5 * (1 + Math.cos(t * Math.PI))
  const direction = distance >= 0 ? 1 : -1
  return direction * (maxScale - 1) * baseSize * 0.5 * factor
}

// 生成唯一 id
export function uid(prefix = 'id'): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`
}

// 限制值在区间内
export function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v))
}

// 防抖
export function debounce<T extends (...args: unknown[]) => void>(fn: T, wait = 100): T {
  let timer: ReturnType<typeof setTimeout> | null = null
  return ((...args: unknown[]) => {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => fn(...args), wait)
  }) as T
}

// 动画帧节流
export function rafThrottle<T extends (...args: unknown[]) => void>(fn: T): T {
  let ticking = false
  return ((...args: unknown[]) => {
    if (ticking) return
    ticking = true
    requestAnimationFrame(() => {
      fn(...args)
      ticking = false
    })
  }) as T
}

// 格式化日期时间（菜单栏用）
export function formatDateTime(d: Date): {
  weekday: string
  weekdayShort: string
  month: string
  day: number
  time: string
  hm: string
  dateFull: string
} {
  const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']
  const weekdaysShort = ['日', '一', '二', '三', '四', '五', '六']
  const months = [
    '1月', '2月', '3月', '4月', '5月', '6月',
    '7月', '8月', '9月', '10月', '11月', '12月'
  ]
  const hh = String(d.getHours()).padStart(2, '0')
  const mm = String(d.getMinutes()).padStart(2, '0')
  return {
    weekday: weekdays[d.getDay()],
    weekdayShort: '周' + weekdaysShort[d.getDay()],
    month: String(d.getMonth() + 1),
    day: d.getDate(),
    hm: `${hh}:${mm}`,
    time: `${hh}:${mm}`,
    dateFull: `${weekdays[d.getDay()]} ${months[d.getMonth()]}${d.getDate()}日`
  }
}

// localStorage JSON 封装
export function storageGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    if (raw) return JSON.parse(raw) as T
  } catch {
    // ignore
  }
  return fallback
}

export function storageSet<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    // ignore
  }
}
