/**
 * 液态玻璃 —— 动态光源
 *
 * 折射材质已经搬到 WebGL（components/cosmic/glass/GlassSheet.vue）：
 * 片元着色器直接采样壁纸纹理做倒角折射 + 色散 + 高光，全程 GPU。
 * 这里只负责全局的「光」：--lg-hx / --lg-hy 跟随指针（rAF 节流），
 * 供 GlassSheet 的光照方向与各玻璃面的高光渐变使用。
 */
function trackLight(): void {
  let raf = 0
  let px = 50
  let py = 0
  /** 已写入根节点的值：相同就跳过（写根 CSS 变量会让引用它的元素整棵重算样式） */
  let appliedX = -1
  let appliedY = -1
  let appliedSpeed = -1

  const apply = () => {
    raf = 0
    const root = document.documentElement
    const nx = Math.round(px * 5) / 5
    const ny = Math.round(py * 5) / 5
    if (nx !== appliedX) {
      appliedX = nx
      root.style.setProperty('--lg-hx', nx.toFixed(1) + '%')
    }
    if (ny !== appliedY) {
      appliedY = ny
      root.style.setProperty('--lg-hy', ny.toFixed(1) + '%')
    }
  }

  // 指针速度 → 玻璃的「弹性」：快速划过时光带变亮、折射加深，
  // 停下后 140ms 内回落到静止值（借自 liquid-glass-vue 的 elasticity 思路）
  let lastX = 0
  let lastY = 0
  let lastT = 0
  let decay = 0
  const setSpeed = (v: number) => {
    // 量化到 0.05：弹性表现不受影响，但避免了每帧一次根变量写入
    const q = Math.round(v * 20) / 20
    if (q === appliedSpeed) return
    appliedSpeed = q
    document.documentElement.style.setProperty('--lg-speed', q.toFixed(3))
  }
  window.addEventListener(
    'pointermove',
    (e) => {
      px = (e.clientX / window.innerWidth) * 100
      py = (e.clientY / window.innerHeight) * 100
      if (!raf) raf = requestAnimationFrame(apply)

      const now = performance.now()
      if (lastT) {
        const dt = Math.max(8, now - lastT)
        const d = Math.hypot(e.clientX - lastX, e.clientY - lastY)
        const v = Math.min(1, d / dt / 1.8) // ≈1800px/s 封顶
        setSpeed(v)
        clearTimeout(decay)
        decay = window.setTimeout(() => setSpeed(0), 140)
      }
      lastX = e.clientX
      lastY = e.clientY
      lastT = now
    },
    { passive: true }
  )
  apply()
  setSpeed(0)
}

export function initLiquidGlass(): void {
  trackLight()
}
