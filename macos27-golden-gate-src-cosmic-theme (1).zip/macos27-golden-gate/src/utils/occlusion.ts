/**
 * 窗口遮挡计算
 *
 * 给「被压在下面的窗口」算出两件事：
 *   ① 被上层窗口盖住的每一块矩形（用于铺磨砂玻璃）
 *   ② 是否整块都被盖住（整块被盖住时直接停渲染，省掉后面那堆 DOM / 画布）
 *
 * 坐标一律用舞台逻辑坐标 —— 和 store 里 win.x / win.y 是同一套，
 * 窗口内部的 left/top 直接减自身原点就能用，不用再过一遍缩放。
 */

export interface ORect {
  x: number
  y: number
  w: number
  h: number
}

export interface RectLike {
  x: number
  y: number
  width: number
  height: number
}

export function rectOf(r: RectLike): ORect {
  return { x: r.x, y: r.y, w: r.width, h: r.height }
}

/** 交集；不足半像素的接触当作没碰上（避免拖到边缘时冒出 0.2px 的磨砂条） */
export function intersect(a: ORect, b: ORect): ORect | null {
  const x = Math.max(a.x, b.x)
  const y = Math.max(a.y, b.y)
  const right = Math.min(a.x + a.w, b.x + b.w)
  const bottom = Math.min(a.y + a.h, b.y + b.h)
  if (right - x < 0.5 || bottom - y < 0.5) return null
  return { x, y, w: right - x, h: bottom - y }
}

/**
 * target 是否被 coverers 的并集完全盖住。
 *
 * 精确解，不用网格采样：把所有矩形的 x 边切成一段段竖条，每个竖条里取
 * 各矩形的 y 区间做并集，看能不能一路盖到 target 底部。矩形只有几个，
 * 复杂度可忽略；采样法反而会把「底部露出 20px」这种细边判成全遮住 ——
 * 那样就会把用户还能看见的一条内容凭空抹掉。
 */
export function fullyCovered(target: ORect, coverers: ORect[]): boolean {
  if (!coverers.length || target.w <= 0 || target.h <= 0) return false
  const eps = 0.01

  // 快路径：只有一块在盖（最大化窗口压住下面的窗口就是这种）。
  // 传进来的矩形已经和 target 求过交，所以「盖满」等价于「交集 = target」。
  if (coverers.length === 1) {
    const c = coverers[0]
    return (
      c.x <= target.x + eps &&
      c.y <= target.y + eps &&
      c.x + c.w >= target.x + target.w - eps &&
      c.y + c.h >= target.y + target.h - eps
    )
  }

  // 多块：先用并集外框挡掉明显盖不满的情况，省掉后面的扫描
  let x0 = Infinity
  let y0 = Infinity
  let x1 = -Infinity
  let y1 = -Infinity
  for (const c of coverers) {
    if (c.x < x0) x0 = c.x
    if (c.y < y0) y0 = c.y
    if (c.x + c.w > x1) x1 = c.x + c.w
    if (c.y + c.h > y1) y1 = c.y + c.h
  }
  if (x0 > target.x + eps || y0 > target.y + eps) return false
  if (x1 < target.x + target.w - eps || y1 < target.y + target.h - eps) return false

  const cs: ORect[] = []
  for (const c of coverers) {
    const r = intersect(c, target)
    if (r) cs.push(r)
  }
  if (!cs.length) return false

  // 竖条边界：target 的两侧 + 每个遮挡块的左右边
  const xs = new Set<number>([target.x, target.x + target.w])
  for (const c of cs) {
    xs.add(c.x)
    xs.add(c.x + c.w)
  }
  const edges = [...xs].sort((a, b) => a - b)
  const bottom = target.y + target.h

  for (let i = 0; i < edges.length - 1; i++) {
    const x0 = edges[i]
    const x1 = edges[i + 1]
    if (x1 - x0 < eps) continue
    const mid = (x0 + x1) / 2
    // 这个竖条里横跨它的矩形，按上边排序后往上接
    const spans = cs
      .filter((c) => c.x <= mid && c.x + c.w >= mid)
      .map((c) => [c.y, c.y + c.h] as [number, number])
      .sort((a, b) => a[0] - b[0])
    let reach = target.y
    for (const [top, bot] of spans) {
      if (top > reach + eps) break
      if (bot > reach) reach = bot
    }
    if (reach < bottom - eps) return false
  }
  return true
}
