/**
 * 应用注册表
 * 定义所有可在 Dock / Launchpad / Spotlight 中出现的应用
 */
import type { AppDefinition } from '@/types'

export const allApps: AppDefinition[] = [
  {
    id: 'finder',
    name: '访达',
    icon: 'finder',
    defaultWidth: 900,
    defaultHeight: 580,
    minWidth: 480,
    minHeight: 320,
    singleton: true,
    component: 'FinderApp'
  },
  {
    id: 'launchpad',
    name: '启动台',
    icon: 'gc-launchpad',
    defaultWidth: 0,
    defaultHeight: 0,
    minWidth: 0,
    minHeight: 0,
    singleton: true,
    component: 'Launchpad'
  },
  {
    id: 'safari',
    name: 'Safari',
    icon: 'safari',
    defaultWidth: 1000,
    defaultHeight: 660,
    minWidth: 500,
    minHeight: 360,
    singleton: true,
    component: 'SafariApp'
  },
  {
    id: 'mail',
    name: '邮件',
    icon: 'mail',
    defaultWidth: 880,
    defaultHeight: 580,
    minWidth: 520,
    minHeight: 360,
    singleton: true,
    component: 'MailApp'
  },
  {
    id: 'messages',
    name: '信息',
    icon: 'messages',
    defaultWidth: 820,
    defaultHeight: 560,
    minWidth: 500,
    minHeight: 360,
    singleton: true,
    component: 'MessagesApp'
  },
  {
    id: 'maps',
    name: '地图',
    icon: 'maps',
    defaultWidth: 900,
    defaultHeight: 600,
    minWidth: 520,
    minHeight: 360,
    singleton: true,
    component: 'MapsApp'
  },
  {
    id: 'photos',
    name: '照片',
    icon: 'photos',
    defaultWidth: 960,
    defaultHeight: 620,
    minWidth: 520,
    minHeight: 360,
    singleton: true,
    component: 'PhotosApp'
  },
  {
    id: 'music',
    name: '音乐',
    icon: 'music',
    defaultWidth: 900,
    defaultHeight: 600,
    minWidth: 520,
    minHeight: 360,
    singleton: true,
    component: 'MusicApp'
  },
  {
    id: 'calendar',
    name: '日历',
    icon: 'calendar',
    defaultWidth: 860,
    defaultHeight: 580,
    minWidth: 480,
    minHeight: 340,
    singleton: true,
    component: 'CalendarApp'
  },
  {
    id: 'notes',
    name: '备忘录',
    icon: 'notes',
    defaultWidth: 860,
    defaultHeight: 580,
    minWidth: 480,
    minHeight: 340,
    singleton: true,
    component: 'NotesApp'
  },
  {
    id: 'settings',
    name: '系统设置',
    icon: 'settings',
    defaultWidth: 920,
    defaultHeight: 620,
    minWidth: 720,
    minHeight: 480,
    singleton: true,
    component: 'SettingsApp'
  },
  {
    id: 'calculator',
    name: '计算器',
    icon: 'calculator',
    defaultWidth: 260,
    defaultHeight: 380,
    minWidth: 240,
    minHeight: 340,
    singleton: true,
    component: 'CalculatorApp'
  },
  {
    id: 'terminal',
    name: '终端',
    icon: 'terminal',
    defaultWidth: 720,
    defaultHeight: 460,
    minWidth: 400,
    minHeight: 280,
    singleton: true,
    component: 'TerminalApp'
  },
  {
    id: 'preview',
    name: '预览',
    icon: 'preview',
    defaultWidth: 820,
    defaultHeight: 560,
    minWidth: 420,
    minHeight: 300,
    singleton: false,
    component: 'PreviewApp'
  },
  {
    id: 'trash',
    name: '废纸篓',
    icon: 'trash',
    defaultWidth: 720,
    defaultHeight: 480,
    minWidth: 420,
    minHeight: 300,
    singleton: true,
    component: 'TrashApp'
  }
]

export function getAppById(id: string): AppDefinition | undefined {
  return allApps.find((a) => a.id === id)
}

// 用于 Launchpad/Spotlight 搜索过滤
export function searchApps(keyword: string): AppDefinition[] {
  const k = keyword.trim().toLowerCase()
  if (!k) return allApps.filter((a) => a.id !== 'trash')
  return allApps.filter(
    (a) =>
      a.id !== 'trash' &&
      (a.name.toLowerCase().includes(k) || a.id.toLowerCase().includes(k))
  )
}
