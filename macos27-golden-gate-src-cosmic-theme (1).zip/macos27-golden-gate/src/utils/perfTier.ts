/**
 * 渲染档位（Performance Tier）
 *
 * 背景：桌面画布是「逻辑尺寸 + transform: scale()」的等比缩放方案。
 * 手机上 1280×720 的画布会被缩到 0.30 左右，而 backdrop-filter / SVG 滤镜
 * 的离屏缓冲是**按缩放前的逻辑尺寸**分配的 —— 一个 620×380 的面板在 DPR 3
 * 的手机上要按 1280×832 级别去光栅化，再缩小合成。玻璃面一多，
 * Android Chrome 直接掉到个位数帧率。
 *
 * 因此把渲染分成两档：
 *   high —— 完整液态玻璃（SVG 位移折射 + 壁纸克隆 + 每帧描边对齐）
 *   low  —— 单层磨砂（纯 blur + tint + 描边高光），零 SVG 滤镜、零壁纸克隆
 *
 * 判定：粗指针（触屏）且短边 ≤ 900 → low。桌面永远 high。
 * 覆盖：URL `?perf=high|low|off`（off = 完全关闭玻璃，仅调试用），
 *       或 localStorage `gg-perf-tier`，或 window.__ggPerf.set(tier)。
 */
import { ref } from 'vue'

export type PerfTier = 'high' | 'low' | 'off'

/** 响应式档位：组件（LgSheet / HUD / 设置页）直接订阅 */
export const perfTier = ref<PerfTier>('high')
/** 是否仍在「自动」（用户没手动指定过） */
export const perfAuto = ref(true)

const STORAGE_KEY = 'gg-perf-tier'

function fromQuery(): PerfTier | null {
  try {
    const v = new URLSearchParams(location.search).get('perf')
    if (v === 'high' || v === 'low' || v === 'off') return v
  } catch {
    /* SSR / 隐私模式 */
  }
  return null
}

function fromStorage(): PerfTier | null {
  try {
    const v = localStorage.getItem(STORAGE_KEY)
    if (v === 'high' || v === 'low' || v === 'off') return v
  } catch {
    /* ignore */
  }
  return null
}

/** 无外力干预时的自动判定 */
function autoTier(): PerfTier {
  if (typeof window === 'undefined') return 'high'
  const coarse = window.matchMedia?.('(pointer: coarse)').matches ?? false
  const shortSide = Math.min(window.innerWidth, window.innerHeight)
  // 触屏且短边 ≤ 900：手机 / 平板竖屏 → 省电档
  if (coarse && shortSide <= 900) return 'low'
  // 非触屏但窗口很小（<= 700）：多半是低配设备/分屏，也降档
  if (shortSide <= 700) return 'low'
  return 'high'
}

let current: PerfTier = 'high'

export function getPerfTier(): PerfTier {
  return current
}

/** 把档位写到 <html data-perf>，CSS 与 JS 都以它为唯一真源 */
export function applyPerfTier(tier: PerfTier): PerfTier {
  current = tier
  perfTier.value = tier
  if (typeof document !== 'undefined') {
    document.documentElement.dataset.perf = tier
  }
  return tier
}

export function setPerfTier(tier: PerfTier, persist = true): PerfTier {
  applyPerfTier(tier)
  perfAuto.value = false
  if (persist) {
    try {
      localStorage.setItem(STORAGE_KEY, tier)
    } catch {
      /* ignore */
    }
  }
  return tier
}

/** 回到自动判定（清掉手动选择） */
export function resetPerfTier(): PerfTier {
  try {
    localStorage.removeItem(STORAGE_KEY)
  } catch {
    /* ignore */
  }
  perfAuto.value = true
  return applyPerfTier(autoTier())
}

/** 启动时调用一次（在挂载前，避免首屏先画一帧完整玻璃） */
export function initPerfTier(): PerfTier {
  const forced = fromQuery() ?? fromStorage()
  perfAuto.value = !forced
  const tier = forced ?? autoTier()
  applyPerfTier(tier)
  if (typeof window !== 'undefined') {
    ;(window as unknown as { __ggPerf: unknown }).__ggPerf = {
      get: getPerfTier,
      set: (t: PerfTier) => setPerfTier(t),
      auto: () => resetPerfTier()
    }
  }
  return tier
}

export const isLowPower = () => current !== 'high'
