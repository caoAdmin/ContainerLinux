/**
 * 图标主题注册表
 *
 * 一个主题 = 一套应用图标 + 一套文件类型图标。当前挂了两套来源：
 *   · Crule / Crule-dark —— KDE 的 Crule 图标主题（WhiteSur 派生），矢量 SVG，
 *     取的是 apps / places / mimes 里的 scalable 版本，任意尺寸都不糊
 *   · Linuxfx 11 —— 之前那套位图（png），保留下来可随时切回去
 *
 * 主题只影响「用位图图标的地方」：Dock、启动台、应用栏、窗口设置页、商店、
 * 文件管理器里的文件/文件夹图标。Remix 字形兜底不受影响 ——
 * 某个主题缺这个应用的图，就自动回落到字形，不会出现空白框。
 */
import type { IconThemeId } from '@/types'

/* ── Crule Dark ── */
import cdFiles from '@/assets/icons/crule-dark/apps/files.svg'
import cdTerminal from '@/assets/icons/crule-dark/apps/terminal.svg'
import cdEdit from '@/assets/icons/crule-dark/apps/edit.svg'
import cdStore from '@/assets/icons/crule-dark/apps/store.svg'
import cdSettings from '@/assets/icons/crule-dark/apps/settings.svg'
import cdPlayer from '@/assets/icons/crule-dark/apps/player.svg'
import cdViewer from '@/assets/icons/crule-dark/apps/viewer.svg'
import cdMonitor from '@/assets/icons/crule-dark/apps/monitor.svg'
import cdScreenshot from '@/assets/icons/crule-dark/apps/screenshot.svg'
import cdFolder from '@/assets/icons/crule-dark/files/folder.svg'
import cdImage from '@/assets/icons/crule-dark/files/image.svg'
import cdAudio from '@/assets/icons/crule-dark/files/audio.svg'
import cdVideo from '@/assets/icons/crule-dark/files/video.svg'
import cdArchive from '@/assets/icons/crule-dark/files/archive.svg'
import cdCode from '@/assets/icons/crule-dark/files/code.svg'
import cdMarkdown from '@/assets/icons/crule-dark/files/markdown.svg'
import cdBinary from '@/assets/icons/crule-dark/files/binary.svg'
import cdText from '@/assets/icons/crule-dark/files/text.svg'
import cdHome from '@/assets/icons/crule-dark/places/home.svg'
import cdDesktop from '@/assets/icons/crule-dark/places/desktop.svg'
import cdDocuments from '@/assets/icons/crule-dark/places/documents.svg'
import cdDownloads from '@/assets/icons/crule-dark/places/downloads.svg'
import cdMusic from '@/assets/icons/crule-dark/places/music.svg'
import cdPictures from '@/assets/icons/crule-dark/places/pictures.svg'
import cdVideos from '@/assets/icons/crule-dark/places/videos.svg'
import cdSystem from '@/assets/icons/crule-dark/places/system.svg'
import cdUsb from '@/assets/icons/crule-dark/places/usb.svg'

/* ── Crule（浅色变体）── */
import clFiles from '@/assets/icons/crule/apps/files.svg'
import clTerminal from '@/assets/icons/crule/apps/terminal.svg'
import clEdit from '@/assets/icons/crule/apps/edit.svg'
import clStore from '@/assets/icons/crule/apps/store.svg'
import clSettings from '@/assets/icons/crule/apps/settings.svg'
import clPlayer from '@/assets/icons/crule/apps/player.svg'
import clViewer from '@/assets/icons/crule/apps/viewer.svg'
import clMonitor from '@/assets/icons/crule/apps/monitor.svg'
import clScreenshot from '@/assets/icons/crule/apps/screenshot.svg'
import clFolder from '@/assets/icons/crule/files/folder.svg'
import clImage from '@/assets/icons/crule/files/image.svg'
import clAudio from '@/assets/icons/crule/files/audio.svg'
import clVideo from '@/assets/icons/crule/files/video.svg'
import clArchive from '@/assets/icons/crule/files/archive.svg'
import clCode from '@/assets/icons/crule/files/code.svg'
import clMarkdown from '@/assets/icons/crule/files/markdown.svg'
import clBinary from '@/assets/icons/crule/files/binary.svg'
import clText from '@/assets/icons/crule/files/text.svg'
import clHome from '@/assets/icons/crule/places/home.svg'
import clDesktop from '@/assets/icons/crule/places/desktop.svg'
import clDocuments from '@/assets/icons/crule/places/documents.svg'
import clDownloads from '@/assets/icons/crule/places/downloads.svg'
import clMusic from '@/assets/icons/crule/places/music.svg'
import clPictures from '@/assets/icons/crule/places/pictures.svg'
import clVideos from '@/assets/icons/crule/places/videos.svg'
import clSystem from '@/assets/icons/crule/places/system.svg'
import clUsb from '@/assets/icons/crule/places/usb.svg'

/* ── Linuxfx 11（之前的位图主题）── */
import lxFiles from '@/assets/icons/linuxfx/files.png'
import lxTerminal from '@/assets/icons/linuxfx/terminal.png'
import lxEdit from '@/assets/icons/linuxfx/edit.png'
import lxStore from '@/assets/icons/linuxfx/store.png'
import lxSettings from '@/assets/icons/linuxfx/settings.png'
import lxPlayer from '@/assets/icons/linuxfx/player.png'
import lxViewer from '@/assets/icons/linuxfx/viewer.png'
import lxMonitor from '@/assets/icons/linuxfx/monitor.png'
import lxScreenshot from '@/assets/icons/linuxfx/screenshot.png'
import lxFolder from '@/assets/icons/linuxfx/folder.png'
import lxImage from '@/assets/icons/linuxfx/image.png'
import lxAudio from '@/assets/icons/linuxfx/audio.png'
import lxVideo from '@/assets/icons/linuxfx/video.png'
import lxArchive from '@/assets/icons/linuxfx/archive.png'
import lxCode from '@/assets/icons/linuxfx/code.png'
import lxMarkdown from '@/assets/icons/linuxfx/markdown.png'
import lxBinary from '@/assets/icons/linuxfx/binary.png'
import lxText from '@/assets/icons/linuxfx/text.png'

// ── Fluent Color（GNOME 风格的彩色图标）──
import flFileManager from '@/assets/icons/fluent-color/file-manager.svg'
import flTerminal from '@/assets/icons/fluent-color/terminal.svg'
import flTextEditor from '@/assets/icons/fluent-color/text-editor.svg'
import flGnomeSoftware from '@/assets/icons/fluent-color/gnome-software.svg'
import flPreferencesSystem from '@/assets/icons/fluent-color/preferences-system.svg'
import flRhythmbox from '@/assets/icons/fluent-color/rhythmbox.svg'
import flAccessoriesDocumentViewer from '@/assets/icons/fluent-color/accessories-document-viewer.svg'
import flUtilitiesSystemMonitor from '@/assets/icons/fluent-color/utilities-system-monitor.svg'
import flAccessoriesScreenshot from '@/assets/icons/fluent-color/accessories-screenshot.svg'
import flDefaultFolder from '@/assets/icons/fluent-color/default-folder.svg'
import flImageXGeneric from '@/assets/icons/fluent-color/image-x-generic.svg'
import flAudioXGeneric from '@/assets/icons/fluent-color/audio-x-generic.svg'
import flVideoXGeneric from '@/assets/icons/fluent-color/video-x-generic.svg'
import flApplicationXArchive from '@/assets/icons/fluent-color/application-x-archive.svg'
import flTextXScript from '@/assets/icons/fluent-color/text-x-script.svg'
import flTextMarkdown from '@/assets/icons/fluent-color/text-markdown.svg'
import flApplicationOctetStream from '@/assets/icons/fluent-color/application-octet-stream.svg'
import flTextXGeneric from '@/assets/icons/fluent-color/text-x-generic.svg'
import flDefaultUserHome from '@/assets/icons/fluent-color/default-user-home.svg'
import flDefaultUserDesktop from '@/assets/icons/fluent-color/default-user-desktop.svg'
import flDefaultFolderDocuments from '@/assets/icons/fluent-color/default-folder-documents.svg'
import flDefaultFolderDownload from '@/assets/icons/fluent-color/default-folder-download.svg'
import flDefaultFolderMusic from '@/assets/icons/fluent-color/default-folder-music.svg'
import flDefaultFolderPictures from '@/assets/icons/fluent-color/default-folder-pictures.svg'
import flDefaultFolderVideo from '@/assets/icons/fluent-color/default-folder-video.svg'
import flDefaultFolderSystem from '@/assets/icons/fluent-color/default-folder-system.svg'
import flDriveRemovableMedia from '@/assets/icons/fluent-color/drive-removable-media.svg'
// 额外应用（补齐启动台里此前回落字形的应用）
import flCalc from '@/assets/icons/fluent-color/calc.svg'
import flCameraPhoto from '@/assets/icons/fluent-color/camera-photo.svg'
import flUtilitiesLogViewer from '@/assets/icons/fluent-color/utilities-log-viewer.svg'
import flDriveHarddisk from '@/assets/icons/fluent-color/drive-harddisk.svg'
import flFontXGeneric from '@/assets/icons/fluent-color/font-x-generic.svg'
import flApplicationsSystem from '@/assets/icons/fluent-color/applications-system.svg'
import flPreferencesDevicesCpu from '@/assets/icons/fluent-color/preferences-devices-cpu.svg'
import flPackageXGeneric from '@/assets/icons/fluent-color/package-x-generic.svg'
import flPreferencesPlugin from '@/assets/icons/fluent-color/preferences-plugin.svg'
import flNetworkWorkgroup from '@/assets/icons/fluent-color/network-workgroup.svg'
import flDocumentOpenRecent from '@/assets/icons/fluent-color/document-open-recent.svg'
import flGbrainy from '@/assets/icons/fluent-color/gbrainy.svg'
import flSystemOsInstall from '@/assets/icons/fluent-color/system-os-install.svg'

/** 文件类型（与 cosmicVfs 里的 VNode.kind 对齐，dir 另算） */
export type FileKindId =
  | 'folder'
  | 'image'
  | 'audio'
  | 'video'
  | 'archive'
  | 'code'
  | 'markdown'
  | 'binary'
  | 'text'

/** 文件管理器侧边栏的位置 / 设备（Linuxfx 那套没有这些图，会自动回落字形） */
export type PlaceId =
  | 'home'
  | 'desktop'
  | 'documents'
  | 'downloads'
  | 'music'
  | 'pictures'
  | 'videos'
  | 'system'
  | 'usb'

export interface IconThemeDef {
  id: IconThemeId
  name: string
  hint: string
  /** appId → 图标地址 */
  apps: Record<string, string>
  /** 文件类型 → 图标地址 */
  files: Record<FileKindId, string>
  /** 位置 / 设备图标；缺省时侧边栏退回 Remix 字形 */
  places?: Partial<Record<PlaceId, string>>
}

const FLUENT_THEME: IconThemeDef = {
  id: 'fluent',
  name: 'Fluent Color',
  hint: 'Fluent 彩色图标（GNOME 风格）',
  apps: {
    files: flFileManager,
    terminal: flTerminal,
    edit: flTextEditor,
    store: flGnomeSoftware,
    settings: flPreferencesSystem,
    player: flRhythmbox,
    viewer: flAccessoriesDocumentViewer,
    monitor: flUtilitiesSystemMonitor,
    screenshot: flAccessoriesScreenshot,
    // 额外应用（补齐启动台此前回落字形的应用）
    calculator: flCalc,
    camera: flCameraPhoto,
    logs: flUtilitiesLogViewer,
    disks: flDriveHarddisk,
    fonts: flFontXGeneric,
    'ct-overview': flApplicationsSystem,
    'ct-kernel': flPreferencesDevicesCpu,
    'ct-distro': flPackageXGeneric,
    'ct-plugins': flPreferencesPlugin,
    'ct-appstore': flGnomeSoftware,
    'ct-swarm': flNetworkWorkgroup,
    'ct-timetravel': flDocumentOpenRecent,
    'ct-claw': flGbrainy,
    'ct-installer': flSystemOsInstall,
    'ct-settings': flPreferencesSystem
  },
  files: {
    folder: flDefaultFolder,
    image: flImageXGeneric,
    audio: flAudioXGeneric,
    video: flVideoXGeneric,
    archive: flApplicationXArchive,
    code: flTextXScript,
    markdown: flTextMarkdown,
    binary: flApplicationOctetStream,
    text: flTextXGeneric
  },
  places: {
    home: flDefaultUserHome,
    desktop: flDefaultUserDesktop,
    documents: flDefaultFolderDocuments,
    downloads: flDefaultFolderDownload,
    music: flDefaultFolderMusic,
    pictures: flDefaultFolderPictures,
    videos: flDefaultFolderVideo,
    system: flDefaultFolderSystem,
    usb: flDriveRemovableMedia
  }
}

export const ICON_THEMES: IconThemeDef[] = [
  FLUENT_THEME,
  {
    id: 'crule-dark',
    name: 'Crule Dark',
    hint: 'KDE Crule 深色（默认）',
    apps: {
      files: cdFiles,
      terminal: cdTerminal,
      edit: cdEdit,
      store: cdStore,
      settings: cdSettings,
      player: cdPlayer,
      viewer: cdViewer,
      monitor: cdMonitor,
      screenshot: cdScreenshot
    },
    files: {
      folder: cdFolder,
      image: cdImage,
      audio: cdAudio,
      video: cdVideo,
      archive: cdArchive,
      code: cdCode,
      markdown: cdMarkdown,
      binary: cdBinary,
      text: cdText
    },
    places: {
      home: cdHome,
      desktop: cdDesktop,
      documents: cdDocuments,
      downloads: cdDownloads,
      music: cdMusic,
      pictures: cdPictures,
      videos: cdVideos,
      system: cdSystem,
      usb: cdUsb
    }
  },
  {
    id: 'crule',
    name: 'Crule',
    hint: 'KDE Crule 浅色',
    apps: {
      files: clFiles,
      terminal: clTerminal,
      edit: clEdit,
      store: clStore,
      settings: clSettings,
      player: clPlayer,
      viewer: clViewer,
      monitor: clMonitor,
      screenshot: clScreenshot
    },
    files: {
      folder: clFolder,
      image: clImage,
      audio: clAudio,
      video: clVideo,
      archive: clArchive,
      code: clCode,
      markdown: clMarkdown,
      binary: clBinary,
      text: clText
    },
    places: {
      home: clHome,
      desktop: clDesktop,
      documents: clDocuments,
      downloads: clDownloads,
      music: clMusic,
      pictures: clPictures,
      videos: clVideos,
      system: clSystem,
      usb: clUsb
    }
  },
  {
    id: 'linuxfx',
    name: 'Linuxfx 11',
    hint: '之前的位图图标包',
    apps: {
      files: lxFiles,
      terminal: lxTerminal,
      edit: lxEdit,
      store: lxStore,
      settings: lxSettings,
      player: lxPlayer,
      viewer: lxViewer,
      monitor: lxMonitor,
      screenshot: lxScreenshot
    },
    files: {
      folder: lxFolder,
      image: lxImage,
      audio: lxAudio,
      video: lxVideo,
      archive: lxArchive,
      code: lxCode,
      markdown: lxMarkdown,
      binary: lxBinary,
      text: lxText
    }
  }
]

export const DEFAULT_ICON_THEME: IconThemeId = 'fluent'

const themeMap = new Map(ICON_THEMES.map((t) => [t.id, t]))

/** 按 id 取主题，未知 id 回落到默认主题（存档或旧配置不会把界面弄成空白） */
export function getIconTheme(id: string): IconThemeDef {
  return themeMap.get(id as IconThemeId) ?? themeMap.get(DEFAULT_ICON_THEME)!
}

/** 应用图标：主题里没有这个应用就返回 undefined，交给字形兜底 */
export function appIconUrl(appId: string | undefined, themeId: string): string | undefined {
  if (!appId) return undefined
  return getIconTheme(themeId).apps[appId]
}

/** 文件类型图标：主题总有一套，缺失时也回落到默认主题 */
export function fileIconUrl(kind: FileKindId, themeId: string): string {
  const t = getIconTheme(themeId)
  return t.files[kind] ?? getIconTheme(DEFAULT_ICON_THEME).files.text
}

/** 位置 / 设备图标：主题没提供就返回 undefined，由调用方回落到字形 */
export function placeIconUrl(place: PlaceId, themeId: string): string | undefined {
  return getIconTheme(themeId).places?.[place]
}
