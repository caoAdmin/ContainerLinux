/**
 * COSMIC 虚拟文件系统（VFS）
 * 供 COSMIC Files / Edit / Terminal / Reader / Player 共享的内存文件树。
 * 所有写操作都是响应式的，任何一个应用改动，其它应用实时可见。
 */
import { reactive } from 'vue'
// 文件类型图标走图标主题（默认 Crule Dark），主题里缺图时退回 Remix 字形
import { fileIconUrl, type FileKindId } from '@/utils/iconThemes'

export interface VNode {
  name: string
  type: 'dir' | 'file'
  children?: VNode[]
  content?: string
  size?: number
  mtime: string
  /** 文件类型标记，用于选图标 / 选默认打开方式 */
  kind?: string
}

export const HOME = '/home/cosmic'

const T = '10月 11 12:34'

function file(name: string, content: string, kind = 'text', mtime = T): VNode {
  return { name, type: 'file', content, size: content.length, mtime, kind }
}

function dir(name: string, children: VNode[] = [], mtime = T): VNode {
  return { name, type: 'dir', children, mtime }
}

export const vfs = reactive<VNode>(
  dir('/', [
    dir('home', [
      dir('cosmic', [
        dir('Desktop', [
          file('welcome.txt', '欢迎使用 COSMIC 桌面。\n', 'text'),
          file('cosmic-epoch.desktop', '[Desktop Entry]\nName=COSMIC\nType=Application\n', 'text')
        ]),
        dir('Documents', [
          file(
            'README.md',
            '# COSMIC Epoch\n\nCOSMIC 是 System76 用 Rust 从零构建的桌面环境。\n\n- 窗口平铺\n- 主题系统\n- 自带应用套件\n',
            'markdown'
          ),
          file('todo.md', '- [x] 构建 COSMIC 应用套件\n- [ ] 支持自动平铺\n- [ ] 完成商店分类\n', 'markdown'),
          file('note.txt', '记得给窗口加上圆角和阴影。\n', 'text'),
          dir('Projects', [
            file('main.rs', 'fn main() {\n    println!("Hello, COSMIC!");\n}\n', 'code'),
            file('Cargo.toml', '[package]\nname = "cosmic-demo"\nversion = "0.1.0"\nedition = "2021"\n', 'code')
          ])
        ]),
        dir('Downloads', [
          file('cosmic-epoch.tar.gz', 'BINARY', 'archive'),
          file('wallpaper-nebula.png', 'BINARY', 'image'),
          file('pop-os-24.04.iso', 'BINARY', 'archive')
        ]),
        dir('Music', [
          file('Departures.mp3', 'AUDIO', 'audio'),
          file('Kimi no Na wa.flac', 'AUDIO', 'audio'),
          file('Myth & Roid - L.L.L.mp3', 'AUDIO', 'audio'),
          file('YOASOBI - 夜に駆ける.mp3', 'AUDIO', 'audio')
        ]),
        dir('Pictures', [
          file('screenshot-01.png', 'BINARY', 'image'),
          file('nebula.jpg', 'BINARY', 'image'),
          file('floating-island.jpg', 'BINARY', 'image')
        ]),
        dir('Videos', [file('demo.mp4', 'VIDEO', 'video')]),
        dir('.config', [
          dir('cosmic', [
            file('com.system76.CosmicTheme.Mode', 'dark\n', 'text'),
            file('com.system76.CosmicPanel', 'position = "bottom"\nsize = "M"\n', 'text')
          ])
        ])
      ])
    ]),
    dir('usr', [
      dir('bin', [file('cosmic-term', 'ELF', 'binary'), file('cosmic-files', 'ELF', 'binary')]),
      dir('share', [dir('applications', [file('cosmic-store.desktop', '[Desktop Entry]\n', 'text')])])
    ]),
    dir('etc', [
      file('os-release', 'NAME="Pop!_OS"\nVERSION="24.04 LTS"\nID=pop\n', 'text'),
      file('hostname', 'cosmic-pc\n', 'text'),
      file('passwd', 'root:x:0:0:root:/root:/bin/bash\ncosmic:x:1000:1000:COSMIC:/home/cosmic:/bin/bash\n', 'text')
    ]),
    dir('var', [dir('log', [file('syslog', 'COSMIC session started\n', 'text')])]),
    dir('tmp', [])
  ])
)

/* ───────────── 路径工具 ───────────── */

export function normalizePath(path: string, cwd = HOME): string {
  let p = path.trim()
  if (!p) return cwd
  if (p.startsWith('~')) p = HOME + p.slice(1)
  if (!p.startsWith('/')) p = `${cwd}/${p}`
  const parts: string[] = []
  for (const seg of p.split('/')) {
    if (!seg || seg === '.') continue
    if (seg === '..') parts.pop()
    else parts.push(seg)
  }
  return '/' + parts.join('/')
}

export function parentPath(path: string): string {
  const i = path.lastIndexOf('/')
  return i <= 0 ? '/' : path.slice(0, i)
}

export function baseName(path: string): string {
  if (path === '/') return '/'
  return path.slice(path.lastIndexOf('/') + 1)
}

export function prettyPath(path: string): string {
  if (path === HOME) return '~'
  if (path.startsWith(HOME + '/')) return '~' + path.slice(HOME.length)
  return path
}

export function getNode(path: string): VNode | null {
  const p = normalizePath(path)
  if (p === '/') return vfs
  let node: VNode = vfs
  for (const seg of p.slice(1).split('/')) {
    if (node.type !== 'dir' || !node.children) return null
    const next = node.children.find((c) => c.name === seg)
    if (!next) return null
    node = next
  }
  return node
}

export function listDir(path: string): VNode[] {
  const node = getNode(path)
  if (!node || node.type !== 'dir' || !node.children) return []
  return [...node.children].sort((a, b) => {
    if (a.type !== b.type) return a.type === 'dir' ? -1 : 1
    return a.name.localeCompare(b.name)
  })
}

export function readFile(path: string): string | null {
  const node = getNode(path)
  if (!node || node.type !== 'file') return null
  return node.content ?? ''
}

export function writeFile(path: string, content: string): boolean {
  const node = getNode(path)
  if (!node || node.type !== 'file') return false
  node.content = content
  node.size = content.length
  node.mtime = nowLabel()
  return true
}

export function createFile(dirPath: string, name: string, content = ''): VNode | null {
  const node = getNode(dirPath)
  if (!node || node.type !== 'dir' || !node.children) return null
  if (node.children.some((c) => c.name === name)) return null
  const n = file(name, content, 'text', nowLabel())
  node.children.push(n)
  return n
}

export function createDir(dirPath: string, name: string): VNode | null {
  const node = getNode(dirPath)
  if (!node || node.type !== 'dir' || !node.children) return null
  if (node.children.some((c) => c.name === name)) return null
  const n = dir(name, [], nowLabel())
  node.children.push(n)
  return n
}

export function removeNode(path: string): boolean {
  const parent = getNode(parentPath(path))
  if (!parent || parent.type !== 'dir' || !parent.children) return false
  const name = baseName(path)
  const i = parent.children.findIndex((c) => c.name === name)
  if (i < 0) return false
  parent.children.splice(i, 1)
  return true
}

export function renameNode(path: string, newName: string): boolean {
  const node = getNode(path)
  const parent = getNode(parentPath(path))
  if (!node || !parent || parent.type !== 'dir' || !parent.children) return false
  if (parent.children.some((c) => c.name === newName && c !== node)) return false
  node.name = newName
  node.mtime = nowLabel()
  return true
}

/* ───────────── 展示工具 ───────────── */

function pad(n: number): string {
  return n < 10 ? '0' + n : String(n)
}

export function nowLabel(): string {
  const d = new Date()
  return `${d.getMonth() + 1}月 ${d.getDate()} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

export function formatSize(n?: number): string {
  if (n == null) return '—'
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / 1024 / 1024).toFixed(1)} MB`
}

export function fileKindOf(name: string): string {
  const ext = name.slice(name.lastIndexOf('.') + 1).toLowerCase()
  if (['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg'].includes(ext)) return 'image'
  if (['mp3', 'flac', 'wav', 'ogg', 'm4a'].includes(ext)) return 'audio'
  if (['mp4', 'mkv', 'webm', 'mov'].includes(ext)) return 'video'
  if (['zip', 'tar', 'gz', 'xz', 'iso', 'deb', 'rpm'].includes(ext)) return 'archive'
  if (['rs', 'ts', 'js', 'vue', 'py', 'json', 'toml', 'sh', 'css', 'html'].includes(ext)) return 'code'
  if (['md', 'markdown'].includes(ext)) return 'markdown'
  if (['desktop', 'conf', 'cfg', 'ini', 'log'].includes(ext)) return 'text'
  return 'text'
}

/** 文件类型 → Linuxfx 位图图标（优先于 iconForNode 的 Remix 字形） */
export function imgForNode(node: VNode, theme: string): string {
  return fileIconUrl(kindOfNode(node), theme)
}

/** 节点 → 图标主题里的文件类型 */
function kindOfNode(node: VNode): FileKindId {
  if (node.type === 'dir') return 'folder'
  switch (node.kind) {
    case 'image':
    case 'audio':
    case 'video':
    case 'archive':
    case 'code':
    case 'markdown':
    case 'binary':
      return node.kind
    default:
      return 'text'
  }
}

/** 文件类型 → Remix 图标名 */
export function iconForNode(node: VNode): string {
  if (node.type === 'dir') return 'ri-folder-3-fill'
  switch (node.kind) {
    case 'image':
      return 'ri-image-2-fill'
    case 'audio':
      return 'ri-music-2-fill'
    case 'video':
      return 'ri-movie-2-fill'
    case 'archive':
      return 'ri-archive-2-fill'
    case 'code':
      return 'ri-code-s-slash-fill'
    case 'markdown':
      return 'ri-markdown-fill'
    case 'binary':
      return 'ri-file-code-fill'
    default:
      return 'ri-file-text-fill'
  }
}

/** 文件类型 → 图标颜色 */
export function colorForNode(node: VNode): string {
  if (node.type === 'dir') return '#e8b04b'
  switch (node.kind) {
    case 'image':
      return '#5bc8a8'
    case 'audio':
      return '#c07ce8'
    case 'video':
      return '#e87c9c'
    case 'archive':
      return '#e8a05b'
    case 'code':
      return '#5b9ce8'
    case 'markdown':
      return '#8ba8e8'
    default:
      return '#9a9aa5'
  }
}

/** 终端命令用：把路径列成树 */
export function treeOf(path: string, prefix = '', depth = 0): string[] {
  const nodes = listDir(path)
  const out: string[] = []
  nodes.forEach((n, i) => {
    const last = i === nodes.length - 1
    out.push(`${prefix}${last ? '└── ' : '├── '}${n.name}`)
    if (n.type === 'dir' && depth < 2) {
      out.push(...treeOf(`${path}/${n.name}`, `${prefix}${last ? '    ' : '│   '}`, depth + 1))
    }
  })
  return out
}
