/**
 * ContainerLinux 系统应用 —— 内容模型
 *
 * 43 个应用全部由 CtApp.vue + CtBlock.vue 数据驱动渲染，
 * 内容取自《ContainerLinux 文档合集》（v6.1 / D38）的真实术语与数字。
 */
export interface CtBlock {
  /** 小部件类型 */
  t: string
  title?: string
  sub?: string
  icon?: string
  badge?: string
  tone?: string
  desc?: string
  text?: string
  lang?: string
  code?: string
  value?: string
  hint?: string
  center?: string
  unit?: string
  options?: string[]
  items?: any[]
  cols?: string[]
  rows?: any[][]
  lines?: any[]
  points?: number[]
  [key: string]: any
}

export interface CtPage {
  id: string
  label: string
  icon: string
  blocks: CtBlock[]
}

export interface CtAppDef {
  id: string
  name: string
  sub: string
  icon: string
  from: string
  to: string
  group: string
  status: string
  desc: string
  fabIcon: string
  tier?: 'app' | 'system' | 'daemon' | 'skip'
  pages: CtPage[]
}
