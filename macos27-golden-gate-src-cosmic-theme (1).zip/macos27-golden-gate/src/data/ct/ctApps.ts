/* 本文件由 gen/ctgen.py 自动生成，请勿手工编辑。
 * 数据源：《ContainerLinux 文档合集》v6.1 / D38，共 48 个系统应用。 */
import type { CtAppDef } from './ctTypes'

export const ctApps: CtAppDef[] = [
  {
    "id": "ct-overview", "tier": "app",
    "name": "系统总览",
    "sub": "ContainerLinux v6.1",
    "icon": "ri-planet-line",
    "from": "#3b6fd4",
    "to": "#6f9de8",
    "group": "CT 系统底座",
    "status": "运行中",
    "desc": "九层模型 · 三平面 · 双运行模式 · CT Runtime 分层",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "overview",
        "label": "概览",
        "icon": "ri-dashboard-3-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-planet-line",
            "badge": "v6.1 · D38",
            "title": "ContainerLinux",
            "tone": "blue",
            "desc": "不依赖任何发行版的独立 Linux：CT-Kernel 固定基座 + CT 功能集 + 可删可换的发行版槽位。名字里没有发行版，架构里也没有。"
          },
          {
            "t": "kpis",
            "title": "系统状态",
            "items": [
              {
                "v": "9",
                "label": "架构层数",
                "unit": "层",
                "tone": ""
              },
              {
                "v": "3",
                "label": "独立平面",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "2",
                "label": "运行模式",
                "unit": "种",
                "tone": ""
              },
              {
                "v": "D38",
                "label": "对齐轮次",
                "unit": "",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "cards",
            "title": "三平面视图",
            "sub": "各自独立演进、通过稳定契约组合",
            "items": [
              {
                "icon": "ri-settings-3-line",
                "title": "Kernel 平面",
                "desc": "CT-Kernel 发行版无关，ctk-old/ctk-new 双档，契约 B：标准 Linux ABI",
                "badge": "地基",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-apps-2-line",
                "title": "Distro 平面",
                "desc": "Ubuntu 26.04 默认；Debian/Fedora/arch/openSUSE 可换装，契约 A：freedesktop + FHS",
                "badge": "租客",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-magic-line",
                "title": "CT 平面",
                "desc": "体验层：TUI / ct-shell / 原子模块 / Wine Direct / LSA / 三层存储 / 模式体系",
                "badge": "精装",
                "tone": "violet",
                "tags": []
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "单一产品形态",
            "text": "出厂 = CT-Kernel + CT 功能集（L0–L4 分层第一方全能力平台）+ Ubuntu 预装槽位（可删）。删掉发行版即进入「零发行版模式」，全部 CT 功能照常日用。"
          }
        ]
      },
      {
        "id": "layers",
        "label": "九层模型",
        "icon": "ri-node-tree",
        "blocks": [
          {
            "t": "steps",
            "title": "自底向上的九层",
            "items": [
              {
                "n": "1",
                "title": "CT-Kernel 通用内核层",
                "desc": "唯一底座：ctk-old/ctk-new 双档、CachyOS 补丁集、NTSync/binder/ct-ko 内置、LinuxBoot 引导链",
                "tone": "blue"
              },
              {
                "n": "2",
                "title": "发行版用户态层",
                "desc": "Ubuntu 26.04 默认；Btrfs 三层存储 / exFAT 统一数据分区 / rec 恢复分区 / RamOS",
                "tone": "teal"
              },
              {
                "n": "3",
                "title": "系统服务层",
                "desc": "PipeWire / ct-netd + ct-download / RDBus / RSystemd / CT-Rust 工具集",
                "tone": "teal"
              },
              {
                "n": "4",
                "title": "交互层",
                "desc": "ct-shell + CTDesktop + TUI 控制中心 + EyeHand Fusion + CTSuperTerminal + 开机动画",
                "tone": "violet"
              },
              {
                "n": "5",
                "title": "兼容性子系统",
                "desc": "Wine Direct + NTSync + DXVK/VKD3D-Proton + LSA + DevVM",
                "tone": "orange"
              },
              {
                "n": "6",
                "title": "原子进程架构",
                "desc": "atom-*.so 签名出厂 + ct-core（Resources）+ RDBus / RSystemd / .cte / .ko",
                "tone": "amber"
              },
              {
                "n": "7",
                "title": "统一应用管理",
                "desc": "containerlinux-app-manager 智能路由 + containerlinux-power-shift 十系统模式",
                "tone": "blue"
              },
              {
                "n": "8",
                "title": "应用生态",
                "desc": "Linux 原生 / Wine Direct / Android(LSA) / DevVM / 蜂群应用",
                "tone": "green"
              },
              {
                "n": "9",
                "title": "万物互联与蜂群协作",
                "desc": "剪贴板同步 / 键鼠共享 / 文件传输 / 应用接续 / P2P 计算池 / 蜂群调度",
                "tone": "pink"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "读法",
            "text": "第一层（CT-Kernel）是地基，第二层（发行版用户态）是装上去的那一层——「装你喜欢的发行版」说的就是往第一层上装第二层这一步。"
          }
        ]
      },
      {
        "id": "stack",
        "label": "技术栈",
        "icon": "ri-stack-line",
        "blocks": [
          {
            "t": "table",
            "title": "技术栈总表",
            "cols": [
              "层",
              "选型",
              "说明"
            ],
            "rows": [
              [
                "内核",
                "CachyOS 定制 CT-Kernel",
                "ctk-old / ctk-new 双档，四格式分发"
              ],
              [
                "图形",
                "Smithay 直连自研合成器",
                "simple-desktop + ct-gpu GLES2"
              ],
              [
                "系统服务",
                "Rust（RDBus / RSystemd）",
                "原子化，D-Bus 原生协议"
              ],
              [
                "兼容",
                "Wine Direct / LSA",
                "三层翻译 + 双后端调度"
              ],
              [
                "存储",
                "Btrfs COW + exFAT",
                "三层存储 + 统一数据分区"
              ],
              [
                "工具链",
                "CT-Rust Tier 0–3",
                "uutils / sudo-rs / ripgrep 等"
              ]
            ]
          },
          {
            "t": "chips",
            "title": "v6.1 十大架构要点",
            "items": [
              "通用内核",
              "CT 依赖显式编入",
              "CT-Rust Tier 0-3",
              "原子架构",
              ".cte + .ko",
              "Smithay 自研合成器",
              "三层自适应存储",
              "双运行模式",
              "代码库实底 2.4 万行",
              "COSMIC 魔改应用"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-kernel", "tier": "app",
    "name": "内核管理",
    "sub": "CT-Kernel / ctk",
    "icon": "ri-cpu-line",
    "from": "#4a5bc4",
    "to": "#7d8ce8",
    "group": "CT 系统底座",
    "status": "ctk-new 档",
    "desc": "双档内核 · governor · EPP · 更新通道 · 四格式分发",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "kernel",
        "label": "内核档位",
        "icon": "ri-cpu-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-cpu-line",
            "badge": "基于 CachyOS",
            "title": "CT-Kernel 通用内核",
            "tone": "blue",
            "desc": "「通用」= 同一份内核能托起任意发行版用户态；内核与发行版解耦，老机新机各得其所。"
          },
          {
            "t": "segments",
            "title": "当前运行档",
            "options": [
              "ctk-old（x86-64 v1）",
              "ctk-new（v3/v4/znver4）"
            ],
            "value": "ctk-new（v3/v4/znver4）",
            "hint": "smart-tune 开机按 CPU 判档自动选择"
          },
          {
            "t": "cards",
            "title": "双档对照",
            "items": [
              {
                "icon": "ri-computer-line",
                "title": "ctk-old",
                "desc": "x86-64 v1 基线档，覆盖老硬件；CachyOS base patchset 共享",
                "badge": "兼容",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-rocket-2-line",
                "title": "ctk-new",
                "desc": "v3/v4/znver4 优化档；LLVM ThinLTO、BORE/EEVDF、BBR3、MGLRU、sched-ext",
                "badge": "性能",
                "tone": "blue",
                "tags": [
                  "ThinLTO",
                  "BORE",
                  "MGLRU"
                ]
              }
            ]
          },
          {
            "t": "toggles",
            "title": "CT 专属内核配置块",
            "items": [
              {
                "label": "NTSync",
                "desc": "Windows 同步原语内核直通",
                "on": true,
                "tone": "good"
              },
              {
                "label": "binder_linux",
                "desc": "LSA 安卓子系统 binder 设备",
                "on": true,
                "tone": "good"
              },
              {
                "label": "ct-ko 中继器",
                "desc": "/dev/containerlinux 内核插件通道",
                "on": true,
                "tone": "good"
              },
              {
                "label": "ct_overdrive / ct_ultra_saver",
                "desc": "过载与超级省电 sysfs 接口",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "Secure Boot 签名",
                "desc": "内核与模块统一 CT 签名链",
                "on": true,
                "tone": "info"
              }
            ]
          }
        ]
      },
      {
        "id": "tune",
        "label": "调频与电源",
        "icon": "ri-speed-mini-line",
        "blocks": [
          {
            "t": "kpis",
            "title": "运行时",
            "items": [
              {
                "v": "performance",
                "label": "当前 governor",
                "unit": "",
                "tone": "accent"
              },
              {
                "v": "0",
                "label": "EPP hint",
                "unit": "",
                "tone": ""
              },
              {
                "v": "4.8",
                "label": "CPU 频率",
                "unit": "GHz",
                "tone": ""
              },
              {
                "v": "62",
                "label": "核心温度",
                "unit": "°C",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "bars",
            "title": "governor 全量编入",
            "items": [
              {
                "label": "performance",
                "pct": 100,
                "tone": "accent"
              },
              {
                "label": "schedutil",
                "pct": 76,
                "tone": ""
              },
              {
                "label": "powersave",
                "pct": 42,
                "tone": ""
              },
              {
                "label": "conservative",
                "pct": 30,
                "tone": ""
              },
              {
                "label": "ondemand",
                "pct": 24,
                "tone": ""
              }
            ]
          },
          {
            "t": "code",
            "title": "运行时切换命令",
            "code": "# 两档内核通用\ncpupower frequency-set -g performance\n# ctk-new 档 EPP 调节\necho 0 > /sys/devices/system/cpu/cpu0/cpufreq/energy_perf_bias\n# 持久化\nsystemctl enable cpupower",
            "lang": "bash"
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与系统模式联动",
            "text": "containerlinux-power-shift 监听模式切换，分解下发 cpufreq sysfs / cgroup / 内核模块参数三平面；预检 → 应用（事务）→ 失败回滚三段式保证原子性。"
          }
        ]
      },
      {
        "id": "dist",
        "label": "分发与更新",
        "icon": "ri-download-cloud-2-line",
        "blocks": [
          {
            "t": "cards",
            "title": "四格式打包矩阵",
            "items": [
              {
                "icon": "ri-file-code-fill",
                "title": ".deb",
                "desc": "Ubuntu / Debian",
                "badge": "一级",
                "tone": "orange",
                "tags": []
              },
              {
                "icon": "ri-file-code-fill",
                "title": ".rpm",
                "desc": "Fedora / openSUSE",
                "badge": "二级",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-file-code-fill",
                "title": "pacman",
                "desc": "arch 系 / CachyOS",
                "badge": "一级",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-archive-2-line",
                "title": "tar.xz",
                "desc": "通用分发（+ headers）",
                "badge": "DKMS",
                "tone": "violet",
                "tags": []
              }
            ]
          },
          {
            "t": "timeline",
            "title": "内核更新通道",
            "items": [
              {
                "time": "stable",
                "title": "稳定通道",
                "desc": "CT 签名 + 原子更新，随 CT Runtime 分发",
                "tone": "good"
              },
              {
                "time": "lts",
                "title": "长期支持",
                "desc": "双档分别维护，老机持续在列",
                "tone": "blue"
              },
              {
                "time": "testing",
                "title": "测试通道",
                "desc": "CI 全矩阵验证后合入",
                "tone": "warn"
              },
              {
                "time": "rescue",
                "title": "ESP 救援副本",
                "desc": "L0 常驻，内核更新失败可回退",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "chips",
            "title": "CT 配置块",
            "items": [
              "BORE/EEVDF",
              "BBR3",
              "MGLRU",
              "sched-ext",
              "ThinLTO",
              "NTSync",
              "binder",
              "ct-ko",
              "HugePages",
              "PREEMPT"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-boot", "tier": "system",
    "name": "引导与智能调参",
    "sub": "LinuxBoot + smart-tune",
    "icon": "ri-rocket-2-line",
    "from": "#3f5168",
    "to": "#6f86a8",
    "group": "CT 系统底座",
    "status": "已就绪",
    "desc": "五阶段启动 · CPU 判档 · 驱动注入 · kexec 交接",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "boot",
        "label": "启动流程",
        "icon": "ri-flight-takeoff-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-rocket-2-line",
            "badge": "initramfs < 5MB",
            "title": "LinuxBoot 智能引导链",
            "tone": "blue",
            "desc": "用 Linux 内核当 bootloader：极简引导内核 + u-root → smart-tune.sh 开机「看面相配药方」→ kexec 交接 ctk-old/new。"
          },
          {
            "t": "steps",
            "title": "五阶段启动流程",
            "items": [
              {
                "n": "①",
                "title": "固件加载极简引导内核",
                "desc": "LinuxBoot（Linux as bootloader），initramfs < 5MB",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "smart-tune.sh 智能调参",
                "desc": "CPU 代际判定 / 触摸校准 / 驱动注入 / 动态 cmdline",
                "tone": "accent"
              },
              {
                "n": "③",
                "title": "选定内核档位",
                "desc": "按判档结果选择 ctk-old 或 ctk-new",
                "tone": "teal"
              },
              {
                "n": "④",
                "title": "kexec 交接",
                "desc": "无重启切换到目标内核，注入专有驱动包",
                "tone": "violet"
              },
              {
                "n": "⑤",
                "title": "CT Runtime 分层装载",
                "desc": "L0→L4 按运行档与槽位探测装载，开机动画（mpv）",
                "tone": "green"
              }
            ]
          },
          {
            "t": "logs",
            "title": "本次启动日志",
            "lines": [
              {
                "t": "0.000",
                "text": "LinuxBoot: minimal kernel up, u-root init",
                "tone": "good"
              },
              {
                "t": "0.184",
                "text": "smart-tune: CPU = Zen4 → ctk-new selected",
                "tone": "accent"
              },
              {
                "t": "0.221",
                "text": "smart-tune: touch calibration loaded",
                "tone": ""
              },
              {
                "t": "0.306",
                "text": "smart-tune: cmdline = quiet splash ct_mode=standard",
                "tone": "info"
              },
              {
                "t": "0.512",
                "text": "kexec: handing over to ctk-new (6.16-ct)",
                "tone": "good"
              },
              {
                "t": "1.043",
                "text": "CT Runtime: L0/L1/L2 mounted, L3/L4 standby",
                "tone": ""
              }
            ]
          }
        ]
      },
      {
        "id": "tune",
        "label": "调参项",
        "icon": "ri-equalizer-line",
        "blocks": [
          {
            "t": "toggles",
            "title": "开机自动判定",
            "items": [
              {
                "label": "CPU 代际判档",
                "desc": "x86-64 v1 / v3 / v4 / znver4 → ctk-old / ctk-new",
                "on": true,
                "tone": "good"
              },
              {
                "label": "触摸校准",
                "desc": "触摸屏设备自动注入校准参数",
                "on": true,
                "tone": "good"
              },
              {
                "label": "专有驱动注入",
                "desc": "EROFS + zstd 驱动包，按内核版本命名",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "动态 cmdline",
                "desc": "按设备组合生成启动参数",
                "on": true,
                "tone": "info"
              },
              {
                "label": "奇葩设备兼容策略",
                "desc": "退化路径矩阵兜底",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "table",
            "title": "专有驱动包工具链",
            "cols": [
              "层级",
              "内容",
              "落点"
            ],
            "rows": [
              [
                "引导内核",
                "砍到只剩渣：仅保留 KMS / 存储 / 网络最小集",
                "initramfs"
              ],
              [
                "驱动包",
                "EROFS + zstd，按内核版本命名",
                "/CTF/Images/drivers/"
              ],
              [
                "CT Runtime",
                "L0 核心层常驻 ESP 救援副本",
                "ESP / L0"
              ],
              [
                "回退",
                "非 LinuxBoot 直启路径",
                "GRUB 参数 ct_mode=tty"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "范围墙",
            "text": "v1 明确不做：不替换固件、不改动 Secure Boot 信任根、不接管 Windows 引导分区。裸机双系统为可选切换项。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-distro", "tier": "system",
    "name": "发行版管理器",
    "sub": "Distro Slot",
    "icon": "ri-exchange-line",
    "from": "#2b7fb8",
    "to": "#5fb6e0",
    "group": "CT 系统底座",
    "status": "有发行版模式",
    "desc": "双运行模式 · 换装目录 · 状态转换 · 能力边界",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "slot",
        "label": "槽位状态",
        "icon": "ri-hard-drive-3-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-exchange-line",
            "badge": "active → Ubuntu 26.04 LTS",
            "title": "发行版槽位",
            "tone": "teal",
            "desc": "CT-Kernel 底座上承载发行版用户态的可替换位置：换租客不搬家——ct-data 与 CT 层不动。"
          },
          {
            "t": "segments",
            "title": "运行模式",
            "options": [
              "有发行版模式（默认）",
              "零发行版模式"
            ],
            "value": "有发行版模式（默认）",
            "hint": "两模式随时可切换"
          },
          {
            "t": "kpis",
            "title": "切换代价",
            "items": [
              {
                "v": "20–40",
                "label": "装发行版",
                "unit": "分钟",
                "tone": ""
              },
              {
                "v": "<5",
                "label": "卸载",
                "unit": "分钟",
                "tone": ""
              },
              {
                "v": "0",
                "label": "CT 层改动",
                "unit": "",
                "tone": ""
              },
              {
                "v": "4",
                "label": "官方换装目录",
                "unit": "个",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "cards",
            "title": "CT 官方可安装发行版",
            "items": [
              {
                "icon": "ri-checkbox-circle-fill",
                "title": "Ubuntu 26.04 LTS",
                "desc": "debootstrap / 官方 ISO · 一级完整验证",
                "badge": "出厂",
                "tone": "orange",
                "tags": []
              },
              {
                "icon": "ri-checkbox-circle-line",
                "title": "Debian 13+",
                "desc": "debootstrap · 一级",
                "badge": "可换装",
                "tone": "pink",
                "tags": []
              },
              {
                "icon": "ri-checkbox-circle-line",
                "title": "Fedora 40+",
                "desc": "dnf --installroot · 二级 CI 全矩阵",
                "badge": "可换装",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-checkbox-circle-line",
                "title": "arch 系 / openSUSE",
                "desc": "pacstrap / zypper · 二级",
                "badge": "可换装",
                "tone": "teal",
                "tags": []
              }
            ]
          }
        ]
      },
      {
        "id": "modes",
        "label": "双模式能力",
        "icon": "ri-layout-grid-line",
        "blocks": [
          {
            "t": "table",
            "title": "能力边界矩阵",
            "cols": [
              "能力",
              "有发行版模式",
              "零发行版模式"
            ],
            "rows": [
              [
                "CT Runtime L0–L4",
                "✓",
                "✓"
              ],
              [
                "TUI / CTTY / CTSuperTerminal",
                "✓",
                "✓"
              ],
              [
                "CTDesktop / LSW / LSA",
                "✓",
                "✓"
              ],
              [
                ".cte 静态加载路径",
                "✓",
                "✓（唯一入口）"
              ],
              [
                "deb / rpm 应用运行器",
                "✓",
                "随发行版在位解锁"
              ],
              [
                "bare profile 原子停运",
                "✓",
                "✓（第三方组件专用）"
              ]
            ]
          },
          {
            "t": "timeline",
            "title": "槽位状态转换",
            "items": [
              {
                "time": "出厂",
                "title": "Ubuntu 26.04 预装",
                "desc": "CT 层 + ct-data 就位，active 指针指向槽位",
                "tone": "good"
              },
              {
                "time": "换装",
                "title": "删旧装新 20–40 分钟",
                "desc": "引导链与 active 指针适配，CI 矩阵纳入",
                "tone": "accent"
              },
              {
                "time": "卸载",
                "title": "< 5 分钟",
                "desc": "槽位空置，进入零发行版模式",
                "tone": "blue"
              },
              {
                "time": "复用",
                "title": "装机 / 换装间隙 / 救援 / 嵌入式",
                "desc": "同一机制，全部 CT 功能照常",
                "tone": "violet"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "一鱼四吃",
            "text": "零发行版日用 / 安装器载体 / 救援环境 / 嵌入式底座——四者复用同一套「槽位为空」机制，不是独立产品形态。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-runtime", "tier": "system",
    "name": "CT Runtime 分层",
    "sub": "L0–L4 装配",
    "icon": "ri-stack-line",
    "from": "#7d4fd1",
    "to": "#a97ef0",
    "group": "CT 系统底座",
    "status": "L0–L4 已挂载",
    "desc": "每层独立 EROFS 镜像 · 独立原子更新 · 槽位探测装载",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "layers",
        "label": "分层装配",
        "icon": "ri-stack-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-stack-line",
            "badge": "随 CT-Kernel 一同分发",
            "title": "CT Runtime 第一方用户态平台",
            "tone": "violet",
            "desc": "分层装配：从地板到全屋精装。每层独立 EROFS 镜像、独立原子更新，L0 核心层随内核原子更新且 ESP 常驻救援副本。"
          },
          {
            "t": "table",
            "title": "L0–L4 分层装配",
            "sub": "每层独立 EROFS 镜像、独立原子更新",
            "cols": [
              "层",
              "组成",
              "体积/定位"
            ],
            "rows": [
              [
                "L0 核心层",
                "TUI / CTTY / .cte 加载",
                "约 35–60MB · ESP 常驻救援副本"
              ],
              [
                "L1 超级终端",
                "CTSuperTerminal（ctty-edex）",
                "零发行版模式的驾驶舱"
              ],
              [
                "L2 CTDesktop",
                "simple-desktop + 桌面应用套件",
                "自包含图形栈"
              ],
              [
                "L3 LSW",
                "Windows 兼容子系统",
                "层内私有库自包含"
              ],
              [
                "L4 LSA",
                "安卓兼容子系统",
                "双后端调度"
              ]
            ]
          },
          {
            "t": "progress",
            "title": "装载状态",
            "items": [
              {
                "label": "L0 核心层",
                "pct": 100,
                "sub": "常驻 ESP · 救援副本",
                "meta": "已挂载",
                "tone": "good"
              },
              {
                "label": "L1 CTSuperTerminal",
                "pct": 100,
                "sub": "零发行版主界面",
                "meta": "已挂载",
                "tone": "good"
              },
              {
                "label": "L2 CTDesktop",
                "pct": 100,
                "sub": "按机裁剪 Mesa + ct-shell",
                "meta": "已挂载",
                "tone": "good"
              },
              {
                "label": "L3 LSW",
                "pct": 72,
                "sub": "按需装载 · 私有库自包含",
                "meta": "待命",
                "tone": "accent"
              },
              {
                "label": "L4 LSA",
                "pct": 40,
                "sub": "双后端调度 · 按需",
                "meta": "待命",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "装载判定",
            "text": "开机由引导链探测发行版槽位：有发行版模式装载 L0–L2 并解锁运行器阶梯；零发行版模式 L0–L4 全部可用，.cte 静态加载路径成为第三方插件唯一入口。"
          }
        ]
      },
      {
        "id": "bare",
        "label": "bare profile",
        "icon": "ri-settings-5-line",
        "blocks": [
          {
            "t": "cards",
            "title": "同一份系统组件的两个运行档",
            "items": [
              {
                "icon": "ri-server-line",
                "title": "完整 profile",
                "desc": "RSystemd / RDBus 全量原子运行，系统服务与第一方子系统齐备",
                "badge": "默认",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-puzzle-line",
                "title": "bare profile",
                "desc": "最小原子集运行档式：系统服务与第一方子系统原子运行，专为第三方组件设计的原子停运",
                "badge": "经济档",
                "tone": "teal",
                "tags": []
              }
            ]
          },
          {
            "t": "code",
            "title": "CTF 自有命名空间",
            "code": "/CTF/\n├── Core       # 原子 / 库 / 运行时\n├── Extensions # .cte 插件 / 扩展\n├── Apps       # 应用挂载包\n├── Data       # 用户数据\n├── Config     # netd.toml / p2p / vpn\n└── Images     # 镜像 / 快照",
            "lang": "ctf"
          },
          {
            "t": "chips",
            "title": "两种模式同一张地图",
            "items": [
              "Core",
              "Extensions",
              "Apps",
              "Data",
              "Config",
              "Images",
              "bind 聚合",
              "ESP + ct-data"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-rust", "tier": "skip",
    "name": "CT-Rust 重写中心",
    "sub": "Tier 0–3 四层模型",
    "icon": "ri-code-s-slash-fill",
    "from": "#2f8f7a",
    "to": "#54bfa2",
    "group": "CT 系统底座",
    "status": "进行中",
    "desc": "即插替换 · 现代套件 · 系统服务 · 内核态 · 观察轨",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "tiers",
        "label": "四层重写模型",
        "icon": "ri-node-tree",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-code-s-slash-fill",
            "badge": "三条红线",
            "title": "重写并理顺 Linux 的 C 代码",
            "tone": "teal",
            "desc": "内存安全 + 理顺历史行为 + 减少攻击面。四层模型 Tier 0-3，外加不设里程碑的观察轨候选池。"
          },
          {
            "t": "cards",
            "title": "Tier 0–3",
            "items": [
              {
                "icon": "ri-checkbox-circle-fill",
                "title": "Tier 0 即插即用替换",
                "desc": "uutils coreutils / findutils / diffutils、sudo-rs、sequoia-pgp、gitoxide、busd、rustls",
                "badge": "抢默认",
                "tone": "good",
                "tags": []
              },
              {
                "icon": "ri-apps-2-line",
                "title": "Tier 1 现代 CLI 套件",
                "desc": "eza / bat / fd / ripgrep / zoxide / dust / procs / bottom / hyperfine / starship",
                "badge": "预装不抢默认",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-server-line",
                "title": "Tier 2 系统服务层",
                "desc": "RDBus / RSystemd / ct-netd / ct-download / ct-resolved 新建即 Rust",
                "badge": "新建",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-cpu-line",
                "title": "Tier 3 内核态",
                "desc": "Rust for Linux 驱动与 ct-ko 模块 → Asterinas 长期三层过渡",
                "badge": "实验轨",
                "tone": "violet",
                "tags": []
              }
            ]
          },
          {
            "t": "chips",
            "title": "观察轨候选（季度评审）",
            "items": [
              "Pingora",
              "Volo",
              "Rspack",
              "youki",
              "krata",
              "fuse-backend-rs",
              "Headcrab"
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "准入三条件",
            "text": "观察轨不设里程碑、不抢默认、季度评审；三条件齐备才升入 Tier。明确「暂不重写」清单同样受红线约束。"
          }
        ]
      },
      {
        "id": "integrate",
        "label": "集成与验证",
        "icon": "ri-git-branch-line",
        "blocks": [
          {
            "t": "steps",
            "title": "并存安装三阶段",
            "items": [
              {
                "n": "A",
                "title": "并存区部署",
                "desc": "Rust 版与 GNU 版并存，alternatives 可回退",
                "tone": "blue"
              },
              {
                "n": "B",
                "title": "差分验证",
                "desc": "ct-difftest 对照通过后抢默认",
                "tone": "accent"
              },
              {
                "n": "C",
                "title": "性能基线",
                "desc": "hyperfine 基准 + 三层存储 / 系统模式联动",
                "tone": "green"
              }
            ]
          },
          {
            "t": "bars",
            "title": "重写进度",
            "items": [
              {
                "label": "Tier 0 即插替换",
                "pct": 78,
                "tone": "good"
              },
              {
                "label": "Tier 1 现代套件",
                "pct": 92,
                "tone": "accent"
              },
              {
                "label": "Tier 2 系统服务",
                "pct": 54,
                "tone": ""
              },
              {
                "label": "Tier 3 内核态",
                "pct": 18,
                "tone": "warn"
              },
              {
                "label": "观察轨",
                "pct": 12,
                "tone": "info"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "量化目标",
            "items": [
              {
                "v": "70%",
                "label": "用户空间 C 替换",
                "unit": "",
                "tone": ""
              },
              {
                "v": "0",
                "label": "已知内存安全漏洞",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "3",
                "label": "并存阶段",
                "unit": "段",
                "tone": ""
              },
              {
                "v": "±5%",
                "label": "性能回归容忍",
                "unit": "",
                "tone": "accent"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-difftest", "tier": "skip",
    "name": "差分测试",
    "sub": "ct-difftest",
    "icon": "ri-scales-3-line",
    "from": "#4d6b5a",
    "to": "#79a68c",
    "group": "CT 系统底座",
    "status": "4,771 通过",
    "desc": "Rust 版 vs GNU 版 · 用例矩阵 · 性能基线",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "diff",
        "label": "对照结果",
        "icon": "ri-scales-3-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-scales-3-line",
            "badge": "双胞胎对照考试",
            "title": "ct-difftest 差分测试框架",
            "tone": "green",
            "desc": "Rust 版与 GNU 版逐用例对照：同样的输入、同样的输出、同样的退出码，才算通过。"
          },
          {
            "t": "kpis",
            "title": "本次运行",
            "items": [
              {
                "v": "4,650",
                "label": "协议/core/rpc 单测",
                "unit": "通过",
                "tone": "good"
              },
              {
                "v": "121",
                "label": "集成 / E2E",
                "unit": "通过",
                "tone": "good"
              },
              {
                "v": "98.52",
                "label": "回环下载",
                "unit": "MiB/s",
                "tone": "accent"
              },
              {
                "v": "0",
                "label": "不一致用例",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "progress",
            "title": "套件通过率",
            "items": [
              {
                "label": "uutils coreutils",
                "pct": 100,
                "sub": "GNU coreutils 对照",
                "meta": "2,140 用例",
                "tone": "good"
              },
              {
                "label": "uutils findutils",
                "pct": 99,
                "sub": "find / xargs",
                "meta": "612 用例",
                "tone": "good"
              },
              {
                "label": "sudo-rs",
                "pct": 96,
                "sub": "权限 / 策略边界",
                "meta": "388 用例",
                "tone": "accent"
              },
              {
                "label": "ripgrep / fd",
                "pct": 100,
                "sub": "搜索行为一致性",
                "meta": "905 用例",
                "tone": "good"
              },
              {
                "label": "gitoxide",
                "pct": 87,
                "sub": "git 命令子集",
                "meta": "421 用例",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "logs",
            "title": "最近一次对照",
            "lines": [
              {
                "t": "PASS",
                "text": "coreutils/ls --color=auto … 2,140/2,140",
                "tone": "good"
              },
              {
                "t": "PASS",
                "text": "coreutils/cp --reflink=auto …",
                "tone": "good"
              },
              {
                "t": "PASS",
                "text": "aria2c / ct-download 20MB → 20,971,520 bytes",
                "tone": "good"
              },
              {
                "t": "WARN",
                "text": "gitoxide: 3 例 plumbing 输出顺序差异（已登记）",
                "tone": "warn"
              },
              {
                "t": "INFO",
                "text": "性能基线 hyperfine 已归档 /CTF/Data/bench/",
                "tone": "info"
              }
            ]
          }
        ]
      },
      {
        "id": "cases",
        "label": "用例矩阵",
        "icon": "ri-list-check-2",
        "blocks": [
          {
            "t": "table",
            "title": "对照组",
            "cols": [
              "组件",
              "GNU 原版",
              "Rust 版",
              "状态"
            ],
            "rows": [
              [
                "ls / cp / mv",
                "coreutils 9.x",
                "uutils",
                "通过"
              ],
              [
                "find / xargs",
                "findutils",
                "uutils",
                "通过"
              ],
              [
                "sudo",
                "sudo 1.9",
                "sudo-rs",
                "边界复核"
              ],
              [
                "grep",
                "grep / ripgrep",
                "ripgrep",
                "通过"
              ],
              [
                "aria2",
                "aria2c C++",
                "ct-download",
                "通过"
              ],
              [
                "diff / patch",
                "diffutils",
                "uutils",
                "进行中"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与性能基线联动",
            "text": "差分通过后接入 hyperfine 性能基线；结果与三层存储快照绑定，任何回归可一键回退到 GNU 版（ct-rustctl）。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-rustctl", "tier": "daemon",
    "name": "替换与回退",
    "sub": "ct-rustctl",
    "icon": "ri-restart-line",
    "from": "#c05a3a",
    "to": "#e8916b",
    "group": "CT 系统底座",
    "status": "可回退",
    "desc": "组件替换管理 · 一键回退 C 版 · alternatives",
    "fabIcon": "ri-restart-line",
    "pages": [
      {
        "id": "ctl",
        "label": "替换管理",
        "icon": "ri-exchange-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-restart-line",
            "badge": "红色大按钮",
            "title": "ct-rustctl 替换管理与回退",
            "tone": "orange",
            "desc": "管理 Rust 版与 GNU 版的并存与抢默认；任何组件出问题，一键回退到 C 版。"
          },
          {
            "t": "table",
            "title": "组件替换状态",
            "cols": [
              "组件",
              "当前默认",
              "并存版本",
              "可回退"
            ],
            "rows": [
              [
                "coreutils",
                "uutils",
                "GNU 9.7",
                "✓"
              ],
              [
                "findutils",
                "uutils",
                "GNU 4.10",
                "✓"
              ],
              [
                "sudo",
                "sudo-rs",
                "sudo 1.9.17",
                "✓"
              ],
              [
                "grep",
                "ripgrep",
                "GNU grep",
                "✓"
              ],
              [
                "init",
                "RSystemd",
                "systemd 257",
                "✓"
              ],
              [
                "bus",
                "RDBus",
                "dbus-daemon",
                "✓"
              ],
              [
                "kernel 驱动",
                "ct-ko (Rust)",
                "C 模块",
                "实验轨"
              ]
            ]
          },
          {
            "t": "toggles",
            "title": "回退策略",
            "items": [
              {
                "label": "alternatives 双登记",
                "desc": "Rust / GNU 双版本同时登记，秒级切换",
                "on": true,
                "tone": "good"
              },
              {
                "label": "自动回退",
                "desc": "ct-difftest 连续失败 3 次自动切回 GNU 版",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "回退写操作日志",
                "desc": "时间 / 组件 / 原因 / 结果全量记录",
                "on": true,
                "tone": "info"
              },
              {
                "label": "全局一键回退",
                "desc": "红色大按钮：所有组件一次性回 C 版",
                "on": false,
                "tone": "bad"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "bad",
            "title": "危险操作",
            "text": "「全局一键回退」会把整个用户空间切回 GNU/C 版本，仅在重大兼容事故时使用；执行前需二次确认并写入操作日志。"
          }
        ]
      },
      {
        "id": "history",
        "label": "切换记录",
        "icon": "ri-history-line",
        "blocks": [
          {
            "t": "timeline",
            "title": "最近操作",
            "items": [
              {
                "time": "09-25 14:02",
                "title": "coreutils 抢默认",
                "desc": "uutils 通过 2,140 差分用例",
                "tone": "good"
              },
              {
                "time": "09-24 11:38",
                "title": "sudo-rs 回退",
                "desc": "边界用例 3 例不一致 → GNU sudo",
                "tone": "warn"
              },
              {
                "time": "09-22 09:15",
                "title": "RDBus 试点",
                "desc": "并存区部署，dbus-daemon 保留兜底",
                "tone": "accent"
              },
              {
                "time": "09-20 20:44",
                "title": "性能基线归档",
                "desc": "hyperfine 结果写入 /CTF/Data/bench/",
                "tone": "info"
              }
            ]
          },
          {
            "t": "logs",
            "title": "ct-rustctl.log",
            "lines": [
              {
                "t": "INFO",
                "text": "alternatives registry: 7 components, 14 binaries",
                "tone": ""
              },
              {
                "t": "INFO",
                "text": "fallback guard: difftest-fail-threshold = 3",
                "tone": ""
              },
              {
                "t": "OK",
                "text": "coreutils → uutils (default)",
                "tone": "good"
              },
              {
                "t": "OK",
                "text": "operation logged → session.log",
                "tone": "good"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-atoms", "tier": "daemon",
    "name": "原子进程",
    "sub": "Atomic Process / Atom",
    "icon": "ri-puzzle-line",
    "from": "#4a5bc4",
    "to": "#7d8ce8",
    "group": "原子架构",
    "status": "已签名出厂",
    "desc": "atom-*.so · 成本画像 · 显式 load/unload · D20",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "atom",
        "label": "概念体系",
        "icon": "ri-box-3-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-puzzle-line",
            "badge": "决策 D20",
            "title": "原子进程架构",
            "tone": "blue",
            "desc": "系统服务的内部模块化单元 + 应用可选的按需功能模块。atom-*.so 签名出厂、声明成本画像，显式 load / unload，存放 /CTF/Core/Atoms/。"
          },
          {
            "t": "cards",
            "title": "四个核心概念",
            "items": [
              {
                "icon": "ri-box-3-line",
                "title": "原子进程（Atom）",
                "desc": "系统服务的「零件」，应用的「可选装备」；签名出厂、成本画像、显式装卸",
                "badge": "模块",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-scales-3-line",
                "title": "资源管理器（ct-core）",
                "desc": "约 150 行 [EST]：HashMap + 预算 + LRU 规则，按需加载、按预算释放的「管家」",
                "badge": "Resources",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-instance-line",
                "title": "成本画像（Cost）",
                "desc": "模块声明资源占用估计（内存 / GPU / fd / 线程），供 Resources 决策",
                "badge": "自报",
                "tone": "amber",
                "tags": []
              },
              {
                "icon": "ri-flow-chart",
                "title": "AtomRegistry",
                "desc": "服务侧原子装载与热更新管理器；单例由 rsystemd-pid1（PID 1）持有",
                "badge": "调度员",
                "tone": "violet",
                "tags": []
              }
            ]
          },
          {
            "t": "toggles",
            "title": "运行约束",
            "items": [
              {
                "label": "AtomRegistry 单例",
                "desc": "其它进程经共享内存访问，禁止各自独立 dlopen 第二份注册表（16.4.3）",
                "on": true,
                "tone": "good"
              },
              {
                "label": "成本画像强制声明",
                "desc": "未声明内存 / GPU / fd / 线程的原子不予装载",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "热更新限定系统服务",
                "desc": "无状态模块热更新，应用侧不开放（18.2）",
                "on": true,
                "tone": "info"
              },
              {
                "label": "超级进程（Super-Process）",
                "desc": "多进程共享内存融合为逻辑单一应用——储备概念，不进 v6.0 实现范围",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与挂载包对称",
            "text": "原子（进程内按需管理）与挂载包（系统级按需管理）构成对称：ct-core / Resources 管进程内，Mounts 管系统级，两者都有 evict_idle 规则。"
          }
        ]
      },
      {
        "id": "layout",
        "label": "实现与路线",
        "icon": "ri-git-branch-line",
        "blocks": [
          {
            "t": "code",
            "title": "按需模块 trait",
            "code": "pub trait OnDemand {\n    fn cost(&self) -> Cost;      // 内存 / GPU / fd / 线程\n    fn load(&mut self) -> Result<()>;\n    fn unload(&mut self) -> Result<()>;\n}\n\n// Resources：get::<M>() / release::<M>() / evict_idle()\nlet m = resources.get::<DecoderAtom>()?;",
            "lang": "rust"
          },
          {
            "t": "timeline",
            "title": "原子架构五阶段路线",
            "items": [
              {
                "time": "A1 · 3 周",
                "title": "ct-core 与基础原子",
                "desc": "HashMap + 预算 + LRU 落地，成本画像 schema 冻结",
                "tone": "good"
              },
              {
                "time": "A2 · 3–6 月",
                "title": "RDBus 试点",
                "desc": "原生 D-Bus wire protocol 原子化",
                "tone": "accent"
              },
              {
                "time": "A3 · 6–12 月",
                "title": "桌面环境",
                "desc": "simple-desktop + COSMIC 原子化魔改",
                "tone": "blue"
              },
              {
                "time": "A4 · 12–18 月",
                "title": "RSystemd",
                "desc": "pid1 / logind / udevd 多进程整合",
                "tone": "violet"
              },
              {
                "time": "A5 · 持续",
                "title": "生态建设",
                "desc": "第三方 .cte 原子与挂载包",
                "tone": "green"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "规模指标",
            "items": [
              {
                "v": "~150",
                "label": "ct-core 行数",
                "unit": "[EST]",
                "tone": ""
              },
              {
                "v": "~200",
                "label": "Mounts 行数",
                "unit": "[EST]",
                "tone": ""
              },
              {
                "v": "4",
                "label": "挂载包类型",
                "unit": "种",
                "tone": ""
              },
              {
                "v": "1",
                "label": "AtomRegistry 单例",
                "unit": "个",
                "tone": "accent"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-core", "tier": "daemon",
    "name": "资源管理器",
    "sub": "ct-core / Resources",
    "icon": "ri-scales-3-line",
    "from": "#2f8f7a",
    "to": "#54bfa2",
    "group": "原子架构",
    "status": "运行中",
    "desc": "HashMap + 预算 + LRU · get/release/evict_idle",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "core",
        "label": "核心设计",
        "icon": "ri-dashboard-3-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-scales-3-line",
            "badge": "约 150 行 [EST]",
            "title": "Resources 资源管理器",
            "tone": "teal",
            "desc": "轻量库：HashMap + 预算 + LRU 规则，提供 get::<M>() / release::<M>() / evict_idle()。按需加载、按预算释放的「管家」。"
          },
          {
            "t": "kpis",
            "title": "当前预算",
            "items": [
              {
                "v": "512",
                "label": "内存预算",
                "unit": "MB",
                "tone": ""
              },
              {
                "v": "38",
                "label": "已装载原子",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "12",
                "label": "空闲待回收",
                "unit": "个",
                "tone": "warn"
              },
              {
                "v": "4",
                "label": "LRU 淘汰",
                "unit": "次",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "progress",
            "title": "资源占用",
            "items": [
              {
                "label": "内存",
                "pct": 62,
                "sub": "318 MB / 512 MB",
                "meta": "38 原子",
                "tone": "accent"
              },
              {
                "label": "GPU 显存",
                "pct": 28,
                "sub": "112 MB / 400 MB",
                "meta": "6 原子",
                "tone": "good"
              },
              {
                "label": "文件描述符",
                "pct": 44,
                "sub": "440 / 1000",
                "meta": "38 原子",
                "tone": ""
              },
              {
                "label": "线程池",
                "pct": 35,
                "sub": "14 / 40",
                "meta": "38 原子",
                "tone": "good"
              }
            ]
          },
          {
            "t": "code",
            "title": "核心接口",
            "code": "pub struct Resources {\n    map: HashMap<TypeId, Box<dyn OnDemand>>,\n    budget: Budget,        // 内存 / GPU / fd / 线程\n    lru: LruCache<TypeId, Instant>,\n}\n\nimpl Resources {\n    pub fn get<M: OnDemand>(&mut self) -> Result<&mut M>;\n    pub fn release<M>(&mut self);\n    pub fn evict_idle(&mut self, timeout: Duration);\n}",
            "lang": "rust"
          }
        ]
      },
      {
        "id": "rules",
        "label": "规则与豁免",
        "icon": "ri-list-check-2",
        "blocks": [
          {
            "t": "table",
            "title": "LRU 回收规则",
            "cols": [
              "规则",
              "触发条件",
              "动作"
            ],
            "rows": [
              [
                "evict_idle",
                "空闲超过 idle_timeout_sec",
                "释放无状态原子，保留热路径"
              ],
              [
                "evict_under_pressure",
                "预算占用超阈值",
                "按 LRU 顺序淘汰至阈值内"
              ],
              [
                "persistent",
                "manifest lifecycle = persistent",
                "常驻，豁免 LRU 回收"
              ],
              [
                "on-demand",
                "manifest lifecycle = on-demand",
                "按需装载，空闲即释放"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "显式豁免：RDBus",
            "text": "RDBus 的 manifest 标记 resident = true，显式豁免 ct-core LRU 回收，不作按需原子（16.4.6）——总线一旦被回收，整条 IPC 链路会断。"
          },
          {
            "t": "toggles",
            "title": "运行策略",
            "items": [
              {
                "label": "成本画像准入",
                "desc": "模块自报「我有多重」后才允许 get",
                "on": true,
                "tone": "good"
              },
              {
                "label": "预算硬上限",
                "desc": "超预算时阻塞新装载而非 OOM",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "系统服务无 LRU 需求",
                "desc": "RSystemd / RDBus 常驻路径走独立分支（15.7）",
                "on": true,
                "tone": "info"
              },
              {
                "label": "零拷贝通信",
                "desc": "dmabuf / 共享内存传递，避免序列化（18.1）",
                "on": true,
                "tone": "good"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-mounts", "tier": "daemon",
    "name": "挂载包与冷热调度",
    "sub": "Mountable & Hot-Cold",
    "icon": "ri-archive-2-line",
    "from": "#b5813a",
    "to": "#dcae63",
    "group": "原子架构",
    "status": "38 个已登记",
    "desc": "四种挂载包 · 冷热三态 · HotColdScheduler",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "mount",
        "label": "挂载包",
        "icon": "ri-box-1-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-archive-2-line",
            "badge": "只读 .erofs + manifest.toml + 签名",
            "title": "挂载包（Mountable）",
            "tone": "amber",
            "desc": "按需挂载的「镜像包裹」：只读镜像 + 说明书 + 签名。四种类型，Mounts 管理器（约 200 行 [EST]）与 Resources 对称。"
          },
          {
            "t": "cards",
            "title": "四种挂载包类型",
            "items": [
              {
                "icon": "ri-box-3-line",
                "title": "resource",
                "desc": "资源包：字体 / 图标 / 模型 / 词库",
                "badge": "资源",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-apps-2-line",
                "title": "application",
                "desc": "应用包：完整应用及其私有依赖",
                "badge": "应用",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-cpu-line",
                "title": "driver",
                "desc": "驱动包：EROFS + zstd，按内核版本命名",
                "badge": "驱动",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-movie-line",
                "title": "scenario",
                "desc": "场景包：DML 动态挂载的 Kali 等场景镜像",
                "badge": "场景",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "code",
            "title": "说明书 schema（manifest.toml）",
            "code": "[mountable]\nname = \"ct-kali-scenario\"\ntype  = \"scenario\"\nversion = \"2026.09\"\nsignature = \"ct-sign-v2\"\n\n[lifecycle]\npolicy = \"on-demand\"        # persistent | on-demand\nidle_timeout_sec = 600\npack_after_idle_days = 7\nmin_keep_sec = 60",
            "lang": "toml"
          },
          {
            "t": "toggles",
            "title": "Mounts 管理器",
            "items": [
              {
                "label": "mount / unmount",
                "desc": "按需挂载与卸载，签名校验后置",
                "on": true,
                "tone": "good"
              },
              {
                "label": "evict_idle",
                "desc": "空闲超时自动卸载",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "evict_under_pressure",
                "desc": "磁盘压力触发立即归档",
                "on": true,
                "tone": "good"
              },
              {
                "label": "AppRegistry 账本",
                "desc": "记录热/温/冷、last_access、启动次数、lifecycle",
                "on": true,
                "tone": "info"
              }
            ]
          }
        ]
      },
      {
        "id": "cold",
        "label": "冷热三态",
        "icon": "ri-temp-cold-line",
        "blocks": [
          {
            "t": "steps",
            "title": "应用的三种存储 / 运行形态",
            "items": [
              {
                "n": "热",
                "title": "热态",
                "desc": "解包目录，可写；直接运行，无挂载开销",
                "tone": "bad"
              },
              {
                "n": "温",
                "title": "温态",
                "desc": "打包挂载，只读；EROFS 挂载即用",
                "tone": "accent"
              },
              {
                "n": "冷",
                "title": "冷态",
                "desc": "打包未挂载，按需恢复；仅占归档空间",
                "tone": "blue"
              }
            ]
          },
          {
            "t": "table",
            "title": "HotColdScheduler 调度规则",
            "cols": [
              "条件",
              "阈值",
              "动作"
            ],
            "rows": [
              [
                "候选打包",
                "7 天未访问",
                "热 → 温"
              ],
              [
                "强制打包",
                "30 天未访问",
                "热/温 → 温"
              ],
              [
                "归档",
                "90 天未访问",
                "温 → 冷"
              ],
              [
                "磁盘压力",
                "立即",
                "全部触发 evict"
              ],
              [
                "自动解包",
                "7 天内启动 ≥ 3 次",
                "冷/温 → 热"
              ]
            ]
          },
          {
            "t": "rings",
            "title": "当前分布",
            "items": [
              {
                "label": "热态",
                "pct": 42,
                "tone": "bad"
              },
              {
                "label": "温态",
                "pct": 35,
                "tone": "accent"
              },
              {
                "label": "冷态",
                "pct": 23,
                "tone": "blue"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "作息表",
            "text": "生命周期策略 persistent（常驻）/ on-demand（按需），配合 idle_timeout_sec / pack_after_idle_days / min_keep_sec 三个参数，由 AppRegistry 记帐后驱动调度。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-rdbus", "tier": "daemon",
    "name": "RDBus 总线",
    "sub": "原生 D-Bus (Rust)",
    "icon": "ri-flow-chart",
    "from": "#2b7fb8",
    "to": "#5fb6e0",
    "group": "原子架构",
    "status": "resident = true",
    "desc": "wire protocol 原子化 · 共享内存 · 豁免 LRU",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "bus",
        "label": "总线状态",
        "icon": "ri-flow-chart",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-flow-chart",
            "badge": "契约 D27",
            "title": "RDBus 原生 D-Bus 协议实现",
            "tone": "cyan",
            "desc": "说标准 D-Bus 话的 Rust 总线：原生 wire protocol 原子化实现，manifest 标记 resident = true，显式豁免 ct-core LRU 回收。"
          },
          {
            "t": "kpis",
            "title": "运行时",
            "items": [
              {
                "v": "18",
                "label": "已注册服务",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "142",
                "label": "活动连接",
                "unit": "条",
                "tone": ""
              },
              {
                "v": "0.8",
                "label": "平均延迟",
                "unit": "ms",
                "tone": "good"
              },
              {
                "v": "0",
                "label": "序列化拷贝",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "cards",
            "title": "RDBus 接口族",
            "items": [
              {
                "icon": "ri-global-line",
                "title": "org.containerlinux.Net",
                "desc": "ct-netd 连接管理（网卡 / WiFi / DHCP / 路由）",
                "badge": "网络",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-download-cloud-2-line",
                "title": "org.containerlinux.Net.Download",
                "desc": "ct-download 提交 / 暂停 / 限速 / 进度",
                "badge": "下载",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-shield-line",
                "title": "org.containerlinux.Net.P2P",
                "desc": "ct-p2p 直连流 / DHT 发现",
                "badge": "P2P",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-window-2-line",
                "title": "org.containerlinux.WebDesk",
                "desc": "ct-webdesk 桌面流（resident / requires-bus = false）",
                "badge": "桌面",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "code",
            "title": "服务声明",
            "code": "[atom]\nname = \"rdbus\"\nresident = true          # 豁免 ct-core LRU 回收\nrequires-bus = false\n\n[bus]\nname = \"org.containerlinux.Net\"\nobjects = [\"/Net\", \"/Net/P2P\", \"/Net/VPN\"]",
            "lang": "toml"
          }
        ]
      },
      {
        "id": "contract",
        "label": "依赖契约",
        "icon": "ri-file-shield-2-line",
        "blocks": [
          {
            "t": "toggles",
            "title": "自研组件依赖契约（D27）",
            "items": [
              {
                "label": "单例 AtomRegistry",
                "desc": "由 rsystemd-pid1（PID 1）持有，其它进程经共享内存访问",
                "on": true,
                "tone": "good"
              },
              {
                "label": "禁止二次 dlopen",
                "desc": "不得各自独立 dlopen 第二份注册表（16.4.3）",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "零拷贝通信",
                "desc": "共享内存 / dmabuf 传递，避免序列化开销（18.1）",
                "on": true,
                "tone": "good"
              },
              {
                "label": "热更新限定无状态模块",
                "desc": "系统服务可热更新，有状态连接保持（18.2）",
                "on": true,
                "tone": "info"
              }
            ]
          },
          {
            "t": "table",
            "title": "接口与所有者",
            "cols": [
              "接口",
              "所有者守护",
              "落点"
            ],
            "rows": [
              [
                "org.containerlinux.Net",
                "ct-netd",
                "/CTF/Services/bin/"
              ],
              [
                "org.containerlinux.Net.P2P",
                "ct-p2p",
                "/CTF/Services/bin/"
              ],
              [
                "org.containerlinux.Net.Penetrate",
                "ct-penetrate",
                "/CTF/Services/bin/"
              ],
              [
                "org.containerlinux.Net.VPN",
                "ct-vpn",
                "/CTF/Services/bin/"
              ],
              [
                "org.containerlinux.WebDesk",
                "ct-webdesk",
                "/CTF/Services/bin/"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "为什么豁免 LRU",
            "text": "总线是全部 IPC 的地基。一旦被 ct-core 按空闲回收，上层所有原子与挂载包的通信链路都会断——因此 manifest 里显式 resident = true，不作为按需原子。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-rsystemd", "tier": "daemon",
    "name": "RSystemd 初始化",
    "sub": "pid1 / logind / udevd",
    "icon": "ri-server-line",
    "from": "#3f5168",
    "to": "#6f86a8",
    "group": "原子架构",
    "status": "PID 1 运行中",
    "desc": "systemd 的 Rust 替代 · 多进程 + AtomRegistry",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "init",
        "label": "init 三兄弟",
        "icon": "ri-server-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-server-line",
            "badge": "Rust 编写",
            "title": "RSystemd：用 Rust 写的 init 三兄弟",
            "tone": "blue",
            "desc": "systemd 的 Rust 替代：pid1 / logind / udevd 多进程 + AtomRegistry 模块化。「超级进程」为储备概念（14.3），不进 v6.0 实现范围。"
          },
          {
            "t": "cards",
            "title": "三大进程",
            "items": [
              {
                "icon": "ri-instance-line",
                "title": "rsystemd-pid1",
                "desc": "PID 1：持有 AtomRegistry 单例，服务启动按 profile 装载原子",
                "badge": "单例持有者",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-user-settings-line",
                "title": "rsystemd-logind",
                "desc": "会话 / 座椅 / 电源事件，经 RDBus 暴露",
                "badge": "会话",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-usb-line",
                "title": "rsystemd-udevd",
                "desc": "设备热插拔与节点管理，驱动包按需挂载",
                "badge": "设备",
                "tone": "violet",
                "tags": []
              }
            ]
          },
          {
            "t": "logs",
            "title": "启动单元日志",
            "lines": [
              {
                "t": "OK",
                "text": "rsystemd-pid1: AtomRegistry singleton acquired",
                "tone": "good"
              },
              {
                "t": "OK",
                "text": "profile = full → 38 atoms loaded",
                "tone": "good"
              },
              {
                "t": "OK",
                "text": "rdbus.service: resident, LRU-exempt",
                "tone": "accent"
              },
              {
                "t": "OK",
                "text": "ct-netd.service / ct-download.service: active",
                "tone": ""
              },
              {
                "t": "INFO",
                "text": "bare profile available for 3rd-party components",
                "tone": "info"
              },
              {
                "t": "OK",
                "text": "graphical.target reached in 1.043s",
                "tone": "good"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "两个运行档",
            "text": "完整 profile 与 bare profile 共用同一份 RSystemd / RDBus：后者是「经济档」最小原子集，专为第三方组件设计的原子停运（7.9.7）。"
          }
        ]
      },
      {
        "id": "units",
        "label": "单元与热更新",
        "icon": "ri-list-check-2",
        "blocks": [
          {
            "t": "table",
            "title": "关键系统单元",
            "cols": [
              "单元",
              "类型",
              "状态"
            ],
            "rows": [
              [
                "rdbus.service",
                "resident atom",
                "active"
              ],
              [
                "ct-netd.service",
                "Rust 服务",
                "active"
              ],
              [
                "ct-download.service",
                "Rust 服务",
                "active"
              ],
              [
                "ct-resolved.service",
                "Rust 服务",
                "active"
              ],
              [
                "ct-p2p.service",
                "Rust 服务",
                "inactive"
              ],
              [
                "ct-vpn.service",
                "Rust 服务",
                "inactive"
              ]
            ]
          },
          {
            "t": "toggles",
            "title": "热更新机制（18.2）",
            "items": [
              {
                "label": "无状态模块热替换",
                "desc": "运行期支持，无需重启服务",
                "on": true,
                "tone": "good"
              },
              {
                "label": "事务式应用",
                "desc": "预检 → 应用 → 失败回滚",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "有状态连接保持",
                "desc": "热更新期间已建立连接不中断",
                "on": true,
                "tone": "info"
              },
              {
                "label": "超级进程融合",
                "desc": "储备概念，v6.0 不实现",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "bars",
            "title": "启动耗时分解",
            "items": [
              {
                "label": "AtomRegistry 装载",
                "pct": 28,
                "tone": "accent"
              },
              {
                "label": "RDBus 就绪",
                "pct": 22,
                "tone": "good"
              },
              {
                "label": "网络服务",
                "pct": 18,
                "tone": ""
              },
              {
                "label": "图形目标",
                "pct": 14,
                "tone": ""
              },
              {
                "label": "其它",
                "pct": 18,
                "tone": ""
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-shell", "tier": "skip",
    "name": "CT Shell 桌面本体",
    "sub": "ct-shell",
    "icon": "ri-window-2-line",
    "from": "#7d4fd1",
    "to": "#a97ef0",
    "group": "原子架构",
    "status": "运行中",
    "desc": "自研 Shell · Smithay 合成器 · 中转站 · 主题",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "shell",
        "label": "桌面本体",
        "icon": "ri-window-2-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-window-2-line",
            "badge": "运行于 simple-desktop 之上",
            "title": "ct-shell 自研桌面 Shell",
            "tone": "violet",
            "desc": "ContainerLinux 的「桌面本体」：运行于 Smithay 直连自研合成器 simple-desktop 之上，承载任务栏、启动器、窗口管理、动画与主题。"
          },
          {
            "t": "cards",
            "title": "Shell 组件",
            "items": [
              {
                "icon": "ri-layout-4-line",
                "title": "窗口管理",
                "desc": "Wayland toplevel 管理、四套优雅动画、拖拽渲染优化",
                "badge": "合成器",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-apps-2-line",
                "title": "启动器",
                "desc": "悬浮 / 全屏双模式 Launchpad，搜索与分类",
                "badge": "启动台",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-layout-bottom-line",
                "title": "任务栏与 Dock",
                "desc": "应用快捷方式、最小化 / 聚焦切换、灵动岛播放控制",
                "badge": "Dock",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-palette-line",
                "title": "主题引擎",
                "desc": "theme.json → CSS 变量，与 ct-shell-web 共用同一套令牌",
                "badge": "主题",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "toggles",
            "title": "桌面体验增强（D24 / D25）",
            "items": [
              {
                "label": "中转站（Tuck 窗格）",
                "desc": "贴边收纳：鼠标进入屏幕边缘触发区展开、移开自动收回",
                "on": true,
                "tone": "good"
              },
              {
                "label": "CTST 内嵌虚拟屏幕",
                "desc": "终端区域内嵌轻量 Wayland 合成器，渲染到纹理而非 DRM",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "Dock 动画与液态玻璃",
                "desc": "壁纸与液态玻璃效果为 .cte 插件",
                "on": true,
                "tone": "info"
              },
              {
                "label": "多窗格独立收纳",
                "desc": "文件 / 快捷方式 / .cte 应用入口各自独立",
                "on": true,
                "tone": "good"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "ct-settings / ct-files",
            "text": "桌面应用套件为 cosmic-settings / cosmic-files 魔改 fork（D13）：会话适配 simple-desktop、系统能力经 RDBus 走 CT 原子、自包含 bundle 随 L2 层原子更新。"
          }
        ]
      },
      {
        "id": "web",
        "label": "Web 图形通道",
        "icon": "ri-global-line",
        "blocks": [
          {
            "t": "steps",
            "title": "浏览器端 CT 桌面（D32 / 22.7）",
            "items": [
              {
                "n": "①",
                "title": "ct-shell-web",
                "desc": "HTML/CSS/JS 复刻 ct-shell，与 ct-shell 共用 theme.json → CSS 变量",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "ct-webdesk",
                "desc": "本机守护拉起流内核、挂载 D25 嵌套合成器，暴露 RDBus org.containerlinux.WebDesk",
                "tone": "accent"
              },
              {
                "n": "③",
                "title": "Selkies 流内核",
                "desc": "Python 控制面 + Rust 媒体扩展 pixelflux（H.264）/ pcmflux（Opus）",
                "tone": "violet"
              },
              {
                "n": "④",
                "title": "HTML5 客户端",
                "desc": "WebCodecs 渲染真实 X11/Wayland 应用画面进网页窗口",
                "tone": "green"
              }
            ]
          },
          {
            "t": "code",
            "title": "共用主题令牌",
            "code": "/* theme.json → ct-shell 与 ct-shell-web 共用 */\n:root {\n  --c-surface:  #1c1c1e;\n  --c-accent:   #3b6fd4;\n  --c-radius:   26px;\n  --c-border:   rgba(255,255,255,.12);\n}",
            "lang": "css"
          },
          {
            "t": "chips",
            "title": "关键决策",
            "items": [
              "D13 COSMIC 魔改",
              "D24 中转站",
              "D25 CTST 内嵌屏",
              "D32 Web 通道",
              "D27 依赖契约",
              "D21 CTTY CPU 渲染"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-plugins", "tier": "app",
    "name": "组件管理器",
    "sub": "内核 · 插件 · 原子 · 发行版 · 镜像包",
    "icon": "ri-stack-line",
    "from": "#c05a3a",
    "to": "#e8916b",
    "group": "原子架构",
    "status": "五分区管理",
    "desc": "内核档位与更新 · .ko/.cte 插件与门禁 · 原子预算 · 发行版槽位换装 · 挂载包冷热三态",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "overview",
        "label": "总览",
        "icon": "ri-dashboard-3-line",
        "blocks": []
      },
      {
        "id": "kernel",
        "label": "内核管理",
        "icon": "ri-cpu-line",
        "blocks": []
      },
      {
        "id": "plugin",
        "label": "插件管理",
        "icon": "ri-puzzle-2-line",
        "blocks": []
      },
      {
        "id": "atom",
        "label": "原子管理",
        "icon": "ri-puzzle-line",
        "blocks": []
      },
      {
        "id": "distro",
        "label": "发行版管理",
        "icon": "ri-exchange-line",
        "blocks": []
      },
      {
        "id": "image",
        "label": "镜像包管理",
        "icon": "ri-box-3-line",
        "blocks": []
      }
    ]
  },
  {
    "id": "ct-ctf", "tier": "skip",
    "name": "CTF 命名空间",
    "sub": "CT File Tree",
    "icon": "ri-folder-2-line",
    "from": "#4d6b5a",
    "to": "#79a68c",
    "group": "原子架构",
    "status": "公民准则 D26",
    "desc": "两模式统一地图 · 六个一级目录 · bind 聚合",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "tree",
        "label": "目录地图",
        "icon": "ri-node-tree",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-folder-2-line",
            "badge": "决策 D16 / D26",
            "title": "CTF：CT 的「自家院子」",
            "tone": "green",
            "desc": "两种运行模式统一：有发行版模式为发行版根下目录，零发行版模式为运行时根自命名空间（bind 聚合自 ESP + ct-data）。"
          },
          {
            "t": "nodes",
            "title": "六个一级目录",
            "center": "/CTF/",
            "items": [
              {
                "label": "Core",
                "sub": "原子 / 库 / 运行时",
                "tone": "blue"
              },
              {
                "label": "Extensions",
                "sub": ".cte 插件 / 扩展",
                "tone": "violet"
              },
              {
                "label": "Apps",
                "sub": "应用挂载包",
                "tone": "teal"
              },
              {
                "label": "Data",
                "sub": "用户数据",
                "tone": "amber"
              },
              {
                "label": "Config",
                "sub": "netd.toml / p2p / vpn",
                "tone": "cyan"
              },
              {
                "label": "Images",
                "sub": "镜像 / 快照",
                "tone": "pink"
              }
            ]
          },
          {
            "t": "code",
            "title": "物理目录树",
            "code": "/CTF/\n├── Core/\n│   ├── Atoms/        # atom-*.so\n│   └── libctnet.so\n├── Extensions/       # .cte 目录包\n├── Apps/             # .erofs 挂载包\n├── Data/             # 用户数据 / bench\n├── Config/           # netd.toml / p2p / vpn\n└── Images/           # 镜像 / 快照 / drivers",
            "lang": "ctf"
          },
          {
            "t": "chips",
            "title": "落位清单",
            "items": [
              ".cte",
              ".ko",
              "模型",
              "信任库",
              "黑客镜像",
              "EROFS 驱动包",
              "操作日志",
              "快照"
            ]
          }
        ]
      },
      {
        "id": "rules",
        "label": "公民准则与分区",
        "icon": "ri-compass-3-line",
        "blocks": [
          {
            "t": "table",
            "title": "分区布局（最小两分区）",
            "cols": [
              "分区",
              "格式",
              "用途"
            ],
            "rows": [
              [
                "ESP",
                "FAT32",
                "引导 + L0 常驻救援副本"
              ],
              [
                "ct-data",
                "Btrfs",
                "三层存储 / 用户数据 / CTF"
              ],
              [
                "rec",
                "—",
                "恢复分区"
              ],
              [
                "share",
                "exFAT",
                "统一数据分区（四方访问）"
              ]
            ]
          },
          {
            "t": "toggles",
            "title": "CTF 公民准则（D26）",
            "items": [
              {
                "label": "CT 自有内容一律落 /CTF/",
                "desc": "不散落发行版目录，换租客不搬家",
                "on": true,
                "tone": "good"
              },
              {
                "label": "两模式同一张地图",
                "desc": "bind 聚合屏蔽差异，应用无需感知槽位",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "第三方只读挂载",
                "desc": ".erofs + 签名，用户数据独立可写",
                "on": true,
                "tone": "info"
              },
              {
                "label": "纯 CTF 架构（chroot 聚合）",
                "desc": "储备方案，第 27 章，v6.1 不启用",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "四方访问",
            "text": "exFAT 统一数据分区供 ContainerLinux / Windows / Android(LSA) / DevVM 四方访问，配合 LogSpace 独立于时间线做文件中转（26.1 / 26.2）。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-desktop", "tier": "skip",
    "name": "CTDesktop 自研桌面",
    "sub": "L2 · simple-desktop",
    "icon": "ri-window-2-line",
    "from": "#3b6fd4",
    "to": "#6f9de8",
    "group": "图形与交互",
    "status": "L2 已挂载",
    "desc": "Smithay 直连合成器 · 按机裁剪 Mesa · 自包含图形栈",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "desktop",
        "label": "合成器",
        "icon": "ri-window-2-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-window-2-line",
            "badge": "L2 层 · 随 CT Runtime 分发",
            "title": "CTDesktop 自包含图形栈",
            "tone": "blue",
            "desc": "不装发行版也能上的桌面：基于 Smithay 库直连的自研 Wayland 合成器 simple-desktop（winit + GLES 骨架已跑通）+ 桌面应用套件 + 按机裁剪 Mesa + ct-shell 基础壳。"
          },
          {
            "t": "cards",
            "title": "四块组成",
            "items": [
              {
                "icon": "ri-layout-4-line",
                "title": "simple-desktop",
                "desc": "Smithay 直连自研 Wayland 合成器，winit + GLES 骨架已跑通",
                "badge": "合成器",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-apps-2-line",
                "title": "桌面应用套件",
                "desc": "ct-settings / ct-files 等，COSMIC 魔改 fork 原子化交付（D13）",
                "badge": "应用",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-cpu-line",
                "title": "按机裁剪 Mesa",
                "desc": "按 GPU 型号裁剪驱动，避免全量 Mesa 拖累体积",
                "badge": "图形库",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-palette-line",
                "title": "ct-shell 基础壳",
                "desc": "壁纸与液态玻璃效果为 .cte 插件，主题走 theme.json → CSS 变量",
                "badge": "外壳",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "kpis",
            "title": "图形栈",
            "items": [
              {
                "v": "Wayland",
                "label": "显示协议",
                "unit": "",
                "tone": ""
              },
              {
                "v": "GLES2",
                "label": "渲染 API",
                "unit": "",
                "tone": ""
              },
              {
                "v": "6",
                "label": "内置 shader",
                "unit": "种",
                "tone": "accent"
              },
              {
                "v": "0",
                "label": "Electron 依赖",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "ct-gpu 公共渲染地基",
            "text": "DRM（raw FFI）→ GBM → EGL → GLES2（glow），shader 含 solid / rounded（SDF + glow）/ scanlines / text——CTSuperTerminal 与 CTDesktop 两套界面的公共画笔。CTTY 走 CPU 渲染，不依赖此栈（D21）。"
          }
        ]
      },
      {
        "id": "stack",
        "label": "渲染管线",
        "icon": "ri-stack-line",
        "blocks": [
          {
            "t": "steps",
            "title": "ct-gpu 自底向上",
            "items": [
              {
                "n": "1",
                "title": "DRM",
                "desc": "raw FFI 直连内核显示设备，零桌面依赖",
                "tone": "blue"
              },
              {
                "n": "2",
                "title": "GBM",
                "desc": "通用缓冲管理，分配 GPU 可访问缓冲",
                "tone": "teal"
              },
              {
                "n": "3",
                "title": "EGL",
                "desc": "上下文与表面绑定",
                "tone": "violet"
              },
              {
                "n": "4",
                "title": "GLES2（glow）",
                "desc": "solid / rounded / scanlines / text 四类 shader",
                "tone": "accent"
              },
              {
                "n": "5",
                "title": "界面层",
                "desc": "CTSuperTerminal（L1）与 CTDesktop（L2）共用",
                "tone": "green"
              }
            ]
          },
          {
            "t": "code",
            "title": "shader 清单",
            "code": "ct-gpu/shaders/\n├── solid.frag      # 纯色填充\n├── rounded.frag    # SDF 圆角 + glow\n├── scanlines.frag  # 科幻终端扫描线\n└── text.frag       # 字形纹理采样",
            "lang": "glsl"
          },
          {
            "t": "chips",
            "title": "相关章节",
            "items": [
              "22.2 CTDesktop",
              "22.3 开机动画 (mpv)",
              "22.4 CT 严选桌面",
              "21.2 CTclaw",
              "D25 内嵌虚拟屏幕"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-superterm", "tier": "skip",
    "name": "CTSuperTerminal",
    "sub": "L1 · ctty-edex",
    "icon": "ri-terminal-box-line",
    "from": "#4a5bc4",
    "to": "#7d8ce8",
    "group": "图形与交互",
    "status": "L1 已挂载",
    "desc": "纯 GPU 科幻终端 · 多路会话 · 系统控制中枢",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "term",
        "label": "驾驶舱",
        "icon": "ri-terminal-box-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-terminal-box-line",
            "badge": "代码库 ctty-edex",
            "title": "零发行版模式的驾驶舱",
            "tone": "violet",
            "desc": "纯 GPU 渲染的原生 eDEX-UI 科幻终端：无 Electron、全 shader 绘制；零发行版模式下的日常主界面，不依赖 L2 图形层。"
          },
          {
            "t": "cards",
            "title": "技术构成",
            "items": [
              {
                "icon": "ri-terminal-line",
                "title": "alacritty_terminal VTE",
                "desc": "终端语义与 PTY 复用，多路会话",
                "badge": "VTE",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-font-size-2",
                "title": "ab_glyph 字体光栅化",
                "desc": "字形图集 + GPU 纹理缓存，CJK/Unicode 完整",
                "badge": "字体",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-magic-line",
                "title": "全 shader 绘制",
                "desc": "扫描线 / 辉光 / 圆角 SDF，零 DOM、零 Electron",
                "badge": "渲染",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-dashboard-3-line",
                "title": "ct-* 工具面板",
                "desc": "系统控制中枢 + 设备协同入口",
                "badge": "面板",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "toggles",
            "title": "能力面板",
            "items": [
              {
                "label": "多路终端会话复用",
                "desc": "单实例多 PTY，标签 / 分屏切换",
                "on": true,
                "tone": "good"
              },
              {
                "label": "系统控制中枢",
                "desc": "模式切换 / 服务状态 / 网络策略直达",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "设备协同入口",
                "desc": "剪贴板 / 键鼠共享 / 蜂群任务",
                "on": true,
                "tone": "info"
              },
              {
                "label": "CTST 内嵌虚拟屏幕",
                "desc": "D25 可选能力，L2 装载后启用，不改变 L1 独立运行承诺",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "L1 独立运行承诺",
            "text": "CTSuperTerminal 不依赖 L2 图形层：即使 CTDesktop 未装载，L1 仍可独立提供完整日常主界面。CTST 内嵌虚拟屏幕只是「锦上添花」的可选能力。"
          }
        ]
      },
      {
        "id": "sessions",
        "label": "会话与快捷键",
        "icon": "ri-layout-grid-line",
        "blocks": [
          {
            "t": "table",
            "title": "活动会话",
            "cols": [
              "ID",
              "会话",
              "状态"
            ],
            "rows": [
              [
                "tty1",
                "ctty-edex / zsh",
                "active"
              ],
              [
                "tty2",
                "ct-netd 日志流",
                "active"
              ],
              [
                "tty3",
                "ct-difftest watch",
                "idle"
              ],
              [
                "tty4",
                "蜂群任务面板",
                "standby"
              ]
            ]
          },
          {
            "t": "logs",
            "title": "面板事件",
            "lines": [
              {
                "t": "INFO",
                "text": "ct-gpu: GLES2 context ready (GBM/DRM)",
                "tone": "good"
              },
              {
                "t": "INFO",
                "text": "4 PTY sessions multiplexed",
                "tone": ""
              },
              {
                "t": "OK",
                "text": "系统控制中枢: 标准模式",
                "tone": "accent"
              },
              {
                "t": "INFO",
                "text": "CTST: L2 未装载，内嵌屏待命",
                "tone": "info"
              }
            ]
          },
          {
            "t": "chips",
            "title": "快捷键",
            "items": [
              "Ctrl+Alt+T 新会话",
              "Ctrl+Tab 切换",
              "Ctrl+Alt+N 标准模式",
              "Ctrl+Alt+O 过载模式",
              "Ctrl+Alt+S 超级省电"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-ctty", "tier": "skip",
    "name": "CTTY 控制台",
    "sub": "用户态 KMS 控制台",
    "icon": "ri-command-line",
    "from": "#3f5168",
    "to": "#6f86a8",
    "group": "图形与交互",
    "status": "CPU 渲染中",
    "desc": "零 GPU 依赖 · KMS dumb buffer · 脏矩形增量刷新",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "ctty",
        "label": "显示底座",
        "icon": "ri-terminal-window-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-command-line",
            "badge": "决策 D21",
            "title": "CTTY 用户态 KMS 控制台",
            "tone": "blue",
            "desc": "传统 VT 的现代化替身：Rust 编写、CPU 渲染、零 GPU 依赖——无 GPU / 无图形栈设备的现代文本界面，也是 32.6 TTY 模式与 31.2 急救的显示底座。"
          },
          {
            "t": "steps",
            "title": "CPU 渲染管线",
            "items": [
              {
                "n": "1",
                "title": "KMS dumb buffer",
                "desc": "直接申请内核显示缓冲，无需 GPU 驱动",
                "tone": "blue"
              },
              {
                "n": "2",
                "title": "帧缓冲 mmap 直绘",
                "desc": "用户态直接写像素，绕过图形栈",
                "tone": "teal"
              },
              {
                "n": "3",
                "title": "字形图集 CPU 光栅化",
                "desc": "预 raster 字形图集，CJK/Unicode 完整",
                "tone": "violet"
              },
              {
                "n": "4",
                "title": "脏矩形增量刷新",
                "desc": "只重绘变化区域，极低 CPU 占用",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "渲染指标",
            "items": [
              {
                "v": "0",
                "label": "GPU 依赖",
                "unit": "",
                "tone": ""
              },
              {
                "v": "60",
                "label": "刷新率",
                "unit": "Hz",
                "tone": "good"
              },
              {
                "v": "~3",
                "label": "CPU 占用",
                "unit": "%",
                "tone": "good"
              },
              {
                "v": "8",
                "label": "控制台",
                "unit": "个",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与 CTSuperTerminal 互补",
            "text": "CTTY 走 CPU 渲染（D21），CTSuperTerminal 走 ct-gpu GPU 管线——两者共用 alacritty_terminal 语义，前者是无 GPU / 急救场景的兜底底座，后者是零发行版模式的日常驾驶舱。"
          }
        ]
      },
      {
        "id": "modes",
        "label": "控制台与急救",
        "icon": "ri-error-warning-line",
        "blocks": [
          {
            "t": "toggles",
            "title": "控制台能力",
            "items": [
              {
                "label": "CJK / Unicode 完整渲染",
                "desc": "字形图集覆盖中日韩与符号",
                "on": true,
                "tone": "good"
              },
              {
                "label": "HiDPI 适配",
                "desc": "按面板 DPI 缩放字形",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "多控制台切换",
                "desc": "8 路 VT，Ctrl+Alt+F1–F8",
                "on": true,
                "tone": "info"
              },
              {
                "label": "急救三层降级",
                "desc": "L0 CTTY → TUI 控制中心 → 恢复环境",
                "on": true,
                "tone": "good"
              }
            ]
          },
          {
            "t": "table",
            "title": "急救模式三层降级（31.2）",
            "cols": [
              "层级",
              "内容",
              "触发"
            ],
            "rows": [
              [
                "第一层",
                "CTTY + ct-shell 最小集",
                "图形栈轻微故障"
              ],
              [
                "第二层",
                "TUI 控制中心（L0）",
                "图形栈不可用"
              ],
              [
                "第三层",
                "ESP L0 救援副本 / 恢复环境",
                "系统无法启动"
              ]
            ]
          },
          {
            "t": "code",
            "title": "切换命令",
            "code": "# 强制进入 TTY 模式（非 LinuxBoot 直启路径）\nGRUB: ct_mode=tty\n\n# 运行时切换控制台\nsudo chvt 3\n# 或 CTTY 内部快捷键 Ctrl+Alt+F3",
            "lang": "bash"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-tui", "tier": "skip",
    "name": "TUI 控制中心",
    "sub": "L0 核心层",
    "icon": "ri-settings-5-line",
    "from": "#4d6b5a",
    "to": "#79a68c",
    "group": "图形与交互",
    "status": "L0 常驻",
    "desc": "零发行版 / 急救 / TTY 的全功能控制中心",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "tui",
        "label": "控制中心",
        "icon": "ri-settings-5-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-settings-5-line",
            "badge": "约 35–60MB · ESP 救援副本",
            "title": "TUI 控制中心",
            "tone": "green",
            "desc": "L0 核心层的全功能文本控制中心：零发行版、急救、TTY 三种场景共用，无需图形栈即可完成系统配置与恢复。"
          },
          {
            "t": "cards",
            "title": "功能模块",
            "items": [
              {
                "icon": "ri-global-line",
                "title": "网络配置",
                "desc": "ct-netd / WiFi / DNS / VPN / 代理",
                "badge": "网络",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-speed-mini-line",
                "title": "系统模式",
                "desc": "十模式切换、过载 / 超级省电",
                "badge": "模式",
                "tone": "pink",
                "tags": []
              },
              {
                "icon": "ri-hard-drive-3-line",
                "title": "存储与快照",
                "desc": "三层存储、时间回溯、LogSpace",
                "badge": "存储",
                "tone": "amber",
                "tags": []
              },
              {
                "icon": "ri-shield-check-line",
                "title": "恢复与安全",
                "desc": "多级恢复、防火墙、签名校验",
                "badge": "安全",
                "tone": "teal",
                "tags": []
              }
            ]
          },
          {
            "t": "code",
            "title": "TUI 主界面",
            "code": "┌─ ContainerLinux TUI 控制中心 ────────────┐\n│ ▸ 网络与连接        [ct-netd  active]    │\n│ ▸ 系统模式          [标准]               │\n│ ▸ 存储与快照        [三层存储  已挂载]   │\n│ ▸ 应用与挂载包      [38 已登记]          │\n│ ▸ 安全与防火墙      [标准模式]           │\n│ ▸ 恢复与急救        [L0 救援副本 就绪]   │\n│ ▸ 关于              [v6.1 / D38]         │\n└──────────────────────────────────────────┘",
            "lang": "tui"
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "L0 常驻",
            "text": "TUI 控制中心属 L0 核心层，随 CT-Kernel 原子更新，且在 ESP 保留常驻救援副本——这是「内核更新失败也能进系统」的底气。"
          }
        ]
      },
      {
        "id": "keys",
        "label": "操作与状态",
        "icon": "ri-keyboard-line",
        "blocks": [
          {
            "t": "table",
            "title": "快捷键",
            "cols": [
              "键",
              "动作"
            ],
            "rows": [
              [
                "↑ / ↓",
                "选择条目"
              ],
              [
                "Enter",
                "进入模块"
              ],
              [
                "Esc",
                "返回上级"
              ],
              [
                "F2",
                "刷新状态"
              ],
              [
                "F5",
                "事务式应用"
              ],
              [
                "F9",
                "查看操作日志"
              ],
              [
                "Ctrl+C",
                "退出 TUI"
              ]
            ]
          },
          {
            "t": "logs",
            "title": "状态栏事件",
            "lines": [
              {
                "t": "OK",
                "text": "L0 core layer mounted from ESP",
                "tone": "good"
              },
              {
                "t": "OK",
                "text": "ct-netd / ct-resolved: active",
                "tone": ""
              },
              {
                "t": "INFO",
                "text": "snapshot: base_1.0 @ 2026-09-25",
                "tone": "info"
              },
              {
                "t": "OK",
                "text": "recovery image verified (ct-sign-v2)",
                "tone": "good"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "L0 规模",
            "items": [
              {
                "v": "35–60",
                "label": "体积",
                "unit": "MB",
                "tone": ""
              },
              {
                "v": "7",
                "label": "一级模块",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "0",
                "label": "图形依赖",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "1",
                "label": "ESP 副本",
                "unit": "份",
                "tone": "accent"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-qingjian", "tier": "system",
    "name": "青简输入法",
    "sub": "Qingjian · D23",
    "icon": "ri-translate-2",
    "from": "#2f8f7a",
    "to": "#54bfa2",
    "group": "图形与交互",
    "status": "三端接入",
    "desc": "Rust Core · 拼音/五笔 · 本地小模型 · 零上传",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "core",
        "label": "Core 与壳",
        "icon": "ri-translate-2",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-translate-2",
            "badge": "GPL-3.0-or-later · D23",
            "title": "青简：平台只是壳，Core 才是青简",
            "tone": "teal",
            "desc": "Rust 编写的跨平台输入法：Core（平台无关输入引擎——拼音 / 五笔 + 词库 + 本地小模型候选重排）+ 平台壳架构，本地零上传。与「内核是基座」同构。"
          },
          {
            "t": "cards",
            "title": "三端接入壳共用同一 Core",
            "items": [
              {
                "icon": "ri-window-2-line",
                "title": "CTDesktop 壳",
                "desc": "Wayland input-method 协议，随 L2 装载",
                "badge": "图形",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-command-line",
                "title": "CTTY 壳",
                "desc": "控制台直绘候选框，字形图集复用",
                "badge": "控制台",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-terminal-box-line",
                "title": "终端壳",
                "desc": "alacritty_terminal 内联候选，零 GPU 可用",
                "badge": "终端",
                "tone": "teal",
                "tags": []
              }
            ]
          },
          {
            "t": "kpis",
            "title": "词库与模型",
            "items": [
              {
                "v": "拼音",
                "label": "输入方案",
                "unit": "",
                "tone": ""
              },
              {
                "v": "五笔",
                "label": "输入方案",
                "unit": "",
                "tone": ""
              },
              {
                "v": "本地",
                "label": "候选重排",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "0",
                "label": "上传数据",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "设计同构",
            "text": "Core 平台无关、平台只是壳——与 CT-Kernel「通用内核 + 可换发行版用户态」是同一套思路：一份稳固底座，多种接入形态。"
          }
        ]
      },
      {
        "id": "engine",
        "label": "输入引擎",
        "icon": "ri-brain-line",
        "blocks": [
          {
            "t": "steps",
            "title": "候选生成与重排",
            "items": [
              {
                "n": "①",
                "title": "按键序列",
                "desc": "拼音 / 五笔码流解析",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "词库检索",
                "desc": "本地词库 + 用户词频",
                "tone": "teal"
              },
              {
                "n": "③",
                "title": "本地小模型重排",
                "desc": "候选顺序按上下文微调，全程离线",
                "tone": "accent"
              },
              {
                "n": "④",
                "title": "壳渲染",
                "desc": "三端各自绘制候选框，共用同一结果",
                "tone": "green"
              }
            ]
          },
          {
            "t": "toggles",
            "title": "隐私与配置",
            "items": [
              {
                "label": "本地零上传",
                "desc": "输入数据不出设备，无云候选",
                "on": true,
                "tone": "good"
              },
              {
                "label": "用户词频自学习",
                "desc": "本地增量更新，随 ct-data 持久化",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "CJK / Unicode 完整",
                "desc": "字形图集覆盖生僻字",
                "on": true,
                "tone": "info"
              },
              {
                "label": "云端联想",
                "desc": "明确不启用，避免输入数据外泄",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "chips",
            "title": "技术栈",
            "items": [
              "Rust",
              "Fluent 国际化",
              "Wayland input-method",
              "ab_glyph",
              "本地小模型",
              "GPL-3.0-or-later"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-eyehand", "tier": "system",
    "name": "EyeHand Fusion",
    "sub": "无障碍系统",
    "icon": "ri-eye-line",
    "from": "#b0527a",
    "to": "#e08aa8",
    "group": "图形与交互",
    "status": "待校准",
    "desc": "眼控瞄准 + 手势确认 · 防误触 · 隐私优先",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "fusion",
        "label": "手眼联控",
        "icon": "ri-eye-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-eye-line",
            "badge": "第 29 章",
            "title": "眼睛当指针，手当按键",
            "tone": "pink",
            "desc": "眼控瞄准 + 手势确认的融合交互：视线负责「选哪里」，手势负责「按下去」，两者分工组合，兼顾精度与确定性。"
          },
          {
            "t": "cards",
            "title": "组件与运行方式",
            "items": [
              {
                "icon": "ri-crosshair-2-line",
                "title": "眼控追踪",
                "desc": "注视点估计 + 平滑滤波，输出瞄准坐标",
                "badge": "瞄准",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-hand-coin-line",
                "title": "手势识别",
                "desc": "捏合 / 握拳 / 停留 作为确认指令",
                "badge": "确认",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-focus-3-line",
                "title": "融合仲裁",
                "desc": "手眼联控：视线候选 + 手势触发，抑制抖动",
                "badge": "融合",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-shield-user-line",
                "title": "隐私与异常",
                "desc": "眼动数据本地处理，校准失败自动降级键鼠",
                "badge": "兜底",
                "tone": "green",
                "tags": []
              }
            ]
          },
          {
            "t": "table",
            "title": "指令集（29.3 / 29.4）",
            "cols": [
              "类型",
              "指令",
              "动作"
            ],
            "rows": [
              [
                "眼控",
                "注视停留 600ms",
                "移动瞄准点 / 高亮候选"
              ],
              [
                "眼控",
                "扫视轨迹",
                "滚动 / 翻页"
              ],
              [
                "手势",
                "捏合",
                "点击确认"
              ],
              [
                "手势",
                "握拳",
                "长按 / 拖拽"
              ],
              [
                "手势",
                "手掌张开",
                "取消 / 返回"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "防误触算法（29.5）",
            "text": "注视抖动、无意扫视与「米达斯触碰」由三级过滤处理：时间窗确认 + 速度阈值 + 手势二次确认。校准失败或硬件缺失时自动退回键鼠，功能不中断。"
          }
        ]
      },
      {
        "id": "perf",
        "label": "性能与隐私",
        "icon": "ri-pulse-line",
        "blocks": [
          {
            "t": "kpis",
            "title": "运行指标",
            "items": [
              {
                "v": "120",
                "label": "追踪采样",
                "unit": "Hz",
                "tone": "good"
              },
              {
                "v": "<40",
                "label": "端到端延迟",
                "unit": "ms",
                "tone": "good"
              },
              {
                "v": "0",
                "label": "云端数据",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "3",
                "label": "降级层级",
                "unit": "级",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "toggles",
            "title": "策略",
            "items": [
              {
                "label": "本地处理",
                "desc": "眼动原始数据不出设备",
                "on": true,
                "tone": "good"
              },
              {
                "label": "校准向导",
                "desc": "首次使用 9 点校准，结果随 ct-data 保存",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "自动降级键鼠",
                "desc": "追踪失效即切换，无需重启应用",
                "on": true,
                "tone": "info"
              },
              {
                "label": "原始眼动日志",
                "desc": "默认关闭，仅诊断时临时开启",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "bars",
            "title": "延迟分解",
            "items": [
              {
                "label": "图像采集",
                "pct": 32,
                "tone": "accent"
              },
              {
                "label": "注视点估计",
                "pct": 38,
                "tone": ""
              },
              {
                "label": "融合仲裁",
                "pct": 18,
                "tone": "good"
              },
              {
                "label": "手势确认",
                "pct": 12,
                "tone": "good"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-tuck", "tier": "system",
    "name": "中转站",
    "sub": "TuckPane 抽屉式收纳",
    "icon": "ri-layout-masonry-line",
    "from": "#7d4fd1",
    "to": "#a97ef0",
    "group": "图形与交互",
    "status": "本地化重写",
    "desc": "屏幕边缘触发展开、离边自动收回的收纳窗格；文件 / 快捷方式 / 应用入口多窗格独立收纳，是桌面交互能力而非独立后台服务。",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "tuck",
        "label": "中转站",
        "icon": "ri-layout-masonry-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-layout-masonry-line",
            "badge": "tuck-pane.cte · D24",
            "title": "屏幕边缘的「抽屉」",
            "tone": "violet",
            "desc": "鼠标进入屏幕边缘触发区 → 窗格展开、移开自动收回；多窗格独立收纳（文件 / 快捷方式 / .cte 应用入口），悬浮与桌面定位双模式。"
          },
          {
            "t": "cards",
            "title": "交互范式",
            "items": [
              {
                "icon": "ri-arrow-left-right-line",
                "title": "贴边即开",
                "desc": "边缘触发区进入即展开，离边自动收回",
                "badge": "触发",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-folder-2-line",
                "title": "多窗格独立收纳",
                "desc": "文件 / 快捷方式 / .cte 应用入口各自独立",
                "badge": "收纳",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-window-2-line",
                "title": "双定位模式",
                "desc": "悬浮模式（浮于窗口之上）/ 桌面定位（占屏一侧）",
                "badge": "定位",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-magic-line",
                "title": "Dock 动画与视觉主题",
                "desc": "液态玻璃效果为 .cte 插件，可按需装卸",
                "badge": "视觉",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "toggles",
            "title": "窗格配置",
            "items": [
              {
                "label": "左边缘文件窗格",
                "desc": "收纳最近文件与固定目录",
                "on": true,
                "tone": "good"
              },
              {
                "label": "右边缘快捷方式",
                "desc": "应用 / .cte 入口快捷启动",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "离边自动收回",
                "desc": "指针离开触发区 300ms 后收回",
                "on": true,
                "tone": "info"
              },
              {
                "label": "桌面定位模式",
                "desc": "占屏一侧，挤压窗口布局",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "本地化重写",
            "text": "交互范式参考 TuckPane，实现为 tuck-pane.cte 本地化重写（22.6）——不引入外部依赖，随 L2 层 .cte 插件体系分发。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-webdesk", "tier": "skip",
    "name": "浏览器端 CT 桌面",
    "sub": "ct-shell-web · D32",
    "icon": "ri-global-line",
    "from": "#2b7fb8",
    "to": "#5fb6e0",
    "group": "图形与交互",
    "status": "守护已就绪",
    "desc": "壳是网页，应用是真程序 · Selkies 流内核",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "web",
        "label": "Web 图形通道",
        "icon": "ri-global-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-global-line",
            "badge": "决策 D32 · 22.7",
            "title": "浏览器里的 CT 桌面",
            "tone": "cyan",
            "desc": "桌面外壳用纯网页实现（任务栏 / 启动器 / 窗口框 / 动画 / 主题全为 DOM + CSS），桌面内跑真实 X11 / Wayland 应用；应用画面经流内核送入网页窗口。"
          },
          {
            "t": "cards",
            "title": "三层组件",
            "items": [
              {
                "icon": "ri-window-2-line",
                "title": "ct-shell-web",
                "desc": "HTML/CSS/JS 复刻 ct-shell，与 ct-shell 共用 theme.json → CSS 变量；窗口管理走 DOM + CSS",
                "badge": "网页壳",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-server-line",
                "title": "ct-webdesk",
                "desc": "本机第一方守护：拉起流内核、挂载 D25 嵌套合成器、暴露 RDBus org.containerlinux.WebDesk",
                "badge": "本机管家",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-broadcast-line",
                "title": "Selkies（MPL-2.0）",
                "desc": "Python 控制面 + Rust 媒体扩展 pixelflux（H.264 编码）/ pcmflux（Opus 音频）+ WebCodecs 客户端",
                "badge": "流内核",
                "tone": "violet",
                "tags": []
              }
            ]
          },
          {
            "t": "kpis",
            "title": "流指标",
            "items": [
              {
                "v": "H.264",
                "label": "视频编码",
                "unit": "",
                "tone": ""
              },
              {
                "v": "Opus",
                "label": "音频编码",
                "unit": "",
                "tone": ""
              },
              {
                "v": "WebCodecs",
                "label": "客户端解码",
                "unit": "",
                "tone": ""
              },
              {
                "v": "2.0",
                "label": "移除 GStreamer",
                "unit": "版",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "壳与核分离",
            "text": "ct-webdesk 把流内核封装为可替换黑盒（供后续 Rust 化），resident = true、requires-bus = false。CT 本机复用 D25 嵌套合成器为显示源，无需额外虚拟显示器。"
          }
        ]
      },
      {
        "id": "pipe",
        "label": "数据流",
        "icon": "ri-route-line",
        "blocks": [
          {
            "t": "nodes",
            "title": "端到端链路",
            "center": "浏览器",
            "items": [
              {
                "label": "X11/Wayland 应用",
                "sub": "真实程序",
                "tone": "blue"
              },
              {
                "label": "D25 嵌套合成器",
                "sub": "显示源",
                "tone": "violet"
              },
              {
                "label": "ct-webdesk",
                "sub": "拉起流内核",
                "tone": "teal"
              },
              {
                "label": "Selkies / pixelflux",
                "sub": "H.264 + Opus",
                "tone": "amber"
              },
              {
                "label": "ct-shell-web",
                "sub": "DOM+CSS 壳",
                "tone": "cyan"
              }
            ]
          },
          {
            "t": "code",
            "title": "RDBus 接口",
            "code": "[atom]\nname = \"ct-webdesk\"\nresident = true\nrequires-bus = false\n\n[bus]\nname = \"org.containerlinux.WebDesk\"\nmethods = [\"StartStream\", \"StopStream\", \"SessionList\"]",
            "lang": "toml"
          },
          {
            "t": "toggles",
            "title": "运行策略",
            "items": [
              {
                "label": "共用主题令牌",
                "desc": "ct-shell 与 ct-shell-web 同一份 theme.json",
                "on": true,
                "tone": "good"
              },
              {
                "label": "流内核可替换",
                "desc": "封装为黑盒，后续 Rust 化不改外壳",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "音频同步",
                "desc": "pcmflux / Opus 与视频同链路",
                "on": true,
                "tone": "info"
              },
              {
                "label": "公网直暴露",
                "desc": "默认仅本机 / 内网，需 ct-penetrate 显式放行",
                "on": false,
                "tone": "warn"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-lsw", "tier": "skip",
    "name": "Wine Direct / LSW",
    "sub": "Windows 兼容子系统",
    "icon": "ri-windows-line",
    "from": "#c05a3a",
    "to": "#e8916b",
    "group": "兼容与生态",
    "status": "L3 已挂载",
    "desc": "三层兼容模型 · PE 直接加载 · 安全网关 · 智能路由",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "engine",
        "label": "翻译架构",
        "icon": "ri-windows-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-windows-line",
            "badge": "决策 D29 · L3 层",
            "title": "LSW：Windows 翻译官的正式编制",
            "tone": "orange",
            "desc": "Linux System Windows 采用三层模型（映射 / 翻译 / 直通）：前两层级引擎为 Wine Direct，第三层为用户自带授权的硬件分区 VM 兜底；层内私有库自包含。"
          },
          {
            "t": "steps",
            "title": "三层兼容模型（23.14）",
            "items": [
              {
                "n": "①",
                "title": "映射层",
                "desc": "containerlinux-kernel32 / user32.so：系统调用与 Win32 API 映射到原生",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "翻译层",
                "desc": "containerlinux-ntdll 用户态翻译 + PE 直接加载，Wine Direct 主体",
                "tone": "accent"
              },
              {
                "n": "③",
                "title": "直通层",
                "desc": "用户自带授权的硬件分区 VM 兜底（性能敏感 / 反作弊场景）",
                "tone": "violet"
              }
            ]
          },
          {
            "t": "cards",
            "title": "Wine Direct 组件栈",
            "items": [
              {
                "icon": "ri-file-code-fill",
                "title": "containerlinux-pe-loader",
                "desc": "PE 直接加载，配合 binfmt_misc 教内核认识 .exe",
                "badge": "加载",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-code-box-line",
                "title": "containerlinux-ntdll",
                "desc": "用户态 NT 系统调用翻译",
                "badge": "翻译",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-settings-3-line",
                "title": "kernel32 / user32.so",
                "desc": "系统调用映射 + Wayland GUI 适配",
                "badge": "映射",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-shield-check-line",
                "title": "containerlinux-gate",
                "desc": "seccomp-bpf 安全网关，始终加载",
                "badge": "安全",
                "tone": "good",
                "tags": []
              }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "来源角标（23.15）",
            "text": "D28 透明原则的受控例外：LSW 运行的 Windows 应用保留来源角标，让用户始终知道当前窗口来自哪个兼容层，避免「以为是原生」的误导。"
          }
        ]
      },
      {
        "id": "stack",
        "label": "图形与沙箱",
        "icon": "ri-gamepad-line",
        "blocks": [
          {
            "t": "table",
            "title": "图形与同步技术栈",
            "cols": [
              "组件",
              "作用"
            ],
            "rows": [
              [
                "NTSync",
                "CT-Kernel 内置，原生实现 Windows 同步原语"
              ],
              [
                "DXVK / VKD3D-Proton",
                "D3D → Vulkan 图形翻译"
              ],
              [
                "dmabuf",
                "内核缓冲区共享，零拷贝图形传输"
              ],
              [
                "protonfixes",
                "Proton 兼容性补丁数据库"
              ],
              [
                "binfmt_misc",
                "按魔数让内核调用自定义解释器"
              ]
            ]
          },
          {
            "t": "kpis",
            "title": "兼容指标",
            "items": [
              {
                "v": "3",
                "label": "兼容层级",
                "unit": "级",
                "tone": ""
              },
              {
                "v": "seccomp",
                "label": "网关类型",
                "unit": "",
                "tone": ""
              },
              {
                "v": "0",
                "label": "VM 依赖",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "100%",
                "label": "层内私有库",
                "unit": "",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "toggles",
            "title": "运行策略",
            "items": [
              {
                "label": "安全网关始终加载",
                "desc": "containerlinux-gate 不可绕过",
                "on": true,
                "tone": "good"
              },
              {
                "label": "Wine 沙箱化配置",
                "desc": "每个应用独立 prefix，隔离注册表与文件系统",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "power-shift 动态资源调度",
                "desc": "游戏场景自动联动过载模式（23.9）",
                "on": true,
                "tone": "info"
              },
              {
                "label": "硬件分区 VM 直通",
                "desc": "需用户自带 Windows 授权，默认关闭",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "chips",
            "title": "相关章节",
            "items": [
              "23.3 三层翻译",
              "23.8 安全网关",
              "23.10 智能路由",
              "23.11 沙箱",
              "23.13 统一验收",
              "D28 透明原则"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-lsa", "tier": "skip",
    "name": "LSA 安卓子系统",
    "sub": "LSA Runtime Dispatcher",
    "icon": "ri-android-line",
    "from": "#4d6b5a",
    "to": "#79a68c",
    "group": "兼容与生态",
    "status": "L4 待命",
    "desc": "双后端调度 · 统一 Smithay toplevel · 安全守护",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "lsa",
        "label": "双后端调度",
        "icon": "ri-android-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-android-line",
            "badge": "24.2 / 24.9 / D28",
            "title": "安卓应用的翻译官",
            "tone": "green",
            "desc": "LSA Runtime Dispatcher 调度 lepton-backend（容器兜底，fork Valve Lepton）+ atl-backend（无容器研究）；两条后端统一产出 Smithay toplevel。"
          },
          {
            "t": "cards",
            "title": "核心组件",
            "items": [
              {
                "icon": "ri-instance-line",
                "title": "LSA Runtime Dispatcher",
                "desc": "统一调度双后端，产出 Smithay toplevel 供 ct-shell 管理",
                "badge": "调度",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-box-3-line",
                "title": "lepton-backend",
                "desc": "容器兜底，fork Valve Lepton；兼容性能画像优于原 Waydroid 工程态",
                "badge": "容器",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-flask-line",
                "title": "atl-backend",
                "desc": "无容器研究轨，直接对接宿主图形栈",
                "badge": "研究",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-shield-check-line",
                "title": "containerlinux-lsa-guard",
                "desc": "安全守护：权限、Intent、应用隔离（24.4）",
                "badge": "守护",
                "tone": "good",
                "tags": []
              }
            ]
          },
          {
            "t": "segments",
            "title": "当前后端",
            "options": [
              "lepton-backend（容器兜底）",
              "atl-backend（无容器研究）"
            ],
            "value": "lepton-backend（容器兜底）",
            "hint": "D28 兼容层统一原则：无论何后端，窗口形态一致"
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "统一原则（FydeOS 式，D28）",
            "text": "兼容层对桌面隐藏实现差异：Android 应用与原生应用一样是普通窗口，可最小化 / 缩放 / 参与窗口管理，用户无需知道背后是容器还是无容器后端。"
          }
        ]
      },
      {
        "id": "runtime",
        "label": "运行时与分发",
        "icon": "ri-smartphone-line",
        "blocks": [
          {
            "t": "table",
            "title": "运行时要点",
            "cols": [
              "项",
              "说明"
            ],
            "rows": [
              [
                "Zygote",
                "Android 应用进程母体，预加载框架类"
              ],
              [
                "binder_linux",
                "CT-Kernel 内置 binder 设备"
              ],
              [
                "Smithay toplevel",
                "统一窗口对象，双后端共同输出"
              ],
              [
                "图形",
                "dmabuf 零拷贝 + ct-gpu 管线"
              ],
              [
                "输入",
                "Wayland input-method（青简共用）"
              ]
            ]
          },
          {
            "t": "progress",
            "title": "兼容性能画像（24.6）",
            "items": [
              {
                "label": "启动延迟",
                "pct": 82,
                "sub": "Lepton 容器 vs 原 Waydroid",
                "meta": "优化 34%",
                "tone": "good"
              },
              {
                "label": "图形吞吐",
                "pct": 76,
                "sub": "dmabuf 零拷贝",
                "meta": "+28%",
                "tone": "good"
              },
              {
                "label": "内存占用",
                "pct": 64,
                "sub": "容器精简",
                "meta": "−19%",
                "tone": "accent"
              },
              {
                "label": "应用覆盖",
                "pct": 58,
                "sub": "闭源 ARM 应用仍需翻译层",
                "meta": "进行中",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "chips",
            "title": "关键决策",
            "items": [
              "D22 翻译双轨",
              "D28 兼容层统一",
              "24.7 应用分发",
              "24.8 双模式应用",
              "NTSync",
              "binder"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-houdini", "tier": "skip",
    "name": "翻译层双轨",
    "sub": "D22 · ARM→x86",
    "icon": "ri-swap-line",
    "from": "#7d4fd1",
    "to": "#a97ef0",
    "group": "兼容与生态",
    "status": "Intel → libhoudini",
    "desc": "闭源生产轨 · 开发调试轨 · 供应链降级",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "tracks",
        "label": "两条轨道",
        "icon": "ri-git-branch-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-swap-line",
            "badge": "决策 D22",
            "title": "ARM 应用的翻译机",
            "tone": "violet",
            "desc": "LSA 生产轨按 CPU 厂商自动二选一闭源 ARM→x86 翻译层；开发调试轨用可审计的 QEMU User Mode；供应链异常时一键降级。"
          },
          {
            "t": "cards",
            "title": "双轨对照",
            "items": [
              {
                "icon": "ri-cpu-line",
                "title": "闭源生产轨",
                "desc": "libhoudini（Intel）/ libndk（AMD）按 CPU 厂商自动二选一，服务闭源 Android 应用",
                "badge": "生产",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-bug-line",
                "title": "开发调试轨",
                "desc": "QEMU User Mode（qemu-arm / qemu-aarch64，GPL-2.0+）：架构与指令覆盖最全、内置 gdbstub 可单步",
                "badge": "调试",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-arrow-go-back-line",
                "title": "降级兜底",
                "desc": "供应链异常时一键降级 QEMU（User Mode），兼生产轨降级",
                "badge": "兜底",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "table",
            "title": "选型矩阵",
            "cols": [
              "维度",
              "libhoudini / libndk",
              "QEMU User Mode"
            ],
            "rows": [
              [
                "许可证",
                "闭源",
                "GPL-2.0+（可审计）"
              ],
              [
                "指令覆盖",
                "厂商优化",
                "最全"
              ],
              [
                "调试能力",
                "有限",
                "gdbstub 单步"
              ],
              [
                "性能",
                "生产级",
                "偏慢"
              ],
              [
                "用途",
                "闭源应用日常运行",
                "开发调试 / 降级兜底"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "供应链风险对冲",
            "text": "闭源翻译层存在供应链不确定性（授权 / 可用性 / 兼容性）。D22 明确要求保留 QEMU 这条可审计的替代路径，异常时一键降级，不让闭源组件成为单点故障。"
          }
        ]
      },
      {
        "id": "route",
        "label": "路由策略",
        "icon": "ri-route-line",
        "blocks": [
          {
            "t": "steps",
            "title": "应用启动时的翻译层选择",
            "items": [
              {
                "n": "①",
                "title": "识别 ABI",
                "desc": "读取 APK 的 arm64-v8a / armeabi-v7a 标记",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "判定 CPU 厂商",
                "desc": "Intel → libhoudini；AMD → libndk",
                "tone": "accent"
              },
              {
                "n": "③",
                "title": "检查来源",
                "desc": "商店直供 x86 则跳过翻译层",
                "tone": "teal"
              },
              {
                "n": "④",
                "title": "兜底决策",
                "desc": "闭源层不可用 → QEMU User Mode",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "toggles",
            "title": "策略开关",
            "items": [
              {
                "label": "厂商自动二选一",
                "desc": "按 /proc/cpuinfo 判定",
                "on": true,
                "tone": "good"
              },
              {
                "label": "x86 直供优先",
                "desc": "CT 应用商店尽量直供 x86 下载地址",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "供应链异常自动降级",
                "desc": "闭源层加载失败即切 QEMU",
                "on": true,
                "tone": "good"
              },
              {
                "label": "强制 QEMU 调试",
                "desc": "开发模式：全量走可审计路径",
                "on": false,
                "tone": "info"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-appstore", "tier": "app",
    "name": "CT 应用商店",
    "sub": "containerlinux-app-store",
    "icon": "ri-store-2-line",
    "from": "#b5813a",
    "to": "#dcae63",
    "group": "兼容与生态",
    "status": "策展中",
    "desc": "策展式分发 · 双模式版本 · 源码优先安装流",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "store",
        "label": "策展分发",
        "icon": "ri-store-2-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-store-2-line",
            "badge": "D22 / 24.7",
            "title": "想要什么，先逛商店",
            "tone": "amber",
            "desc": "第一方策展式应用分发：闭源应用尽量直供 x86 下载地址、开源应用给电脑 + 平板双模式版本；商店外来源走源码优先安装流。"
          },
          {
            "t": "cards",
            "title": "分发策略",
            "items": [
              {
                "icon": "ri-download-line",
                "title": "闭源应用",
                "desc": "尽量直供 x86 下载地址，避免 ARM→x86 翻译损耗",
                "badge": "直供",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-code-box-line",
                "title": "开源应用",
                "desc": "提供电脑 + 平板双模式版本，源码优先",
                "badge": "双模式",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-git-branch-line",
                "title": "商店外来源",
                "desc": "源码优先安装流：拉取源码 → 本地构建 → 签名 → 挂载包",
                "badge": "源码流",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-shield-check-line",
                "title": "签名与信任",
                "desc": "全部应用经 CT 签名链校验后进入 /CTF/Apps/",
                "badge": "安全",
                "tone": "good",
                "tags": []
              }
            ]
          },
          {
            "t": "table",
            "title": "应用来源与处理",
            "cols": [
              "来源",
              "处理路径",
              "产物"
            ],
            "rows": [
              [
                "商店 · 闭源 x86",
                "直接下载 + 签名校验",
                "x86 挂载包"
              ],
              [
                "商店 · 开源",
                "双模式版本 / 源码构建",
                "电脑 + 平板双 UI"
              ],
              [
                "商店外 · 开源",
                "源码优先安装流",
                "本地构建挂载包"
              ],
              [
                "Android (ARM)",
                "翻译层双轨",
                "LSA 窗口"
              ],
              [
                "Windows",
                "Wine Direct / LSW",
                "LSW 窗口"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "双模式应用（24.8）",
            "text": "同一份 x86 Linux 代码 + 响应式双 UI（iced Responsive）：电脑模式（多窗口布局，桌面生产）与平板模式（触控布局，快捷操作）为同一应用的两种响应式布局，共享数据。"
          }
        ]
      },
      {
        "id": "stages",
        "label": "两阶段路线",
        "icon": "ri-calendar-line",
        "blocks": [
          {
            "t": "timeline",
            "title": "24.8 两阶段",
            "items": [
              {
                "time": "阶段一",
                "title": "电脑模式优先",
                "desc": "桌面生产场景，多窗口布局 + 键鼠",
                "tone": "good"
              },
              {
                "time": "阶段二",
                "title": "平板模式跟进",
                "desc": "触控布局、快捷操作，与电脑模式共享数据",
                "tone": "accent"
              },
              {
                "time": "后续",
                "title": "蜂群应用",
                "desc": "跨设备接续与 P2P 计算池",
                "tone": "violet"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "商店指标",
            "items": [
              {
                "v": "x86",
                "label": "首选架构",
                "unit": "",
                "tone": ""
              },
              {
                "v": "2",
                "label": "UI 模式",
                "unit": "种",
                "tone": ""
              },
              {
                "v": "0",
                "label": "第三方签名绕过",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "/CTF/Apps",
                "label": "落点",
                "unit": "",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "chips",
            "title": "技术栈",
            "items": [
              "iced Responsive",
              "CT 签名链",
              "EROFS 挂载包",
              "源码优先",
              "D22",
              "RDBus"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-devvm", "tier": "skip",
    "name": "DevVM 开发虚拟机",
    "sub": "第 25 章",
    "icon": "ri-code-box-line",
    "from": "#3f5168",
    "to": "#6f86a8",
    "group": "兼容与生态",
    "status": "待启动",
    "desc": "隔离开发环境 · 硬件分区 · 与宿主协同",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "devvm",
        "label": "开发虚拟机",
        "icon": "ri-code-box-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-code-box-line",
            "badge": "第 25 章",
            "title": "DevVM：隔离的开发环境",
            "tone": "blue",
            "desc": "面向开发者的隔离虚拟机：与宿主共享 ct-data / exFAT 数据分区，同时提供可复现、可丢弃的完整系统环境。"
          },
          {
            "t": "cards",
            "title": "能力",
            "items": [
              {
                "icon": "ri-box-3-line",
                "title": "完整系统环境",
                "desc": "与宿主隔离，可随意安装依赖、破坏性测试",
                "badge": "隔离",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-folder-2-line",
                "title": "数据互通",
                "desc": "经 exFAT 统一数据分区与宿主四方访问",
                "badge": "共享",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-archive-2-line",
                "title": "场景镜像",
                "desc": "DML 动态挂载 Kali 等场景镜像（DML / 49）",
                "badge": "场景",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-git-branch-line",
                "title": "快照与回滚",
                "desc": "三层存储快照绑定，随时回到干净状态",
                "badge": "可回滚",
                "tone": "good",
                "tags": []
              }
            ]
          },
          {
            "t": "table",
            "title": "与 LSW 直通层的关系",
            "cols": [
              "维度",
              "DevVM",
              "LSW 第三层 VM"
            ],
            "rows": [
              [
                "用途",
                "开发 / 测试",
                "Windows 应用性能兜底"
              ],
              [
                "授权",
                "无需额外授权",
                "需用户自带 Windows 授权"
              ],
              [
                "数据来源",
                "ct-data / exFAT",
                "独立硬件分区"
              ],
              [
                "随 Runtime",
                "可选能力",
                "L3 层可选"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与安装器 / 救援复用",
            "text": "DevVM 与「零发行版模式」装机载体、救援环境复用同一套镜像与挂载机制——一鱼多吃，不为开发场景单独造一套。"
          }
        ]
      },
      {
        "id": "spec",
        "label": "规格",
        "icon": "ri-list-check-2",
        "blocks": [
          {
            "t": "kpis",
            "title": "默认规格",
            "items": [
              {
                "v": "4",
                "label": "vCPU",
                "unit": "核",
                "tone": ""
              },
              {
                "v": "8",
                "label": "内存",
                "unit": "GB",
                "tone": ""
              },
              {
                "v": "40",
                "label": "磁盘",
                "unit": "GB",
                "tone": ""
              },
              {
                "v": "Btrfs",
                "label": "快照格式",
                "unit": "",
                "tone": ""
              }
            ]
          },
          {
            "t": "toggles",
            "title": "运行配置",
            "items": [
              {
                "label": "共享剪贴板",
                "desc": "经 RDBus 与宿主互通",
                "on": true,
                "tone": "good"
              },
              {
                "label": "exFAT 数据分区挂载",
                "desc": "四方访问的统一数据中转",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "嵌套虚拟化",
                "desc": "按需开启，供容器内再跑 VM",
                "on": true,
                "tone": "info"
              },
              {
                "label": "GPU 直通",
                "desc": "性能敏感场景，默认关闭",
                "on": false,
                "tone": "warn"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-appmgr", "tier": "app",
    "name": "统一应用管理",
    "sub": "app-manager",
    "icon": "ri-apps-2-line",
    "from": "#3b6fd4",
    "to": "#6f9de8",
    "group": "兼容与生态",
    "status": "智能路由中",
    "desc": "五类应用来源 · 智能路由 · 冷热状态账本",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "router",
        "label": "智能路由",
        "icon": "ri-apps-2-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-apps-2-line",
            "badge": "23.10",
            "title": "containerlinux-app-manager",
            "tone": "blue",
            "desc": "统一应用管理：五类应用来源经智能路由落到对应运行器，用户只看到「打开应用」，不关心背后是原生、Wine、LSA 还是蜂群。"
          },
          {
            "t": "steps",
            "title": "启动一条应用时的路由",
            "items": [
              {
                "n": "①",
                "title": "识别来源",
                "desc": "读取挂载包 manifest 的 source 标记",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "选择运行器",
                "desc": "原生 / Wine Direct / LSA / DevVM / 蜂群",
                "tone": "accent"
              },
              {
                "n": "③",
                "title": "冷热恢复",
                "desc": "查 AppRegistry：冷态先挂载 / 解包",
                "tone": "teal"
              },
              {
                "n": "④",
                "title": "资源预算",
                "desc": "ct-core 按成本画像分配预算",
                "tone": "violet"
              },
              {
                "n": "⑤",
                "title": "模式联动",
                "desc": "power-shift 按应用类型切换系统模式",
                "tone": "green"
              }
            ]
          },
          {
            "t": "table",
            "title": "五类应用来源",
            "cols": [
              "来源",
              "运行器",
              "窗口形态"
            ],
            "rows": [
              [
                "Linux 原生",
                "直接执行",
                "Wayland toplevel"
              ],
              [
                "Windows",
                "Wine Direct / LSW",
                "LSW 窗口（带来源角标）"
              ],
              [
                "Android",
                "LSA Runtime Dispatcher",
                "LSA 窗口"
              ],
              [
                "开发 / 场景",
                "DevVM",
                "虚拟机窗口"
              ],
              [
                "蜂群应用",
                "ct_swarmd 远程调度",
                "接续窗口"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与冷热调度联动",
            "text": "路由结果与 AppRegistry 的热/温/冷状态绑定：7 天候选打包、30 天强制、90 天归档；7 天内启动 ≥ 3 次自动解包回热态（49A.6）。"
          }
        ]
      },
      {
        "id": "registry",
        "label": "应用注册表",
        "icon": "ri-clipboard-line",
        "blocks": [
          {
            "t": "kpis",
            "title": "账本概况",
            "items": [
              {
                "v": "38",
                "label": "已登记应用",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "16",
                "label": "热态",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "13",
                "label": "温态",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "9",
                "label": "冷态",
                "unit": "个",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "rings",
            "title": "三态分布",
            "items": [
              {
                "label": "热态",
                "pct": 42,
                "tone": "bad"
              },
              {
                "label": "温态",
                "pct": 34,
                "tone": "accent"
              },
              {
                "label": "冷态",
                "pct": 24,
                "tone": "blue"
              }
            ]
          },
          {
            "t": "logs",
            "title": "路由事件",
            "lines": [
              {
                "t": "OK",
                "text": "app: blender → 原生运行器 · 热态",
                "tone": "good"
              },
              {
                "t": "OK",
                "text": "app: photoshop → LSW · 来源角标显示",
                "tone": "accent"
              },
              {
                "t": "INFO",
                "text": "app: 某 ARM 应用 → LSA / lepton-backend",
                "tone": "info"
              },
              {
                "t": "OK",
                "text": "cold-restore: 归档挂载包已解包 → 热态",
                "tone": "good"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-modes", "tier": "system",
    "name": "系统模式与性能",
    "sub": "power-shift",
    "icon": "ri-speed-mini-line",
    "from": "#b0527a",
    "to": "#e08aa8",
    "group": "兼容与生态",
    "status": "标准模式",
    "desc": "十系统模式 · 过载 / 超级省电 · 热键 · 影响矩阵",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "modes",
        "label": "模式体系",
        "icon": "ri-grid-fill",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-speed-mini-line",
            "badge": "Ctrl+Alt+N/O/S/F…",
            "title": "containerlinux-power-shift",
            "tone": "pink",
            "desc": "核心哲学：用户决定系统资源的归属，而不是内核默认的「公平调度」。十种模式覆盖从游戏到冬眠的全部场景。"
          },
          {
            "t": "segments",
            "title": "当前模式",
            "options": [
              "标准",
              "过载",
              "超级省电",
              "专注",
              "演示",
              "安全",
              "恢复",
              "蜂群",
              "TTY",
              "兼容"
            ],
            "value": "标准",
            "hint": "切换经预检 → 应用（事务）→ 失败回滚三段式"
          },
          {
            "t": "cards",
            "title": "模式总览",
            "items": [
              {
                "icon": "ri-checkbox-blank-circle-line",
                "title": "标准模式",
                "desc": "公平共享 · 默认 CFS/EEVDF + 快照隔离 · 日常办公",
                "badge": "Ctrl+Alt+N",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-flashlight-line",
                "title": "过载模式",
                "desc": "性能独裁 · 全核锁频 + 裸磁盘 + 冻结后台 · 游戏/实时渲染",
                "badge": "Ctrl+Alt+O",
                "tone": "bad",
                "tags": []
              },
              {
                "icon": "ri-moon-line",
                "title": "超级省电",
                "desc": "脉动生存 · 单核 400MHz + 冻结一切 + 零写盘",
                "badge": "Ctrl+Alt+S",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-focus-3-line",
                "title": "专注模式",
                "desc": "屏蔽通知 + 应用白名单 + 网络收敛",
                "badge": "Ctrl+Alt+F",
                "tone": "violet",
                "tags": []
              }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "过载模式（32.7）",
            "text": "ct_overdrive.ko：全核锁频、裸磁盘直访、冻结后台进程、GPU 独占。切换前预检电源与温度，事务式应用；任何一步失败整体回滚，不留半套状态。"
          }
        ]
      },
      {
        "id": "matrix",
        "label": "影响矩阵",
        "icon": "ri-layout-grid-line",
        "blocks": [
          {
            "t": "table",
            "title": "十模式速览（32.9）",
            "cols": [
              "模式",
              "热键",
              "核心动作"
            ],
            "rows": [
              [
                "标准",
                "N",
                "公平调度 + 快照隔离"
              ],
              [
                "过载",
                "O",
                "全核锁频 / 冻结后台"
              ],
              [
                "超级省电",
                "S",
                "单核 400MHz / 零写盘"
              ],
              [
                "专注",
                "F",
                "通知屏蔽 / 白名单"
              ],
              [
                "演示",
                "P",
                "分辨率锁定 / 动画增强"
              ],
              [
                "安全",
                "E",
                "防火墙收紧 / 沙箱强化"
              ],
              [
                "恢复",
                "R",
                "L0 救援副本 / 只读"
              ],
              [
                "蜂群",
                "W",
                "P2P 计算池 / 任务让渡"
              ],
              [
                "TTY",
                "T",
                "切 CTTY 控制台"
              ],
              [
                "兼容",
                "C",
                "最大兼容 / 关闭优化"
              ]
            ]
          },
          {
            "t": "kpis",
            "title": "切换机制",
            "items": [
              {
                "v": "3",
                "label": "切换段",
                "unit": "段",
                "tone": ""
              },
              {
                "v": "0",
                "label": "半套状态",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "10",
                "label": "模式数",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "<1",
                "label": "切换耗时",
                "unit": "s",
                "tone": "good"
              }
            ]
          },
          {
            "t": "toggles",
            "title": "三平面下发",
            "items": [
              {
                "label": "cpufreq sysfs",
                "desc": "governor / EPP / 锁频",
                "on": true,
                "tone": "good"
              },
              {
                "label": "cgroup",
                "desc": "CPU / IO / 内存配额与后台冻结",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "内核模块参数",
                "desc": "ct_overdrive / ct_ultra_saver sysfs 接口",
                "on": true,
                "tone": "info"
              },
              {
                "label": "失败自动回滚",
                "desc": "事务式应用，任一步失败整体回退",
                "on": true,
                "tone": "good"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-swarm", "tier": "system",
    "name": "蜂群管理",
    "sub": "第 28 章",
    "icon": "ri-share-line",
    "from": "#2b7fb8",
    "to": "#5fb6e0",
    "group": "兼容与生态",
    "status": "3 台在线",
    "desc": "剪贴板同步 · 键鼠共享 · 应用接续 · P2P 计算池",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "swarm",
        "label": "蜂群调度",
        "icon": "ri-team-line",
        "blocks": [
          {
            "t": "swarm",
            "title": "蜂群节点与任务",
            "sub": "ct_swarmd · 多设备协同调度",
            "nodes": [
              {
                "name": "本机（蜂后）",
                "role": "协调 · 蜂后",
                "status": "online",
                "ip": "127.0.0.1",
                "isQueen": true
              },
              {
                "name": "书房 NUC",
                "role": "算力",
                "status": "online",
                "ip": "192.168.1.20"
              },
              {
                "name": "客厅迷你机",
                "role": "算力",
                "status": "idle",
                "ip": "192.168.1.21"
              },
              {
                "name": "工作站",
                "role": "GPU 渲染",
                "status": "online",
                "ip": "192.168.1.30"
              },
              {
                "name": "边缘盒子",
                "role": "待命",
                "status": "offline",
                "ip": "192.168.1.40"
              }
            ],
            "tasks": [
              {
                "name": "4K 视频分片渲染",
                "node": "工作站",
                "progress": 38,
                "status": "running"
              },
              {
                "name": "日志聚合分析",
                "node": "书房 NUC",
                "progress": 72,
                "status": "running"
              }
            ]
          }
        ]
      },
      {
        "id": "about",
        "label": "关于",
        "icon": "ri-information-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-team-line",
            "badge": "ct_swarmd",
            "title": "蜂群管理",
            "tone": "blue",
            "desc": "把多台 ContainerLinux 设备组成一个「蜂群」：一台做蜂后协调，其余做工蜂执行。调度层（ct_swarmd）与传输层（ct-p2p）分离，换算法不用动网络栈。"
          },
          {
            "t": "cards",
            "title": "它能做什么",
            "items": [
              {
                "icon": "ri-server-line",
                "title": "节点管理",
                "desc": "连接 / 断开节点，一键指定蜂后，状态实时刷新。",
                "tone": "teal"
              },
              {
                "icon": "ri-task-line",
                "title": "任务分发",
                "desc": "提交分布式任务，自动派给在线工蜂并跟踪进度。",
                "tone": "violet"
              },
              {
                "icon": "ri-shield-line",
                "title": "容错迁移",
                "desc": "节点掉线，蜂后自动把任务漂移到其他在线节点。",
                "tone": "amber"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "演示说明",
            "text": "当前为前端模拟：节点状态切换、蜂后指定、任务进度与新增节点 / 任务均为本地交互，不连接真实设备。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-storage", "tier": "system",
    "name": "三层存储",
    "sub": "Btrfs COW",
    "icon": "ri-database-2-line",
    "from": "#b5813a",
    "to": "#dcae63",
    "group": "存储与恢复",
    "status": "已挂载",
    "desc": "基础模板 + 增量层 + 操作日志 · 快照=引用",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "model",
        "label": "三层模型",
        "icon": "ri-database-2-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-database-2-line",
            "badge": "第 20 章",
            "title": "系统的时间机器",
            "tone": "amber",
            "desc": "Btrfs COW 基础上的三层存储：基础模板（只读）+ 增量层（可写）+ 操作日志。快照是引用而非复制——「拍照不要钱」。"
          },
          {
            "t": "steps",
            "title": "三层结构",
            "items": [
              {
                "n": "①",
                "title": "基础模板层",
                "desc": "base_1.0 只读子卷，系统出厂基线",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "增量层",
                "desc": "当前会话的所有写操作，COW 只记差异",
                "tone": "accent"
              },
              {
                "n": "③",
                "title": "操作日志",
                "desc": "containerlinux-logd（Rust inotify 最小版）记录每次变更",
                "tone": "teal"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "当前卷",
            "items": [
              {
                "v": "base_1.0",
                "label": "基础模板",
                "unit": "",
                "tone": ""
              },
              {
                "v": "128",
                "label": "活动快照",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "2.4",
                "label": "增量层",
                "unit": "GB",
                "tone": ""
              },
              {
                "v": "0",
                "label": "快照复制",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "code",
            "title": "Btrfs 子卷结构（44.1）",
            "code": "/@\n├── base_1.0/          # 只读基础模板\n├── increment/         # 当前增量层（COW）\n├── snapshots/         # 快照 = 引用，非复制\n│   ├── 2026-09-25-0900/\n│   └── 2026-09-24-1800/\n├── log/               # 操作日志（logd）\n└── ct-data/           # 用户数据（跨快照保留）",
            "lang": "btrfs"
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "关机两条路",
            "text": "containerlinux-seal（关机固化）：把增量层提交为新快照；containerlinux-discard（关机丢弃）：直接丢弃增量层回到基线。用户开机时即可选择本次会话是否留痕。"
          }
        ]
      },
      {
        "id": "adaptive",
        "label": "自适应存储",
        "icon": "ri-sd-card-line",
        "blocks": [
          {
            "t": "table",
            "title": "20.5 三层自适应",
            "cols": [
              "层级",
              "介质",
              "策略"
            ],
            "rows": [
              [
                "热数据",
                "NVMe / 内存",
                "增量层常驻，低延迟"
              ],
              [
                "温数据",
                "SSD",
                "快照压缩存放（zstd）"
              ],
              [
                "冷数据",
                "HDD / 归档",
                "只读镜像、按需挂载"
              ]
            ]
          },
          {
            "t": "toggles",
            "title": "运行策略",
            "items": [
              {
                "label": "写时复制（COW）",
                "desc": "快照只记引用，创建几乎零成本",
                "on": true,
                "tone": "good"
              },
              {
                "label": "zstd 压缩",
                "desc": "快照与镜像透明压缩",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "操作日志 inotify",
                "desc": "logd 实时捕获文件变更",
                "on": true,
                "tone": "info"
              },
              {
                "label": "跨快照保留 ct-data",
                "desc": "用户数据不随回滚丢失",
                "on": true,
                "tone": "good"
              }
            ]
          },
          {
            "t": "bars",
            "title": "介质分布",
            "items": [
              {
                "label": "NVMe 热数据",
                "pct": 38,
                "tone": "accent"
              },
              {
                "label": "SSD 快照",
                "pct": 44,
                "tone": ""
              },
              {
                "label": "HDD 归档",
                "pct": 18,
                "tone": "good"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-timetravel", "tier": "system",
    "name": "时间回溯",
    "sub": "LogSpace / 操作日志",
    "icon": "ri-history-line",
    "from": "#7d4fd1",
    "to": "#a97ef0",
    "group": "存储与恢复",
    "status": "128 个快照",
    "desc": "时间线回溯 · LogSpace 文件中转 · 操作类型区分",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "overview",
        "label": "概览",
        "icon": "ri-dashboard-3-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-history-line",
            "badge": "Btrfs",
            "title": "时间回溯",
            "tone": "blue",
            "desc": "系统状态是一条 Btrfs 快照链：快照是引用而非复制，创建几乎零成本。任意节点一键回滚到过去状态，增量层被替换而不动基线。"
          },
          {
            "t": "kpis",
            "title": "快照概览",
            "items": [
              {
                "v": "5",
                "label": "可用快照",
                "unit": "个",
                "tone": "blue"
              },
              {
                "v": "0",
                "label": "回滚耗时",
                "unit": "s",
                "tone": "green"
              },
              {
                "v": "1.2",
                "label": "最新快照",
                "unit": "GB",
                "tone": "teal"
              }
            ]
          },
          {
            "t": "cards",
            "title": "回滚原则",
            "items": [
              {
                "icon": "ri-git-branch-line",
                "title": "引用快照",
                "desc": "不复制数据，回滚就是换指针。",
                "tone": "violet"
              },
              {
                "icon": "ri-shield-check-line",
                "title": "基线不动",
                "desc": "出厂基线始终可回，不会越回越旧。",
                "tone": "amber"
              },
              {
                "icon": "ri-time-line",
                "title": "增量替换",
                "desc": "回滚替换增量层，当前变更被丢弃。",
                "tone": "cyan"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "注意",
            "text": "回滚会丢弃当前增量层中的未快照变更。演示中回滚为本地模拟，不会真正改写磁盘。"
          }
        ]
      },
      {
        "id": "time",
        "label": "时间轴",
        "icon": "ri-history-line",
        "blocks": [
          {
            "t": "review",
            "title": "系统快照链",
            "sub": "点击任意节点回滚到该状态",
            "current": "live",
            "snapshots": [
              {
                "id": "live",
                "date": "实时",
                "label": "当前增量层",
                "type": "live",
                "size": "—",
                "tone": "good"
              },
              {
                "id": "s1",
                "date": "2026-11-03 14:20",
                "label": "系统更新 · 内核 ctk-new",
                "type": "更新",
                "size": "1.2GB",
                "tone": "blue"
              },
              {
                "id": "s2",
                "date": "2026-10-28 09:05",
                "label": "安装 Docker 运行时",
                "type": "安装",
                "size": "840MB",
                "tone": "teal"
              },
              {
                "id": "s3",
                "date": "2026-10-15 21:40",
                "label": "桌面主题切换 · 霓虹",
                "type": "配置",
                "size": "24MB",
                "tone": "violet"
              },
              {
                "id": "base",
                "date": "2026-09-30 00:00",
                "label": "出厂基线",
                "type": "基线",
                "size": "—",
                "tone": "amber"
              }
            ]
          }
        ]
      },
      {
        "id": "log",
        "label": "回滚日志",
        "icon": "ri-list-check-2",
        "blocks": [
          {
            "t": "logs",
            "title": "历史回滚记录",
            "lines": [
              {
                "t": "09-30",
                "text": "初始化出厂基线（base）",
                "tone": "amber"
              },
              {
                "t": "10-15",
                "text": "创建快照 s3 · 桌面主题切换",
                "tone": "violet"
              },
              {
                "t": "10-28",
                "text": "创建快照 s2 · Docker 运行时",
                "tone": "teal"
              },
              {
                "t": "11-03",
                "text": "创建快照 s1 · 内核 ctk-new",
                "tone": "blue"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-ramos", "tier": "skip",
    "name": "RamOS 内存看门狗",
    "sub": "第 21.1 章",
    "icon": "ri-pulse-line",
    "from": "#2f8f7a",
    "to": "#54bfa2",
    "group": "存储与恢复",
    "status": "守护中",
    "desc": "硬盘断开系统不死 · 内存驻留 · 零写盘",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "ramos",
        "label": "看门狗",
        "icon": "ri-pulse-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-pulse-line",
            "badge": "系统的保安",
            "title": "硬盘断开，系统不死",
            "tone": "teal",
            "desc": "RamOS 内存看门狗：关键运行时常驻内存，存储意外断开时维持系统可操作，给足时间保存工作或切换恢复流程。"
          },
          {
            "t": "steps",
            "title": "断开时的三段响应",
            "items": [
              {
                "n": "①",
                "title": "检测",
                "desc": "块设备心跳丢失，立即标记存储降级",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "冻结",
                "desc": "切换零写盘，冻结一切可能触发 IO 的后台任务",
                "tone": "accent"
              },
              {
                "n": "③",
                "title": "维持",
                "desc": "内存中的运行时继续可用，弹出恢复 / 保存引导",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "内存预算",
            "items": [
              {
                "v": "1.2",
                "label": "常驻镜像",
                "unit": "GB",
                "tone": ""
              },
              {
                "v": "0",
                "label": "写盘操作",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "<50",
                "label": "检测延迟",
                "unit": "ms",
                "tone": "good"
              },
              {
                "v": "∞",
                "label": "维持时长",
                "unit": "(内存允许)",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "与超级省电联动",
            "text": "RamOS 与 ct_ultra_saver.ko 共享「零写盘」路径：后者是主动的脉动生存模式，前者是被动的存储故障兜底，两者复用同一套冻结与内存驻留机制。"
          }
        ]
      },
      {
        "id": "policy",
        "label": "策略",
        "icon": "ri-shield-check-line",
        "blocks": [
          {
            "t": "toggles",
            "title": "守护策略",
            "items": [
              {
                "label": "块设备心跳",
                "desc": "周期探测，丢失即降级",
                "on": true,
                "tone": "good"
              },
              {
                "label": "关键运行时内存驻留",
                "desc": "L0 核心层 + TUI + 恢复入口",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "自动冻结后台",
                "desc": "阻止 IO 触发的级联错误",
                "on": true,
                "tone": "info"
              },
              {
                "label": "写盘缓冲回灌",
                "desc": "存储恢复后按操作日志重放",
                "on": true,
                "tone": "good"
              }
            ]
          },
          {
            "t": "logs",
            "title": "看门狗日志",
            "lines": [
              {
                "t": "INFO",
                "text": "ramos: watchdog armed (interval 500ms)",
                "tone": ""
              },
              {
                "t": "OK",
                "text": "L0 runtime pinned in memory (1.2GB)",
                "tone": "good"
              },
              {
                "t": "INFO",
                "text": "zero-write path ready",
                "tone": ""
              },
              {
                "t": "OK",
                "text": "recovery entry: /CTF/Images/rescue.img",
                "tone": "good"
              }
            ]
          },
          {
            "t": "rings",
            "title": "内存驻留分布",
            "items": [
              {
                "label": "L0 运行时",
                "pct": 48,
                "tone": "accent"
              },
              {
                "label": "TUI / 恢复",
                "pct": 22,
                "tone": "good"
              },
              {
                "label": "页面缓存",
                "pct": 18,
                "tone": "blue"
              },
              {
                "label": "预留",
                "pct": 12,
                "tone": "warn"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-dml", "tier": "system",
    "name": "动态镜像 DML",
    "sub": "DLC / 第 49 章",
    "icon": "ri-disc-line",
    "from": "#c05a3a",
    "to": "#e8916b",
    "group": "存储与恢复",
    "status": "2 个已挂载",
    "desc": "按需挂载场景镜像 · 元数据仓库 · dlc-daemon",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "dml",
        "label": "动态镜像",
        "icon": "ri-disc-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-disc-line",
            "badge": "用到才挂的「抽屉」",
            "title": "动态挂载层 DML",
            "tone": "orange",
            "desc": "按需挂载 Kali 等场景镜像：不常驻、不占系统体积，用到时才挂、用完即卸。containerlinux-dlc-daemon 负责下载与生命周期。"
          },
          {
            "t": "cards",
            "title": "镜像分级规格（49.2）",
            "items": [
              {
                "icon": "ri-box-1-line",
                "title": "基础镜像",
                "desc": "最小可用场景，约数百 MB",
                "badge": "L1",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-box-3-line",
                "title": "标准镜像",
                "desc": "常用工具集，约 1–2 GB",
                "badge": "L2",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-archive-2-line",
                "title": "完整镜像",
                "desc": "全量场景，按需下载",
                "badge": "L3",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-shield-line",
                "title": "黑客模式镜像",
                "desc": "隔离沙箱内挂载，安全策略收紧（34.3）",
                "badge": "隔离",
                "tone": "bad",
                "tags": []
              }
            ]
          },
          {
            "t": "table",
            "title": "可用场景镜像",
            "cols": [
              "镜像",
              "级别",
              "状态"
            ],
            "rows": [
              [
                "ct-kali-scenario",
                "L3 完整",
                "已挂载"
              ],
              [
                "ct-dev-scenario",
                "L2 标准",
                "已挂载"
              ],
              [
                "ct-rescue-scenario",
                "L1 基础",
                "本地就绪"
              ],
              [
                "ct-pentest-full",
                "L3 完整",
                "未下载"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与挂载包体系同源",
            "text": "DML 场景镜像就是 Mountable 的 scenario 类型：只读 .erofs + manifest.toml + 签名，由 Mounts 管理器 evict_idle / evict_under_pressure 统一释放。"
          }
        ]
      },
      {
        "id": "flow",
        "label": "挂载流程",
        "icon": "ri-route-line",
        "blocks": [
          {
            "t": "steps",
            "title": "动态挂载 / 卸载（49.4）",
            "items": [
              {
                "n": "①",
                "title": "元数据查询",
                "desc": "查仓库 manifest 与本地缓存",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "下载（dlc-daemon）",
                "desc": "ct-download 多连接分片 + 校验",
                "tone": "accent"
              },
              {
                "n": "③",
                "title": "签名校验",
                "desc": "CT 签名链通过后才允许 mount",
                "tone": "violet"
              },
              {
                "n": "④",
                "title": "只读挂载",
                "desc": "EROFS 挂到 /CTF/Images/",
                "tone": "teal"
              },
              {
                "n": "⑤",
                "title": "空闲卸载",
                "desc": "evict_idle 触发 unmount",
                "tone": "green"
              }
            ]
          },
          {
            "t": "progress",
            "title": "下载进度",
            "items": [
              {
                "label": "ct-kali-scenario",
                "pct": 100,
                "sub": "L3 完整镜像 · 3.2 GB",
                "meta": "已挂载",
                "tone": "good"
              },
              {
                "label": "ct-dev-scenario",
                "pct": 100,
                "sub": "L2 标准 · 1.4 GB",
                "meta": "已挂载",
                "tone": "good"
              },
              {
                "label": "ct-pentest-full",
                "pct": 36,
                "sub": "L3 完整 · 4.8 GB",
                "meta": "下载中",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "仓库指标",
            "items": [
              {
                "v": "4",
                "label": "场景镜像",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "2",
                "label": "已挂载",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "3",
                "label": "分级",
                "unit": "级",
                "tone": ""
              },
              {
                "v": "zstd",
                "label": "压缩",
                "unit": "",
                "tone": "accent"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-recovery", "tier": "skip",
    "name": "多级恢复体系",
    "sub": "第 31 章",
    "icon": "ri-shield-check-line",
    "from": "#4d6b5a",
    "to": "#79a68c",
    "group": "存储与恢复",
    "status": "L0 副本就绪",
    "desc": "多级恢复 · 三层急救降级 · ESP 救援副本",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "levels",
        "label": "多级恢复",
        "icon": "ri-shield-check-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-shield-check-line",
            "badge": "31.1",
            "title": "从「点一下」到「全盘重建」",
            "tone": "green",
            "desc": "多级恢复体系按故障深度逐级升级：文件级 → 快照级 → 系统级 → 救援级，每一级都有明确的入口与代价。"
          },
          {
            "t": "steps",
            "title": "四级恢复",
            "items": [
              {
                "n": "L1",
                "title": "文件级",
                "desc": "LogSpace / 快照里取回单个文件，零停机",
                "tone": "good"
              },
              {
                "n": "L2",
                "title": "快照级",
                "desc": "时间回溯回滚到任一快照，重启生效",
                "tone": "blue"
              },
              {
                "n": "L3",
                "title": "系统级",
                "desc": "丢弃增量层回到 base_1.0，CT 层不变",
                "tone": "accent"
              },
              {
                "n": "L4",
                "title": "救援级",
                "desc": "ESP L0 常驻救援副本引导，重装修复",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "table",
            "title": "急救模式三层降级（31.2）",
            "cols": [
              "层",
              "内容",
              "触发条件"
            ],
            "rows": [
              [
                "第一层",
                "CTTY + ct-shell 最小集",
                "图形栈轻微故障"
              ],
              [
                "第二层",
                "TUI 控制中心（L0）",
                "图形栈不可用"
              ],
              [
                "第三层",
                "ESP L0 救援副本 / 恢复环境",
                "系统无法启动"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "为什么能兜底",
            "text": "L0 核心层（约 35–60MB，TUI / CTTY / .cte 加载）随 CT-Kernel 原子更新，并在 ESP 保留常驻救援副本——即使增量层全毁，仍有一个可引导的最小系统。"
          }
        ]
      },
      {
        "id": "tools",
        "label": "恢复工具",
        "icon": "ri-tools-line",
        "blocks": [
          {
            "t": "cards",
            "title": "可用工具",
            "items": [
              {
                "icon": "ri-history-line",
                "title": "时间回溯 TUI",
                "desc": "选择快照 / 查看差异 / 一键回滚",
                "badge": "L2",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-refresh-line",
                "title": "seal / discard",
                "desc": "关机时固化或丢弃增量层",
                "badge": "L3",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-archive-2-line",
                "title": "ESP 救援副本",
                "desc": "L0 常驻，内核更新失败可回退",
                "badge": "L4",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-shield-star-line",
                "title": "急救环境",
                "desc": "只读挂载 + 修复工具集",
                "badge": "急救",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "kpis",
            "title": "恢复能力",
            "items": [
              {
                "v": "4",
                "label": "恢复级别",
                "unit": "级",
                "tone": ""
              },
              {
                "v": "3",
                "label": "急救降级层",
                "unit": "层",
                "tone": ""
              },
              {
                "v": "1",
                "label": "ESP 副本",
                "unit": "份",
                "tone": "accent"
              },
              {
                "v": "0",
                "label": "外部介质依赖",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "logs",
            "title": "健康检查",
            "lines": [
              {
                "t": "OK",
                "text": "ESP L0 rescue image verified (ct-sign-v2)",
                "tone": "good"
              },
              {
                "t": "OK",
                "text": "Btrfs: 128 snapshots healthy",
                "tone": ""
              },
              {
                "t": "OK",
                "text": "base_1.0 read-only subvolume intact",
                "tone": "good"
              },
              {
                "t": "INFO",
                "text": "last seal: 2026-09-24 18:00",
                "tone": "info"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-exfat", "tier": "skip",
    "name": "统一数据分区",
    "sub": "第 26 章",
    "icon": "ri-sd-card-line",
    "from": "#2b7fb8",
    "to": "#5fb6e0",
    "group": "存储与恢复",
    "status": "四方访问中",
    "desc": "exFAT · ContainerLinux / Windows / LSA / DevVM",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "partition",
        "label": "数据分区",
        "icon": "ri-sd-card-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-sd-card-line",
            "badge": "26.1 / 26.2",
            "title": "一份数据，四方访问",
            "tone": "cyan",
            "desc": "exFAT 统一数据分区：ContainerLinux 本体、Windows（双系统 / LSW）、Android（LSA）、DevVM 四方共用同一份用户数据，无需来回拷贝。"
          },
          {
            "t": "nodes",
            "title": "四方访问",
            "center": "exFAT /share",
            "items": [
              {
                "label": "ContainerLinux",
                "sub": "原生读写",
                "tone": "blue"
              },
              {
                "label": "Windows / LSW",
                "sub": "双系统 / 兼容层",
                "tone": "violet"
              },
              {
                "label": "LSA (Android)",
                "sub": "应用数据共享",
                "tone": "teal"
              },
              {
                "label": "DevVM",
                "sub": "开发环境互通",
                "tone": "amber"
              }
            ]
          },
          {
            "t": "table",
            "title": "分区布局",
            "cols": [
              "分区",
              "格式",
              "用途"
            ],
            "rows": [
              [
                "ESP",
                "FAT32",
                "引导 + L0 救援副本"
              ],
              [
                "ct-data",
                "Btrfs",
                "三层存储 / 用户数据 / CTF"
              ],
              [
                "rec",
                "—",
                "恢复分区"
              ],
              [
                "share",
                "exFAT",
                "统一数据分区（四方访问）"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "为什么是 exFAT",
            "text": "Btrfs 对 Windows / Android 不友好，NTFS 在 Linux 上权限模型别扭。exFAT 是四方都能原生读写的最大公约数——代价是没有 COW 快照，因此只放「数据」，系统状态仍由 ct-data 的 Btrfs 管。"
          }
        ]
      },
      {
        "id": "policy",
        "label": "挂载策略",
        "icon": "ri-links-line",
        "blocks": [
          {
            "t": "toggles",
            "title": "自动挂载（44.9）",
            "items": [
              {
                "label": "开机自动挂载 /share",
                "desc": "udev + fstab，四方均可访问",
                "on": true,
                "tone": "good"
              },
              {
                "label": "字符集与权限映射",
                "desc": "UTF-8 文件名，统一 umask",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "四方并发写保护",
                "desc": "文件锁 + 冲突提示",
                "on": true,
                "tone": "info"
              },
              {
                "label": "纳入时间线快照",
                "desc": "默认否，避免污染快照链",
                "on": false,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "分区指标",
            "items": [
              {
                "v": "exFAT",
                "label": "文件系统",
                "unit": "",
                "tone": ""
              },
              {
                "v": "4",
                "label": "访问方",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "UTF-8",
                "label": "文件名编码",
                "unit": "",
                "tone": ""
              },
              {
                "v": "0",
                "label": "快照占用",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "chips",
            "title": "相关能力",
            "items": [
              "LogSpace 文件中转",
              "剪贴板同步",
              "P2P 文件传输",
              "DevVM 数据互通",
              "双系统切换"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-claw", "tier": "system",
    "name": "小C",
    "sub": "第 21.2 章 / D40",
    "icon": "ri-brain-line",
    "from": "#7d4fd1",
    "to": "#a97ef0",
    "group": "存储与恢复",
    "status": "按需唤醒",
    "desc": "零常驻 · 五层模型路由 · 技能系统 · Agent 底座",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "claw",
        "label": "对话",
        "icon": "ri-robot-line",
        "blocks": [
          {
            "t": "chat",
            "title": "CTclaw 系统智慧助手",
            "sub": "本地规则引擎 · 交互演示",
            "hints": [
              "当前系统模式",
              "我的模型档位",
              "帮我优化内存",
              "有哪些蜂群节点在线",
              "试试唤醒 / 跑个 Agent"
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "零常驻 · P0 标杆",
            "text": "空载 0MB，用完即走。左侧各页是可交互的「契约演示」，不代表 D33/D38 已在系统侧落地；真实手势 / 虚拟输入 / RDBus 在合成器与运行时侧。"
          }
        ]
      },
      {
        "id": "state",
        "label": "零常驻状态机",
        "icon": "ri-pulse-line",
        "blocks": [
          {
            "t": "lifecycle",
            "title": "零常驻生命周期",
            "sub": "点任意阶段体验 · 演示态",
            "shellMB": 10,
            "phases": [
              { "id": "idle", "label": "空载", "mem": "0MB", "desc": "主菜单 / 桌面", "tone": "blue" },
              { "id": "loading", "label": "加载中", "mem": "0→400MB", "desc": "唤醒 / 进入助手", "tone": "amber" },
              { "id": "ready", "label": "快速就绪", "mem": "400MB", "desc": "本地 Qwen3-0.6B · <500ms", "tone": "teal" },
              { "id": "deep", "label": "深度加载", "mem": "1.5GB", "desc": "Ctrl+→ 切 Qwen3-1.5B", "tone": "violet" },
              { "id": "released", "label": "已释放", "mem": "0MB", "desc": "关闭面板 · 模型进程退出", "tone": "green" }
            ],
            "note": "点「已释放」体验模型进程退出；调度外壳（~10MB）始终在。"
          },
          {
            "t": "kpis",
            "title": "内存预算",
            "items": [
              { "v": "0", "label": "空载 PSS", "unit": "MB", "tone": "good" },
              { "v": "400", "label": "就绪模型", "unit": "MB", "tone": "blue" },
              { "v": "1.5", "label": "深度模式", "unit": "GB", "tone": "violet" },
              { "v": "<500", "label": "本地延迟", "unit": "ms", "tone": "teal" }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "别把外壳说成零常驻",
            "text": "~10MB 调度外壳常驻监听 RDBus；~400MB 模型进程按需加载。「已释放」指模型进程退出、内存归零，不是整个 CT AI 消失。"
          }
        ]
      },
      {
        "id": "route",
        "label": "五层路由",
        "icon": "ri-route-line",
        "blocks": [
          {
            "t": "tiers",
            "title": "五层可降级模型路由",
            "sub": "成本递增 · 隐私递减 · 点档位切换",
            "tiers": [
              { "id": "local", "label": "本地 Qwen3-0.6B", "provider": "本地 llama.cpp", "privacy": "local", "dest": "不出本机", "defaultOn": true, "canDefault": true, "tone": "good", "desc": "永远兜底 · 离线 / 零成本 · <500ms" },
              { "id": "ct-selfhosted", "label": "CT 自建云档", "provider": "CT 自有服务器", "privacy": "local", "dest": "CT infra", "defaultOn": false, "canDefault": true, "tone": "blue", "desc": "隐私友好 · 8 万启动金试点 · 7B–14B" },
              { "id": "glm-flash", "label": "GLM 免费档", "provider": "智谱 GLM", "privacy": "cloud", "dest": "智谱", "defaultOn": false, "canDefault": true, "tone": "teal", "desc": "glm-4.7-flash · 200K 上下文 · 零账单" },
              { "id": "byok", "label": "用户 BYOK", "provider": "用户自填 endpoint", "privacy": "cloud", "dest": "用户填的 endpoint", "defaultOn": false, "canDefault": true, "tone": "violet", "desc": "可靠强模型档 · key 自持" },
              { "id": "free-web", "label": "free-web 尝鲜", "provider": "逆向网页（默认关闭）", "privacy": "cloud", "dest": "第三方网页", "defaultOn": false, "canDefault": false, "tone": "warn", "desc": "risk: high · 默认关闭 · 永不抢默认位" }
            ]
          },
          {
            "t": "steps",
            "title": "路由规则",
            "items": [
              { "n": "1", "title": "本地永远兜底", "desc": "所有云端失效，用户仍可基础对话。", "tone": "good" },
              { "n": "2", "title": "自建优先于第三方云", "desc": "隐私友好的云端选项，GLM 失效时亦可降级到自建。", "tone": "blue" },
              { "n": "3", "title": "free-web 永不抢默认", "desc": "灰色尝鲜兜底，违反 ToS / 随时失效，UI 持续标注。", "tone": "warn" }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "隐私分档，不能一句「不联网」带过",
            "text": "只有本地档真正离线；自建云档数据在 CT 自有服务器；GLM / BYOK / free-web 会把数据发送至第三方，UI 必须明确提示。"
          }
        ]
      },
      {
        "id": "skills",
        "label": "技能系统",
        "icon": "ri-magic-line",
        "blocks": [
          {
            "t": "kpis",
            "title": "技能规模",
            "items": [
              { "v": "102", "label": "技能总数", "unit": "个", "tone": "violet" },
              { "v": "4", "label": "tier 分类", "unit": "类", "tone": "blue" },
              { "v": "3", "label": "触发方式", "unit": "种", "tone": "teal" },
              { "v": "101", "label": "脚本编译通过", "unit": "个", "tone": "good" }
            ]
          },
          {
            "t": "cards",
            "title": "四分类 tier",
            "items": [
              { "icon": "ri-shield-check-line", "title": "system", "desc": "本地开源、零 key：天气 / 搜索 / TTS / STT / OCR / 翻译。", "tags": ["零 key", "可离线"], "tone": "good" },
              { "icon": "ri-apps-line", "title": "app", "desc": "目标应用经 AI-Host 运行时注册的能力。", "tags": ["运行时注册"], "tone": "blue" },
              { "icon": "ri-key-line", "title": "cloud", "desc": "用户 BYOK，经「一键填入」激活，如 deepseek-official。", "tags": ["用户 key"], "tone": "violet" },
              { "icon": "ri-eye-line", "title": "free-web", "desc": "逆向抓取，默认关闭、最低优先级、持续标注。", "tags": ["risk high", "默认关"], "tone": "warn" }
            ]
          },
          {
            "t": "toggles",
            "title": "三种触发方式（点开关体验，高风险项会二次确认）",
            "items": [
              { "label": "@技能名 显式触发", "desc": "例如 @weather 直接调用天气技能", "on": true, "tone": "blue" },
              { "label": "/快捷指令", "desc": "斜杠命令，确定性触发", "on": true, "tone": "teal" },
              { "label": "description 语义匹配", "desc": "弱模型下的确定性兜底", "on": true, "tone": "violet" },
              { "label": "启用 deepseek-web-free", "desc": "risk: high · 违反 ToS / 随时失效 / 账号风控", "on": false, "tone": "warn", "confirm": "启用 free-web 技能？该技能逆向抓取网页，可能违反服务条款、随时失效并触发账号风控。" }
            ]
          },
          {
            "t": "code",
            "lang": "json",
            "code": "{\n  \"status\": \"error\",\n  \"code\": \"NO_KEY\",\n  \"skill\": \"deepseek-official\",\n  \"field\": \"key\",\n  \"hint\": \"请在 CT优选一键填入你的 API key；CT优选与 CTclaw 均无法查看。\"\n}",
            "title": "结构化错误契约：NO_KEY（脚本输出单行 JSON，禁用正则抠文本）"
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "deepseek-web-free 必须持续标注",
            "text": "free-web 技能 risk: high、默认关闭、最低优先级。风险：违反 ToS / 随时失效 / 账号 IP 风控；UI 必须长期显示警告，不得与官方 API 混为一谈。"
          }
        ]
      },
      {
        "id": "provider",
        "label": "CT优选导入",
        "icon": "ri-import-line",
        "blocks": [
          {
            "t": "importer",
            "title": "一键填入 CTClaw",
            "sub": "入口可信，非钥匙托管",
            "spec": "ctclaw.provider/v1",
            "sample": {
              "provider": "deepseek-official",
              "label": "DeepSeek 官方 · CT优选精选",
              "endpoint": "https://api.deepseek.com/v1/chat/completions"
            },
            "note": "分享配置不含 key；key 只由你自己在下方填入。"
          },
          {
            "t": "code",
            "lang": "json",
            "code": "{\n  \"schema\": \"ctclaw.provider/v1\",\n  \"provider\": \"deepseek-official\",\n  \"label\": \"DeepSeek 官方 · CT优选精选\",\n  \"endpoint\": \"https://api.deepseek.com/v1/chat/completions\",\n  \"auth_scheme\": \"bearer\",\n  \"key_hint\": \"sk-...（你的 DeepSeek 官方 API key）\",\n  \"models\": [\"deepseek-chat\", \"deepseek-reasoner\"],\n  \"capabilities\": [\"chat\", \"reasoning\"],\n  \"curated_by\": \"CT优选\",\n  \"verified_at\": \"2026-09-18\"\n}",
            "title": "分享包原文（无 key 字段）"
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "五条安全约束",
            "text": "签名/白名单校验 · key 加密入库 · 不回传不打印不落日志 · 可随时撤销 · 明文 key 绝不进分享链路。CT优选只证明接入点可用，不代持用户 key。"
          }
        ]
      },
      {
        "id": "wake",
        "label": "唤醒演示",
        "icon": "ri-keyboard-line",
        "blocks": [
          {
            "t": "wake",
            "title": "长按空格 1s 唤醒",
            "sub": "按住屏幕键或真实空格 · 演示契约",
            "holdMs": 1000,
            "avoid": "输入框 / textarea / contenteditable 内自动避让，不触发唤醒",
            "steps": [
              "合成器全局手势表捕获 keydown(Space)，起 1s 计时",
              "焦点处于文本输入态则不放行（上下文感知，零成本）",
              "无 keyup 满 1s → 经 RDBus 回调唤醒 CTclaw",
              "拉起调度外壳 + 按需加载模型进程，窗口就位"
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "唤起形态",
            "text": "屏幕中心对话框或左/右侧边栏。真实手势注册在合成器层（独立应用抓不到全局键盘）；这里演示的是交互契约。"
          }
        ]
      },
      {
        "id": "agent",
        "label": "Agent 执行",
        "icon": "ri-robot-2-line",
        "blocks": [
          {
            "t": "agent",
            "title": "大馒头 → 小馒头 ×N",
            "sub": "点「开始执行」看子任务并行推进",
            "parent": "大馒头",
            "origin": "agent:大馒头",
            "subtasks": [
              { "name": "拆解任务 · 生成执行计划", "weight": 1 },
              { "name": "调用工具链 · 抓取上下文", "weight": 1 },
              { "name": "汇总结果 · 回显确认", "weight": 1 }
            ],
            "note": "子任务动作带 origin: agent:<task> 以示可追溯；进度经信息岛推送，后台不阻塞用户。"
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与「第三方订阅额度」是两套模型",
            "text": "大馒头 / 小馒头是子任务 worker（AgentItem 执行态），进度走信息岛状态镜像；Codex/Claude 那套 quotas 额度表与之无关，演示全程不写入额度。"
          }
        ]
      },
      {
        "id": "attach",
        "label": "附着与 Host",
        "icon": "ri-node-tree",
        "blocks": [
          {
            "t": "steps",
            "title": "拖拽转移链：拖进应用 = 转移，不是复制",
            "items": [
              { "n": "1", "title": "面板作为 drag source", "desc": "携带 application/x-ct-ai-session + 会话 ID。", "tone": "blue" },
              { "n": "2", "title": "合成器自己做 drop 处理者", "desc": "识别源=CTclaw 会话、目标=某应用 toplevel。", "tone": "teal" },
              { "n": "3", "title": "会话转「应用内绑定」", "desc": "全局面板关闭，目标应用建立 AI-Host 会话。", "tone": "violet" },
              { "n": "4", "title": "落点菜单", "desc": "「使用当前上下文 / 新建对话」决定带入历史还是仅绑定 context。", "tone": "amber" }
            ]
          },
          {
            "t": "toggles",
            "title": "AI-Host（opt-in 增强层 · 兜底永远在）",
            "items": [
              { "label": "COSMIC 系原生内嵌侧边栏", "desc": "ct-settings / ct-files 优先适配（演示）", "on": false, "tone": "blue" },
              { "label": "拖入即浮动覆盖（兜底）", "desc": "零适配，所有应用立刻有 AI；始终生效", "on": true, "tone": "good" }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "AI-Host 强制 vs 合成器兜底 + 渐进",
            "text": "决策采用「合成器兜底 + 渐进」：兜底永远在，不接 AI-Host 的应用也能立刻有 AI；深度应用再 opt-in 拿原生内嵌体验。"
          }
        ]
      },
      {
        "id": "roadmap",
        "label": "后续试点",
        "icon": "ri-calendar-line",
        "blocks": [
          {
            "t": "timeline",
            "title": "D41 / D42 / D43 · 文档留下的开放项",
            "items": [
              { "time": "D41", "title": "自建推理试点", "desc": "机型选型与最小可用架构待单独成稿（二手 3090 / A100 起步）。", "tone": "blue" },
              { "time": "D42", "title": "AI-Host 接口", "desc": "RDBus 方法签名待细化（应用声明能暴露什么、能接收什么 AI 动作）。", "tone": "violet" },
              { "time": "D43", "title": "GLM key 签发", "desc": "核实 Z.AI 是否支持 per-user token / OAuth，决定客户端直连还是代理池。", "tone": "teal" }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "仅为占位，不代表已裁定",
            "text": "三项均为待细化开放项；另有 free-web 技能在中国大陆的可达性替代方案待评估。原型只标注诚实边界，不做已落地的表述。"
          }
        ]
      },
      {
        "id": "compare",
        "label": "选型对标",
        "icon": "ri-scales-3-line",
        "blocks": [
          {
            "t": "cards",
            "title": "三个维度：侧边栏 + 系统级 + 能干活",
            "items": [
              { "icon": "ri-cursor-line", "title": "① 系统级 · 能干活", "desc": "真能看屏 + 点鼠标，跨应用复杂流程。", "tags": ["UI-TARS Desktop", "cua", "Hermes Desktop", "Goose"], "tone": "violet" },
              { "icon": "ri-side-bar-line", "title": "② 侧边栏 · 入口型", "desc": "读屏给上下文，呼出即用的轻量侧栏。", "tags": ["Fluent AI Sidebar", "DuckAI"], "tone": "blue" },
              { "icon": "ri-sparkling-2-line", "title": "③ 轻量 / 实验", "desc": "聚合侧栏 / dock 小窗 / 透明悬浮层。", "tags": ["Noi", "Kel", "Julie"], "tone": "teal" }
            ]
          },
          {
            "t": "table",
            "title": "开源项目对照（原文数据，许可按 D40 口径）",
            "cols": ["项目", "出处 / 许可", "侧边栏", "系统级", "能干活", "定位要点"],
            "rows": [
              ["UI-TARS Desktop", "字节 · Apache-2.0", "—", "✓", "✓✓", "纯视觉 Computer Use，~3.9 万 star；吃显存，支付/登录别交给它"],
              ["cua", "trycua · MIT", "—", "✓", "✓✓", "~3.1 万 star，持续发布；驱动 + CLI/MCP/SDK，适合搭 Agent 底座"],
              ["Hermes Desktop", "Nous Research · MIT", "✓✓", "✓", "✓", "Side Panel 最贴题；~180MB / 启动 <1.2s，Skills + 细粒度权限沙箱"],
              ["Goose", "Block→AAIF · Apache-2.0", "—", "✓✓", "✓", "Rust + Electron，58+ 模型商，MCP / Recipe 定时 / Smart Approve，不绑模型商"],
              ["Fluent AI Sidebar", "MIT", "✓✓", "—", "—", "F8 框选 OCR，翻译/解释/改写/回复，剪贴板监听，朴素但稳"],
              ["DuckAI", "MIT", "✓✓", "—", "—", "Electron + FastAPI，截屏 OCR 做上下文，30+ 工具 + 本地 RAG + 回写"],
              ["Noi", "lencx", "✓✓", "—", "—", "聚合 ChatGPT/Claude/Gemini/DeepSeek，多窗口并行、提示词库、全局快捷键"],
              ["Kel", "MIT", "✓✓", "—", "—", "Ctrl+K 呼出，dock 在屏幕边缘，本地 SQLite 会话，走 OpenRouter"],
              ["Julie", "MIT", "✓", "✓", "✓", "透明悬浮层 + Ghost Mode 鼠标穿透，读屏 + 语音 + Groq，macOS 带 computer use"]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "一句选型（原文结论）",
            "text": "要 AI 真的替你操作电脑 → UI-TARS Desktop / cua；要常驻、挂旁边、能干活、权限可控 → Hermes Desktop（Side Panel 最贴题）；要生态稳、不绑模型、能定时跑任务 → Goose；只要「呼出即读屏」的轻量侧栏 → Noi / Kel / Fluent AI Sidebar。"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-perf", "tier": "skip",
    "name": "性能优化",
    "sub": "第 32 章",
    "icon": "ri-speed-mini-line",
    "from": "#b0463f",
    "to": "#de7a6c",
    "group": "存储与恢复",
    "status": "全项启用",
    "desc": "GPU / 同步 / 内存 / 存储启动 / 网络 五维优化",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "perf",
        "label": "五维优化",
        "icon": "ri-speed-mini-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-speed-mini-line",
            "badge": "32.1–32.5",
            "title": "五个维度的系统级优化",
            "tone": "red",
            "desc": "从图形栈到网络栈的全链路调优：GPU 零拷贝、同步原语内核直通、内存 MGLRU、存储与启动优化、网络 BBR3 拥塞控制。"
          },
          {
            "t": "cards",
            "title": "五维清单",
            "items": [
              {
                "icon": "ri-cpu-line",
                "title": "GPU 图形栈（32.1）",
                "desc": "ct-gpu GLES2 + dmabuf 零拷贝，按机裁剪 Mesa",
                "badge": "图形",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-swap-line",
                "title": "同步原语（32.2）",
                "desc": "NTSync 内核直通，Windows 锁不再 userspace 模拟",
                "badge": "同步",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-database-2-line",
                "title": "内存优化（32.3）",
                "desc": "MGLRU 多代 LRU + HugePages + zswap",
                "badge": "内存",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-hard-drive-3-line",
                "title": "存储与启动（32.4）",
                "desc": "EROFS + zstd、Btrfs COW、LinuxBoot 极简引导",
                "badge": "存储",
                "tone": "amber",
                "tags": []
              }
            ]
          },
          {
            "t": "bars",
            "title": "优化收益（相对基线）",
            "items": [
              {
                "label": "应用冷启动",
                "pct": 38,
                "tone": "accent"
              },
              {
                "label": "图形帧延迟",
                "pct": 31,
                "tone": "good"
              },
              {
                "label": "Windows 同步",
                "pct": 46,
                "tone": "good"
              },
              {
                "label": "内存回收效率",
                "pct": 27,
                "tone": ""
              },
              {
                "label": "网络吞吐（BBR3）",
                "pct": 34,
                "tone": "accent"
              },
              {
                "label": "开机时间",
                "pct": 52,
                "tone": "good"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与模式体系的关系",
            "text": "32.1–32.5 是「静态底座优化」，32.6 起的十系统模式是「动态策略」——前者全时生效，后者按场景在 cpufreq / cgroup / 内核模块三平面动态下发。"
          }
        ]
      },
      {
        "id": "bench",
        "label": "基准与配置",
        "icon": "ri-line-chart-line",
        "blocks": [
          {
            "t": "table",
            "title": "关键调优项",
            "cols": [
              "维度",
              "技术",
              "收益"
            ],
            "rows": [
              [
                "GPU",
                "dmabuf 零拷贝 + ct-gpu",
                "图形路径减一次拷贝"
              ],
              [
                "同步",
                "NTSync 内核模块",
                "Windows 同步延迟显著下降"
              ],
              [
                "内存",
                "MGLRU / HugePages / zswap",
                "回收更准、大页更少 TLB miss"
              ],
              [
                "存储",
                "EROFS + zstd + Btrfs COW",
                "镜像更小、快照零成本"
              ],
              [
                "启动",
                "LinuxBoot + initramfs < 5MB",
                "用系统启动系统"
              ],
              [
                "网络",
                "BBR3 + 多连接分片",
                "高延迟链路吞吐提升"
              ]
            ]
          },
          {
            "t": "kpis",
            "title": "基准指标",
            "items": [
              {
                "v": "1.043",
                "label": "图形目标达成",
                "unit": "s",
                "tone": "good"
              },
              {
                "v": "98.52",
                "label": "回环下载",
                "unit": "MiB/s",
                "tone": "accent"
              },
              {
                "v": "60",
                "label": "CTTY 刷新",
                "unit": "Hz",
                "tone": "good"
              },
              {
                "v": "±5%",
                "label": "性能回归容忍",
                "unit": "",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "toggles",
            "title": "优化开关",
            "items": [
              {
                "label": "MGLRU 多代 LRU",
                "desc": "ctk-new 档默认编入",
                "on": true,
                "tone": "good"
              },
              {
                "label": "BBR3 拥塞控制",
                "desc": "ct-netd 网络策略联动",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "HugePages / zswap",
                "desc": "大内存 workload 受益",
                "on": true,
                "tone": "info"
              },
              {
                "label": "sched-ext 自定义调度器",
                "desc": "实验特性，按需启用",
                "on": false,
                "tone": "warn"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-netd", "tier": "system",
    "name": "连接管理",
    "sub": "ct-netd · D30",
    "icon": "ri-global-line",
    "from": "#3b6fd4",
    "to": "#6f9de8",
    "group": "网络与工程",
    "status": "已连接",
    "desc": "网卡 / WiFi(iwd) / DHCP / 路由 · RDBus 暴露",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "net",
        "label": "连接状态",
        "icon": "ri-global-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-global-line",
            "badge": "第一方 Rust 守护 · D30",
            "title": "系统的「网卡管家」",
            "tone": "blue",
            "desc": "网卡 / WiFi（iwd 默认）/ DHCP / IP 路由经 RDBus org.containerlinux.Net 暴露，网络状态对所有 CT 组件一致可见。"
          },
          {
            "t": "cards",
            "title": "当前连接",
            "items": [
              {
                "icon": "ri-wifi-line",
                "title": "wlan0 · WiFi",
                "desc": "iwd 管理 · CT-5G · 信号 −42 dBm",
                "badge": "主连接",
                "tone": "good",
                "tags": []
              },
              {
                "icon": "ri-global-line",
                "title": "eth0 · 有线",
                "desc": "未连接（链路已就绪）",
                "badge": "备用",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-route-line",
                "title": "默认路由",
                "desc": "192.168.1.1 · metric 100",
                "badge": "路由",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-shield-line",
                "title": "ct-resolved",
                "desc": "DoT 已启用 · 防应用旁路",
                "badge": "DNS",
                "tone": "violet",
                "tags": []
              }
            ]
          },
          {
            "t": "kpis",
            "title": "链路指标",
            "items": [
              {
                "v": "−42",
                "label": "信号强度",
                "unit": "dBm",
                "tone": "good"
              },
              {
                "v": "866",
                "label": "协商速率",
                "unit": "Mbps",
                "tone": "good"
              },
              {
                "v": "8",
                "label": "延迟",
                "unit": "ms",
                "tone": "good"
              },
              {
                "v": "BBR3",
                "label": "拥塞控制",
                "unit": "",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "table",
            "title": "接口清单",
            "cols": [
              "接口",
              "类型",
              "状态"
            ],
            "rows": [
              [
                "wlan0",
                "WiFi (iwd)",
                "up · 192.168.1.23/24"
              ],
              [
                "eth0",
                "以太网",
                "down"
              ],
              [
                "lo",
                "回环",
                "up · 127.0.0.1"
              ],
              [
                "tun0",
                "VPN (ct-vpn)",
                "按需"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "RDBus 契约",
            "text": "所有网络能力经 org.containerlinux.Net 系列接口暴露（D27 合规），上层 TUI / 设置 / 系统模式不直接操作 ip / iw 命令，策略由 net-policy 统一仲裁。"
          }
        ]
      },
      {
        "id": "config",
        "label": "配置与命令",
        "icon": "ri-terminal-line",
        "blocks": [
          {
            "t": "code",
            "title": "使用命令（33.8）",
            "code": "# 连接状态\nct-netctl status\n# WiFi 扫描 / 连接\nct-netctl wifi scan\nct-netctl wifi connect CT-5G --psk ****\n# 策略查询\nnet-policy status --mode focus",
            "lang": "bash"
          },
          {
            "t": "toggles",
            "title": "连接策略",
            "items": [
              {
                "label": "iwd 默认后端",
                "desc": "替代 wpa_supplicant，Rust 生态更顺",
                "on": true,
                "tone": "good"
              },
              {
                "label": "DHCP 自动",
                "desc": "IPv4 / IPv6 双栈",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "多链路优先级",
                "desc": "WiFi / 有线 / VPN 按策略切换",
                "on": true,
                "tone": "info"
              },
              {
                "label": "网络状态变更通知",
                "desc": "经 RDBus 广播给订阅组件",
                "on": true,
                "tone": "good"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-download", "tier": "system",
    "name": "下载引擎与加速层",
    "sub": "ct-download · D30",
    "icon": "ri-download-cloud-2-line",
    "from": "#2f8f7a",
    "to": "#54bfa2",
    "group": "网络与工程",
    "status": "3 个任务",
    "desc": "全协议 · 多线程分片 · 蜂群加速 · DownloadEngine",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "engine",
        "label": "下载引擎",
        "icon": "ri-download-cloud-2-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-download-cloud-2-line",
            "badge": "fork aria2_rust · GPL-3.0-or-later",
            "title": "系统「天生会下载」的零件",
            "tone": "teal",
            "desc": "第一方 CT-Rust 原生下载引擎：全协议、多线程分片、断点续传、做种、磁盘缓存、代理；aria2 C++ 原版仅作兜底后端。"
          },
          {
            "t": "cards",
            "title": "能力矩阵",
            "items": [
              {
                "icon": "ri-global-line",
                "title": "全协议",
                "desc": "HTTP/HTTPS/FTP/SFTP/BT/Metalink + uTP/MSE",
                "badge": "协议",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-split-cells-horizontal",
                "title": "多线程分片",
                "desc": "多连接并行 + 断点续传 + 磁盘缓存",
                "badge": "传输",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-share-line",
                "title": "做种与 web-seed",
                "desc": "BT 做种 + web-seed 蜂群加速",
                "badge": "蜂群",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-swap-line",
                "title": "DownloadEngine trait",
                "desc": "submit/pause/resume/speed_limit/progress/校验，后端可替换",
                "badge": "接口",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "progress",
            "title": "活动任务",
            "items": [
              {
                "label": "ct-kali-scenario.erofs",
                "pct": 100,
                "sub": "3.2 GB · 16 分片",
                "meta": "已完成",
                "tone": "good"
              },
              {
                "label": "ct-dev-scenario.erofs",
                "pct": 100,
                "sub": "1.4 GB · 12 分片",
                "meta": "已完成",
                "tone": "good"
              },
              {
                "label": "ct-pentest-full.erofs",
                "pct": 36,
                "sub": "4.8 GB · 24 分片 · 42.6 MB/s",
                "meta": "下载中",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "加速层不是并列后端（33.5）",
            "text": "WARP / WireGuard 隧道 + ghproxy URL 重写 + 多连接分片 / BT web-seed 统称「蜂群加速」，是叠加在 DownloadEngine 之上的统一加速策略层，由 net-policy 调度——不是与 aria2 并列的第二个下载后端。"
          }
        ]
      },
      {
        "id": "backends",
        "label": "后端与校验",
        "icon": "ri-list-check-2",
        "blocks": [
          {
            "t": "table",
            "title": "可替换后端",
            "cols": [
              "后端",
              "实现",
              "用途"
            ],
            "rows": [
              [
                "aria2-backend",
                "ct-download 本体（Rust）",
                "默认"
              ],
              [
                "aria2-cpp-backend",
                "aria2 C++ 原版",
                "兼容兜底"
              ],
              [
                "加速层",
                "WARP / WireGuard / ghproxy / web-seed",
                "策略叠加，非后端"
              ]
            ]
          },
          {
            "t": "kpis",
            "title": "本次会话",
            "items": [
              {
                "v": "98.52",
                "label": "回环吞吐",
                "unit": "MiB/s",
                "tone": "good"
              },
              {
                "v": "24",
                "label": "最大分片",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "20,971,520",
                "label": "校验字节",
                "unit": "B",
                "tone": "accent"
              },
              {
                "v": "0",
                "label": "校验失败",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "code",
            "title": "DownloadEngine trait",
            "code": "pub trait DownloadEngine {\n    fn submit(&mut self, req: Request) -> Result<TaskId>;\n    fn pause(&mut self, id: TaskId);\n    fn resume(&mut self, id: TaskId);\n    fn speed_limit(&mut self, kbps: u32);\n    fn progress(&self, id: TaskId) -> Progress;\n    fn verify(&self, id: TaskId) -> Result<()>;\n}",
            "lang": "rust"
          },
          {
            "t": "chips",
            "title": "落点",
            "items": [
              "/CTF/Core/Atoms/",
              "libctnet",
              "RDBus org.containerlinux.Net.Download",
              "ct-difftest 对照",
              "hyperfine 基线"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-resolved", "tier": "system",
    "name": "DNS 与网络策略",
    "sub": "ct-resolved / net-policy",
    "icon": "ri-shield-keyhole-line",
    "from": "#2b7fb8",
    "to": "#5fb6e0",
    "group": "网络与工程",
    "status": "策略收口中",
    "desc": "DoT / DoH · 防旁路 · 十类策略统一仲裁",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "dns",
        "label": "私密 DNS",
        "icon": "ri-shield-keyhole-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-shield-keyhole-line",
            "badge": "第一方 Rust resolver · D30",
            "title": "系统的「域名翻译官」",
            "tone": "cyan",
            "desc": "私密 DNS（DoT / DoH）、防应用旁路：所有解析请求收口到 ct-resolved，应用不能偷偷绕过系统策略直连公网 DNS。"
          },
          {
            "t": "cards",
            "title": "解析配置",
            "items": [
              {
                "icon": "ri-lock-line",
                "title": "DoT / DoH",
                "desc": "上游加密，查询内容不外泄明文",
                "badge": "加密",
                "tone": "good",
                "tags": []
              },
              {
                "icon": "ri-shield-user-line",
                "title": "防应用旁路",
                "desc": "iptables / nftables 拦截 53 端口直连",
                "badge": "收口",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-route-line",
                "title": "net-policy",
                "desc": "十类网络策略統一仲裁（D31 扩展）",
                "badge": "策略",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-database-2-line",
                "title": "本地缓存",
                "desc": "TTL 缓存 + 负缓存，降低延迟",
                "badge": "缓存",
                "tone": "teal",
                "tags": []
              }
            ]
          },
          {
            "t": "kpis",
            "title": "解析指标",
            "items": [
              {
                "v": "DoT",
                "label": "上游协议",
                "unit": "",
                "tone": ""
              },
              {
                "v": "6",
                "label": "平均延迟",
                "unit": "ms",
                "tone": "good"
              },
              {
                "v": "1,284",
                "label": "缓存命中",
                "unit": "次",
                "tone": "good"
              },
              {
                "v": "0",
                "label": "旁路尝试",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "D31 策略收口",
            "text": "专注 / 安全 / RamOS / 蜂群 / LSA / LSW / 防火墙 / P2P / 内网穿透 / 多协议 VPN——十类网络诉求全部由 net-policy 仲裁，避免各守护各写一套规则互相打架（33.7 / 33.12）。"
          }
        ]
      },
      {
        "id": "policy",
        "label": "策略仲裁",
        "icon": "ri-settings-5-line",
        "blocks": [
          {
            "t": "table",
            "title": "net-policy 规则来源",
            "cols": [
              "来源",
              "诉求",
              "仲裁结果"
            ],
            "rows": [
              [
                "专注模式",
                "屏蔽非白名单域名",
                "生效"
              ],
              [
                "安全模式",
                "强制 DoT + 收紧防火墙",
                "生效"
              ],
              [
                "蜂群模式",
                "放行 P2P 直连端口",
                "按任务放行"
              ],
              [
                "LSW / LSA",
                "兼容层网络隔离",
                "沙箱内放行"
              ],
              [
                "ct-vpn",
                "TUN 全局代理",
                "路由优先级最高"
              ],
              [
                "ct-penetrate",
                "逐服务端口映射",
                "token 鉴权"
              ]
            ]
          },
          {
            "t": "toggles",
            "title": "策略开关",
            "items": [
              {
                "label": "全局 DoT / DoH",
                "desc": "默认开启，上游可配",
                "on": true,
                "tone": "good"
              },
              {
                "label": "防旁路拦截",
                "desc": "阻断应用直连 53 / 明文 DoH 探测",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "按模式自动切换",
                "desc": "power-shift 模式变更即重算策略",
                "on": true,
                "tone": "info"
              },
              {
                "label": "允许应用自定义 DNS",
                "desc": "默认关闭，破坏收口",
                "on": false,
                "tone": "warn"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-p2p", "tier": "system",
    "name": "P2P 设备直连",
    "sub": "ct-p2p · D31",
    "icon": "ri-links-line",
    "from": "#7d4fd1",
    "to": "#a97ef0",
    "group": "网络与工程",
    "status": "6 个对等点",
    "desc": "Kademlia DHT · NAT 穿透 · QUIC/TCP 直连流",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "p2p",
        "label": "通用传输层",
        "icon": "ri-links-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-links-line",
            "badge": "吸收 rust-libp2p · MIT OR Apache-2.0",
            "title": "设备直连的「通用传输层」",
            "tone": "violet",
            "desc": "第一方 P2P 网状传输守护：Kademlia DHT 发现 / NAT 穿透（relay / UPnP / ICE）/ pubsub / 直连流（QUIC/TCP）。与第 28 章蜂群 ct_swarmd 解耦。"
          },
          {
            "t": "cards",
            "title": "四大能力",
            "items": [
              {
                "icon": "ri-radar-line",
                "title": "Kademlia DHT",
                "desc": "去中心节点发现，无需注册中心",
                "badge": "发现",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-route-line",
                "title": "NAT 穿透",
                "desc": "relay / UPnP / ICE 三条路径自动择优",
                "badge": "穿透",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-broadcast-line",
                "title": "pubsub",
                "desc": "任务广播与状态订阅",
                "badge": "消息",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-swap-line",
                "title": "直连流",
                "desc": "QUIC / TCP 双栈，端到端加密",
                "badge": "传输",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "nodes",
            "title": "对等点拓扑",
            "center": "本节点",
            "items": [
              {
                "label": "工蜂 A",
                "sub": "QUIC 直连",
                "tone": "good"
              },
              {
                "label": "工蜂 B",
                "sub": "relay 中继",
                "tone": "accent"
              },
              {
                "label": "工蜂 C",
                "sub": "UPnP 映射",
                "tone": "blue"
              },
              {
                "label": "DHT 引导节点",
                "sub": "发现服务",
                "tone": "teal"
              }
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "与蜂群解耦",
            "text": "ct-p2p 只提供「怎么连」，ct_swarmd 决定「连来干什么」。传输层与调度层分离，蜂群换调度算法不用动网络栈，P2P 换穿透方案也不影响上层业务。"
          }
        ]
      },
      {
        "id": "status",
        "label": "连接状态",
        "icon": "ri-pulse-line",
        "blocks": [
          {
            "t": "kpis",
            "title": "网络概况",
            "items": [
              {
                "v": "6",
                "label": "对等点",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "4",
                "label": "直连",
                "unit": "条",
                "tone": "good"
              },
              {
                "v": "2",
                "label": "中继",
                "unit": "条",
                "tone": "warn"
              },
              {
                "v": "QUIC",
                "label": "主要协议",
                "unit": "",
                "tone": ""
              }
            ]
          },
          {
            "t": "progress",
            "title": "穿透成功率",
            "items": [
              {
                "label": "QUIC 直连",
                "pct": 67,
                "sub": "4 / 6 对等点",
                "meta": "低延迟",
                "tone": "good"
              },
              {
                "label": "UPnP 映射",
                "pct": 50,
                "sub": "1 / 2 可用",
                "meta": "依赖路由器",
                "tone": "accent"
              },
              {
                "label": "relay 中继",
                "pct": 100,
                "sub": "2 / 2 兜底",
                "meta": "高延迟",
                "tone": "warn"
              }
            ]
          },
          {
            "t": "code",
            "title": "RDBus 接口",
            "code": "[atom]\nname = \"ct-p2p\"\n\n[bus]\nname = \"org.containerlinux.Net.P2P\"\nmethods = [\"Discover\", \"Dial\", \"Publish\", \"Subscribe\"]\n\n[transport]\nprotocols = [\"quic\", \"tcp\"]\nnat = [\"relay\", \"upnp\", \"ice\"]",
            "lang": "toml"
          }
        ]
      }
    ]
  },
  {
    "id": "ct-penetrate", "tier": "system",
    "name": "内网穿透",
    "sub": "ct-penetrate · D31",
    "icon": "ri-door-open-line",
    "from": "#b5813a",
    "to": "#dcae63",
    "group": "网络与工程",
    "status": "2 条隧道",
    "desc": "公网中继 + NAT 后客户端 · TLS/Noise · 逐服务 token",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "tunnel",
        "label": "隧道",
        "icon": "ri-door-open-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-door-open-line",
            "badge": "吸收 rathole（Rust, MIT）",
            "title": "把内网服务「捅」到公网",
            "tone": "amber",
            "desc": "第一方内网穿透守护：公网中继服务器 + NAT 后客户端，TCP/UDP 转发 + TLS/Noise 加密 + 逐服务 token 鉴权。"
          },
          {
            "t": "cards",
            "title": "架构",
            "items": [
              {
                "icon": "ri-server-line",
                "title": "公网中继服务器",
                "desc": "有公网 IP，接受客户端反连并转发流量",
                "badge": "中继",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-computer-line",
                "title": "NAT 后客户端",
                "desc": "部署在内网，主动连中继，无需公网 IP / 端口映射",
                "badge": "客户端",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-lock-line",
                "title": "TLS / Noise 加密",
                "desc": "控制通道与数据通道双向加密",
                "badge": "加密",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-key-line",
                "title": "逐服务 token 鉴权",
                "desc": "每个暴露服务独立 token，最小权限",
                "badge": "鉴权",
                "tone": "good",
                "tags": []
              }
            ]
          },
          {
            "t": "table",
            "title": "活动隧道",
            "cols": [
              "服务",
              "本地端口",
              "公网端口",
              "状态"
            ],
            "rows": [
              [
                "ct-webdesk",
                "127.0.0.1:8080",
                "relay:18080",
                "active"
              ],
              [
                "SSH 开发",
                "127.0.0.1:22",
                "relay:10022",
                "active"
              ],
              [
                "DevVM 调试",
                "127.0.0.1:3389",
                "—",
                "已停用"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "默认不暴露",
            "text": "ct-webdesk 默认仅本机 / 内网可访问；公网穿透需用户显式启用，并逐服务签发 token。net-policy 收口后，穿透端口同样受三模式防火墙约束（33.12）。"
          }
        ]
      },
      {
        "id": "config",
        "label": "配置",
        "icon": "ri-file-code-fill",
        "blocks": [
          {
            "t": "code",
            "title": "客户端配置",
            "code": "[client]\nremote_addr = \"relay.ct.example:2333\"\n\n[client.services.ct-webdesk]\ntoken = \"svc-wd-****\"\nlocal_addr = \"127.0.0.1:8080\"\n\n[client.services.ssh]\ntoken = \"svc-ssh-****\"\nlocal_addr = \"127.0.0.1:22\"\n\n[transport]\ntype = \"noise\"      # tls | noise",
            "lang": "toml"
          },
          {
            "t": "kpis",
            "title": "隧道指标",
            "items": [
              {
                "v": "2",
                "label": "活动服务",
                "unit": "个",
                "tone": ""
              },
              {
                "v": "Noise",
                "label": "加密协议",
                "unit": "",
                "tone": ""
              },
              {
                "v": "2",
                "label": "独立 token",
                "unit": "个",
                "tone": "good"
              },
              {
                "v": "0",
                "label": "匿名访问",
                "unit": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "toggles",
            "title": "安全策略",
            "items": [
              {
                "label": "逐服务 token",
                "desc": "每服务独立凭据，可单独吊销",
                "on": true,
                "tone": "good"
              },
              {
                "label": "控制通道加密",
                "desc": "TLS / Noise 二选一",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "net-policy 收口",
                "desc": "穿透端口纳入防火墙规则",
                "on": true,
                "tone": "info"
              },
              {
                "label": "默认放行全部端口",
                "desc": "明确禁止",
                "on": false,
                "tone": "bad"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-vpn", "tier": "system",
    "name": "多协议 VPN",
    "sub": "ct-vpn · D31",
    "icon": "ri-shield-flash-line",
    "from": "#4a5bc4",
    "to": "#7d8ce8",
    "group": "网络与工程",
    "status": "TUN 就绪",
    "desc": "TUN 全局 · 六协议节点 · CoreManager 监管",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "vpn",
        "label": "VPN 内核",
        "icon": "ri-shield-flash-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-shield-flash-line",
            "badge": "meow-rs + clash-verge-rev CoreManager",
            "title": "系统级多协议 VPN 的内核管家",
            "tone": "blue",
            "desc": "以 Rust 版 mihomo/Clash Meta（meow-rs，14 crate）为内核，clash-verge-rev 的 CoreManager 作监管层；TUN 虚拟网卡实现系统级全局代理。"
          },
          {
            "t": "cards",
            "title": "组成",
            "items": [
              {
                "icon": "ri-shield-line",
                "title": "meow-rs 内核",
                "desc": "Rust 版 Clash Meta，MIT，14 crate",
                "badge": "内核",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-settings-5-line",
                "title": "CoreManager 监管层",
                "desc": "吸收 clash-verge-rev（GPL-3.0），独立 GPL 子 crate",
                "badge": "监管",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-route-line",
                "title": "TUN 虚拟网卡",
                "desc": "系统级 VPN，全部应用流量经此",
                "badge": "全局",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-global-line",
                "title": "多协议节点",
                "desc": "Shadowsocks / Trojan / VLESS / VMess / Snell / Hysteria2",
                "badge": "协议",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "segments",
            "title": "当前模式",
            "options": [
              "规则分流",
              "全局代理",
              "直连"
            ],
            "value": "规则分流",
            "hint": "由 net-policy 仲裁，与专注 / 安全模式联动"
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "许可证处理",
            "text": "接受 copyleft：clash-verge-rev 为 GPL-3.0，监管层作为独立 GPL 子 crate 隔离，不污染 MIT 内核与 CT 自有代码（D31）。"
          }
        ]
      },
      {
        "id": "nodes",
        "label": "节点与策略",
        "icon": "ri-global-line",
        "blocks": [
          {
            "t": "table",
            "title": "节点清单",
            "cols": [
              "协议",
              "节点",
              "延迟"
            ],
            "rows": [
              [
                "Hysteria2",
                "HK-01",
                "18 ms"
              ],
              [
                "VLESS",
                "JP-02",
                "32 ms"
              ],
              [
                "Trojan",
                "SG-03",
                "46 ms"
              ],
              [
                "Shadowsocks",
                "US-04",
                "128 ms"
              ]
            ]
          },
          {
            "t": "progress",
            "title": "代理流量",
            "items": [
              {
                "label": "规则分流命中",
                "pct": 72,
                "sub": "1,284 / 1,782 请求",
                "meta": "今日",
                "tone": "accent"
              },
              {
                "label": "TUN 全局覆盖",
                "pct": 100,
                "sub": "含 LSW / LSA 兼容层",
                "meta": "已启用",
                "tone": "good"
              },
              {
                "label": "节点可用性",
                "pct": 88,
                "sub": "4 节点中 3 个低延迟",
                "meta": "",
                "tone": "good"
              }
            ]
          },
          {
            "t": "code",
            "title": "RDBus 接口",
            "code": "[atom]\nname = \"ct-vpn\"\n\n[bus]\nname = \"org.containerlinux.Net.VPN\"\nmethods = [\"SetMode\", \"SelectNode\", \"Status\"]\n\n[tun]\ndevice = \"tun0\"\nstack = \"system\"   # 系统级，非应用级",
            "lang": "toml"
          },
          {
            "t": "chips",
            "title": "协议支持",
            "items": [
              "Shadowsocks",
              "Trojan",
              "VLESS",
              "VMess",
              "Snell",
              "Hysteria2",
              "TUN",
              "规则分流"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-firewall", "tier": "system",
    "name": "三模式防火墙",
    "sub": "第 34 章",
    "icon": "ri-shield-check-line",
    "from": "#b0463f",
    "to": "#de7a6c",
    "group": "网络与工程",
    "status": "标准模式",
    "desc": "三模式 · 各子系统策略 · 黑客模式与 DML 整合",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "fw",
        "label": "三模式",
        "icon": "ri-shield-check-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-shield-check-line",
            "badge": "34.1",
            "title": "三模式防火墙",
            "tone": "red",
            "desc": "安全系统按场景提供三档防火墙策略，并与各子系统的安全策略、黑客模式与动态镜像（DML）整合，由 net-policy 统一收口。"
          },
          {
            "t": "segments",
            "title": "防火墙模式",
            "options": [
              "标准",
              "严格",
              "开放"
            ],
            "value": "标准",
            "hint": "安全模式自动切「严格」；演示 / 兼容模式可临时「开放」"
          },
          {
            "t": "cards",
            "title": "三档策略",
            "items": [
              {
                "icon": "ri-shield-line",
                "title": "标准",
                "desc": "默认放行已建立连接，入站按需放行",
                "badge": "日常",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-lock-line",
                "title": "严格",
                "desc": "默认拒绝入站，仅白名单端口；DoT 强制 + 沙箱强化",
                "badge": "安全模式",
                "tone": "red",
                "tags": []
              },
              {
                "icon": "ri-door-open-line",
                "title": "开放",
                "desc": "本地开发 / 演示场景，临时放宽并计时自动回退",
                "badge": "临时",
                "tone": "amber",
                "tags": []
              }
            ]
          },
          {
            "t": "table",
            "title": "各子系统安全策略（34.2）",
            "cols": [
              "子系统",
              "策略要点"
            ],
            "rows": [
              [
                "LSW / Wine Direct",
                "containerlinux-gate seccomp-bpf 始终加载"
              ],
              [
                "LSA",
                "containerlinux-lsa-guard 权限与 Intent 隔离"
              ],
              [
                ".cte 插件",
                "bwrap 沙箱 + privilege 分级 + 签名链"
              ],
              [
                "ct-p2p",
                "互信配对 + 传输加密 + 最小权限让渡"
              ],
              [
                "ct-penetrate",
                "逐服务 token 鉴权 + 加密通道"
              ],
              [
                "CTclaw",
                "本地优先，云端调用需逐次授权"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "warn",
            "title": "黑客模式与 DML（34.3）",
            "text": "黑客模式挂载隔离的渗透场景镜像（DML scenario）：沙箱内允许攻击性工具，出沙箱一律拒绝；退出即卸载镜像，不留痕到主系统时间线。"
          }
        ]
      },
      {
        "id": "rules",
        "label": "规则与日志",
        "icon": "ri-file-list-3-line",
        "blocks": [
          {
            "t": "kpis",
            "title": "今日统计",
            "items": [
              {
                "v": "1,284",
                "label": "放行连接",
                "unit": "条",
                "tone": ""
              },
              {
                "v": "37",
                "label": "拦截入站",
                "unit": "次",
                "tone": "warn"
              },
              {
                "v": "0",
                "label": "旁路尝试",
                "unit": "",
                "tone": "good"
              },
              {
                "v": "3",
                "label": "策略模式",
                "unit": "档",
                "tone": "accent"
              }
            ]
          },
          {
            "t": "logs",
            "title": "最近拦截",
            "lines": [
              {
                "t": "DROP",
                "text": "IN=eth0 SRC=203.0.113.9 DPT=22",
                "tone": "warn"
              },
              {
                "t": "DROP",
                "text": "IN=eth0 SRC=198.51.100.4 DPT=3389",
                "tone": "warn"
              },
              {
                "t": "OK",
                "text": "ct-gate: seccomp profile attached to LSW app",
                "tone": "good"
              },
              {
                "t": "INFO",
                "text": "net-policy: 安全模式 → 防火墙切「严格」",
                "tone": "info"
              },
              {
                "t": "OK",
                "text": "DML hacker scenario unmounted, sandbox closed",
                "tone": "good"
              }
            ]
          },
          {
            "t": "toggles",
            "title": "策略开关",
            "items": [
              {
                "label": "默认拒绝入站",
                "desc": "标准模式亦生效",
                "on": true,
                "tone": "good"
              },
              {
                "label": "模式联动",
                "desc": "安全 → 严格 / 演示 → 开放",
                "on": true,
                "tone": "accent"
              },
              {
                "label": "临时开放自动回退",
                "desc": "超时自动切回标准",
                "on": true,
                "tone": "info"
              },
              {
                "label": "允许匿名入站",
                "desc": "明确禁止",
                "on": false,
                "tone": "bad"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "ct-installer", "tier": "app",
    "name": "安装器与工程",
    "sub": "第 50 章 / 构建指南",
    "icon": "ri-install-line",
    "from": "#4a5568",
    "to": "#7a889e",
    "group": "网络与工程",
    "status": "v6.1 就绪",
    "desc": "Ubiquity 改造 · 分区实操 · 四轨道里程碑",
    "fabIcon": "ri-refresh-line",
    "pages": [
      {
        "id": "install",
        "label": "安装流程",
        "icon": "ri-install-line",
        "blocks": [
          {
            "t": "hero",
            "icon": "ri-install-line",
            "badge": "50.1 · 基于 Ubuntu Ubiquity 改造",
            "title": "v3 单一形态 + 发行版槽位",
            "tone": "blue",
            "desc": "安装器基于 Ubuntu Ubiquity 改造：装 CT-Kernel 固定基座 + CT 功能集，并把发行版用户态放进可删可换的槽位。"
          },
          {
            "t": "steps",
            "title": "安装流程（50.2）",
            "items": [
              {
                "n": "①",
                "title": "环境预检",
                "desc": "硬件判档（smart-tune）→ 推荐 ctk-old / ctk-new",
                "tone": "blue"
              },
              {
                "n": "②",
                "title": "磁盘分区",
                "desc": "gdisk 实操：ESP / ct-data(Btrfs) / rec / share(exFAT)",
                "tone": "teal"
              },
              {
                "n": "③",
                "title": "基座安装",
                "desc": "CT-Kernel + L0–L4 CT Runtime 分层镜像",
                "tone": "accent"
              },
              {
                "n": "④",
                "title": "发行版槽位",
                "desc": "Ubuntu 26.04 LTS 预装（可选跳过 → 零发行版模式）",
                "tone": "violet"
              },
              {
                "n": "⑤",
                "title": "首次引导",
                "desc": "LinuxBoot + smart-tune → kexec 交接",
                "tone": "green"
              }
            ]
          },
          {
            "t": "table",
            "title": "构建 Phase（第 43–47 章）",
            "cols": [
              "Phase",
              "内容"
            ],
            "rows": [
              [
                "Phase 0",
                "环境准备：Ubuntu 26.04 Server / Rust / C / Python / SSH"
              ],
              [
                "Phase 1",
                "Btrfs 三层存储：子卷、debootstrap、fstab、seal / discard、logd"
              ],
              [
                "Phase K",
                "CT-Kernel 构建：叠加 CT 配置、编译双档、打包四格式、QEMU 验证"
              ],
              [
                "Phase R",
                "CT-Rust 替换：uutils multicall、并存区、差分、抢默认"
              ]
            ]
          },
          {
            "t": "callout",
            "tone": "info",
            "title": "范围墙（7.9.11）",
            "text": "v1 不替换固件、不改动 Secure Boot 信任根、不接管 Windows 引导分区；裸机双系统为可选切换项（第 30 章）。"
          }
        ]
      },
      {
        "id": "milestones",
        "label": "里程碑四轨道",
        "icon": "ri-flag-line",
        "blocks": [
          {
            "t": "cards",
            "title": "M / K / R / A（第 38 章）",
            "items": [
              {
                "icon": "ri-git-branch-line",
                "title": "M 轨 · 主干",
                "desc": "系统主线功能与集成",
                "badge": "主干",
                "tone": "blue",
                "tags": []
              },
              {
                "icon": "ri-cpu-line",
                "title": "K 轨 · CT-Kernel",
                "desc": "双档内核、补丁集、四格式分发",
                "badge": "内核",
                "tone": "teal",
                "tags": []
              },
              {
                "icon": "ri-code-s-slash-fill",
                "title": "R 轨 · CT-Rust",
                "desc": "Tier 0–3 重写与差分验证",
                "badge": "重写",
                "tone": "violet",
                "tags": []
              },
              {
                "icon": "ri-box-3-line",
                "title": "A 轨 · 原子架构",
                "desc": "ct-core / RDBus / 桌面 / RSystemd / 生态",
                "badge": "原子",
                "tone": "orange",
                "tags": []
              }
            ]
          },
          {
            "t": "bars",
            "title": "优先级工期估算（42.2）",
            "items": [
              {
                "label": "Phase 0–1 存储基线",
                "pct": 86,
                "tone": "good"
              },
              {
                "label": "Phase K 双档内核",
                "pct": 72,
                "tone": "accent"
              },
              {
                "label": "Phase R 抢默认",
                "pct": 54,
                "tone": ""
              },
              {
                "label": "A 轨 桌面环境",
                "pct": 38,
                "tone": ""
              },
              {
                "label": "蜂群 / 生态",
                "pct": 22,
                "tone": "warn"
              }
            ]
          },
          {
            "t": "kpis",
            "title": "工程指标",
            "items": [
              {
                "v": "2.4",
                "label": "代码库实底",
                "unit": "万行",
                "tone": ""
              },
              {
                "v": "D38",
                "label": "对齐轮次",
                "unit": "",
                "tone": ""
              },
              {
                "v": "4",
                "label": "并行轨道",
                "unit": "条",
                "tone": ""
              },
              {
                "v": "48",
                "label": "可 GUI 化子系统",
                "unit": "个",
                "tone": "accent"
              }
            ]
          }
        ]
      }
    ]
  }
]

export const ctAppMap: Record<string, CtAppDef> = Object.fromEntries(
  ctApps.map((a) => [a.id, a])
) as Record<string, CtAppDef>

export const ctGroups: string[] = Array.from(new Set(ctApps.map((a) => a.group)))
