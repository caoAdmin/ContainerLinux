/**
 * useDockMagnify —— Dock 悬停放大引擎
 *
 * 移植自 https://github.com/puruvj/macos-web （src/components/Dock/DockItem.svelte）
 *
 * 上游做法与本实现的差异（都是刻意为之）：
 *
 * 1) **上游改图标的真实宽度**（<img style:width>），靠 flex 布局自动挤开邻居，
 *    胶囊也跟着变宽。本项目不能这么做 —— `.dock-group` 是官方 LiquidGlass 的宿主
 *    （OfficialGlass.vue 的 fill 模式 absolute 铺满宿主），宿主宽度一变，
 *    ResizeObserver 会重算壁纸副本坐标、`.dock-wrap` 的 translateX(-50%) 还会
 *    平滑滑动 420ms → 玻璃边框与图标错位（历史上反复踩过的坑）。
 *    这里改用 **transform 放大**：宿主宽度恒定，玻璃零风险。
 *    代价是胶囊不变宽，邻居的让位要自己算。
 *
 * 2) **上游每帧读 getBoundingClientRect() 算图标中心**，而图标宽度又参与布局
 *    → 放大→中心偏移→距离变化→再放大的正反馈。这里改用**静态中心**
 *    （由 flex 布局规则直接算出），从根上消除反馈，视觉更稳。
 *
 * 3) **上游用 popmotion interpolate + svelte spring**，本项目不引新依赖：
 *    分段插值手写即可；弹簧用手写阻尼谐振子（固定子步长积分），
 *    因为目标是连续变化的（鼠标扫过时每帧都在变），CSS transition 每次改目标
 *    都要重启、会永远追不上（粘滞感）。
 *
 * 坐标说明：`.stage-canvas` 带 transform: scale()，但 getBoundingClientRect()
 * 与 MouseEvent.clientX **同属屏幕坐标**，无需除以缩放比。
 */
import { onBeforeUnmount, onMounted, ref, watch, type Ref } from 'vue'

/* ══════════════ 距离 → 缩放（上游 7 点分段线性插值的参数化版本）══════════════ */

/**
 * 上游的原始数据（baseWidth = 57.6）：
 *   distanceInput  = [-6, -4.8, -3, 0, 3, 4.8, 6] × baseWidth
 *   widthOutput    = [1, 1.1, 1.414, 2, 1.414, 1.1, 1] × baseWidth
 *
 * 归一化到「图标宽」为单位（R = 影响范围，K = 最大倍率）：
 *   输入断点 u = 0, R/2, R·0.8, R
 *   输出超额 e = (scale-1)/(K-1) = 1, 0.414, 0.1, 0
 * 于是可以完全参数化。
 */
export function scaleFromDistance(u: number, range: number, max: number): number {
  if (u >= range) return 1
  const P: Array<[number, number]> = [
    [0, 1],
    [range / 2, 0.414],
    [range * 0.8, 0.1],
    [range, 0]
  ]
  let e = 0
  for (let i = 0; i < P.length - 1; i++) {
    const [u0, e0] = P[i]
    const [u1, e1] = P[i + 1]
    if (u <= u1) {
      e = e0 + (e1 - e0) * ((u - u0) / (u1 - u0))
      break
    }
  }
  return 1 + (max - 1) * e
}

/* ══════════════ 弹簧（阻尼谐振子）══════════════ */

/** x'' = -k(x - target) - c·x'，k = ω²，c = 2ζω */
function springStep(
  cur: number,
  vel: number,
  target: number,
  dt: number,
  omega: number,
  zeta: number
): [number, number] {
  const k = omega * omega
  const c = 2 * zeta * omega
  const v = vel + (-k * (cur - target) - c * vel) * dt
  return [cur + v * dt, v]
}

/** 固定子步长：不同帧率下手感一致；低帧率机器上也不会炸 */
const SUB_STEP = 1 / 120
const MAX_DT = 1 / 30

/* ══════════════ 参数 ══════════════ */

export interface DockMagnifyOptions {
  /** 停靠方向：底部为水平排列，左/右为竖排 */
  position: Ref<'bottom' | 'left' | 'right'>
  /** 图标基准边长（px） */
  iconSize: Ref<number>
  /** 放大总开关 */
  enabled: Ref<boolean>
  /** 最大倍率 */
  max: Ref<number>
  /** 影响范围（以图标个数计） */
  range: Ref<number>
  /** 弹簧响应速度 ω（rad/s） */
  speed: Ref<number>
  /** 弹簧阻尼比 ζ */
  damping: Ref<number>
  /** 邻位让位强度 0–1 */
  neighbor: Ref<number>
  /** 浮起高度系数 0–1 */
  lift: Ref<number>
  /** 全局动画开关（关掉时瞬间到位） */
  animations: Ref<boolean>
}

export interface DockMagnify {
  /** 绑定到 .dock-group 上（用函数式 ref 赋值） */
  groupRef: Ref<HTMLElement | null>
  /** 注册每个 .dock-app-ico 包装层；返回该元素在数组中的下标 */
  registerIco(el: HTMLElement | null, index: number): void
  /** 指针是否在 Dock 内 */
  hovering: Ref<boolean>
}

/**
 * Dock 悬停放大。
 *
 * 用法：把 groupRef 绑到 .dock-group，icoRefs 绑到每个 .dock-app-ico，
 * 引擎会自行接管 pointermove / pointerleave 并写 transform。
 */
export function useDockMagnify(opts: DockMagnifyOptions): DockMagnify {
  const groupRef = ref<HTMLElement | null>(null)
  const icoRefs = ref<Array<HTMLElement | null>>([])
  const hovering = ref(false)

  /**
   * 注册图标包装层。
   * 用法：:ref="(el) => magnify.registerIco(el as HTMLElement | null, ai)"
   *
   * 不能让调用方直接写 icoRefs.value[i] = el —— Vue 的函数式 ref 在每次
   * 重渲染时会先把旧值置 null、再赋新元素，直接按索引赋值会在数组里留空洞，
   * 导致 measure() 读到错误的图标数。这里统一走 setter，按下标覆盖。
   */
  function registerIco(el: HTMLElement | null, index: number) {
    const arr = icoRefs.value
    while (arr.length <= index) arr.push(null)
    arr[index] = el
  }

  /* ── 几何缓存 ──
     沿排列轴量出每个图标的中心。
     刻意用实测而非公式推算：竖排（left/right）时 .dock-app 的高度是 auto，
     加上 .dock-dot 的贴底间距，实际间距并不等于 size+gap（实测是 51px 而非
     44px），按公式算中心会整体偏移几十像素。
     这里只在布局变化时测一次（ResizeObserver 触发），不是每帧读 —— 每帧
     getBoundingClientRect 会强制 layout，正是上游实现的老毛病。 */
  const GAP = 6
  const PAD = 8
  let centers: number[] = []
  let groupStart = 0
  let groupSize = 0
  let count = 0

  function isVertical() {
    return opts.position.value !== 'bottom'
  }

  /** 重算静态几何（沿排列轴）。只在布局变化时调用。 */
  function measure() {
    const g = groupRef.value
    if (!g) return
    const live = icoRefs.value.filter((el): el is HTMLElement => !!el)
    const n = live.length
    count = n
    groupSize = opts.iconSize.value
    if (n === 0) {
      centers = []
      return
    }
    // 测量前先清掉放大 transform：否则量到的是「已放大偏移后」的中心，
    // 而缩放又是按中心算的 → 放大→中心偏移→再放大的正反馈。
    const prev = live.map((el) => el.style.transform)
    live.forEach((el) => { el.style.transform = 'none' })
    const rect = g.getBoundingClientRect()
    // 每个图标的中心：用图标自身（.dock-app-ico）的实测中心。
    // ico 层包住了 tile，放大前它的中心就是图标的真实中心。
    centers = live.map((el) => {
      const r = el.getBoundingClientRect()
      return isVertical() ? r.top + r.height / 2 : r.left + r.width / 2
    })
    // 沿轴的起点：水平时是 rect.left，竖排时是 rect.top
    groupStart = isVertical() ? rect.top : rect.left
    // 还原 transform（由 apply() 按弹簧状态重写）
    live.forEach((el, i) => { el.style.transform = prev[i] })
  }

  /* ── 弹簧状态 ── */
  let scales: number[] = []
  let vels: number[] = []
  let lifts: number[] = []
  let liftVels: number[] = []
  let shifts: number[] = []
  let shiftVels: number[] = []

  function ensureState(n: number) {
    if (scales.length === n) return
    scales = new Array(n).fill(1)
    vels = new Array(n).fill(0)
    lifts = new Array(n).fill(0)
    liftVels = new Array(n).fill(0)
    shifts = new Array(n).fill(0)
    shiftVels = new Array(n).fill(0)
  }

  /* ── 指针位置（屏幕坐标，与 getBoundingClientRect 同空间）── */
  let pointerX = -1
  let pointerY = -1
  let raf = 0
  let lastT = 0

  /** 取排列轴上的指针坐标：底部 Dock 取 X，左/右竖排取 Y */
  function pointerAxis(): number {
    return isVertical() ? pointerY : pointerX
  }

  /** 依据指针位置算出每个图标的目标缩放 */
  function computeTargets(): { s: number[]; lift: number[] } {
    const s = new Array(count).fill(1)
    const lift = new Array(count).fill(0)
    if (!opts.enabled.value || pointerAxis() < 0) return { s, lift }
    const range = Math.max(0.5, opts.range.value)
    const max = Math.max(1, opts.max.value)
    const base = groupSize || opts.iconSize.value
    for (let i = 0; i < count; i++) {
      const u = Math.abs(pointerAxis() - centers[i]) / base
      s[i] = scaleFromDistance(u, range, max)
      // 浮起高度跟随缩放：放大越多，脱离底边越多
      lift[i] = (s[i] - 1) * opts.lift.value * base * 0.5
    }
    return { s, lift }
  }

  /**
   * 邻位让位：放大图标会压到邻居上，按「虚拟变宽布局」算出邻居应平移多少。
   * 让位预算 = 胶囊左右内边距 × 强度，避免邻居被推出胶囊。
   */
  function computeShifts(targetScales: number[]): number[] {
    const n = count
    const shifts = new Array(n).fill(0)
    if (n === 0) return shifts

    // 虚拟布局：每个图标占 base × scale 的槽位
    const slot: number[] = new Array(n)
    for (let i = 0; i < n; i++) slot[i] = groupSize * targetScales[i]

    // 虚拟中心（相对 groupStart）—— 假设图标按放大的宽度依次排开
    const virtCenter: number[] = new Array(n)
    let acc = 0
    for (let i = 0; i < n; i++) {
      virtCenter[i] = acc + slot[i] / 2
      acc += slot[i] + GAP
    }
    // 静态中心（相对 groupStart）—— 用实测值换算，避免竖排时公式失准
    const statCenter: number[] = new Array(n)
    for (let i = 0; i < n; i++) {
      statCenter[i] = centers[i] - groupStart
    }

    // 最大超出量：放大图标相对静态布局多占的宽度
    let maxOverflow = 0
    for (let i = 0; i < n; i++) {
      const d = Math.abs(virtCenter[i] - statCenter[i])
      if (d > maxOverflow) maxOverflow = d
    }
    if (maxOverflow <= 0) return shifts

    // 让位预算：胶囊内边距空间 × 强度
    const budget = PAD * 2 * Math.max(0, Math.min(1, opts.neighbor.value))
    const rho = Math.min(1, budget / (maxOverflow * 2 || 1))

    // 按「离放大中心越近，让位越多」分配
    let peak = 1
    let peakIdx = -1
    for (let i = 0; i < n; i++) {
      if (targetScales[i] > peak) {
        peak = targetScales[i]
        peakIdx = i
      }
    }
    if (peakIdx < 0) return shifts

    // 邻居间距（实测相邻中心的距离，用于归一化衰减）
    const spacing = n > 1 ? Math.abs(centers[1] - centers[0]) : groupSize + GAP
    for (let i = 0; i < n; i++) {
      if (i === peakIdx) continue
      const dir = i < peakIdx ? -1 : 1
      // 距离越近，让位越多
      const dist = Math.abs(centers[i] - centers[peakIdx])
      const falloff = 1 - Math.min(1, dist / (spacing * 2))
      shifts[i] = dir * maxOverflow * rho * falloff
    }
    // 放大图标自身反方向补偿一点，视觉上更居中
    shifts[peakIdx] = 0
    return shifts
  }

  /** 写 transform 到 DOM（每帧只写，不读） */
  function apply() {
    const pos = opts.position.value
    const vertical = pos !== 'bottom'
    const live = icoRefs.value.filter((el): el is HTMLElement => !!el)
    for (let i = 0; i < count; i++) {
      const el = live[i]
      if (!el) continue
      const k = scales[i]
      const lift = lifts[i]
      const sh = shifts[i]
      // 底部 Dock：向上凸出（-lift）+ 水平让位（sh）
      // 左侧 Dock：向右凸出（+lift）+ 竖直让位（sh）
      // 右侧 Dock：向左凸出（-lift）+ 竖直让位（sh）
      let tx: number, ty: number
      if (!vertical) {
        tx = sh
        ty = -lift
      } else if (pos === 'left') {
        tx = lift
        ty = sh
      } else {
        tx = -lift
        ty = sh
      }
      el.style.transform = `translate3d(${tx.toFixed(2)}px, ${ty.toFixed(2)}px, 0) scale(${k.toFixed(4)})`
      // 放大的图标要压住邻居 → 抬 z-index
      const parent = el.parentElement
      if (parent) {
        const z = k > 1.001 ? 1 + Math.round(k * 10) : 1
        if (parent.style.zIndex !== String(z)) parent.style.zIndex = String(z)
      }
    }
  }

  function tick(t: number) {
    raf = requestAnimationFrame(tick)
    const dt = lastT ? Math.min(MAX_DT, (t - lastT) / 1000) : 1 / 60
    lastT = t

    const { s: targetScales, lift: targetLifts } = computeTargets()
    const targetShifts = computeShifts(targetScales)

    const omega = Math.max(1, opts.speed.value)
    const zeta = Math.max(0.05, opts.damping.value)
    const instant = !opts.animations.value

    let moving = false
    for (let i = 0; i < count; i++) {
      if (instant) {
        scales[i] = targetScales[i]
        lifts[i] = targetLifts[i]
        shifts[i] = targetShifts[i]
        vels[i] = 0
        liftVels[i] = 0
        shiftVels[i] = 0
        continue
      }
      let remain = Math.min(MAX_DT, dt)
      while (remain > 0) {
        const h = Math.min(SUB_STEP, remain)
        ;[scales[i], vels[i]] = springStep(scales[i], vels[i], targetScales[i], h, omega, zeta)
        ;[lifts[i], liftVels[i]] = springStep(lifts[i], liftVels[i], targetLifts[i], h, omega, zeta)
        ;[shifts[i], shiftVels[i]] = springStep(shifts[i], shiftVels[i], targetShifts[i], h, omega, zeta)
        remain -= h
      }
      // 收敛判定
      if (
        Math.abs(scales[i] - targetScales[i]) > 0.001 ||
        Math.abs(lifts[i] - targetLifts[i]) > 0.05 ||
        Math.abs(shifts[i] - targetShifts[i]) > 0.05
      ) {
        moving = true
      } else if (
        Math.abs(scales[i] - targetScales[i]) <= 0.001 &&
        Math.abs(lifts[i] - targetLifts[i]) <= 0.05 &&
        Math.abs(shifts[i] - targetShifts[i]) <= 0.05
      ) {
        scales[i] = targetScales[i]
        lifts[i] = targetLifts[i]
        shifts[i] = targetShifts[i]
        vels[i] = 0
        liftVels[i] = 0
        shiftVels[i] = 0
      }
    }

    apply()

    // 全部收敛且无指针 → 停机，省电
    if (!moving && pointerAxis() < 0) {
      cancelAnimationFrame(raf)
      raf = 0
      lastT = 0
    }
  }

  function start() {
    if (raf) return
    lastT = 0
    raf = requestAnimationFrame(tick)
  }

  /* ── 事件 ──
     监听挂在 window 上：放大后图标会超出 .dock-group 的盒子，
     若只监听 group，指针在放大图标上时会误判为「离开 Dock」而回弹。 */
  function onPointerMove(e: PointerEvent) {
    pointerX = e.clientX
    pointerY = e.clientY
    const g = groupRef.value
    if (!g) return
    // 指针是否在 Dock 区域内（含放大后溢出的部分）
    const r = g.getBoundingClientRect()
    const pad = groupSize * 2
    const inside =
      pointerX >= r.left - pad && pointerX <= r.right + pad &&
      pointerY >= r.top - pad && pointerY <= r.bottom + pad
    hovering.value = inside
    if (!inside) {
      pointerX = -1
      pointerY = -1
    } else if (!opts.enabled.value) {
      pointerX = -1
      pointerY = -1
    }
    // 只在指针进入 Dock 时给宿主挂标记 —— CSS 据此给图标加 will-change。
    // 14 个图标常驻 will-change 会多出 14 个合成层，白白吃内存。
    const g2 = groupRef.value
    if (g2) g2.classList.toggle('dock-magnify-on', inside && opts.enabled.value)
    start()
  }

  /* ── 几何失效重算 ── */
  let ro: ResizeObserver | null = null
  function bindObserver() {
    const g = groupRef.value
    if (!g) return
    if (ro) ro.disconnect()
    ro = new ResizeObserver(() => {
      measure()
      start()
    })
    ro.observe(g)
  }

  onMounted(() => {
    // Dock 可能被 v-if（showDock）延迟渲染，宿主与图标未必在 mount 时就绪。
    // 这里轮询几帧直到两者都就位，避免「首次不生效」。
    let tries = 0
    const boot = () => {
      const g = groupRef.value
      const n = icoRefs.value.filter(Boolean).length
      if (g && n > 0) {
        measure()
        ensureState(count)
        window.addEventListener('pointermove', onPointerMove)
        bindObserver()
        apply()
        return
      }
      if (++tries < 60) requestAnimationFrame(boot)
    }
    requestAnimationFrame(boot)
  })

  onBeforeUnmount(() => {
    if (raf) cancelAnimationFrame(raf)
    raf = 0
    ro?.disconnect()
    ro = null
    window.removeEventListener('pointermove', onPointerMove)
  })

  /* 图标注册完成（数量变化）→ 重测 */
  watch(
    () => icoRefs.value.filter(Boolean).length,
    () => {
      measure()
      ensureState(count)
      apply()
    }
  )

  /* 设置变化 → 立即重算并启动（参数改动要立刻见效） */
  watch(
    () => [
      opts.enabled.value,
      opts.max.value,
      opts.range.value,
      opts.speed.value,
      opts.damping.value,
      opts.neighbor.value,
      opts.lift.value,
      opts.animations.value
    ],
    () => {
      measure()
      start()
    }
  )

  /* 停靠方向 / 图标尺寸变化 → 几何全变，重测 */
  watch(
    () => [opts.position.value, opts.iconSize.value],
    () => {
      measure()
      start()
    }
  )

  return { groupRef, registerIco, hovering }
}
