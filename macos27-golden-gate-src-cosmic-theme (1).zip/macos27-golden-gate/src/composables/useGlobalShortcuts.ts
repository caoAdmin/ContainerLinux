/**
 * 全局快捷键处理
 * 支持：Cmd+Space 呼 Spotlight、Cmd+Q 关窗、Cmd+M 最小化、
 *      F3 调度中心、Esc 关浮层、Cmd+, 打开设置、Ctrl+Option+方向键分屏
 */
import { onMounted, onUnmounted } from 'vue'
import { useWindowStore } from '@/stores/windows'
import { useUIStore } from '@/stores/ui'

export function useGlobalShortcuts() {
  function handleKeydown(e: KeyboardEvent) {
    const winStore = useWindowStore()
    const ui = useUIStore()
    const meta = e.metaKey || e.ctrlKey
    const option = e.altKey
    const ctrl = e.ctrlKey

    // Esc：关闭浮层（含调度中心）
    if (e.key === 'Escape') {
      if (winStore.missionControlActive) {
        winStore.closeMissionControl()
        e.preventDefault()
        return
      }
      if (ui.spotlightOpen || ui.launchpadOpen || ui.activePanel || ui.contextMenu || ui.notificationCenterOpen || ui.aboutOpen) {
        ui.closeAll()
        e.preventDefault()
        return
      }
      return
    }

    // Cmd + Space → Spotlight
    if (meta && e.code === 'Space' && !option) {
      e.preventDefault()
      ui.toggleSpotlight()
      return
    }

    // F3 → 调度中心
    if (e.key === 'F3') {
      e.preventDefault()
      winStore.toggleMissionControl()
      return
    }

    // Cmd + , → 系统设置
    if (meta && e.key === ',' && !option && !e.shiftKey) {
      e.preventDefault()
      // 在窗口 store 中打开 settings
      const { openWindow, findWindowByApp } = winStore
      const exists = findWindowByApp('settings')
      if (exists) {
        winStore.activateWindow(exists.id)
        if (exists.minimized) exists.minimized = false
      } else {
        openWindow({ appId: 'settings' })
      }
      ui.closeAll()
      return
    }

    // Cmd + Q → 关闭当前激活窗口
    if (meta && (e.key === 'q' || e.key === 'Q') && !option) {
      if (winStore.activeWindowId) {
        e.preventDefault()
        winStore.closeWindow(winStore.activeWindowId)
      }
      return
    }

    // Cmd + W → 关闭当前激活窗口（mac 常用）
    if (meta && (e.key === 'w' || e.key === 'W') && !option) {
      if (winStore.activeWindowId) {
        e.preventDefault()
        winStore.closeWindow(winStore.activeWindowId)
      }
      return
    }

    // Cmd + M → 最小化
    if (meta && (e.key === 'm' || e.key === 'M') && !option) {
      if (winStore.activeWindowId) {
        e.preventDefault()
        winStore.minimizeWindow(winStore.activeWindowId)
      }
      return
    }

    // Ctrl + Option + ←/→/↑ 分屏
    if (ctrl && option && winStore.activeWindowId) {
      if (e.key === 'ArrowLeft') {
        e.preventDefault()
        winStore.tileWindow(winStore.activeWindowId, 'left')
      } else if (e.key === 'ArrowRight') {
        e.preventDefault()
        winStore.tileWindow(winStore.activeWindowId, 'right')
      } else if (e.key === 'ArrowUp') {
        e.preventDefault()
        winStore.tileWindow(winStore.activeWindowId, 'full')
      }
    }

    // Ctrl + ↑ 进入调度中心（排除 Ctrl+Option+↑ 的分屏组合）
    if (ctrl && !option && e.key === 'ArrowUp') {
      e.preventDefault()
      winStore.toggleMissionControl()
    }
  }

  onMounted(() => {
    window.addEventListener('keydown', handleKeydown)
  })
  onUnmounted(() => {
    window.removeEventListener('keydown', handleKeydown)
  })
}
