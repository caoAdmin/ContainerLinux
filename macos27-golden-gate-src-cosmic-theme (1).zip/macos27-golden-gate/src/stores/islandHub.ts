/**
 * IslandHub —— 桌面「信息岛」数据底座
 *
 * 功能取材自：
 *   · fly-island  —— 剪贴板历史、QQ/微信/邮箱消息、快捷翻译、AI 状态灯、
 *                    待办与每日笔记归档、外观预设、应用内更新
 *   · 岛仔 Daozai —— 微信/QQ 未读红点、五款皮肤、刘海/胶囊形态、三边停靠、
 *                    自动避让、月历日程、重复待办、番茄专注、饮水提醒、
 *                    文件置物架、验证码卡片、AI 额度、系统状态提示、
 *                    功能页开关与拖动排序
 *
 * 音乐播放 / 歌词 / 媒体控制保留在原有「音乐灵动岛」，本 store 不涉及。
 * 所有数据落在 localStorage，刷新不丢；网络类能力在纯前端以本地演示数据实现。
 */
import { defineStore } from 'pinia'
import { computed, reactive, ref, watch } from 'vue'

/* ══════════════ 类型 ══════════════ */

/** island = 跟随音乐灵动岛的玻璃/磨砂材质（默认）；其余为可自选的整岛主题 */
export type SkinId = 'island' | 'classic' | 'cream' | 'glass-light' | 'glass-dark' | 'cloud'
export type ShapeId = 'notch' | 'capsule'
/** top = 与音乐灵动岛合一（顶部居中，作为同一摞的下层）；left/right = 独立停靠 */
export type DockId = 'top' | 'left' | 'right'
export type FontId = 'system' | 'pixel'

export interface TodoItem {
  id: number
  text: string
  done: boolean
  /** 当前专注的那一条（收起态胶囊上会显示） */
  current: boolean
  /** 单次 / 每天 / 每周指定日 */
  repeat: 'once' | 'daily' | 'weekly'
  weekday: number
  /** 提醒时间，空串为不提醒 */
  remind: string
  date: string
}

export interface NoteArchive {
  date: string
  text: string
  done: number
  total: number
}

export interface ClipItem {
  id: number
  type: 'text' | 'image'
  content: string
  note: string
  favorite: boolean
  time: number
}

export type MsgSource = 'wechat' | 'qq' | 'mail'
export interface MessageItem {
  id: number
  source: MsgSource
  from: string
  title: string
  preview: string
  body: string
  time: number
  unread: boolean
  /** 微信多开账号 */
  account?: string
}

export interface OtpItem {
  id: number
  code: string
  from: string
  time: number
  /** 30 / 60 / 300 秒后自动隐藏 */
  hideAfter: number
  revealed: boolean
}

export interface TranslateItem {
  id: number
  src: string
  dst: string
  dir: string
  time: number
}

export type AgentState = 'idle' | 'running' | 'done' | 'attention'
export interface AgentItem {
  id: string
  name: string
  state: AgentState
  task: string
  time: number
  /** 'ct' = CTclaw 状态镜像（§12.4）；这类行只由 ctai store 写入，禁止手动 cycle */
  origin?: 'ct'
}

export interface QuotaItem {
  id: string
  name: string
  color: string
  plan: string
  used: number
  total: number
  unit: string
  reset: string
  balance?: string
  account: string
}

export interface CalEvent {
  id: number
  title: string
  date: string
  start: string
  end: string
  allDay: boolean
  repeat: 'once' | 'daily' | 'weekly'
  calendar: string
  color: string
  remind: number
}

export interface WaterRecord { id: number; ml: number; time: number }
export interface ShelfFile { id: number; name: string; size: number; type: string; time: number }
export interface SysHint { id: number; icon: string; text: string; time: number; tone: string }

export interface PageDef {
  id: string
  label: string
  icon: string
  enabled: boolean
  group: string
  kw: string
}

export interface Preset { id: number; name: string; skin: SkinId; shape: ShapeId; dock: DockId; scale: number; accent: string }

export const SKINS: { id: SkinId; name: string; swatch: string }[] = [
  { id: 'island', name: '灵动玻璃', swatch: 'linear-gradient(135deg,#23262d,#08080a)' },
  { id: 'classic', name: '经典黑', swatch: '#15181c' },
  { id: 'cream', name: '奶油', swatch: '#f0e6d2' },
  { id: 'glass-light', name: '毛玻璃 · 浅', swatch: 'linear-gradient(135deg,#e9eef5,#c9d6e8)' },
  { id: 'glass-dark', name: '毛玻璃 · 深', swatch: 'linear-gradient(135deg,#3a4150,#1b2029)' },
  { id: 'cloud', name: '星云紫', swatch: 'linear-gradient(135deg,#7b5cf0,#25c2a0)' }
]

export const DEFAULT_PAGES: PageDef[] = [
  { id: 'home', label: '今日概览', icon: 'ri-dashboard-3-line', enabled: true, group: '日常', kw: '首页 待办 日程 专注 汇总' },
  { id: 'todos', label: '待办与笔记', icon: 'ri-checkbox-circle-line', enabled: true, group: '日常', kw: '任务 每日笔记 归档 结转 markdown' },
  { id: 'calendar', label: '日历与日程', icon: 'ri-calendar-line', enabled: true, group: '日常', kw: '月历 时间线 会议 全天 重复 ics' },
  { id: 'focus', label: '专注与饮水', icon: 'ri-timer-line', enabled: true, group: '日常', kw: '番茄钟 休息 计时 喝水 目标' },
  { id: 'clipboard', label: '剪贴板历史', icon: 'ri-clipboard-line', enabled: true, group: '效率', kw: '复制 文本 图片 收藏 备注 搜索' },
  { id: 'messages', label: '消息与验证码', icon: 'ri-message-3-line', enabled: true, group: '效率', kw: '微信 QQ 邮箱 未读 正文 验证码 OTP' },
  { id: 'translate', label: '快捷翻译', icon: 'ri-translate-2', enabled: true, group: '效率', kw: '中英 自动识别 剪贴板 译文' },
  { id: 'shelf', label: '文件置物架', icon: 'ri-archive-line', enabled: true, group: '效率', kw: '拖入 文件 临时 收集 拖出' },
  { id: 'ai', label: 'AI 状态与额度', icon: 'ri-brain-line', enabled: true, group: '状态', kw: 'Codex Claude Kimi Grok Gemini ZCode WorkBuddy DeepSeek 余额' },
  { id: 'system', label: '系统状态', icon: 'ri-pulse-line', enabled: true, group: '状态', kw: '电量 网络 音量 大写锁定 输入语言 蓝牙' },
  { id: 'appearance', label: '外观与布局', icon: 'ri-palette-line', enabled: true, group: '设置', kw: '皮肤 刘海 胶囊 停靠 缩放 透明度 预设 排序' },
  { id: 'updates', label: '关于与更新', icon: 'ri-download-cloud-2-line', enabled: true, group: '设置', kw: '版本 检查更新 更新日志' }
]

/* ══════════════ 工具 ══════════════ */

const KEY = 'cosmic.islandHub.v1'
const now = () => Date.now()
const uid = () => Math.floor(Math.random() * 1e9)
const dayKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
const clock = (t: number) =>
  new Date(t).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false })

/** 极小的本地演示词典：纯前端无后端，翻译走内置短语 + 逐词替换 */
const DICT: [string, string][] = [
  ['你好', 'Hello'], ['谢谢', 'Thank you'], ['早上好', 'Good morning'], ['晚上好', 'Good evening'],
  ['今天天气很好', 'The weather is nice today'], ['我正在工作', 'I am working'],
  ['请把这个文件发给我', 'Please send me this file'], ['稍等一下', 'Wait a moment'],
  ['好的', 'OK'], ['没问题', 'No problem'], ['专注', 'Focus'], ['待办', 'To-do'],
  ['日程', 'Schedule'], ['消息', 'Message'], ['复制', 'Copy'], ['完成', 'Done'],
  ['hello', '你好'], ['thank you', '谢谢'], ['good morning', '早上好'],
  ['how are you', '你好吗'], ['i am working', '我正在工作'], ['focus', '专注'],
  ['schedule', '日程'], ['message', '消息'], ['copy', '复制'], ['done', '完成'],
  ['please send me this file', '请把这个文件发给我'], ['wait a moment', '稍等一下'],
  ['the weather is nice today', '今天天气很好'], ['no problem', '没问题'], ['ok', '好的']
]

function hasCJK(s: string) { return /[\u4e00-\u9fa5]/.test(s) }

/* ══════════════ Store ══════════════ */

export const useIslandHubStore = defineStore('islandHub', () => {

  /* ── 外观与布局 ── */
  const settings = reactive({
    skin: 'island' as SkinId,
    shape: 'capsule' as ShapeId,
    dock: 'top' as DockId,
    scale: 100,
    opacity: 100,
    accent: '#8ab4f8',
    font: 'system' as FontId,
    topOffset: 13,
    minimal: false,
    clock24: true,
    showTitle: true,
    autostart: false,
    autoTuck: true,
    captureCopy: true,
    captureImages: true,
    clipMax: 30,
    clipShortcut: 'Alt+C'
  })
  const presets = ref<Preset[]>([
    { id: 1, name: '灵动玻璃', skin: 'island', shape: 'capsule', dock: 'top', scale: 100, accent: '#8ab4f8' },
    { id: 2, name: '经典黑', skin: 'classic', shape: 'capsule', dock: 'top', scale: 100, accent: '#1f6b46' },
    { id: 3, name: '奶油刘海', skin: 'cream', shape: 'notch', dock: 'top', scale: 105, accent: '#b6793c' },
    { id: 4, name: '毛玻璃深', skin: 'glass-dark', shape: 'capsule', dock: 'top', scale: 100, accent: '#5aa9f5' },
    { id: 5, name: '星云紫', skin: 'cloud', shape: 'capsule', dock: 'right', scale: 110, accent: '#7b5cf0' }
  ])
  const pages = ref<PageDef[]>(DEFAULT_PAGES.map((p) => ({ ...p })))

  /* ── 待办 / 每日笔记 / 归档 ── */
  const todos = ref<TodoItem[]>([
    { id: 1, text: '整理灵动岛交互稿', done: false, current: true, repeat: 'once', weekday: 1, remind: '10:00', date: dayKey() },
    { id: 2, text: '回复设计评审邮件', done: false, current: false, repeat: 'once', weekday: 1, remind: '14:30', date: dayKey() },
    { id: 3, text: '每周同步会议纪要', done: false, current: false, repeat: 'weekly', weekday: 3, remind: '09:30', date: dayKey() },
    { id: 4, text: '喝水 & 站起来走走', done: true, current: false, repeat: 'daily', weekday: 1, remind: '', date: dayKey() }
  ])
  const note = ref('今天把两个灵动岛项目的功能过了一遍，挑能用的都搬上桌。')
  const archives = ref<NoteArchive[]>([
    { date: '2026-11-06', text: '玻璃材质切换 + 通知条收回动画收尾。', done: 5, total: 6 },
    { date: '2026-11-05', text: '彗星进度条调了六轮，终于和封面主题色对上了。', done: 4, total: 5 }
  ])
  const carryOver = ref(true)

  /* ── 剪贴板 ── */
  const clips = ref<ClipItem[]>([
    { id: 11, type: 'text', content: 'https://github.com/vinceliuice/Fluent-icon-theme', note: '图标库', favorite: true, time: now() - 3600e3 },
    { id: 12, type: 'text', content: 'npm run build && npm run preview', note: '', favorite: false, time: now() - 7200e3 },
    { id: 13, type: 'image', content: 'linear-gradient(135deg,#7b5cf0,#25c2a0)', note: '配色参考', favorite: false, time: now() - 86000e3 },
    { id: 14, type: 'text', content: 'Displacement 99 · Blur 0.12 · Saturation 140%', note: '玻璃参数', favorite: true, time: now() - 172000e3 }
  ])

  /* ── 消息 / 验证码 ── */
  const msgSource = ref<MsgSource>('wechat')
  const messages = ref<MessageItem[]>([
    { id: 21, source: 'wechat', from: '设计组 · 小林', title: '灵动岛展开稿', preview: '这版动画顺多了，周五之前…', body: '这版动画顺多了，周五之前把交互说明补一下就可以进评审了。另外胶囊堆叠的虚化层再压暗一点，和主卡拉开层次。', time: now() - 8 * 60e3, unread: true, account: '工作号' },
    { id: 22, source: 'wechat', from: '家里', title: '晚饭', preview: '今晚想吃什么？', body: '今晚想吃什么？我路过菜市场可以带点。', time: now() - 42 * 60e3, unread: true, account: '个人号' },
    { id: 23, source: 'qq', from: 'COSMIC 开发群', title: '构建通过', preview: 'vue-tsc -b 无报错', body: 'vue-tsc -b 无报错，预览已更新到 4321 端口，大家强刷一下。', time: now() - 15 * 60e3, unread: true },
    { id: 24, source: 'qq', from: '阿哲', title: '周末打球', preview: '周日下午老地方？', body: '周日下午老地方？场地我订好了。', time: now() - 3 * 3600e3, unread: false },
    { id: 25, source: 'mail', from: 'GitHub <noreply@github.com>', title: '[fly-island] 新版本 v0.2.20', preview: '重新启用液态玻璃', body: 'fly-island v0.2.20 发布：重新启用液态玻璃外观，修复若干窗口布局问题。查看 Release 了解完整变更。', time: now() - 55 * 60e3, unread: true },
    { id: 26, source: 'mail', from: 'CI <ci@local.dev>', title: '验证码通知', preview: '本次登录验证码 482913', body: '本次登录验证码为 482913，5 分钟内有效。请勿转发给他人。', time: now() - 2 * 60e3, unread: true }
  ])
  const otps = ref<OtpItem[]>([
    { id: 31, code: '482913', from: 'CI 登录验证', time: now() - 40e3, hideAfter: 60, revealed: false }
  ])
  const previewEnabled = ref(false)

  /* ── 翻译 ── */
  const translateDir = ref<'auto' | 'zh2en' | 'en2zh'>('auto')
  const translateHistory = ref<TranslateItem[]>([
    { id: 41, src: '今天天气很好', dst: 'The weather is nice today', dir: '中 → 英', time: now() - 3600e3 }
  ])

  /* ── AI 状态灯 / 额度 ── */
  const agents = ref<AgentItem[]>([
    { id: 'codex', name: 'Codex', state: 'running', task: '重构 IslandStack 过渡动画', time: now() - 90e3 },
    { id: 'claude', name: 'Claude Code', state: 'done', task: '生成本地演示数据', time: now() - 12 * 60e3 },
    /* CTclaw 状态镜像（§12.4）：当前档位 / 是否有运行中的小馒头 / 是否需关注。
       会话主体仍在「小C」窗口，这里只做状态镜像；不进 quotas。 */
    { id: 'ctclaw', name: 'CTclaw', origin: 'ct', state: 'idle', task: '档位 local · 零常驻', time: now() }
  ])
  const quotas = ref<QuotaItem[]>([
    { id: 'codex', name: 'Codex', color: '#10a37f', plan: 'Team', used: 62, total: 100, unit: '次', reset: '11-09 00:00', account: '主账号' },
    { id: 'claude', name: 'Claude', color: '#d97757', plan: 'Pro', used: 38, total: 100, unit: '条', reset: '11-08 09:00', account: '主账号' },
    { id: 'kimi', name: 'Kimi', color: '#4c6ef5', plan: '免费', used: 12, total: 50, unit: '次', reset: '每日重置', account: '默认' },
    { id: 'grok', name: 'Grok Bot', color: '#8b93a5', plan: 'X Premium', used: 75, total: 100, unit: '次', reset: '11-10 00:00', account: '默认' },
    { id: 'gemini', name: 'Gemini', color: '#4285f4', plan: 'API', used: 24, total: 100, unit: '万 token', reset: '每月 1 日', account: '默认' },
    { id: 'zcode', name: 'ZCode', color: '#e5a50a', plan: '套餐 A', used: 46, total: 200, unit: '次', reset: '11-30', account: '默认' },
    { id: 'workbuddy', name: 'WorkBuddy', color: '#7b5cf0', plan: '积分', used: 1280, total: 2000, unit: '积分', reset: '不重置', account: '本机登录' },
    { id: 'deepseek', name: 'DeepSeek', color: '#4d6bfe', plan: 'API', used: 0, total: 0, unit: '', reset: '—', balance: '¥ 86.40', account: 'API Key' }
  ])

  /* ── 日历 / 日程 ── */
  const calCursor = ref(new Date())
  const calSelected = ref(dayKey())
  const events = ref<CalEvent[]>([
    { id: 51, title: '设计评审会', date: dayKey(), start: '10:30', end: '11:30', allDay: false, repeat: 'once', calendar: '工作', color: '#7b5cf0', remind: 15 },
    { id: 52, title: '灵动岛联调', date: dayKey(), start: '14:00', end: '15:30', allDay: false, repeat: 'once', calendar: '工作', color: '#25c2a0', remind: 10 },
    { id: 53, title: '周报', date: dayKey(), start: '17:00', end: '17:30', allDay: false, repeat: 'weekly', calendar: '工作', color: '#e5a50a', remind: 5 },
    { id: 54, title: '团队 Offsite', date: dayKey(new Date(now() + 86400e3)), start: '', end: '', allDay: true, repeat: 'once', calendar: '工作', color: '#e01b24', remind: 60 }
  ])
  const calendars = ref(['工作', '个人', '邮件邀请'])

  /* ── 专注 / 饮水 ── */
  const focus = reactive({
    mode: 'focus' as 'focus' | 'break',
    running: false,
    remaining: 25 * 60,
    focusMin: 25,
    breakMin: 5,
    sessions: 3
  })
  const water = reactive({ goal: 2000, cup: 250 })
  const waterRecords = ref<WaterRecord[]>([
    { id: 61, ml: 250, time: now() - 2 * 3600e3 },
    { id: 62, ml: 250, time: now() - 3600e3 }
  ])

  /* ── 文件置物架 ── */
  const shelf = ref<ShelfFile[]>([
    { id: 71, name: '灵动岛交互稿_v3.fig', size: 2_480_000, type: 'fig', time: now() - 3600e3 },
    { id: 72, name: '封面主题色.png', size: 384_000, type: 'png', time: now() - 7200e3 }
  ])

  /* ── 系统状态提示 ── */
  const sysHints = ref<SysHint[]>([
    { id: 81, icon: 'ri-battery-line', text: '电量 76% · 正在充电', time: now() - 5 * 60e3, tone: '#2ec27e' },
    { id: 82, icon: 'ri-wifi-line', text: '已连接 COSMIC-5G', time: now() - 18 * 60e3, tone: '#3584e4' },
    { id: 83, icon: 'ri-bluetooth-line', text: 'AirPods Pro 已连接', time: now() - 42 * 60e3, tone: '#7b5cf0' }
  ])
  const capsLock = ref(false)
  const inputLang = ref('简体中文')
  const volume = ref(55)

  /* ── 更新 ── */
  const update = reactive({ checking: false, progress: 0, state: 'idle' as 'idle' | 'latest' | 'found' | 'done', version: 'v1.4.0' })

  /* ── 胶囊堆 / 工作台 ── */
  const stackOpen = ref(false)
  const activeCard = ref(0)
  /** 整摞的顶卡是不是音乐胶囊。false = 某张信息卡轮到最上层（清晰），
      音乐胶囊下沉成底层。滚轮在 [音乐, 卡0, 卡1, …] 这张环形牌堆上轮转。 */
  const topIsMusic = ref(true)
  const activePage = ref('home')
  const windowOpen = ref(false)
  const toast = ref('')
  let toastTimer = 0

  /* ══════════════ 派生 ══════════════ */

  const enabledPages = computed(() => pages.value.filter((p) => p.enabled))
  const unreadCount = computed(() => messages.value.filter((m) => m.unread).length)
  const unreadBySource = computed(() => ({
    wechat: messages.value.filter((m) => m.unread && m.source === 'wechat').length,
    qq: messages.value.filter((m) => m.unread && m.source === 'qq').length,
    mail: messages.value.filter((m) => m.unread && m.source === 'mail').length
  }))
  const currentTodo = computed(() => todos.value.find((t) => t.current && !t.done) ?? todos.value.find((t) => !t.done))
  const todayDone = computed(() => todos.value.filter((t) => t.done).length)
  const waterTotal = computed(() => waterRecords.value.reduce((s, r) => s + r.ml, 0))
  const todayEvents = computed(() =>
    events.value.filter((e) => e.date === calSelected.value).sort((a, b) => a.start.localeCompare(b.start))
  )
  const runningAgent = computed(() => agents.value.find((a) => a.state === 'running') ?? null)
  const attentionAgent = computed(() => agents.value.find((a) => a.state === 'attention') ?? null)
  const visibleOtps = computed(() =>
    otps.value.filter((o) => now() - o.time < o.hideAfter * 1000)
  )

  /** 胶囊堆里的卡片：视觉最多露 3 层，但卡片总数不限（其余在展开面板里） */
  const stackCards = computed(() => {
    const list: { id: string; icon: string; label: string; sub: string; tone: string; page: string; badge: number }[] = []
    const main = currentTodo.value
    list.push({
      id: 'today', icon: 'ri-sun-line', label: main ? main.text : '今天没有待办',
      sub: `待办 ${todayDone.value}/${todos.value.length} · 日程 ${todayEvents.value.length} 项`,
      tone: settings.accent, page: 'home', badge: 0
    })
    if (unreadCount.value) list.push({
      id: 'msg', icon: 'ri-message-3-line', label: `${unreadCount.value} 条新消息`,
      sub: `微信 ${unreadBySource.value.wechat} · QQ ${unreadBySource.value.qq} · 邮件 ${unreadBySource.value.mail}`,
      tone: '#d94a4a', page: 'messages', badge: unreadCount.value
    })
    if (visibleOtps.value.length) list.push({
      id: 'otp', icon: 'ri-shield-keyhole-line', label: `验证码 ${visibleOtps.value[0].revealed ? visibleOtps.value[0].code : '••••••'}`,
      sub: `${visibleOtps.value[0].from} · 点击复制`, tone: '#e5a50a', page: 'messages', badge: 0
    })
    list.push({
      id: 'focus', icon: 'ri-timer-line', label: focus.running ? '专注进行中' : '番茄专注',
      sub: focus.running ? `剩余 ${Math.floor(focus.remaining / 60)}:${String(focus.remaining % 60).padStart(2, '0')} · 第 ${focus.sessions + 1} 轮` : `已喝 ${waterTotal.value}/${water.goal} ml · 开始一轮专注`,
      tone: '#7b5cf0', page: 'focus', badge: 0
    })
    if (runningAgent.value || attentionAgent.value) list.push({
      id: 'agent', icon: 'ri-brain-line',
      label: attentionAgent.value ? 'Agent 需要关注' : `${runningAgent.value?.name} 运行中`,
      sub: (attentionAgent.value ?? runningAgent.value)?.task ?? '',
      tone: attentionAgent.value ? '#e5a50a' : '#10a37f', page: 'ai', badge: 0
    })
    list.push({
      id: 'quota', icon: 'ri-pulse-line', label: 'AI 额度',
      sub: `Codex ${quotas.value[0].used}% · WorkBuddy ${quotas.value[6].used} 积分`,
      tone: '#25c2a0', page: 'ai', badge: 0
    })
    list.push({
      id: 'system', icon: 'ri-battery-line', label: '系统状态',
      sub: `电量 76% · 音量 ${volume.value}% · ${inputLang.value}`,
      tone: '#3584e4', page: 'system', badge: 0
    })
    return list
  })

  /* ── 环形牌堆统一视图 ──
     把「音乐胶囊(pos 0)」与「信息卡(pos 1..n)」合成一个长度为 n+1 的环，
     环上相对位置 rel = (pos - activePos + total) % total。

     视觉上有 5 个槽位，卡片永远常驻 DOM、只在槽位之间平滑移动：

       rel 0            → top      顶槽（清晰主卡）
       rel 1            → mid      中槽（略收窄略虚，从顶卡下方探出）
       rel 2            → low      底槽（再收窄再虚，只留轮廓）
       rel 3 .. total-2 → offDown  已从底部滚出（下方待命，不可见）
       rel total-1      → offUp    顶卡上方待命（不可见）

     这个映射对滚动方向自洽：activePos 递减时每张卡 rel+1，
     top→mid→low→offDown 一路向下滚，而 offUp 那张滑进 top（从上方落入）；
     activePos 递增时每张卡 rel-1，整摞反向向上滚。

     ⚠️ 铁律：所有卡片都渲染、只换槽位类名，绝不按可见性 v-if 卸载。
     一卸载，元素就得重新挂载，CSS transition 从第一帧就是终值 ——
     切换就彻底没有过渡动画了（曾经踩过）。 */
  type IslandSlot = 'top' | 'mid' | 'low' | 'offUp' | 'offDown'

  const ringTotal = computed(() => stackCards.value.length + 1)
  /** 当前顶卡在环上的位置：音乐 = 0，信息卡 i = i+1 */
  const activePos = computed(() => (topIsMusic.value ? 0 : activeCard.value + 1))

  function slotOf(rel: number, total: number): IslandSlot {
    if (rel === 0) return 'top'
    if (rel === 1) return 'mid'
    if (rel === 2) return 'low'
    if (total > 3 && rel === total - 1) return 'offUp'
    return 'offDown'
  }

  /** 音乐胶囊当前槽位（pos 恒为 0） */
  const musicSlot = computed<IslandSlot>(() => {
    const total = ringTotal.value
    const rel = ((0 - activePos.value) % total + total) % total
    return slotOf(rel, total)
  })
  /** 兼容旧调用：0=顶 1=中 2=底 -1=不在可见槽位 */
  const musicLevel = computed(() => {
    const sl = musicSlot.value
    return sl === 'top' ? 0 : sl === 'mid' ? 1 : sl === 'low' ? 2 : -1
  })
  /** 每张信息卡的槽位（卡片总数不限，全部渲染） */
  const ringCards = computed(() => {
    const cards = stackCards.value
    const total = ringTotal.value
    const ap = activePos.value
    return cards.map((card, i) => {
      const pos = i + 1
      const rel = ((pos - ap) % total + total) % total
      return { card, pos, rel, slot: slotOf(rel, total) }
    })
  })

  /* ══════════════ 动作 ══════════════ */

  function say(text: string) {
    toast.value = text
    window.clearTimeout(toastTimer)
    toastTimer = window.setTimeout(() => (toast.value = ''), 2200)
  }

  async function copyText(text: string, ok = '已复制') {
    try {
      await navigator.clipboard.writeText(text)
      say(ok)
    } catch {
      const ta = document.createElement('textarea')
      ta.value = text
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.select()
      try { document.execCommand('copy'); say(ok) } catch { say('复制失败，请手动选择') }
      document.body.removeChild(ta)
    }
  }

  /* 待办 */
  function addTodo(text: string, repeat: TodoItem['repeat'] = 'once') {
    const t = text.trim()
    if (!t) return
    todos.value.unshift({ id: uid(), text: t, done: false, current: false, repeat, weekday: new Date().getDay(), remind: '', date: dayKey() })
  }
  function toggleTodo(id: number) {
    const t = todos.value.find((x) => x.id === id)
    if (t) t.done = !t.done
  }
  function removeTodo(id: number) { todos.value = todos.value.filter((x) => x.id !== id) }
  function setCurrent(id: number) {
    todos.value.forEach((t) => (t.current = t.id === id))
  }
  function clearDone() { todos.value = todos.value.filter((t) => !t.done) }
  function saveArchive() {
    archives.value.unshift({ date: dayKey(), text: note.value, done: todayDone.value, total: todos.value.length })
    if (carryOver.value) {
      const undone = todos.value.filter((t) => !t.done)
      todos.value = undone.map((t) => ({ ...t, id: uid(), date: dayKey() }))
      note.value = ''
      say(`已归档，${undone.length} 项未完成任务结转到今天`)
    } else say('今日笔记已归档')
  }
  function exportMarkdown() {
    const md = [`# 待办与笔记 ${dayKey()}`, '', '## 待办', ...todos.value.map((t) => `- [${t.done ? 'x' : ' '}] ${t.text}`), '', '## 每日笔记', '', note.value].join('\n')
    const blob = new Blob([md], { type: 'text/markdown' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `island-${dayKey()}.md`
    a.click()
    URL.revokeObjectURL(a.href)
    say('已导出 Markdown')
  }

  /* 剪贴板 */
  function addClip(content: string, type: ClipItem['type'] = 'text') {
    const c = content.trim()
    if (!c) return
    if (clips.value[0]?.content === c) return
    clips.value.unshift({ id: uid(), type, content: c, note: '', favorite: false, time: now() })
    if (clips.value.length > settings.clipMax) clips.value.length = settings.clipMax
  }
  function removeClip(id: number) { clips.value = clips.value.filter((c) => c.id !== id) }
  function toggleFav(id: number) {
    const c = clips.value.find((x) => x.id === id)
    if (c) c.favorite = !c.favorite
  }
  function setClipNote(id: number, note: string) {
    const c = clips.value.find((x) => x.id === id)
    if (c) c.note = note
  }
  function clearClips() { clips.value = [] }

  /* 消息 / 验证码 */
  function readMessage(id: number) {
    const m = messages.value.find((x) => x.id === id)
    if (m) m.unread = false
    return m
  }
  function markAllRead(source?: MsgSource) {
    messages.value.forEach((m) => { if (!source || m.source === source) m.unread = false })
    say('已全部标为已读')
  }
  function revealOtp(id: number) {
    const o = otps.value.find((x) => x.id === id)
    if (o) o.revealed = !o.revealed
  }
  function dismissOtp(id: number) { otps.value = otps.value.filter((o) => o.id !== id) }

  /* 翻译 */
  function translate(src: string): { dst: string; dir: string } {
    const s = src.trim()
    if (!s) return { dst: '', dir: '' }
    const autoZh = hasCJK(s)
    const dir = translateDir.value === 'auto' ? (autoZh ? 'zh2en' : 'en2zh') : translateDir.value
    const label = dir === 'zh2en' ? '中 → 英' : '英 → 中'
    const lower = s.toLowerCase()
    let out = DICT.find(([k]) => k.toLowerCase() === lower)?.[1] ?? ''
    if (!out) {
      let rest = s
      const hits: string[] = []
      for (const [k, v] of DICT) {
        if (rest.toLowerCase().includes(k.toLowerCase())) { hits.push(v); rest = rest.replace(new RegExp(k, 'gi'), '') }
      }
      out = hits.length ? hits.join(' ') : ''
      if (!out) out = dir === 'zh2en' ? `[英译] ${s}` : `[中译] ${s}`
      else if (rest.trim()) out += ` (${rest.trim()})`
    }
    return { dst: out, dir: label }
  }
  function commitTranslate(src: string, dst: string, dir: string) {
    if (!src.trim() || !dst) return
    translateHistory.value.unshift({ id: uid(), src, dst, dir, time: now() })
    if (translateHistory.value.length > 30) translateHistory.value.length = 30
  }

  /* AI */
  function cycleAgent(id: string) {
    const a = agents.value.find((x) => x.id === id)
    if (!a) return
    if (a.origin === 'ct') return // CTclaw 镜像行只由 ctai store 驱动，禁止手动切换
    const order: AgentState[] = ['idle', 'running', 'done', 'attention']
    a.state = order[(order.indexOf(a.state) + 1) % order.length]
    a.time = now()
  }

  /**
   * CTclaw 状态镜像（§12.4）——由 ctai store 单向调用。
   * 只更新 agents 中 id==='ctclaw' 的那一行；绝不触碰 quotas（第三方订阅额度）。
   */
  function syncCtMirror(p: {
    phase: string
    tier: string
    runningCount: number
    needsAttention: boolean
    state: AgentState
  }) {
    const a = agents.value.find((x) => x.id === 'ctclaw')
    if (!a) return
    a.state = p.state
    a.task = `档位 ${p.tier} · ${p.runningCount > 0 ? `${p.runningCount} 个小馒头运行中` : '零常驻'}`
    a.time = now()
  }
  function refreshQuota(id: string) {
    const q = quotas.value.find((x) => x.id === id)
    if (!q || !q.total) return
    q.used = Math.max(0, Math.min(q.total, q.used + Math.round((Math.random() - 0.5) * 8)))
    say(`${q.name} 额度已刷新`)
  }

  /* 日历 */
  function addEvent(e: Omit<CalEvent, 'id'>) { events.value.push({ ...e, id: uid() }) }
  function removeEvent(id: number) { events.value = events.value.filter((e) => e.id !== id) }
  function shiftMonth(n: number) {
    const d = new Date(calCursor.value)
    d.setMonth(d.getMonth() + n)
    calCursor.value = d
  }

  /* 专注 / 饮水 */
  let focusTimer = 0
  function startFocus() {
    if (focus.running) {
      focus.running = false
      window.clearInterval(focusTimer)
      return
    }
    focus.running = true
    focusTimer = window.setInterval(() => {
      if (focus.remaining > 0) { focus.remaining--; return }
      window.clearInterval(focusTimer)
      focus.running = false
      if (focus.mode === 'focus') {
        focus.sessions++
        focus.mode = 'break'
        focus.remaining = focus.breakMin * 60
        pushHint('ri-timer-line', '专注完成，休息一下吧', '#25c2a0')
        say('专注完成，进入休息')
      } else {
        focus.mode = 'focus'
        focus.remaining = focus.focusMin * 60
        pushHint('ri-timer-line', '休息结束，开始下一轮', '#7b5cf0')
      }
    }, 1000)
  }
  function resetFocus() {
    window.clearInterval(focusTimer)
    focus.running = false
    focus.mode = 'focus'
    focus.remaining = focus.focusMin * 60
  }
  function drink() {
    waterRecords.value.push({ id: uid(), ml: water.cup, time: now() })
    pushHint('ri-drop-line', `记录饮水 +${water.cup} ml`, '#3584e4')
    say(`+${water.cup} ml，今日 ${waterTotal.value + water.cup} ml`)
  }
  function undoWater() {
    waterRecords.value.pop()
    say('已撤销上一条饮水记录')
  }

  /* 置物架 */
  function addShelfFiles(files: FileList | File[]) {
    Array.from(files).forEach((f) => shelf.value.unshift({ id: uid(), name: f.name, size: f.size, type: f.name.split('.').pop() ?? 'file', time: now() }))
    say(`已收进置物架 ${files.length} 个文件`)
  }
  function removeShelf(id: number) { shelf.value = shelf.value.filter((f) => f.id !== id) }

  /* 系统提示 */
  function pushHint(icon: string, text: string, tone = '#7b5cf0') {
    sysHints.value.unshift({ id: uid(), icon, text, time: now(), tone })
    if (sysHints.value.length > 40) sysHints.value.length = 40
  }

  /* 外观：预设 / 页面排序 */
  function savePreset(name: string) {
    if (presets.value.length >= 6) { say('最多保存 6 个样式预设'); return }
    presets.value.push({ id: uid(), name: name || `预设 ${presets.value.length + 1}`, skin: settings.skin, shape: settings.shape, dock: settings.dock, scale: settings.scale, accent: settings.accent })
    say('样式预设已保存')
  }
  function applyPreset(p: Preset) {
    settings.skin = p.skin; settings.shape = p.shape; settings.dock = p.dock
    settings.scale = p.scale; settings.accent = p.accent
    say(`已应用「${p.name}」`)
  }
  function removePreset(id: number) { presets.value = presets.value.filter((p) => p.id !== id) }
  function togglePage(id: string) {
    const p = pages.value.find((x) => x.id === id)
    if (p) p.enabled = !p.enabled
  }
  function movePage(id: string, delta: number) {
    const i = pages.value.findIndex((p) => p.id === id)
    const j = i + delta
    if (i < 0 || j < 0 || j >= pages.value.length) return
    const arr = pages.value.slice()
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
    pages.value = arr
  }

  /* 更新 */
  function checkUpdate() {
    if (update.checking) return
    update.checking = true
    update.progress = 0
    update.state = 'idle'
    const timer = window.setInterval(() => {
      update.progress += 8
      if (update.progress >= 100) {
        window.clearInterval(timer)
        update.checking = false
        update.state = 'found'
        say(`发现新版本 ${update.version}`)
      }
    }, 90)
  }
  function installUpdate() {
    update.state = 'done'
    say('已更新到最新版本')
  }

  /* 胶囊堆 / 工作台 */
  function openStack(page = 'home') {
    stackOpen.value = true
    activePage.value = page
    windowOpen.value = false
  }
  function closeStack() { stackOpen.value = false }
  /** 环形牌堆步进：音乐 = pos 0，信息卡 i = pos i+1，环长 total = n+1。
      dir = +1（下一张）让 activePos 递减 —— 每张卡的 rel 都 +1，
      于是 top→mid→low→offDown 一路向下滚，而 offUp 那张从容滑进 top
      （从上方落入）；dir = -1 时反向，整摞向上滚。

      因为 offUp / offDown 都是真实存在的槽位（元素常驻，只是移出可见区），
      任何一步都不会出现「卡片被卸载 → 瞬间消失」，所以这里不需要任何
      方向重定向补丁：纯环形步进即可，正反向完全对称。 */
  function nextCard(dir = 1) {
    const n = stackCards.value.length
    if (!n) return
    const total = n + 1
    let ap = activePos.value
    ap = ((ap - dir) % total + total) % total
    topIsMusic.value = ap === 0
    if (!topIsMusic.value) activeCard.value = ap - 1
  }
  /** 直接把某张卡（或音乐胶囊）放到最上层，供圆点条 / 音乐胶囊点击使用 */
  function goTop(idx: number | 'music') {
    if (idx === 'music') { topIsMusic.value = true; return }
    topIsMusic.value = false
    activeCard.value = idx
  }
  function openCard(cardId: string) {
    const c = stackCards.value.find((x) => x.id === cardId)
    if (c) openStack(c.page)
  }
  function toggleWindow() { windowOpen.value = !windowOpen.value; if (windowOpen.value) stackOpen.value = false }

  /* ══════════════ 持久化 ══════════════ */
  const PERSIST_KEYS = [
    'settings', 'presets', 'pages', 'todos', 'note', 'archives', 'carryOver',
    'clips', 'messages', 'otps', 'previewEnabled', 'translateHistory',
    'agents', 'quotas', 'events', 'water', 'waterRecords', 'shelf', 'volume', 'inputLang', 'sysHints'
  ] as const

  function load() {
    try {
      const raw = localStorage.getItem(KEY)
      if (!raw) return
      const data = JSON.parse(raw) as Record<string, unknown>
      const bag: Record<string, unknown> = {
        settings, presets, pages, todos, note, archives, carryOver, clips, messages, otps,
        previewEnabled, translateHistory, agents, quotas, events, water, waterRecords,
        shelf, volume, inputLang, sysHints
      }
      for (const k of PERSIST_KEYS) {
        const v = data[k]
        if (v === undefined) continue
        const target = bag[k]
        if (Array.isArray(v) && 'value' in (target as object)) (target as { value: unknown }).value = v
        else if (typeof v === 'object' && v !== null && !('value' in (target as object))) Object.assign(target as object, v)
        else if ('value' in (target as object)) (target as { value: unknown }).value = v
      }
      // 过期验证码直接丢弃
      otps.value = otps.value.filter((o) => now() - o.time < o.hideAfter * 1000)
    } catch { /* 隐私模式 / 脏数据 → 用默认值 */ }
  }
  load()

  /* 旧版本把 topOffset 当作「整摞距屏幕上沿的距离」（默认 62/70），
     会把信息卡推到离音乐胶囊半屏远，看起来是分家的两坨。
     合一后它只表示层叠错位量，宿主位置由 CSS 硬绑定 top:13px，
     这里把历史大值收敛回默认，避免升级后仍残留旧间距。 */
  if (settings.topOffset > 28 || settings.topOffset < 8) settings.topOffset = 13

  /* ── 全岛配色：皮肤 / 主题色 / 字体统一写到 <html> ──
     音乐灵动岛在 CosmicDesktop 里、胶囊堆叠与应用窗口在信息岛组件树里，
     三方本来互不继承 CSS 变量。挂到 documentElement 后，一整套令牌
     （--ih-shell / --ih-fg / --ih-accent …）对全岛同时生效：
     换一次皮肤，音乐岛壳体、堆叠卡、工作台会一起变，不会各用各的。 */
  function applyTheme() {
    if (typeof document === 'undefined') return
    const root = document.documentElement
    root.dataset.ihSkin = settings.skin
    root.dataset.ihFont = settings.font
    root.dataset.ihShape = settings.shape
    root.dataset.ihDock = settings.dock
    root.style.setProperty('--ih-accent', settings.accent)
    root.style.setProperty('--ih-scale', String(settings.scale / 100))
    root.style.setProperty('--ih-opacity', String(settings.opacity / 100))
  }
  watch(
    () => [settings.skin, settings.font, settings.shape, settings.dock, settings.accent, settings.scale, settings.opacity],
    applyTheme,
    { immediate: true }
  )

  let saveTimer = 0
  watch(
    () => PERSIST_KEYS.map((k) => {
      const bag: Record<string, unknown> = {
        settings, presets, pages, todos, note, archives, carryOver, clips, messages, otps,
        previewEnabled, translateHistory, agents, quotas, events, water, waterRecords,
        shelf, volume, inputLang, sysHints
      }
      return bag[k]
    }),
    () => {
      window.clearTimeout(saveTimer)
      saveTimer = window.setTimeout(() => {
        try {
          const bag: Record<string, unknown> = {
            settings, presets, pages, todos, note, archives, carryOver, clips, messages, otps,
            previewEnabled, translateHistory, agents, quotas, events, water, waterRecords,
            shelf, volume, inputLang, sysHints
          }
          const out: Record<string, unknown> = {}
          for (const k of PERSIST_KEYS) {
            const t = bag[k]
            out[k] = t && typeof t === 'object' && 'value' in t ? (t as { value: unknown }).value : t
          }
          localStorage.setItem(KEY, JSON.stringify(out))
        } catch { /* 容量超限忽略 */ }
      }, 260)
    },
    { deep: true }
  )

  /* 真实浏览器能力：监听复制事件自动记录；监听 CapsLock / 网络 / 电量 */
  function onCopy(e: ClipboardEvent) {
    if (!settings.captureCopy) return
    const text = e.clipboardData?.getData('text/plain')
    if (text) addClip(text)
  }
  function onKey(e: KeyboardEvent) {
    const on = e.getModifierState?.('CapsLock') ?? false
    if (on !== capsLock.value) {
      capsLock.value = on
      pushHint('ri-keyboard-line', `大写锁定已${on ? '开启' : '关闭'}`, on ? '#e5a50a' : '#8b93a5')
    }
  }
  function onOnline() { pushHint('ri-wifi-line', '网络已连接', '#2ec27e') }
  function onOffline() { pushHint('ri-wifi-off-line', '网络已断开', '#e01b24') }
  function bindGlobal() {
    document.addEventListener('copy', onCopy)
    window.addEventListener('keydown', onKey)
    window.addEventListener('online', onOnline)
    window.addEventListener('offline', onOffline)
  }
  function unbindGlobal() {
    document.removeEventListener('copy', onCopy)
    window.removeEventListener('keydown', onKey)
    window.removeEventListener('online', onOnline)
    window.removeEventListener('offline', onOffline)
    window.clearInterval(focusTimer)
    window.clearTimeout(toastTimer)
    window.clearTimeout(saveTimer)
  }

  return {
    // 状态
    settings, presets, pages, todos, note, archives, carryOver, clips, msgSource, messages,
    otps, previewEnabled, translateDir, translateHistory, agents, quotas, calCursor,
    calSelected, events, calendars, focus, water, waterRecords, shelf, sysHints,
    capsLock, inputLang, volume, update, stackOpen, activeCard, topIsMusic, activePage, windowOpen, toast,
    // 派生
    enabledPages, unreadCount, unreadBySource, currentTodo, todayDone, waterTotal,
    todayEvents, runningAgent, attentionAgent, visibleOtps, stackCards, ringTotal, activePos, musicSlot, musicLevel, ringCards,
    // 动作
    say, copyText, addTodo, toggleTodo, removeTodo, setCurrent, clearDone, saveArchive,
    exportMarkdown, addClip, removeClip, toggleFav, setClipNote, clearClips, readMessage,
    markAllRead, revealOtp, dismissOtp, translate, commitTranslate, cycleAgent, refreshQuota, syncCtMirror,
    addEvent, removeEvent, shiftMonth, startFocus, resetFocus, drink, undoWater,
    addShelfFiles, removeShelf, pushHint, savePreset, applyPreset, removePreset,
    togglePage, movePage, checkUpdate, installUpdate, openStack, closeStack, nextCard, goTop,
    openCard, toggleWindow, bindGlobal, unbindGlobal, clock, dayKey
  }
})
