/**
 * 窗口管理 Store
 * 管理窗口列表、z-index 层级、激活、创建/最小化/关闭/缩放
 */
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { WindowState, CreateWindowOptions } from '@/types'
import { getAppById } from '@/utils/appRegistry'

let zIndexCounter = 10
let idCounter = 0

function genId(): string {
  idCounter += 1
  return `win-${Date.now()}-${idCounter}`
}

// 初始打开的窗口
function getBootWindows(): WindowState[] {
  return []
}

export const useWindowStore = defineStore('windows', () => {
  const windows = ref<WindowState[]>(getBootWindows())
  const activeWindowId = ref<string | null>(null)
  // 调度中心 / Mission Control
  const missionControlActive = ref(false)
  // Stage Manager 侧边小窗显示
  const stageManagerActive = ref(false)

  // 打开（非最小化、非关闭）的窗口
  const openWindows = computed(() =>
    windows.value.filter((w) => !w.closed && !w.minimized)
  )

  // 找到某 app 已打开的窗口（单例查找）
  function findWindowByApp(appId: string): WindowState | undefined {
    return windows.value.find((w) => w.appId === appId && !w.closed)
  }

  /** 创建或激活窗口 */
  function openWindow(opts: CreateWindowOptions): WindowState {
    const appDef = getAppById(opts.appId)
    // 单例应用：如果已存在未关闭的窗口，直接激活
    if (appDef?.singleton) {
      const existing = findWindowByApp(opts.appId)
      if (existing) {
        activateWindow(existing.id)
        // 如果最小化了就恢复
        if (existing.minimized) existing.minimized = false
        return existing
      }
    }

    const viewW = window.innerWidth
    const viewH = window.innerHeight - 24 // 减去菜单栏
    const defW = opts.width ?? appDef?.defaultWidth ?? 820
    const defH = opts.height ?? appDef?.defaultHeight ?? 560
    const w: WindowState = {
      id: genId(),
      appId: opts.appId,
      title: opts.title ?? appDef?.name ?? opts.appId,
      icon: opts.icon ?? appDef?.icon ?? 'finder',
      x: opts.x ?? Math.round((viewW - defW) / 2 + (Math.random() - 0.5) * 40),
      y: opts.y ?? Math.round((viewH - defH) / 2 - 20 + (Math.random() - 0.5) * 30),
      width: defW,
      height: defH,
      minWidth: opts.minWidth ?? appDef?.minWidth ?? 360,
      minHeight: opts.minHeight ?? appDef?.minHeight ?? 240,
      zIndex: ++zIndexCounter,
      minimized: false,
      maximized: false,
      fullscreen: false,
      closed: false,
      focused: true,
      resizable: opts.resizable ?? true,
      originRect: opts.originRect
    }
    // 其它窗口失焦
    windows.value.forEach((win) => {
      win.focused = false
    })
    windows.value.push(w)
    activeWindowId.value = w.id
    return w
  }

  /** 激活窗口（置顶） */
  function activateWindow(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w || w.closed) return
    windows.value.forEach((win) => {
      win.focused = win.id === id
    })
    w.zIndex = ++zIndexCounter
    w.minimized = false
    activeWindowId.value = id
  }

  /** 关闭窗口（软关闭） */
  function closeWindow(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    w.closing = true
    // 动画后真正关闭
    setTimeout(() => {
      w.closed = true
      w.closing = false
      if (activeWindowId.value === id) {
        // 找下一个激活
        const next = [...windows.value]
          .reverse()
          .find((x) => !x.closed && !x.minimized && x.id !== id)
        activeWindowId.value = next?.id ?? null
        if (next) next.focused = true
      }
    }, 300)
  }

  /** 最小化 */
  function minimizeWindow(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    w.minimized = true
    w.focused = false
    if (activeWindowId.value === id) {
      const next = [...windows.value]
        .reverse()
        .find((x) => !x.closed && !x.minimized && x.id !== id)
      activeWindowId.value = next?.id ?? null
      if (next) next.focused = true
    }
  }

  /** 最大化切换 */
  function toggleMaximize(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    if (w.maximized) {
      // 还原
      if (w.prev) {
        w.x = w.prev.x
        w.y = w.prev.y
        w.width = w.prev.width
        w.height = w.prev.height
      }
      w.maximized = false
    } else {
      w.prev = { x: w.x, y: w.y, width: w.width, height: w.height }
      w.x = 0
      w.y = 24 // 菜单栏
      w.width = window.innerWidth
      w.height = window.innerHeight - 24
      w.maximized = true
    }
  }

  /** 双击标题栏缩放（等同最大化） */
  function zoomWindow(id: string) {
    toggleMaximize(id)
  }

  /** 分屏：左半屏/右半屏/全屏 */
  function tileWindow(id: string, direction: 'left' | 'right' | 'full') {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    if (!w.prev || w.maximized === false) {
      w.prev = { x: w.x, y: w.y, width: w.width, height: w.height }
    }
    w.maximized = true
    w.y = 24
    if (direction === 'left') {
      w.x = 0
      w.width = Math.floor(window.innerWidth / 2)
      w.height = window.innerHeight - 24
    } else if (direction === 'right') {
      w.x = Math.ceil(window.innerWidth / 2)
      w.width = Math.floor(window.innerWidth / 2)
      w.height = window.innerHeight - 24
    } else {
      w.x = 0
      w.width = window.innerWidth
      w.height = window.innerHeight - 24
      w.fullscreen = true
    }
  }

  /** 移动窗口 */
  function moveWindow(id: string, x: number, y: number) {
    const w = windows.value.find((win) => win.id === id)
    if (!w || w.maximized) return
    w.x = x
    w.y = Math.max(24, y) // 不能拖到菜单栏上方
  }

  /** 调整大小 */
  function resizeWindow(
    id: string,
    patch: Partial<Pick<WindowState, 'x' | 'y' | 'width' | 'height'>>
  ) {
    const w = windows.value.find((win) => win.id === id)
    if (!w) return
    if (patch.width && patch.width < w.minWidth) patch.width = w.minWidth
    if (patch.height && patch.height < w.minHeight) patch.height = w.minHeight
    Object.assign(w, patch)
  }

  /** 更新窗口位置（用于拖拽动画） */
  function setWindowOrigin(
    id: string,
    rect: { x: number; y: number; size: number }
  ) {
    const w = windows.value.find((win) => win.id === id)
    if (w) w.originRect = rect
  }

  /** 调度中心 */
  function toggleMissionControl() {
    missionControlActive.value = !missionControlActive.value
  }

  function closeMissionControl(winId?: string) {
    missionControlActive.value = false
    if (winId) activateWindow(winId)
  }

  return {
    windows,
    activeWindowId,
    openWindows,
    missionControlActive,
    stageManagerActive,
    openWindow,
    activateWindow,
    closeWindow,
    minimizeWindow,
    toggleMaximize,
    zoomWindow,
    tileWindow,
    moveWindow,
    resizeWindow,
    setWindowOrigin,
    toggleMissionControl,
    closeMissionControl,
    findWindowByApp
  }
})
