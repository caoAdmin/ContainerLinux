/**
 * 系统设置 Store
 * 管理外观、壁纸、Dock、控制中心开关、Liquid Glass 透明度等
 * 支持 localStorage 持久化
 */
import { defineStore } from 'pinia'
import { ref, computed, watch } from 'vue'
import type {
  AppearanceMode,
  WallpaperType,
  DockPosition,
  SystemSettings
} from '@/types'

const STORAGE_KEY = 'macos27-settings'

// 默认设置
const defaultSettings: SystemSettings = {
  appearance: 'light',
  wallpaper: 'golden-gate-evening',
  glassOpacity: 0.5,
  hdrGlow: 0.6,
  dockSize: 56,
  dockMagnification: true,
  dockMagnificationLevel: 1.35,
  dockPosition: 'bottom',
  dockAutoHide: false,
  menubarAutoHide: false,
  wifiEnabled: true,
  bluetoothEnabled: true,
  airdropEnabled: false,
  focusEnabled: false,
  darkMode: false,
  brightness: 0.85,
  volume: 0.6
}

function loadSettings(): SystemSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) {
      return { ...defaultSettings, ...JSON.parse(raw) }
    }
  } catch {
    // ignore
  }
  return { ...defaultSettings }
}

export const useSystemStore = defineStore('system', () => {
  const settings = ref<SystemSettings>(loadSettings())

  /**
   * 持久化 + 样式同步。
   *
   * 性能要点：
   *  - `applyGlobalStyles` 立即执行（视觉反馈必须跟手），但内部只写**真正变化**的
   *    自定义属性。像 `--glass-opacity` 被 --menubar-bg / --dock-bg / 玻璃底衬等
   *    十几个派生变量引用，重复写一次就等于让全站玻璃面重算样式并重绘 ——
   *    拖亮度滑块时曾是 100ms+ 长帧的主因。
   *  - `localStorage.setItem` 是同步阻塞 API，去抖到 250ms 只写一次。
   */
  let saveTimer = 0
  const persist = (val: SystemSettings) => {
    window.clearTimeout(saveTimer)
    saveTimer = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(val))
      } catch {
        // ignore
      }
    }, 250)
  }

  watch(
    settings,
    (val) => {
      persist(val)
      applyGlobalStyles(val)
    },
    { deep: true, immediate: true }
  )

  if (typeof window !== 'undefined') {
    // 关页前把未落盘的设置补写一次，避免去抖窗口内丢配置
    window.addEventListener('beforeunload', () => {
      window.clearTimeout(saveTimer)
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(settings.value))
      } catch {
        // ignore
      }
    })
  }

  // 响应式外观（考虑 auto 模式根据系统偏好）
  const effectiveAppearance = computed<'light' | 'dark'>(() => {
    if (settings.value.appearance === 'auto') {
      if (typeof window !== 'undefined' && window.matchMedia) {
        return window.matchMedia('(prefers-color-scheme: dark)').matches
          ? 'dark'
          : 'light'
      }
      return 'light'
    }
    return settings.value.appearance === 'dark' || settings.value.darkMode
      ? 'dark'
      : 'light'
  })

  // 设置项变更方法
  function setAppearance(mode: AppearanceMode) {
    settings.value.appearance = mode
    if (mode !== 'auto') {
      settings.value.darkMode = mode === 'dark'
    }
  }

  function toggleDarkMode() {
    settings.value.darkMode = !settings.value.darkMode
    settings.value.appearance = settings.value.darkMode ? 'dark' : 'light'
  }

  function setWallpaper(wp: WallpaperType) {
    settings.value.wallpaper = wp
  }

  function setGlassOpacity(v: number) {
    settings.value.glassOpacity = Math.max(0, Math.min(1, v))
  }

  function setHdrGlow(v: number) {
    settings.value.hdrGlow = Math.max(0, Math.min(1, v))
  }

  function setDockSize(size: number) {
    settings.value.dockSize = Math.max(40, Math.min(76, size))
  }

  function setDockPosition(pos: DockPosition) {
    settings.value.dockPosition = pos
  }

  function toggle(key: keyof SystemSettings) {
    const cur = settings.value[key]
    if (typeof cur === 'boolean') {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      ;(settings.value as any)[key] = !cur
    }
  }

  function setBrightness(v: number) {
    settings.value.brightness = Math.max(0, Math.min(1, v))
  }

  function setVolume(v: number) {
    settings.value.volume = Math.max(0, Math.min(1, v))
  }

  function resetAll() {
    settings.value = { ...defaultSettings }
  }

  return {
    settings,
    effectiveAppearance,
    setAppearance,
    toggleDarkMode,
    setWallpaper,
    setGlassOpacity,
    setHdrGlow,
    setDockSize,
    setDockPosition,
    toggle,
    setBrightness,
    setVolume,
    resetAll
  }
})

// 将设置同步为 CSS 自定义属性
/** 上一次真正写入根节点的值：相同就不写，避免全站样式失效 */
const appliedVars = { glassOpacity: NaN as number, hdrGlow: NaN as number }
let appliedMode: 'light' | 'dark' | '' = ''
let appliedBrightness = NaN as number

function applyGlobalStyles(s: SystemSettings) {
  if (typeof document === 'undefined') return
  const root = document.documentElement

  // Liquid Glass 透明度（被大量派生变量引用，只在变化时写）
  if (s.glassOpacity !== appliedVars.glassOpacity) {
    appliedVars.glassOpacity = s.glassOpacity
    root.style.setProperty('--glass-opacity', String(s.glassOpacity))
  }
  // HDR 泛光
  if (s.hdrGlow !== appliedVars.hdrGlow) {
    appliedVars.hdrGlow = s.hdrGlow
    root.style.setProperty('--hdr-glow', String(s.hdrGlow))
  }

  // 亮度遮罩（只影响单个叠层，成本极低）
  if (s.brightness !== appliedBrightness) {
    appliedBrightness = s.brightness
    const brightnessOverlay = document.getElementById('brightness-overlay')
    if (brightnessOverlay) {
      const alpha = 1 - s.brightness
      brightnessOverlay.style.background = `rgba(0,0,0,${alpha * 0.5})`
    }
  }

  // 外观类名：值没变就不动 classList
  const mode: 'light' | 'dark' =
    s.appearance === 'auto'
      ? window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light'
      : s.appearance === 'dark' || s.darkMode
        ? 'dark'
        : 'light'
  if (mode !== appliedMode) {
    appliedMode = mode
    root.classList.remove('light', 'dark')
    root.classList.add(mode)
  }
}
