/**
 * 布局 / 分辨率自适应 Store
 *
 * 之前的做法是把 1920×1080 的设计稿整体缩放，结果是**比例被锁死**：
 * 屏幕比例一旦不是 16:9，就只能在两边/上下留黑边，界面并不会真的铺开。
 *
 * 现在默认用「自适应铺满」：画布尺寸直接等于视口尺寸，缩放恒为 1，
 * 各个部件用锚点（顶部居中 / 左上 / 右下…）定位，所以能真的填满任意比例。
 * 视口小到装不下最小可用布局（<1280×720）时也不留黑边：
 * 仍取等比缩放（不拉伸变形），但画布沿短边方向延展到正好铺满视口
 * （s = min(vw/1280, vh/720)，画布 = vw/s × vh/s，两个维度都不会小于最小可用值）。
 *
 * 其余三种模式保留为可选项（等比适应 / 等比铺满 / 拉伸铺满），
 * 它们仍以 1920×1080 设计稿为基准，适合需要「永远保持设计稿比例」的场景。
 */
import { computed, ref } from 'vue'
import { defineStore } from 'pinia'

export type FitMode = 'fluid' | 'contain' | 'cover' | 'stretch'

/** 设计稿尺寸（non-fluid 模式的基准画布） */
export const DESIGN_W = 1920
export const DESIGN_H = 1080
/** 小屏回落时的最小逻辑画布 */
export const MIN_W = 1280
export const MIN_H = 720

export const FIT_MODES: { id: FitMode; label: string; desc: string }[] = [
  { id: 'fluid', label: '自适应铺满', desc: '画布随屏幕尺寸变化，任意比例都能真正铺满（推荐）' },
  { id: 'contain', label: '等比适应', desc: '保持 16:9 设计稿完整可见，多余区域留黑边' },
  { id: 'cover', label: '等比铺满', desc: '保持 16:9 并铺满屏幕，会裁掉超出部分' },
  { id: 'stretch', label: '拉伸铺满', desc: '保持铺满但画面会被拉伸变形' }
]

export const useLayoutStore = defineStore('layout', () => {
  /** 当前视口（物理像素） */
  const vw = ref(DESIGN_W)
  const vh = ref(DESIGN_H)

  /** 适配模式 */
  const mode = ref<FitMode>('fluid')
  /** 右下角缩放角标 */
  const showBadge = ref(false)

  function sync() {
    if (typeof window === 'undefined') return
    vw.value = window.innerWidth
    vh.value = window.innerHeight
  }
  sync()
  if (typeof window !== 'undefined') {
    window.addEventListener('resize', sync)
    window.addEventListener('orientationchange', sync)
  }

  /** 视口是否小到需要回落缩放 */
  const needsScale = computed(() => vw.value < MIN_W || vh.value < MIN_H)

  /**
   * 逻辑画布尺寸：所有组件的坐标基准。
   * 回落缩放时画布 = vw/s × vh/s（s 取等比缩放系数），
   * 保证**正好铺满视口**（不留黑边）且两个维度都 ≥ 最小可用画布。
   * 例：手机横屏 1080×460 → s = 460/720 ≈ 0.64，画布 ≈ 1693×720，宽度方向自然延展。
   */
  const canvasW = computed(() => {
    if (mode.value !== 'fluid') return DESIGN_W
    if (!needsScale.value) return vw.value
    return Math.ceil(vw.value / scaleConst.value)
  })
  const canvasH = computed(() => {
    if (mode.value !== 'fluid') return DESIGN_H
    if (!needsScale.value) return vh.value
    return Math.ceil(vh.value / scaleConst.value)
  })

  /** 回落时的等比缩放系数：取 min 保证画布两个维度都不小于最小可用值 */
  const scaleConst = computed(() => Math.min(vw.value / MIN_W, vh.value / MIN_H))

  const scale = computed(() => {
    if (mode.value === 'fluid') {
      if (!needsScale.value) return { x: 1, y: 1 }
      const s = scaleConst.value
      return { x: s, y: s }
    }
    const sx = vw.value / DESIGN_W
    const sy = vh.value / DESIGN_H
    if (mode.value === 'stretch') return { x: sx, y: sy }
    const s = mode.value === 'cover' ? Math.max(sx, sy) : Math.min(sx, sy)
    return { x: s, y: s }
  })

  const scaleX = computed(() => scale.value.x)
  const scaleY = computed(() => scale.value.y)
  const zoom = computed(() => Math.round(scaleX.value * 100))

  /** 画布外层样式 */
  const canvasStyle = computed(() => ({
    width: canvasW.value + 'px',
    height: canvasH.value + 'px',
    transform: `scale(${scaleX.value}, ${scaleY.value})`
  }))

  /* ── 指针坐标换算：物理像素 → 逻辑像素 ── */
  function toLogicalDelta(dx: number, dy: number) {
    return { x: dx / scaleX.value, y: dy / scaleY.value }
  }
  function toLogical(clientX: number, clientY: number, canvasRect?: DOMRect) {
    if (!canvasRect) return { x: clientX / scaleX.value, y: clientY / scaleY.value }
    return {
      x: (clientX - canvasRect.left) / scaleX.value,
      y: (clientY - canvasRect.top) / scaleY.value
    }
  }

  /** 是否处于回落缩放状态 */
  const isScaled = computed(() => scaleX.value !== 1)
  const hasLetterbox = computed(() => isScaled.value)

  const modeLabel = computed(() => FIT_MODES.find((m) => m.id === mode.value)?.label ?? '自适应铺满')

  const fitSummary = computed(() => {
    if (mode.value === 'fluid') {
      return needsScale.value
        ? `自适应（视口偏小，已等比缩放至 ${zoom.value}% 并延展铺满，无黑边）`
        : `自适应铺满（1:1 使用 ${vw.value}×${vh.value}）`
    }
    if (mode.value === 'stretch') return '非等比拉伸填满'
    if (mode.value === 'cover') return '等比铺满并裁切'
    return hasLetterbox.value ? '等比适应（留黑边）' : '等比适应（正好铺满）'
  })

  return {
    vw,
    vh,
    mode,
    showBadge,
    needsScale,
    canvasW,
    canvasH,
    scale,
    scaleX,
    scaleY,
    zoom,
    canvasStyle,
    isScaled,
    hasLetterbox,
    modeLabel,
    fitSummary,
    toLogicalDelta,
    toLogical,
    sync
  }
})
