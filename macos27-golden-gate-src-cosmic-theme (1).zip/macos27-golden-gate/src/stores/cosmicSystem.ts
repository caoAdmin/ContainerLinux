/**
 * COSMIC 系统状态 Store
 * 承载「COSMIC Settings」各分页的真实状态：网络 / 蓝牙 / 声音 / 电源 / 显示 /
 * 输入设备 / 区域语言 / 用户 / 通知 / 默认应用 / 窗口管理 / 启动项 /
 * 辅助功能 / 时间 / 系统更新 / 固件 / 桌面 / 面板 / Dock。
 */
import { defineStore } from 'pinia'
import { reactive, ref } from 'vue'
import type { IconThemeId } from '@/types'

export interface WifiNetwork {
  ssid: string
  strength: number
  secure: boolean
  known: boolean
}
export interface BtDevice {
  name: string
  mac: string
  icon: string
  connected: boolean
  paired: boolean
}

export const useCosmicSystemStore = defineStore('cosmicSystem', () => {
  /* ── 网络 ── */
  const wifi = reactive({
    enabled: true,
    connected: 'Pop!_OS-5G',
    ip: '192.168.1.42',
    mac: 'A4:5E:60:C1:2D:8F',
    networks: [
      { ssid: 'Pop!_OS-5G', strength: 92, secure: true, known: true },
      { ssid: 'COSMIC-Lab', strength: 74, secure: true, known: true },
      { ssid: 'CoffeeHouse_Free', strength: 48, secure: false, known: false },
      { ssid: 'TP-LINK_9F2A', strength: 33, secure: true, known: false },
      { ssid: 'ChinaNet-xKpQ', strength: 18, secure: true, known: false }
    ] as WifiNetwork[]
  })
  const wired = reactive({ connected: true, name: '以太网', speed: '1000 Mb/s', ip: '192.168.1.108' })
  const proxy = reactive({ mode: 'none' as 'none' | 'auto' | 'manual', host: '', port: 8080 })
  const vpn = reactive({ enabled: false, profiles: ['公司 VPN', 'WireGuard-Home'] })

  /* ── 蓝牙 ── */
  const bt = reactive({
    enabled: true,
    scanning: false,
    devices: [
      { name: 'WH-1000XM5', mac: 'AC:80:0A:3F:11:22', icon: 'ri-headphone-fill', connected: true, paired: true },
      { name: 'MX Master 3S', mac: 'B0:12:9F:44:7A:01', icon: 'ri-mouse-fill', connected: true, paired: true },
      { name: 'Keychron K3', mac: 'C2:44:1A:90:33:B7', icon: 'ri-keyboard-fill', connected: false, paired: true },
      { name: 'Pixel Buds Pro', mac: '9C:11:70:22:8E:5F', icon: 'ri-headphone-line', connected: false, paired: false }
    ] as BtDevice[]
  })

  /* ── 声音 ── */
  const sound = reactive({
    outputVolume: 68,
    inputVolume: 80,
    alertVolume: 55,
    muted: false,
    overamplify: false,
    sink: '内置扬声器 (Radeon HD Audio)',
    source: '内置麦克风',
    outputLevel: 0.62,
    inputLevel: 0.18
  })

  /* ── 电源 ── */
  const power = reactive({
    mode: 'balanced' as 'performance' | 'balanced' | 'saver',
    battery: 76,
    charging: false,
    screenOffMin: 10,
    suspendMin: 30,
    showPercent: true,
    dimOnBattery: true
  })

  /* ── 显示 ── */
  const display = reactive({
    brightness: 78,
    resolution: '1920 × 1080',
    refreshRate: '60.00 Hz',
    scale: '100%',
    orientation: '横向',
    vrr: false,
    nightLight: false,
    nightStart: '21:00',
    nightEnd: '07:00',
    nightTemp: 3800,
    hdr: false,
    monitors: [
      { name: 'eDP-1 内置显示器', size: '14.0"', res: '1920 × 1080', refresh: '60.00 Hz', primary: true },
      { name: 'HDMI-A-1 DELL U2723QE', size: '27.0"', res: '3840 × 2160', refresh: '60.00 Hz', primary: false }
    ]
  })

  /* ── 输入设备 ── */
  const mouse = reactive({
    speed: 0.5,
    accel: true,
    naturalScroll: false,
    primaryButton: '左键',
    doubleClick: 400,
    scrollSpeed: 1,
    buttons: [
      { key: '左键', action: '主点击' },
      { key: '中键', action: '中键点击' },
      { key: '右键', action: '次点击' },
      { key: '后退键', action: '返回' },
      { key: '前进键', action: '前进' }
    ]
  })
  const touchpad = reactive({ tapToClick: true, naturalScroll: true, speed: 0.5, twoFinger: true, disableWhileTyping: true })
  const keyboard = reactive({
    repeatDelay: 250,
    repeatRate: 30,
    layouts: ['英语 (US)', '中文 (拼音)'],
    composeKey: '关闭',
    capsLockBehavior: '大写锁定',
    backlight: 60,
    osk: false,
    numLockOnBoot: true
  })
  const tablet = reactive({
    enabled: true,
    name: 'Wacom Intuos Pro M',
    devices: [
      { name: 'Wacom Intuos Pro M', kind: '数位板', connected: true },
      { name: 'Wacom Pro Pen 2', kind: '笔', connected: true },
      { name: 'Wacom ExpressKey Remote', kind: '遥控器', connected: false }
    ],
    mode: 'absolute' as 'absolute' | 'relative',
    mapping: 'full' as 'full' | 'monitor' | 'custom',
    targetMonitor: 'eDP-1 内置显示器',
    area: '100% × 100%',
    pressureCurve: 50,
    penButton1: '中键点击',
    penButton2: '右键点击',
    touchRing: true,
    expressKeys: 8
  })

  /* ── 区域与语言 ── */
  const region = reactive({
    language: '简体中文',
    format: '中国 (zh-CN)',
    timezone: 'Asia/Shanghai (GMT+8)',
    firstDay: '星期一',
    inputSources: ['中文 (拼音)', '英语 (US)'],
    spellcheck: true
  })

  /* ── 用户 ── */
  const users = reactive({
    list: [
      { name: 'cosmic', full: 'COSMIC 用户', type: '管理员', online: true },
      { name: 'xibei', full: 'Xibei', type: '标准用户', online: false }
    ],
    autoLogin: true,
    lastLogin: '今天 12:41',
    fingerprint: true
  })

  /* ── 通知 ── */
  const notif = reactive({
    dnd: false,
    dndStart: '22:00',
    dndEnd: '07:00',
    banner: true,
    onLockScreen: true,
    sounds: true,
    apps: [
      { name: 'COSMIC Store', icon: 'ri-store-3-fill', on: true },
      { name: 'COSMIC Player', icon: 'ri-play-circle-fill', on: true },
      { name: 'COSMIC Terminal', icon: 'ri-terminal-box-fill', on: false },
      { name: 'COSMIC Files', icon: 'ri-folders-fill', on: true },
      { name: 'COSMIC Edit', icon: 'ri-file-edit-fill', on: false }
    ]
  })

  /* ── 默认应用 ── */
  const defaults = reactive({
    browser: 'COSMIC Browser',
    mail: 'Thunderbird',
    files: 'COSMIC Files',
    image: 'COSMIC Viewer',
    music: 'COSMIC Player',
    video: 'COSMIC Player',
    terminal: 'COSMIC Terminal',
    textEditor: 'COSMIC Edit'
  })

  /* ── 窗口管理 ── */
  const windows = reactive({
    autoTile: false,
    tileMode: 'grid' as 'grid' | 'rows' | 'columns',
    focusFollowsMouse: false,
    gaps: 8,
    snapping: true,
    edgeResistance: 30,
    buttonPosition: 'right' as 'left' | 'right'
  })

  /* ── 启动应用程序 ── */
  const startup = reactive({
    items: [
      { name: 'COSMIC Panel', cmd: 'cosmic-panel', on: true, system: true },
      { name: 'Clipman 剪贴板', cmd: 'wl-clip-persist', on: true, system: false },
      { name: 'Flameshot 截图', cmd: 'flameshot', on: false, system: false },
      { name: 'Syncthing', cmd: 'syncthing', on: true, system: false }
    ]
  })

  /* ── 辅助功能 ── */
  const a11y = reactive({
    largeText: false,
    highContrast: false,
    reduceMotion: false,
    screenReader: false,
    magnifier: false,
    stickyKeys: false,
    cursorSize: 24,
    visualAlerts: false,
    oskEnabled: false,
    oskAutoShow: true,
    magnifierZoom: 2
  })

  /* ── 时间与日期 ── */
  const time = reactive({
    auto: true,
    timezone: 'Asia/Shanghai',
    format: '24h' as '24h' | '12h',
    // 默认精确到分；需要秒可在「时间与日期」里打开
    showSeconds: false,
    showWeekNumber: false
  })

  /* ── 系统更新 ── */
  const updates = reactive({
    current: '1.0.0',
    channel: 'stable' as 'stable' | 'beta' | 'staging',
    autoUpdate: true,
    autoDownload: true,
    checking: false,
    progress: 0,
    lastCheck: '今天 12:30',
    available: [
      { name: 'cosmic-comp', from: '1.0.0~1758000000~24.04', to: '1.0.0~1758800000~24.04' },
      { name: 'cosmic-files', from: '1.0.0~1757900000~24.04', to: '1.0.0~1758700000~24.04' },
      { name: 'linux-image-generic', from: '6.12.0-1012', to: '6.12.0-1018' }
    ],
    history: [
      { date: '今天 12:30', text: '已安装 4 个更新' },
      { date: '昨天 09:12', text: '已安装 12 个更新' },
      { date: '10月 08日', text: '已安装 7 个更新' }
    ]
  })

  /* ── 固件 ── */
  const firmware = reactive({
    devices: [
      { name: 'System Firmware (UEFI)', vendor: 'LENOVO', current: '1.62', latest: '1.68', update: true },
      { name: 'NVMe SSD Firmware', vendor: 'Samsung', current: '4B2QJXD7', latest: '4B2QJXD7', update: false },
      { name: 'ThinkPad 触控板', vendor: 'Synaptics', current: '1.0.4', latest: '1.0.4', update: false }
    ]
  })

  /* ── 隐私 ── */
  const privacy = reactive({
    location: false,
    camera: true,
    microphone: true,
    screenRecording: false,
    fileHistory: true,
    crashReports: true
  })

  /* ── 桌面 ── */
  const desktop = reactive({
    wallpaper: 'nebula',
    fill: '填充',
    iconSize: 48,
    showIcons: true,
    workspaces: 4,
    workspaceLayout: 'vertical' as 'vertical' | 'horizontal',
    hotCorners: false
  })

  /* ── 面板 ── */
  const panel = reactive({
    position: 'top' as 'top' | 'bottom' | 'left' | 'right',
    size: 'M' as 'S' | 'M' | 'L',
    autoHide: false,
    transparency: 0.9,
    plugins: [
      { id: 'workspaces', label: '工作区', icon: 'ri-layout-grid-line', on: true },
      { id: 'appbutton', label: '应用启动器', icon: 'ri-apps-2-line', on: true },
      { id: 'focused', label: '当前窗口标题', icon: 'ri-window-line', on: true },
      { id: 'tray', label: '系统托盘', icon: 'ri-inbox-unarchive-line', on: true },
      { id: 'network', label: '网络', icon: 'ri-wifi-line', on: true },
      { id: 'bluetooth', label: '蓝牙', icon: 'ri-bluetooth-line', on: false },
      { id: 'sound', label: '音量', icon: 'ri-volume-up-line', on: true },
      { id: 'battery', label: '电池', icon: 'ri-battery-line', on: true },
      { id: 'time', label: '时间', icon: 'ri-time-line', on: true },
      { id: 'power', label: '电源菜单', icon: 'ri-shut-down-line', on: true }
    ]
  })

  /* ── 启动器 / 应用 ── */
  const applications = reactive({
    launcherSearch: true,
    launcherCategories: true,
    rememberRecent: true,
    recentCount: 8
  })

  /* ── 应用图标主题 / 外观扩展 ── */
  const appearance = reactive({
    /** 图标主题：默认 Crule Dark，可切回 Crule 浅色或之前的 Linuxfx 11 位图包 */
    iconTheme: 'fluent' as IconThemeId,
    cursorTheme: 'COSMIC',
    fontScale: 1,
    transparency: 0.88,
    windowShadow: true
  })

  /* ── 壁纸（独立分页）── */
  const wallpapers = reactive({
    current: 'city',
    mode: 'image' as 'image' | 'solid' | 'gradient',
    solidColor: '#2b1b4d',
    gradientFrom: '#7b5cf0',
    gradientTo: '#e45b9c',
    fill: '填充',
    blur: 0,
    darken: 0,
    onAll: true,
    perMonitor: ['nebula', 'ocean'],
    accentColor: '#7B5CF0',
    items: [
      { id: 'nebula', name: 'COSMIC 星云', tone: '#6b3fa0' },
      { id: 'ubuntu', name: 'Pop!_OS 橙', tone: '#7a2547' },
      { id: 'ocean', name: '深海', tone: '#1c5c8a' },
      { id: 'forest', name: '森林', tone: '#2c6b45' },
      { id: 'sunset', name: '落日', tone: '#a83a56' },
      { id: 'mono', name: '石墨', tone: '#33333a' },
      { id: 'aurora', name: '极光', tone: '#1f7a6b' },
      { id: 'flare', name: '耀斑', tone: '#c9622a' },
      { id: 'violet', name: '紫罗兰', tone: '#5b3fa8' },
      { id: 'ice', name: '冰原', tone: '#4a7fa8' },
      { id: 'ember', name: '余烬', tone: '#8c3b2a' },
      { id: 'void', name: '虚空', tone: '#1d1d22' },
      { id: 'prism', name: '棱镜网格', tone: '#2de0c8' },
      { id: 'city', name: '城市暮色', tone: '#1b6fc4' }
    ]
  })

  /* ── 打印机 ── */
  const printers = reactive({
    list: [
      { name: 'HP LaserJet M404dn', uri: 'ipp://192.168.1.20/ipp/print', state: '空闲', default: true, driver: 'HP LaserJet 系列 (无驱动)' },
      { name: 'Brother DCP-L2550DW', uri: 'ipp://192.168.1.31/ipp/print', state: '空闲', default: false, driver: 'Brother 兼容驱动' },
      { name: '导出为 PDF', uri: 'cups-pdf:/', state: '就绪', default: false, driver: 'CUPS-PDF' }
    ],
    jobs: [
      { id: 142, name: '设计稿-终版.pdf', printer: 'HP LaserJet M404dn', state: '打印中', pages: '3 / 12' },
      { id: 139, name: '发票-10月.pdf', printer: 'Brother DCP-L2550DW', state: '已完成', pages: '1 / 1' }
    ]
  })

  /* ── 键盘快捷键 ── */
  const shortcuts = reactive({
    groups: [
      {
        name: '启动器与面板',
        items: [
          { label: '打开应用库', keys: ['Super'], custom: false },
          { label: '打开启动器', keys: ['Super', 'Enter'], custom: false },
          { label: '切换工作区视图', keys: ['Super', 'W'], custom: false },
          { label: '打开通知中心', keys: ['Super', 'N'], custom: false }
        ]
      },
      {
        name: '窗口',
        items: [
          { label: '关闭窗口', keys: ['Super', 'Q'], custom: false },
          { label: '最大化 / 还原', keys: ['Super', 'M'], custom: false },
          { label: '切换平铺模式', keys: ['Super', 'T'], custom: false },
          { label: '窗口左移', keys: ['Super', '←'], custom: false },
          { label: '窗口右移', keys: ['Super', '→'], custom: false },
          { label: '切换到下一个窗口', keys: ['Alt', 'Tab'], custom: false }
        ]
      },
      {
        name: '工作区',
        items: [
          { label: '上一个工作区', keys: ['Super', 'Ctrl', '↑'], custom: false },
          { label: '下一个工作区', keys: ['Super', 'Ctrl', '↓'], custom: false },
          { label: '把窗口移到上一屏', keys: ['Super', 'Shift', 'Ctrl', '↑'], custom: true }
        ]
      },
      {
        name: '系统',
        items: [
          { label: '打开终端', keys: ['Super', 'T'], custom: false },
          { label: '打开设置', keys: ['Super', 'S'], custom: false },
          { label: '锁屏', keys: ['Super', 'Esc'], custom: false },
          { label: '截图（区域）', keys: ['PrtSc'], custom: false },
          { label: '截图（整屏）', keys: ['Shift', 'PrtSc'], custom: false }
        ]
      }
    ],
    recording: null as string | null
  })

  /* ── 每个应用的音量 ── */
  const soundApps = reactive({
    apps: [
      { name: 'COSMIC Player', icon: 'ri-play-circle-fill', volume: 82, muted: false, route: '内置扬声器' },
      { name: 'Firefox', icon: 'ri-firefox-fill', volume: 64, muted: false, route: '内置扬声器' },
      { name: 'COSMIC Store', icon: 'ri-store-3-fill', volume: 40, muted: true, route: '内置扬声器' },
      { name: 'Thunderbird', icon: 'ri-mail-line', volume: 55, muted: false, route: 'WH-1000XM5' },
      { name: 'COSMIC Screenshot', icon: 'ri-screenshot-2-fill', volume: 70, muted: false, route: '内置扬声器' }
    ]
  })

  /* ── 工作区 ── */
  const workspaces = reactive({
    count: 4,
    layout: 'vertical' as 'vertical' | 'horizontal',
    dynamic: false,
    wrapAround: true,
    switchOnDrag: true,
    labels: ['主界面', '开发', '娱乐', '临时'],
    showLabels: false
  })

  /* ── 旧版（X11）应用 ── */
  const legacy = reactive({
    xwaylandEnabled: true,
    items: [
      { name: 'GIMP', cmd: 'gimp', scale: '自动', enabled: true },
      { name: 'Steam', cmd: 'steam', scale: '1.25x', enabled: false },
      { name: 'JetBrains Toolbox', cmd: 'jetbrains-toolbox', scale: '自动', enabled: true },
      { name: '旧版 WPS Office', cmd: 'wps', scale: '1.5x', enabled: false }
    ],
    defaultScale: '自动' as '自动' | '1.0x' | '1.25x' | '1.5x' | '2.0x'
  })

  /* ── 存储（Dock 状态卡片与 Files 侧栏共用同一份数据）── */
  const storage = reactive({
    disk1: { label: 'Disk 1', totalGB: 512, usedGB: 215, mount: '/' },
    disk2: { label: 'Disk 2', totalGB: 1024, usedGB: 328, mount: '/mnt/data' }
  })

  const checkedAt = ref('今天 12:30')

  return {
    wifi, wired, proxy, vpn, bt, sound, power, display,
    mouse, touchpad, keyboard, tablet, region, users, notif, defaults,
    windows, startup, a11y, time, updates, firmware, privacy,
    desktop, panel, applications, appearance,
    wallpapers, printers, shortcuts, soundApps, workspaces, legacy,
    storage,
    checkedAt
  }
})
