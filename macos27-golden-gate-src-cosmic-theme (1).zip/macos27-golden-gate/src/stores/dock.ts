/**
 * Dock Store
 * 管理 Dock 图标列表、运行状态、排序、拖拽
 */
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { DockItem } from '@/types'
import { allApps } from '@/utils/appRegistry'

const STORAGE_KEY = 'macos27-dock'

// 默认 Dock 图标顺序（id 列表）
const DEFAULT_DOCK: Array<{ appId: string; persistent: boolean }> = [
  { appId: 'finder', persistent: true },
  { appId: 'launchpad', persistent: true },
  { appId: 'safari', persistent: true },
  { appId: 'mail', persistent: true },
  { appId: 'messages', persistent: true },
  { appId: 'maps', persistent: true },
  { appId: 'photos', persistent: true },
  { appId: 'music', persistent: true },
  { appId: 'calendar', persistent: true },
  { appId: 'notes', persistent: true },
  { appId: 'settings', persistent: true },
  // 分隔符
  { appId: 'divider', persistent: true },
  { appId: 'trash', persistent: true }
]

function loadDock(): DockItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) {
      const saved = JSON.parse(raw) as DockItem[]
      if (Array.isArray(saved) && saved.length) return saved
    }
  } catch {
    // ignore
  }
  return DEFAULT_DOCK.map((d, idx) => {
    if (d.appId === 'divider') {
      return {
        id: `dock-divider-${idx}`,
        appId: 'divider',
        name: '',
        icon: 'divider',
        isPersistent: true,
        isRunning: false
      }
    }
    const app = allApps.find((a) => a.id === d.appId)
    return {
      id: `dock-${d.appId}-${idx}`,
      appId: d.appId,
      name: app?.name ?? d.appId,
      icon: app?.icon ?? d.appId,
      isPersistent: d.persistent,
      isRunning: false
    }
  })
}

export const useDockStore = defineStore('dock', () => {
  const items = ref<DockItem[]>(loadDock())
  const mouseOverItem = ref<string | null>(null)
  const mousePos = ref<{ x: number; y: number } | null>(null)
  const hidden = ref(false)

  // 持久化
  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items.value))
    } catch {
      // ignore
    }
  }

  const persistentItems = computed(() =>
    items.value.filter((i) => i.appId !== 'divider' && i.appId !== 'trash')
  )

  const runningItems = computed(() => items.value.filter((i) => i.isRunning))

  function setRunning(appId: string, running: boolean) {
    const item = items.value.find((i) => i.appId === appId)
    if (item) {
      item.isRunning = running
      persist()
    } else if (running) {
      // 非常驻运行中 App：插入到废纸篓前
      const app = allApps.find((a) => a.id === appId)
      if (app) {
        const trashIdx = items.value.findIndex((i) => i.appId === 'trash')
        const newItem: DockItem = {
          id: `dock-${appId}-${Date.now()}`,
          appId,
          name: app.name,
          icon: app.icon,
          isPersistent: false,
          isRunning: true
        }
        items.value.splice(trashIdx, 0, newItem)
        persist()
      }
    }
  }

  function removeFromDock(appId: string) {
    const idx = items.value.findIndex((i) => i.appId === appId)
    if (idx > -1) {
      const item = items.value[idx]
      if (item.isPersistent && !item.isRunning) {
        items.value.splice(idx, 1)
        persist()
      } else if (!item.isPersistent) {
        items.value.splice(idx, 1)
        persist()
      }
    }
  }

  function reorder(fromIdx: number, toIdx: number) {
    if (fromIdx === toIdx) return
    const [moved] = items.value.splice(fromIdx, 1)
    items.value.splice(toIdx, 0, moved)
    persist()
  }

  function setMouseOver(id: string | null) {
    mouseOverItem.value = id
  }

  function setMousePos(x: number, y: number) {
    mousePos.value = { x, y }
  }

  function toggleAutoHide(force?: boolean) {
    hidden.value = force ?? !hidden.value
  }

  function getSeparatorIndex(): number {
    return items.value.findIndex((i) => i.appId === 'divider')
  }

  return {
    items,
    mouseOverItem,
    mousePos,
    hidden,
    persistentItems,
    runningItems,
    setRunning,
    removeFromDock,
    reorder,
    setMouseOver,
    setMousePos,
    toggleAutoHide,
    getSeparatorIndex
  }
})
