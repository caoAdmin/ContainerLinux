/**
 * CT AI 状态（隔离层）
 *
 * 供「小C」(ct-claw) 应用的交互演示使用，对应《CTclaw_CTAI_独立摘录_D40.md》§12。
 *
 * ⚠️ 边界（三条红线 / §12.3）：
 *  1. 这里只保存「演示态」，不是真的常驻 AI。~10MB 调度外壳 SHELL_MB 恒在，
 *     ~400MB 模型进程按需加载，两者严格区分；released 表示「模型进程已释放」。
 *  2. 只有 local / ct-selfhosted 档才是「完全离线」；任何云端档的隐私文案
 *     必须是「数据将发送至 <provider>」，不得笼统写成不联网。
 *  3. 网页壳只能演示交互契约，不代表 D33/D38 已落地。
 *
 * ⚠️ 与信息岛（islandHub）的关系（§12.4）：
 *  - 本 store 是 CT AI 状态的唯一来源；只**单向**调用 islandHub 的
 *    syncCtMirror / pushHint / say 做「状态镜像 + 进度推送」。
 *  - 绝不写 islandHub.quotas —— 那是 Codex/Claude 等第三方订阅额度模型，
 *    与「大馒头 / 小馒头」子任务 worker 是两套语义，§12.2#9 明令禁止复用。
 */
import { computed, reactive, ref } from 'vue'
import { defineStore } from 'pinia'
import { useIslandHubStore } from './islandHub'

export type CtPhase = 'idle' | 'loading' | 'ready' | 'deep' | 'released'
export type CtTier = 'local' | 'ct-selfhosted' | 'glm-flash' | 'byok' | 'free-web'
/** 唤醒对话框里的两个本地模型（§2.2 模型规格）：0.6B 轻量 / 1.5B 深度。
 *  Agent 不是模型，而是工作模式（panelAgent）——两种模型下都能跑 Agent。 */
export type CtPanelMode = 'chat' | 'deep'

export interface CtAgentTask {
  id: number
  name: string
  parent: string
  progress: number
  state: 'running' | 'done' | 'canceled'
  origin: string
}

/** ~10MB 调度外壳：常驻监听 RDBus；与按需加载的模型进程不是一回事 */
export const CT_SHELL_MB = 10

/** Agent 工作台提示条的「永久关闭」偏好（本次关闭不落盘，只存内存） */
const AGENT_HINT_PREF_KEY = 'cosmic.ctai.agentHint.v1'
function loadAgentHintForever(): boolean {
  try {
    const raw = localStorage.getItem(AGENT_HINT_PREF_KEY)
    if (!raw) return false
    return (JSON.parse(raw) as { forever?: boolean }).forever === true
  } catch {
    return false
  }
}
function saveAgentHintForever() {
  try {
    localStorage.setItem(AGENT_HINT_PREF_KEY, JSON.stringify({ forever: true }))
  } catch {
    /* 隐私模式下忽略 */
  }
}

const MEM: Record<CtPhase, number> = {
  idle: 0,
  loading: 40,
  ready: 400,
  deep: 1536,
  released: 0
}

/** 五层路由的隐私去向：只有 system / 自建是本地 */
const TIER_PROVIDER: Record<CtTier, string> = {
  local: '本地 llama.cpp',
  'ct-selfhosted': 'CT 自有服务器',
  'glm-flash': '智谱 GLM',
  byok: '用户自填 endpoint',
  'free-web': '逆向网页（默认关闭）'
}
const LOCAL_TIERS: CtTier[] = ['local', 'ct-selfhosted']

let taskSeq = 0

export const useCtAIStore = defineStore('ctai', () => defineCtStore())

function defineCtStore() {
  const phase = ref<CtPhase>('released')
  /** loading 阶段的动态内存（爬升动画覆盖静态值） */
  const loadingBoost = ref(0)
  const memMB = computed(() => (phase.value === 'loading' ? loadingBoost.value : MEM[phase.value]))
  const tier = ref<CtTier>('local')
  const tierLabel = computed(() => TIER_PROVIDER[tier.value])
  const isLocalTier = computed(() => LOCAL_TIERS.includes(tier.value))
  const privacyText = computed(() =>
    isLocalTier.value
      ? '完全离线 · 数据不出本机'
      : `数据将发送至 ${tierLabel.value}`
  )

  const importState = reactive({
    endpoint: '',
    key: '',
    status: 'idle' as 'idle' | 'ok' | 'no_key'
  })

  const tasks = ref<CtAgentTask[]>([])
  const runningCount = computed(() => tasks.value.filter((t) => t.state === 'running').length)
  const needsAttention = computed(() => tasks.value.some((t) => t.state === 'canceled'))

  const wake = reactive({ active: false, progress: 0 })
  const optInAIHost = ref(false)

  /* ── 底部唤醒对话框（长按空格 1s 弹出，替代 Dock 位置）── */
  const panelOpen = ref(false)
  const panelMode = ref<CtPanelMode>('chat')
  /** 工作模式：对话(false) / Agent(true)，与模型正交（Agent 用的是当前选中的 chat/deep 模型） */
  const panelAgent = ref(false)
  const panelInput = ref('')
  const panelBusy = ref(false)
  /** 智能搜索开关（云端档）：命中后回答会带「已检索公开网页」标注 */
  const panelSearch = ref(false)
  interface PanelMsg { role: 'bot' | 'me'; text: string; steps?: string[] }
  const panelMsgs = ref<PanelMsg[]>([
    { role: 'bot', text: '我是 CTclaw —— 零常驻系统智慧助手。轻量对话走本地 Qwen3-0.6B（约 400MB），用完即释放。' }
  ])

  /* ── Agent 工作台提示条 + 右侧侧栏（增量视图，不搬走底部对话框）── */
  /** 侧栏开合 */
  const panelAgentSidebarOpen = ref(false)
  /** 工作台形态：false = 接管模式（包围屏幕、左缘外展翼、右侧贴边），true = 后台模式（悬浮卡片、四角圆角、不贴边） */
  const agentFloat = ref(false)
  /** 本次唤醒会话内是否关闭了提示条（每次 openPanel 重置） */
  const hintDismissedThisSession = ref(false)
  /** 永久关闭（落 localStorage，刷新后仍生效） */
  const hintDismissedForever = ref(loadAgentHintForever())
  /** 提示条显示条件：仅 Agent 工作模式、未被本次/永久关闭 */
  const showAgentHint = computed(
    () => panelAgent.value && !hintDismissedThisSession.value && !hintDismissedForever.value
  )
  /** 派活记录（大馒头接单 / 里程碑 / 终态），侧栏倒序展示 */
  const agentLog = ref<Array<{ time: string; text: string }>>([])
  function logAgent(text: string) {
    agentLog.value.push({
      time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
      text
    })
  }

  /** 轻量的本地规则引擎：按关键词命中文档知识，纯前端演示，不代表模型推理 */
  function panelReply(q: string, mode: CtPanelMode): PanelMsg {
    const s = q.toLowerCase()
    const hit = (...ks: string[]) => ks.some((k) => s.includes(k))
    if (hit('内存', '占用', 'mb', '省电')) {
      return { role: 'bot', text: `当前档位「${tierLabel.value}」· 模型进程 ${memMB.value}MB；~10MB 调度外壳常驻监听 RDBus，关闭面板即释放模型进程。${mode === 'deep' ? '深度模式按需切 Qwen3-1.5B（1.5GB）。' : ''}` }
    }
    if (hit('档位', '路由', '模型', '离线', '隐私', '联网', '云端')) {
      return { role: 'bot', text: `五层路由：本地 llama.cpp → CT 自建 → 智谱 GLM → BYOK → 免费网页（默认关闭）。当前「${tierLabel.value}」：${privacyText.value}。` }
    }
    if (hit('蜂群', '节点', 'p2p', 'swarm')) {
      return { role: 'bot', text: '蜂群由 ct_swarmd（mDNS + QUIC）组网：局域网设备自动组 P2P 计算池，AI 推理 / 编译 / 渲染自动拆分，节点离线任务自动迁移。' }
    }
    if (hit('回滚', '快照', '基线')) {
      return { role: 'bot', text: '快照回滚走系统快照子系统：选择时间点 → 校验完整性 → 原子切换 Btrfs 子卷。真实执行需在「系统快照」应用内确认，这里只演示引导。' }
    }
    if (hit('唤醒', '长按', '空格', '手势')) {
      return { role: 'bot', text: '全局唤醒链在合成器层捕获「长按 Space 1s」，查焦点 surface 是否处于文本输入态（是则不放行），经 RDBus 回调拉起本面板。' }
    }
    if (hit('技能', 'skill', 'risk', '沙箱')) {
      return { role: 'bot', text: '技能系统 102 项，tier 四色徽章；触发分 @技能名 / /指令 / 语义匹配；risk low·mid·high 三档确认，ZeroClaw fork 的 fail-closed 沙箱统一兜底。' }
    }
    if (hit('agent', '任务', '大馒头', '小馒头', '分解', '执行')) {
      return { role: 'bot', text: '大馒头是调度主脑，分裂出小馒头（子任务 worker ×N），经虚拟 pointer + virtual-keyboard 把动作注入目标窗口，进度经 RDBus 推信息岛，不阻塞你。打开上方「Agent」开关即可演示，它用的是当前选中的同一个模型。' }
    }
    if (hit('内核', 'kernel', '进程')) {
      return { role: 'bot', text: 'CT-Kernel 负责零常驻调度：P0 懒启动，冷启静置 PSS ≤750MB@1080p。CTclaw 严格按需加载，用完即走（§51.2 标杆）。' }
    }
    if (hit('你好', 'hi', 'hello', '你是谁')) {
      return { role: 'bot', text: '你好，我是「小C」CTclaw。零常驻、分层路由、技能系统、Agent 底座 —— 你想了解哪一块？' }
    }
    if (mode === 'deep') {
      return {
        role: 'bot',
        text: `已用深度模型（Qwen3-1.5B · 演示）分析「${q}」：本原型是 macOS/COSMIC 风格的交互演示，问题命中本地文档知识库，未联网。`,
        steps: ['解析问题意图 → 匹配文档实体', '检索本地 CT AI 知识片段', '生成回答 · 全程本地（local 档）']
      }
    }
    return { role: 'bot', text: `收到「${q}」。我可以回答模式 / 内存 / 蜂群 / 快照 / 唤醒 / 技能 / Agent / 内核，或打开「Agent」开关演示大馒头派活。当前档位「${tierLabel.value}」· ${privacyText.value}。` }
  }

  /* ── 计时器句柄：统一清理，避免关窗残留 ── */
  let loadTimer = 0
  let agentTimer = 0
  let wakeTimer = 0
  let panelTimer = 0

  function hub() {
    return useIslandHubStore()
  }

  /** 单向镜像到信息岛：只写 agents 中 id==='ctclaw' 的那一行，不碰 quotas */
  function syncMirror() {
    const stateMap: Record<CtPhase, 'idle' | 'running' | 'done' | 'attention'> = {
      idle: 'idle',
      loading: 'running',
      ready: 'done',
      deep: 'done',
      released: 'idle'
    }
    const effective = runningCount.value > 0
      ? 'running'
      : needsAttention.value
        ? 'attention'
        : stateMap[phase.value]
    hub().syncCtMirror({
      phase: phase.value,
      tier: tier.value,
      runningCount: runningCount.value,
      needsAttention: needsAttention.value,
      state: effective
    })
  }

  function setPhase(p: CtPhase) {
    if (p === 'released') return release()
    if (p === 'ready' || p === 'deep') return load(p)
    window.clearInterval(loadTimer)
    loadingBoost.value = 0
    phase.value = p
    syncMirror()
  }

  /** 按需加载模型进程：loading 内存爬升动画后落到目标阶段 */
  function load(to: 'ready' | 'deep') {
    window.clearInterval(loadTimer)
    phase.value = 'loading'
    loadingBoost.value = MEM.loading
    syncMirror()
    const target = MEM[to]
    loadTimer = window.setInterval(() => {
      if (loadingBoost.value >= target) {
        window.clearInterval(loadTimer)
        phase.value = to
        loadingBoost.value = 0
        hub().say(to === 'deep' ? '深度模型已就绪 · 1.5GB（演示）' : '本地模型已就绪 · 400MB（演示）')
        syncMirror()
      } else {
        loadingBoost.value = Math.min(target, loadingBoost.value + 90)
      }
    }, 90)
  }

  function release() {
    window.clearInterval(loadTimer)
    window.clearInterval(agentTimer)
    loadingBoost.value = 0
    tasks.value.forEach((t) => { if (t.state === 'running') t.state = 'canceled' })
    phase.value = 'released'
    syncMirror()
    hub().say('模型进程已释放 · 0MB（~10MB 调度外壳仍在）')
  }

  function setTier(id: CtTier) {
    // free-web：默认关闭、永不抢默认位；这里允许「试用」但仍标记非默认
    tier.value = id
    hub().pushHint('ri-route-line', `模型档位 → ${TIER_PROVIDER[id]}（${isLocalTier.value ? '本地' : '云端'}）`, '#7b5cf0')
    syncMirror()
  }

  /** 一键填入：只带 endpoint / 配置，key 永远留给用户自己填 */
  function applyImport(sample: { endpoint?: string; provider?: string }) {
    importState.endpoint = sample.endpoint || ''
    importState.key = ''
    importState.status = 'no_key'
    hub().say('已导入接入配置 · 请在下方填入你自己的 key（CT优选看不到）')
  }

  function setKey(v: string) {
    importState.key = v
    importState.status = v ? 'ok' : 'no_key'
  }

  /** 分享包绝不含 key 字段 */
  function shareJson(): string {
    return JSON.stringify({
      schema: 'ctclaw.provider/v1',
      provider: 'ct-selfhosted',
      label: 'CT 自建 · 演示接入',
      endpoint: 'https://ctclaw.example.invalid/v1/chat/completions',
      auth_scheme: 'bearer',
      key_hint: '（请填入你自己的 key）',
      models: ['glm-4.7-flash'],
      capabilities: ['chat', 'reasoning'],
      curated_by: 'CT优选'
    }, null, 2)
  }

  function copyShare() {
    const json = shareJson()
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(json).then(
        () => hub().say('已复制分享包（不含 key）'),
        () => hub().say('复制失败，请手动选择 JSON 文本')
      )
    } else {
      hub().say('当前环境不支持剪贴板，分享包已在下方显示')
    }
  }

  /* ── Agent 执行：大馒头 → 小馒头 ×N ── */
  function startAgent(parent: string, subs: Array<{ name: string; weight?: number }>) {
    window.clearInterval(agentTimer)
    agentLog.value = []
    logAgent(`${parent} 接单 · 拆成 ${subs.length} 个小馒头并行执行`)
    tasks.value = subs.map((s) => ({
      id: ++taskSeq,
      name: s.name,
      parent,
      progress: 0,
      state: 'running' as const,
      origin: `agent:${parent}`
    }))
    let lastMilestone = 0
    agentTimer = window.setInterval(() => {
      let done = true
      tasks.value.forEach((t) => {
        if (t.state !== 'running') return
        t.progress = Math.min(100, t.progress + 7 + Math.floor(Math.random() * 6))
        if (t.progress < 100) done = false
        else t.state = 'done'
      })
      const maxP = Math.max(0, ...tasks.value.map((t) => t.progress))
      const milestone = Math.floor(maxP / 25) * 25
      if (milestone > lastMilestone && milestone < 100) {
        lastMilestone = milestone
        logAgent(`${parent} → 小馒头进度 ${milestone}%`)
        hub().pushHint('ri-robot-line', `${parent} → 小馒头进度 ${milestone}%（演示 · origin: agent:${parent}）`, '#7b5cf0')
      }
      syncMirror()
      if (done) {
        window.clearInterval(agentTimer)
        logAgent(`${parent}：全部小馒头已完成`)
        hub().say(`${parent}：全部小馒头已完成（演示）`)
        syncMirror()
      }
    }, 650)
  }

  function cancelAgent() {
    window.clearInterval(agentTimer)
    tasks.value.forEach((t) => { if (t.state === 'running') t.state = 'canceled' })
    if (tasks.value.length) logAgent('已取消 Agent 执行')
    hub().say('已取消 Agent 执行（演示）')
    syncMirror()
  }
  /** 取消单个小馒头任务（工作台任务卡操作）：全取消时收掉计时器 */
  function cancelTask(id: number) {
    const t = tasks.value.find((x) => x.id === id)
    if (!t || t.state !== 'running') return
    t.state = 'canceled'
    logAgent(`已取消小馒头任务 #${id}`)
    if (!tasks.value.some((x) => x.state === 'running')) window.clearInterval(agentTimer)
    syncMirror()
  }
  /** 清空派活记录（工作台操作） */
  function clearAgentLog() {
    agentLog.value = []
  }

  /* ── 长按空格唤醒 ── */
  function startWake() {
    if (phase.value === 'ready' || phase.value === 'deep') return
    wake.active = true
    wake.progress = 0
    window.clearInterval(wakeTimer)
    wakeTimer = window.setInterval(() => {
      wake.progress = Math.min(100, wake.progress + 10)
    }, 100)
  }
  function tickWake(p: number) {
    wake.progress = Math.max(0, Math.min(100, p))
  }
  function cancelWake() {
    window.clearInterval(wakeTimer)
    wake.active = false
    wake.progress = 0
  }
  function wakeUp() {
    window.clearInterval(wakeTimer)
    wake.active = false
    wake.progress = 100
    load('ready')
    hub().say('CTclaw 已唤醒 · 本地模型 400MB（演示）')
  }

  function setAIHost(v: boolean) {
    optInAIHost.value = v
    hub().pushHint('ri-node-tree', v ? '已开启 AI-Host 原生内嵌（演示）' : '已回落到浮动覆盖兜底（演示）', '#7b5cf0')
  }

  /* ── 唤醒对话框 actions ── */
  function openPanel(mode: CtPanelMode = 'chat') {
    // 对话框与工作台严格互斥：唤醒对话框时先收起工作台（不释放模型、不取消任务，
    // Agent 任务转后台继续跑，跑完推信息岛；提示条可随时再进工作台）
    panelAgentSidebarOpen.value = false
    panelOpen.value = true
    // 每次重新唤醒：本次关闭的提示条重新生效（永久关闭不受影响）
    hintDismissedThisSession.value = false
    setPanelMode(mode)
    syncMirror()
  }
  /** 关闭面板 = 绑定拆除 → 模型进程退出释放（§2.3 / §51.3 规则③） */
  function closePanel() {
    window.clearTimeout(panelTimer)
    panelOpen.value = false
    panelBusy.value = false
    panelAgentSidebarOpen.value = false
    if (tasks.value.some((t) => t.state === 'running')) cancelAgent()
    release()
  }
  function setPanelMode(m: CtPanelMode) {
    panelMode.value = m
    // 模式即模型：只有两档 —— 轻量 0.6B / 深度 1.5B；Agent 是工作模式，不加载额外模型
    if (m === 'deep') load('deep')
    else if (phase.value !== 'ready') load('ready')
    hub().pushHint(
      m === 'chat' ? 'ri-chat-3-line' : 'ri-brain-line',
      m === 'chat' ? '轻量模型 · Qwen3-0.6B' : '深度模型 · Qwen3-1.5B（1.5GB）',
      '#7b5cf0'
    )
  }
  /** 对话 / Agent 工作模式切换：Agent 沿用当前选中的模型，只是把回答改成派活流程 */
  function setPanelAgent(v: boolean) {
    panelAgent.value = v
    // 切回「对话」时侧栏一并关闭（侧栏属于 Agent 工作台）
    if (!v) panelAgentSidebarOpen.value = false
    hub().pushHint(
      v ? 'ri-robot-line' : 'ri-chat-3-line',
      v ? `Agent 工作模式 · 沿用当前模型（${panelMode.value === 'deep' ? 'Qwen3-1.5B' : 'Qwen3-0.6B'}）` : '对话工作模式',
      '#7b5cf0'
    )
  }
  /** 提示条二选一关闭 */
  function dismissHintThisSession() {
    hintDismissedThisSession.value = true
  }
  function dismissHintForever() {
    hintDismissedForever.value = true
    saveAgentHintForever()
  }
  /** Agent 工作台侧栏开合：与对话框严格互斥 —— 二者不同时处于「开启」状态 */
  function openAgentSidebar() {
    if (!panelAgent.value) return
    // 进工作台 = 对话框真正关闭（不是仅视觉隐藏）。会话 panelMsgs 与已加载的模型
    // 保留给工作台复用，避免重复加载；panelOpen 置 false 后对话框不再挂在那里。
    panelOpen.value = false
    modelOpenHintGuard()
    panelAgentSidebarOpen.value = true
  }
  function closeAgentSidebar() {
    panelAgentSidebarOpen.value = false
    // 关工作台 = 回到桌面，不自动弹回对话框（要对话请重新长按空格 / 用「返回对话」）
    window.clearTimeout(panelTimer)
    panelBusy.value = false
    if (tasks.value.some((t) => t.state === 'running')) cancelAgent()
    release()
  }
  /** 接管模式 ↔ 后台模式：只改形态，不影响会话 / 任务 / 模型 */
  function toggleAgentFloat() {
    agentFloat.value = !agentFloat.value
    hub().pushHint(
      agentFloat.value ? 'ri-picture-in-picture-line' : 'ri-fullscreen-line',
      agentFloat.value ? 'Agent 工作台 · 后台模式（悬浮）' : 'Agent 工作台 · 接管模式（包围屏幕）',
      '#7b5cf0'
    )
  }
  /** 返回对话：退出 Agent 工作模式并重新唤醒对话框，工作台随之关闭 */
  function backToChat() {
    setPanelAgent(false)
    openPanel('chat')
  }
  /** 对话框收起时清一下模型菜单标记（占位，保证 openAgentSidebar 状态干净） */
  function modelOpenHintGuard() {
    hintDismissedThisSession.value = false
  }
  function sendPanel(text?: string) {
    const q = (text ?? panelInput.value).trim()
    if (!q || panelBusy.value) return
    panelInput.value = ''
    panelMsgs.value.push({ role: 'me', text: q })

    // Agent 工作模式：大馒头接单 → 分解为小馒头子任务卡，进度推信息岛（后台不阻塞）
    // 用的是当前选中的同一个模型（chat 或 deep），不存在独立的「Agent 模型」
    if (panelAgent.value) {
      panelBusy.value = true
      window.clearTimeout(panelTimer)
      panelTimer = window.setTimeout(() => {
        const subs = [
          { name: `拆解「${q}」的目标`, weight: 1 },
          { name: '检索本机相关文件与状态', weight: 1 },
          { name: '汇总结果并生成草稿', weight: 1 }
        ]
        panelMsgs.value.push({
          role: 'bot',
          text: `大馒头（${panelMode.value === 'deep' ? 'Qwen3-1.5B' : 'Qwen3-0.6B'}）已接单「${q}」，拆成 ${subs.length} 个小馒头并行执行。`,
          steps: ['origin: agent:大馒头 · 虚拟输入注入', '后台执行不阻塞当前会话', '进度经 RDBus 推信息岛']
        })
        startAgent('大馒头', subs)
        panelBusy.value = false
      }, 460)
      return
    }

    panelBusy.value = true
    window.clearTimeout(panelTimer)
    panelTimer = window.setTimeout(() => {
      const reply = panelReply(q, panelMode.value)
      if (panelSearch.value) {
        reply.text = `[智能搜索 · 数据已发往 ${tierLabel.value}] ${reply.text}`
      }
      panelMsgs.value.push(reply)
      panelBusy.value = false
    }, panelMode.value === 'deep' ? 920 : 520)
  }
  function resetPanelChat() {
    window.clearTimeout(panelTimer)
    panelBusy.value = false
    const model = panelMode.value === 'deep' ? 'Qwen3-1.5B' : 'Qwen3-0.6B'
    const welcome = panelAgent.value
      ? `Agent 工作模式（当前模型 ${model}）：大馒头已待命，描述一件事我会拆给小馒头并行执行，后台不阻塞、进度推信息岛。`
      : panelMode.value === 'deep'
        ? '深度模型 Qwen3-1.5B 已就绪（1.5GB · 演示）。问我系统问题，我会展开推理步骤。'
        : '我是 CTclaw —— 零常驻系统智慧助手。轻量对话走本地 Qwen3-0.6B（约 400MB），用完即释放。'
    panelMsgs.value = [{ role: 'bot', text: welcome }]
  }

  return {
    // 状态
    phase, memMB, tier, tierLabel, isLocalTier, privacyText,
    importState, tasks, runningCount, needsAttention, wake, optInAIHost,
    panelOpen, panelMode, panelAgent, panelInput, panelBusy, panelSearch, panelMsgs,
    panelAgentSidebarOpen, showAgentHint, agentLog, agentFloat,
    CT_SHELL_MB,
    // 动作
    setPhase, release, load, setTier, applyImport, setKey, shareJson, copyShare,
    startAgent, cancelAgent, cancelTask, clearAgentLog, startWake, tickWake, cancelWake, wakeUp, setAIHost, syncMirror,
    openPanel, closePanel, setPanelMode, setPanelAgent, sendPanel, resetPanelChat,
    dismissHintThisSession, dismissHintForever, openAgentSidebar, closeAgentSidebar, backToChat, toggleAgentFloat
  }
}
