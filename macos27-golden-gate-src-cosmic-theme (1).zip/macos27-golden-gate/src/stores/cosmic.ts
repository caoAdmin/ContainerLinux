/**
 * COSMIC 窗口 / 主题 Store
 * 管理 COSMIC 应用窗口堆叠与桌面外观设置（设置应用改的就是这里，实时生效）。
 */
import { defineStore } from 'pinia'
import { ref, reactive, computed, watch } from 'vue'
import { getCosmicApp, cosmicApps } from '@/utils/cosmicApps'
import { useLayoutStore } from '@/stores/layout'
import { DEFAULT_M3E, normalizeM3E, type M3ETheme } from '@/utils/m3eTheme'

export interface CosmicWindowState {
  id: string
  appId: string
  title: string
  x: number
  y: number
  width: number
  height: number
  minWidth: number
  minHeight: number
  zIndex: number
  minimized: boolean
  maximized: boolean
  closing?: boolean
  /** 置顶：始终压在其它窗口上面 */
  pinned?: boolean
  prev?: { x: number; y: number; width: number; height: number }
}

export interface CosmicSettings {
  accent: string
  mode: 'dark' | 'light'
  radius: number
  dockPosition: 'bottom' | 'left' | 'right'
  dockSize: 'S' | 'M' | 'L'
  autoHideDock: boolean
  showDock: boolean
  wallpaperDim: number
  animations: boolean
  timeFormat: '24h' | '12h'
  /** 全站玻璃材质：liquid = 官方 LiquidGlass 折射；frosted = 纯磨砂雾面；flat = 无玻璃（不透明实心面板） */
  glassMode: 'liquid' | 'frosted' | 'flat'

  /* ── M3E Expressive 主题引擎（移植自 lnkiai/m3e-canvas）── */
  /** 是否启用 M3E 主题（关闭 = 原 GNOME/libadwaita 标准色） */
  m3eEnabled: boolean
  /** M3E 五条主题轴：配色 / 对比度 / 形状 / 字体 / 动效 */
  m3e: M3ETheme

  /* ── COSMIC ThemeProvider（移植自 pop-os/cosmic-theme）── */
  /** 活动主题名：'auto' 跟随深浅模式；内置 cosmic-dark/light(-highcontrast)；或用户主题名 */
  cosmicTheme: string

  /* ── Dock 悬停放大（移植自 puruvj/macos-web）── */
  /** 是否启用悬停放大 */
  dockMagnify: boolean
  /** 最大放大倍率 */
  dockMagnifyMax: number
  /** 影响范围（以图标个数计） */
  dockMagnifyRange: number
  /** 弹簧响应速度 ω（rad/s，越大越跟手） */
  dockMagnifySpeed: number
  /** 弹簧阻尼比 ζ（越大越稳，越小越弹） */
  dockMagnifyDamping: number
  /** 邻位让位强度 0–100（%），决定放大图标最多把邻居推开多少 */
  dockMagnifyNeighbor: number
  /** 浮起高度系数 0–1（0 = 只放大不浮起） */
  dockMagnifyLift: number

  /* ── Dock 图标弹跳 ── */
  /** 是否启用弹跳 */
  dockBounce: boolean
  /** 弹跳幅度（px） */
  dockBounceHeight: number
  /** 弹跳时长（ms） */
  dockBounceDuration: number
  /** 仅在真正新开应用时弹跳（对齐上游语义；默认关，保持原有行为） */
  dockBounceLaunchOnly: boolean
}

export interface AccentPreset {
  name: string
  hex: string
}

export const ACCENTS: AccentPreset[] = [
  { name: 'COSMIC 紫', hex: '#7B5CF0' },
  { name: '深蓝', hex: '#3584E4' },
  { name: '青碧', hex: '#25C2A0' },
  { name: '翠绿', hex: '#2EC27E' },
  { name: '金黄', hex: '#E5A50A' },
  { name: '暖橙', hex: '#FF7800' },
  { name: '绯红', hex: '#E01B24' },
  { name: '樱粉', hex: '#E45B9C' }
]

let zCounter = 10
let idCounter = 0

/** 顶部为「顶栏 + 窗口外侧的应用栏」预留的高度 —— 普通窗口的上边界。
 *  应用栏挂在窗口外侧上方（高 46 + 8 间距），窗口要给它和顶栏都让出位置。 */
export const TOP_RESERVED = 116

/** 最大化时窗口的上边界：应用栏这时已并进顶栏那一行，只需让开顶栏本身。 */
export const MAX_TOP = 69

/* ══════════════ Dock 偏好持久化 ══════════════
   本项目的 cosmic.settings 整体没有持久化（刷新即回默认）。
   这里只单独存 Dock 这批偏好，不改变其它设置项的现有行为。 */
const DOCK_PREF_KEY = 'cosmic.dock.v1'

/** 参与持久化的字段白名单 */
const DOCK_PREF_FIELDS = [
  'dockMagnify', 'dockMagnifyMax', 'dockMagnifyRange',
  'dockMagnifySpeed', 'dockMagnifyDamping', 'dockMagnifyNeighbor', 'dockMagnifyLift',
  'dockBounce', 'dockBounceHeight', 'dockBounceDuration', 'dockBounceLaunchOnly'
] as const

/** 数值字段的合法区间 —— 读档时钳制，防止手改 localStorage 造成 NaN / 越界 */
const DOCK_PREF_RANGE: Record<string, [number, number]> = {
  dockMagnifyMax: [1.1, 2.4],
  dockMagnifyRange: [1, 6],
  dockMagnifySpeed: [6, 28],
  dockMagnifyDamping: [0.45, 1.1],
  dockMagnifyNeighbor: [0, 100],
  dockMagnifyLift: [0, 1],
  dockBounceHeight: [4, 28],
  dockBounceDuration: [300, 1200]
}

function loadDockPrefs(): Partial<CosmicSettings> {
  try {
    const raw = localStorage.getItem(DOCK_PREF_KEY)
    if (!raw) return {}
    const obj = JSON.parse(raw) as Record<string, unknown>
    const out: Record<string, unknown> = {}
    for (const k of DOCK_PREF_FIELDS) {
      const v = obj[k]
      if (typeof v === 'boolean') {
        out[k] = v
      } else if (typeof v === 'number' && Number.isFinite(v)) {
        const r = DOCK_PREF_RANGE[k]
        if (r) out[k] = Math.min(r[1], Math.max(r[0], v))
      }
    }
    return out as Partial<CosmicSettings>
  } catch {
    return {} // 隐私模式 / 非法 JSON → 用默认值
  }
}

function saveDockPrefs(src: CosmicSettings) {
  try {
    const out: Record<string, unknown> = {}
    for (const k of DOCK_PREF_FIELDS) out[k] = src[k]
    localStorage.setItem(DOCK_PREF_KEY, JSON.stringify(out))
  } catch {
    /* 隐私模式下忽略 */
  }
}

/* ── 玻璃材质偏好 + M3E 主题（同 key 持久化） ── */
const THEME_PREF_KEY = 'cosmic.theme.v1'
function loadThemePrefs(): Partial<CosmicSettings> {
  try {
    const raw = localStorage.getItem(THEME_PREF_KEY)
    if (!raw) return {}
    const v = JSON.parse(raw) as Record<string, unknown>
    const out: Partial<CosmicSettings> = {}
    if (v.glassMode === 'liquid' || v.glassMode === 'frosted' || v.glassMode === 'flat') out.glassMode = v.glassMode
    if (typeof v.m3eEnabled === 'boolean') out.m3eEnabled = v.m3eEnabled
    if (v.m3e && typeof v.m3e === 'object') out.m3e = normalizeM3E(v.m3e as Partial<M3ETheme>)
    if (typeof v.cosmicTheme === 'string') out.cosmicTheme = v.cosmicTheme
    return out
  } catch {
    return {}
  }
}
function saveThemePrefs(src: CosmicSettings) {
  try {
    localStorage.setItem(THEME_PREF_KEY, JSON.stringify({ glassMode: src.glassMode, m3eEnabled: src.m3eEnabled, m3e: src.m3e, cosmicTheme: src.cosmicTheme }))
  } catch {
    /* 隐私模式下忽略 */
  }
}

export const useCosmicStore = defineStore('cosmic', () => {
  const windows = ref<CosmicWindowState[]>([])
  /** 处于「全屏独占」的窗口 id：它会铺满画布，其它窗口暂时让位 */
  const exclusiveId = ref<string | null>(null)
  const activeId = ref<string | null>(null)
  const launcherOpen = ref(false)
  /** 启动器的打开方式：'apps' = 开始按钮（看应用网格），'search' = AI Search（直接输入） */
  const launcherMode = ref<'apps' | 'search'>('apps')
  /** 启动台视图：'float' = 悬浮面板（原布局），'fullscreen' = 苹果全屏 Launchpad */
  const launcherView = ref<'float' | 'fullscreen'>(
    typeof localStorage !== 'undefined' && localStorage.getItem('cosmic.launcherView') === 'fullscreen'
      ? 'fullscreen'
      : 'float'
  )

  /** 顶栏面板：通知 / 控制中心（移植自 HighOS 的 TopBar；两者互斥，也和启动器互斥） */
  const notifOpen = ref(false)
  const ccOpen = ref(false)
  /** 跨应用打开请求：key = appId，value = 载荷（文件路径 / 歌曲索引…） */
  const pending = reactive<Record<string, unknown>>({})
  /** 已安装应用（Store 里可继续安装 / 卸载） */
  const installed = ref<string[]>(cosmicApps.map((a) => a.id))

  const settings = reactive<CosmicSettings>({
    accent: '#7B5CF0',
    mode: 'dark',
    radius: 12,
    dockPosition: 'bottom',
    dockSize: 'M',
    autoHideDock: false,
    showDock: true,
    wallpaperDim: 0,
    animations: true,
    timeFormat: '24h',
    glassMode: 'liquid',

    /* M3E 主题（默认关闭 = 原 GNOME 标准色） */
    m3eEnabled: false,
    m3e: { ...DEFAULT_M3E },

    /* COSMIC 主题（'auto' = 跟随深浅模式选内置 cosmic-dark/light） */
    cosmicTheme: 'auto',

    /* Dock 悬停放大 */
    dockMagnify: true,
    dockMagnifyMax: 1.8,
    dockMagnifyRange: 3,
    dockMagnifySpeed: 16,
    dockMagnifyDamping: 0.72,
    dockMagnifyNeighbor: 80,
    dockMagnifyLift: 0.35,

    /* Dock 图标弹跳 */
    dockBounce: true,
    dockBounceHeight: 13,
    dockBounceDuration: 680,
    dockBounceLaunchOnly: false,
    ...loadDockPrefs(),
    ...loadThemePrefs()
  })

  /* Dock 偏好回写（只盯白名单字段，改主题色不会触发写盘）。
     这些字段含多个滑杆（放大倍率/范围/速度…），拖动时每帧都会变；
     localStorage 是同步阻塞 API，因此去抖 250ms 再落盘。 */
  let dockSaveTimer = 0
  watch(
    () => DOCK_PREF_FIELDS.map((k) => settings[k]),
    () => {
      window.clearTimeout(dockSaveTimer)
      dockSaveTimer = window.setTimeout(() => saveDockPrefs(settings), 250)
    }
  )
  /* 玻璃材质 + M3E 主题 + COSMIC 主题单独回写（切换即时生效，刷新后保持） */
  watch(
    () => [settings.glassMode, settings.m3eEnabled, settings.m3e, settings.cosmicTheme],
    () => saveThemePrefs(settings),
    { deep: true }
  )

  const openWindows = computed(() => windows.value.filter((w) => !w.closing))

  /** Dock 占据的屏幕边缘空间 —— 「最大化」把窗口收进工作区时要给它让位；
   *  只有「全屏独占」才会压过 Dock。数值按实测的 Dock 盒模型来：
   *  底部停靠时 Dock 高 50 + 离屏底 18 + 一点间隙 ≈ 82。 */
  const dockInsets = computed(() => {
    const inset = { top: 0, right: 0, bottom: 0, left: 0 }
    if (settings.showDock && !settings.autoHideDock) {
      if (settings.dockPosition === 'bottom') inset.bottom = 82
      else if (settings.dockPosition === 'left') inset.left = 82
      else inset.right = 82
    }
    return inset
  })

  /** 是否有应用正在覆盖桌面（最小化的不算） */
  const hasWindows = computed(() => openWindows.value.some((w) => !w.minimized))

  /** 外壳是否缩回：只有「全屏独占」才让顶栏与 Dock 退场。
   *  普通「最大化」只是铺满工作区 —— 顶栏和 Dock 照旧留着。 */
  const isFullscreen = computed(() => exclusiveId.value !== null)

  /** 正在播放（灵动岛与 Player 共享） */
  const nowPlaying = reactive({
    title: 'Departures ～ありがとう～',
    artist: 'EGOIST',
    album: 'Departures',
    playing: true,
    progress: 32,
    from: '#7d4fd1',
    to: '#a97ef0'
  })

  /** Player 注册的播放控制，供灵动岛调用 */
  const playerControls = ref<{ next?: () => void; prev?: () => void; toggle?: () => void }>({})

  /** 正在「弹跳」的 Dock 图标（应用打开 / 最小化 / 还原时给点反馈） */
  const bouncing = ref<string[]>([])
  const bounceTimers: Record<string, number> = {}
  /** 弹跳触发原因：launch = 真正新开窗口 / minimize = 最小化 / restore = 从最小化还原 */
  type BounceReason = 'launch' | 'minimize' | 'restore'
  function bounce(appId: string, reason: BounceReason = 'launch') {
    if (!settings.animations) return
    if (!settings.dockBounce) return
    // 「仅新开时弹」：只有真正新建窗口才弹，聚焦已有窗口 / 最小化都不弹
    if (settings.dockBounceLaunchOnly && reason !== 'launch') return
    if (!bouncing.value.includes(appId)) bouncing.value = [...bouncing.value, appId]
    window.clearTimeout(bounceTimers[appId])
    // 兜底：正常路径由 CSS animationend 驱动清除（见 CosmicDesktop.onDockAnimEnd），
    // 这里只是防止动画被跳过（全局关动画）时状态卡住。
    bounceTimers[appId] = window.setTimeout(() => {
      clearBounce(appId)
    }, settings.dockBounceDuration + 400)
  }

  /** 移除某个图标的弹跳态（animationend 或兜底定时器调用） */
  function clearBounce(appId: string) {
    window.clearTimeout(bounceTimers[appId])
    delete bounceTimers[appId]
    if (bouncing.value.includes(appId)) {
      bouncing.value = bouncing.value.filter((x) => x !== appId)
    }
  }

  /** 歌词（折叠在灵动岛里，桌面上的歌词卡已移除） */
  const lyrics = [
    { jp: 'ふたりの間に', cn: '两人之间' },
    { jp: '越えられない壁があって', cn: '隔着一道无法跨越的高墙' },
    { jp: '必要とされることもない', cn: '也不再需要我' },
    { jp: 'それでもここにいるのに', cn: '可我明明还在这里' },
    { jp: '涙さえも必要とされない', cn: '连眼泪都无人需要' }
  ]
  const lyricIndex = ref(2)
  function nextLyric() {
    // 在 1..3 之间循环，保证首尾两行始终作为「上下文」可见
    lyricIndex.value = 1 + ((lyricIndex.value + 1) % (lyrics.length - 2))
  }

  function islandToggle() {
    if (playerControls.value.toggle) playerControls.value.toggle()
    else nowPlaying.playing = !nowPlaying.playing
  }
  function islandNext() {
    if (playerControls.value.next) playerControls.value.next()
  }
  function islandPrev() {
    if (playerControls.value.prev) playerControls.value.prev()
  }

  function genId(): string {
    idCounter += 1
    return `cw-${Date.now()}-${idCounter}`
  }

  function openApp(appId: string, opts: { title?: string } = {}): CosmicWindowState | null {
    const def = getCosmicApp(appId)
    if (!def) return null
    // 全屏独占态下打开 / 聚焦应用：先退出独占，否则新窗口被独占窗口挡着看不见
    if (exclusiveId.value) exclusiveId.value = null
    if (def.singleton) {
      const existing = windows.value.find((w) => w.appId === appId)
      if (existing) {
        existing.minimized = false
        focus(existing.id)
        launcherOpen.value = false
        return existing
      }
    }
    const layout = useLayoutStore()
    // 窗口坐标一律基于逻辑画布（1920×1080），与外层缩放无关
    const vw = layout.canvasW
    const vh = layout.canvasH
    // 画布很小时，窗口默认尺寸不能超过画布；
    // 高度还要给「顶栏 + 应用栏」（TOP_RESERVED）和 Dock（dockInsets）留位，
    // 否则小屏上默认窗口不是压住顶栏就是怼进 Dock
    const w = Math.min(def.width, vw - 80)
    const h = Math.min(def.height, vh - TOP_RESERVED - dockInsets.value.bottom - 16)
    // 以屏幕中上区域为中心，稍微错开，避免完全重叠
    const offset = (windows.value.length % 5) * 26
    const win: CosmicWindowState = {
      id: genId(),
      appId,
      title: opts.title ?? def.name,
      x: Math.max(16, Math.round((vw - w) / 2) - 40 + offset),
      // 下限与 move() 一致用 TOP_RESERVED：窗口上方悬着 56px 高的应用栏，
      // 小画布（720 高）上垂直居中会算出负值，若只钳到 56 应用栏就会压住顶栏
      y: Math.max(TOP_RESERVED, Math.round((vh - h) / 2) - 60 + offset),
      width: w,
      height: h,
      minWidth: Math.min(def.minWidth, w),
      minHeight: Math.min(def.minHeight, h),
      zIndex: ++zCounter,
      minimized: false,
      maximized: false
    }
    windows.value.push(win)
    activeId.value = win.id
    launcherOpen.value = false
    bounce(appId, 'launch')
    return win
  }

  function focus(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    w.zIndex = ++zCounter
    if (w.minimized) {
      w.minimized = false
      bounce(w.appId, 'restore')
    }
    activeId.value = id
    // 被置顶的窗口永远压在上面（全屏独占时例外，独占的那个说了算）
    if (!exclusiveId.value) {
      windows.value.forEach((x) => {
        if (x.pinned && x.id !== id) x.zIndex = ++zCounter
      })
    }
  }

  function close(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    if (exclusiveId.value === id) exclusiveId.value = null
    w.closing = true
    setTimeout(() => {
      windows.value = windows.value.filter((x) => x.id !== id)
      if (activeId.value === id) {
        const next = [...windows.value].sort((a, b) => a.zIndex - b.zIndex).pop()
        activeId.value = next?.id ?? null
      }
    }, settings.animations ? 160 : 0)
  }

  /** 全屏独占：铺满整块画布并压到最上层，其它窗口让位；再点一次回到原样 */
  function toggleExclusive(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    if (exclusiveId.value === id) {
      exclusiveId.value = null
      if (w.maximized) {
        if (w.prev) Object.assign(w, w.prev)
        w.maximized = false
      }
      w.prev = undefined
      focus(id)
      return
    }
    exclusiveId.value = id
    if (!w.maximized) w.prev = { x: w.x, y: w.y, width: w.width, height: w.height }
    const layout = useLayoutStore()
    w.x = 0
    w.y = 0
    w.width = layout.canvasW
    w.height = layout.canvasH
    w.maximized = true
    w.minimized = false
    focus(id)
  }

  /** 置顶开关 */
  function togglePin(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    w.pinned = !w.pinned
    if (w.pinned) w.zIndex = ++zCounter
    else focus(id)
  }

  /** 有窗口进入全屏独占时，其它窗口让位（保留状态，只是不显示） */
  function isVisible(w: CosmicWindowState) {
    return !exclusiveId.value || exclusiveId.value === w.id
  }

  function minimize(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    // 独占的窗口被最小化：先退出独占，否则其它窗口会被一个看不见的独占窗口一直挡着
    if (exclusiveId.value === id) exclusiveId.value = null
    w.minimized = true
    if (activeId.value === id) activeId.value = null
    bounce(w.appId, 'minimize')
  }

  function toggleMaximize(id: string) {
    const w = windows.value.find((x) => x.id === id)
    if (!w) return
    // 独占态下点「还原」= 退出独占（几何由 toggleExclusive 负责恢复）
    if (exclusiveId.value === id) {
      toggleExclusive(id)
      return
    }
    if (w.maximized) {
      if (w.prev) Object.assign(w, w.prev)
      w.maximized = false
    } else {
      w.prev = { x: w.x, y: w.y, width: w.width, height: w.height }
      const layout = useLayoutStore()
      const i = dockInsets.value
      // 最大化 = 铺满「工作区」：顶部只让开顶栏那一行（应用栏这时并进了顶栏），
      // 边缘让开 Dock。顶栏和 Dock 都留在原位，只有「全屏独占」才会让外壳缩回。
      w.x = i.left
      w.y = MAX_TOP
      w.width = layout.canvasW - i.left - i.right
      w.height = layout.canvasH - MAX_TOP - i.bottom
      w.maximized = true
    }
  }

  function move(id: string, x: number, y: number) {
    const w = windows.value.find((v) => v.id === id)
    if (!w || w.maximized) return
    const layout = useLayoutStore()
    // 始终保留至少 120px 在画布内，避免窗口被拖到看不见的地方。
    // 上边界要给窗口外侧上方的应用栏留位置，否则它会被顶栏压住。
    w.x = Math.min(Math.max(x, -w.width + 120), layout.canvasW - 120)
    w.y = Math.min(Math.max(y, TOP_RESERVED), layout.canvasH - 60)
  }

  function resize(id: string, patch: Partial<Pick<CosmicWindowState, 'x' | 'y' | 'width' | 'height'>>) {
    const w = windows.value.find((v) => v.id === id)
    if (!w) return
    if (patch.width != null) patch.width = Math.max(w.minWidth, patch.width)
    if (patch.height != null) patch.height = Math.max(w.minHeight, patch.height)
    Object.assign(w, patch)
  }

  function cycleOrMinimize(appId: string) {
    const wins = windows.value.filter((w) => w.appId === appId)
    if (!wins.length) return false
    const top = wins.reduce((a, b) => (a.zIndex > b.zIndex ? a : b))
    if (activeId.value === top.id && !top.minimized) minimize(top.id)
    else focus(top.id)
    return true
  }

  function toggleLauncher() {
    if (launcherOpen.value) {
      launcherOpen.value = false
    } else {
      launcherMode.value = 'apps'
      launcherOpen.value = true
      closePanels()
    }
  }

  /** 由「开始按钮」或「AI Search」打开启动器 */
  function openLauncher(mode: 'apps' | 'search' = 'apps') {
    launcherMode.value = mode
    launcherOpen.value = true
    closePanels()
  }

  /** 切换启动台视图，并记住偏好（刷新后保持） */
  function setLauncherView(v: 'float' | 'fullscreen') {
    launcherView.value = v
    try {
      localStorage.setItem('cosmic.launcherView', v)
    } catch {
      /* 隐私模式下忽略 */
    }
  }

  /** 切换顶栏面板（通知 / 控制中心）。两者互斥，也会收起启动器 */
  function togglePanel(name: 'notif' | 'cc') {
    const next = name === 'notif' ? !notifOpen.value : !ccOpen.value
    notifOpen.value = name === 'notif' && next
    ccOpen.value = name === 'cc' && next
    if (next) launcherOpen.value = false
  }

  /** 收起全部浮层（通知 / 控制中心） */
  function closePanels() {
    notifOpen.value = false
    ccOpen.value = false
  }

  /** 用指定载荷打开应用（文件 / 曲目…），并等待窗口挂载后取走 */
  function openWithPayload(appId: string, payload: unknown) {
    pending[appId] = payload
    openApp(appId)
  }

  function takePending(appId: string): unknown {
    const v = pending[appId]
    if (v !== undefined) delete pending[appId]
    return v
  }

  function setTitle(winId: string, title: string) {
    const w = windows.value.find((x) => x.id === winId)
    if (w) w.title = title
  }

  function install(id: string) {
    if (!installed.value.includes(id)) installed.value.push(id)
  }

  function uninstall(id: string) {
    installed.value = installed.value.filter((x) => x !== id)
  }

  function closeAll() {
    // 清空窗口时一并退出独占，否则外壳会一直缩着、桌面空白
    if (exclusiveId.value) exclusiveId.value = null
    windows.value = []
    activeId.value = null
  }

  function minimizeAll() {
    if (exclusiveId.value) exclusiveId.value = null
    windows.value.forEach((w) => (w.minimized = true))
    activeId.value = null
  }

  return {
    windows,
    openWindows,
    activeId,
    hasWindows,
    isFullscreen,
    nowPlaying,
    playerControls,
    bouncing,
    bounce,
    clearBounce,
    lyrics,
    lyricIndex,
    nextLyric,
    islandToggle,
    islandNext,
    islandPrev,
    launcherOpen,
    launcherMode,
    launcherView,
    setLauncherView,
    notifOpen,
    ccOpen,
    togglePanel,
    closePanels,
    pending,
    installed,
    settings,
    openApp,
    focus,
    close,
    minimize,
    toggleMaximize,
    exclusiveId,
    toggleExclusive,
    togglePin,
    isVisible,
    move,
    resize,
    cycleOrMinimize,
    toggleLauncher,
    openLauncher,
    openWithPayload,
    takePending,
    setTitle,
    install,
    uninstall,
    closeAll,
    minimizeAll
  }
})
