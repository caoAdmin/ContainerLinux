/**
 * UI 浮层状态 Store
 * 管理菜单栏面板、Spotlight、Launchpad、通知中心等浮层的显示
 * 规则：浮层互斥，同一时刻最多打开一个
 */
import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { MenubarPanel } from '@/types'

export const useUIStore = defineStore('ui', () => {
  // 当前打开的菜单栏面板
  const activePanel = ref<MenubarPanel>(null)
  // 右键菜单
  const contextMenu = ref<{
    x: number
    y: number
    items: ContextMenuItem[]
  } | null>(null)
  // Spotlight
  const spotlightOpen = ref(false)
  const spotlightMode = ref<'search' | 'siri'>('search')
  // Launchpad
  const launchpadOpen = ref(false)
  // 通知中心
  const notificationCenterOpen = ref(false)
  // 关于本机弹窗
  const aboutOpen = ref(false)
  // Siri 独立窗口状态由 window store 管理，这里仅 Spotlight 内 Siri 对话
  // 拖拽预览/吸附
  const tilingPreview = ref<null | 'left' | 'right' | 'full'>(null)

  function openPanel(p: MenubarPanel) {
    // 互斥：关闭其它浮层
    spotlightOpen.value = false
    launchpadOpen.value = false
    notificationCenterOpen.value = false
    contextMenu.value = null
    activePanel.value = activePanel.value === p ? null : p
  }

  function closePanel() {
    activePanel.value = null
  }

  function toggleSpotlight() {
    const opening = !spotlightOpen.value
    closeAll()
    spotlightOpen.value = opening
    if (opening) spotlightMode.value = 'search'
  }

  function toggleLaunchpad() {
    const opening = !launchpadOpen.value
    closeAll()
    launchpadOpen.value = opening
  }

  function toggleNotificationCenter() {
    const opening = !notificationCenterOpen.value
    closeAll()
    notificationCenterOpen.value = opening
  }

  function showContextMenu(x: number, y: number, items: ContextMenuItem[]) {
    closeAll()
    contextMenu.value = { x, y, items }
  }

  function closeContextMenu() {
    contextMenu.value = null
  }

  function openAbout() {
    closeAll()
    aboutOpen.value = true
  }

  function closeAbout() {
    aboutOpen.value = false
  }

  function closeAll() {
    activePanel.value = null
    contextMenu.value = null
    spotlightOpen.value = false
    launchpadOpen.value = false
    notificationCenterOpen.value = false
    tilingPreview.value = null
  }

  function setSpotlightMode(mode: 'search' | 'siri') {
    spotlightMode.value = mode
  }

  function setTilingPreview(area: null | 'left' | 'right' | 'full') {
    tilingPreview.value = area
  }

  return {
    activePanel,
    contextMenu,
    spotlightOpen,
    spotlightMode,
    launchpadOpen,
    notificationCenterOpen,
    aboutOpen,
    tilingPreview,
    openPanel,
    closePanel,
    toggleSpotlight,
    toggleLaunchpad,
    toggleNotificationCenter,
    showContextMenu,
    closeContextMenu,
    openAbout,
    closeAbout,
    closeAll,
    setSpotlightMode,
    setTilingPreview
  }
})

// 右键菜单项类型
export interface ContextMenuItem {
  id: string
  label: string
  shortcut?: string
  disabled?: boolean
  separator?: boolean
  submenu?: ContextMenuItem[]
  action?: () => void
}
