<script setup lang="ts">
/**
 * App.vue 根组件
 * 外层：分辨率自适应舞台（把 1920×1080 逻辑画布按窗口尺寸缩放）
 * 底层：sijin-xb/dotfiles 桌面外观（基于 macos27 工程基底）
 * 上层：COSMIC 应用层（窗口 + Dock + App Library）
 */
import DotfilesDesktop from '@/components/dotfiles/DotfilesDesktop.vue'
import CosmicDesktop from '@/components/cosmic/CosmicDesktop.vue'
import PerfHud from '@/components/dev/PerfHud.vue'
import { useLayoutStore } from '@/stores/layout'

const layout = useLayoutStore()

/* 真机性能尺子：?hud=1 打开（手机上 DevTools 不可用时靠它读帧率） */
const showHud =
  typeof location !== 'undefined' && new URLSearchParams(location.search).get('hud') === '1'
</script>

<template>
  <div class="stage">
    <div class="stage-canvas" :style="layout.canvasStyle">
      <DotfilesDesktop />
      <CosmicDesktop />
    </div>

    <!-- 缩放角标（可在设置里打开） -->
    <div v-if="layout.showBadge" class="stage-badge">
      {{ layout.vw }} × {{ layout.vh }} · {{ layout.modeLabel }} {{ layout.zoom }}%
    </div>

    <!-- 真机性能 HUD（?hud=1） -->
    <PerfHud v-if="showHud" />
  </div>
</template>

<style>
html,
body,
#app {
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
  overflow: hidden;
}

/* 舞台：负责居中与裁切，多出来的区域留黑边 */
.stage {
  position: fixed;
  inset: 0;
  overflow: hidden;
  background: #000;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 逻辑画布：所有坐标都以它为准，transform 缩放不影响内部布局 */
.stage-canvas {
  position: relative;
  flex: none;
  transform-origin: center center;
  /* 这里刻意不写 will-change: transform。
     它会把整块 1920×1080 画布提升成一个图层，窗口移动时整层重绘，
     开的应用越多越卡；去掉后每个窗口才能各自成层、只重绘自己。 */
}

.stage-badge {
  position: fixed;
  right: 12px;
  bottom: 12px;
  z-index: 99999;
  padding: 5px 11px;
  border-radius: 9px;
  background: rgba(0, 0, 0, 0.66);
  color: #fff;
  font-family: 'JetBrains Mono', Consolas, monospace;
  font-size: 11.5px;
  letter-spacing: 0.3px;
  backdrop-filter: blur(8px);
  pointer-events: none;
}
</style>
