<script setup lang="ts">
/**
 * Spotlight / Siri "Search or Ask"
 */
import { ref, computed, watch, nextTick, onMounted, onUnmounted } from 'vue'
import { useUIStore } from '@/stores/ui'
import { useDockStore } from '@/stores/dock'
import { useWindowStore } from '@/stores/windows'
import { searchApps } from '@/utils/appRegistry'
import Icon from '@/components/common/Icon.vue'
import { uid } from '@/utils'

const ui = useUIStore()
const dockStore = useDockStore()
const winStore = useWindowStore()

const inputEl = ref<HTMLInputElement | null>(null)
const input = ref('')
const selectedIdx = ref(0)

const fakeFiles = [
  { id: 'f1', name: '产品周报.md', kind: '文档' },
  { id: 'f2', name: '屏幕快照 2026-10-02.png', kind: '图片' },
  { id: 'f3', name: 'GoldenGate 设计.sketch', kind: '设计稿' }
]
const matchedApps = computed(() => searchApps(input.value).slice(0, 6))
const matchedFiles = computed(() => {
  const k = input.value.trim().toLowerCase()
  if (!k) return []
  return fakeFiles.filter((f) => f.name.toLowerCase().includes(k)).slice(0, 4)
})
const totalItems = computed(() => matchedApps.value.length + matchedFiles.value.length + 1)

watch(input, () => { selectedIdx.value = 0; ui.setSpotlightMode('search') })
watch(() => ui.spotlightOpen, (v) => {
  if (v) { input.value = ''; nextTick(() => inputEl.value?.focus()) }
  else { siriInput.value = '' }
})

function selectPrev() { selectedIdx.value = (selectedIdx.value - 1 + totalItems.value) % totalItems.value }
function selectNext() { selectedIdx.value = (selectedIdx.value + 1) % totalItems.value }

function activateSelected() {
  const apps = matchedApps.value
  const files = matchedFiles.value
  if (selectedIdx.value < apps.length) { clickApp(apps[selectedIdx.value].id); return }
  if (selectedIdx.value - apps.length < files.length) {
    ui.closeAll(); dockStore.setRunning('finder', true); winStore.openWindow({ appId: 'finder' }); return
  }
  enterSiri()
}
function clickApp(id: string) { ui.closeAll(); dockStore.setRunning(id, true); winStore.openWindow({ appId: id }) }

function handleKeydown(e: KeyboardEvent) {
  if (!ui.spotlightOpen) return
  if (ui.spotlightMode === 'siri') {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendSiri() }
    return
  }
  if (e.key === 'ArrowDown') { e.preventDefault(); selectNext() }
  else if (e.key === 'ArrowUp') { e.preventDefault(); selectPrev() }
  else if (e.key === 'Enter') { e.preventDefault(); activateSelected() }
}

// Siri
interface SiriMsg { id: string; role: 'user' | 'assistant'; text: string; ts: number }
const siriMessages = ref<SiriMsg[]>([
  { id: uid('msg'), role: 'assistant', text: '你好，我是 Siri。可以问我任何事，比如"今天天气怎么样？"', ts: Date.now() }
])
const siriInput = ref('')
const siriTyping = ref(false)

function enterSiri() { ui.setSpotlightMode('siri'); nextTick(() => inputEl.value?.focus()) }
function backToSearch() { ui.setSpotlightMode('search'); nextTick(() => inputEl.value?.focus()) }

const presets: Array<{ kw: string[]; reply: (() => string) | string }> = [
  { kw: ['天气','气温'], reply: '济南今天晴，气温 16°–25°，空气质量优，适合外出。' },
  { kw: ['时间','几点'], reply: () => '现在是 ' + new Date().toLocaleTimeString('zh-CN', { hour12: false }) + '。' },
  { kw: ['笑话'], reply: '为什么程序员不喜欢户外？因为外面有太多 bug。' },
  { kw: ['写','一段话'], reply: '金门大桥的日落把整片海湾染成蜜糖般的金橙色，桥塔投下修长的阴影，海浪与风轻轻走过——这就是 macOS 27 Golden Gate 的黄昏。' },
  { kw: ['你好','hi','hello'], reply: '你好！需要我帮你做什么？' }
]
function reply(q: string): string {
  const low = q.toLowerCase()
  for (const p of presets) if (p.kw.some((k) => low.includes(k))) return typeof p.reply === 'function' ? p.reply() : p.reply
  return `关于「${q}」，我可以帮你查找网页、设置提醒或打开相关 App。试试问我天气、时间。`
}
async function typeReply(text: string) {
  siriTyping.value = true
  const rid = uid('msg')
  siriMessages.value.push({ id: rid, role: 'assistant', text: '', ts: Date.now() })
  await new Promise((r) => setTimeout(r, 200))
  for (let i = 0; i < text.length; i++) {
    siriMessages.value[siriMessages.value.length - 1].text = text.slice(0, i + 1)
    await new Promise((r) => setTimeout(r, 18))
  }
  siriTyping.value = false
}
function sendSiri() {
  const q = siriInput.value.trim(); if (!q) return
  siriMessages.value.push({ id: uid('msg'), role: 'user', text: q, ts: Date.now() })
  siriInput.value = ''
  typeReply(reply(q))
}

onMounted(() => window.addEventListener('keydown', handleKeydown))
onUnmounted(() => window.removeEventListener('keydown', handleKeydown))
</script>

<template>
  <Transition name="sp-fade">
    <div v-if="ui.spotlightOpen" class="fixed inset-0 z-[9700] flex items-start justify-center" style="padding-top:14vh;" @click.self="ui.closeAll()">
      <div class="w-[640px] max-w-[92vw] rounded-[14px] overflow-hidden"
        :style="{
          background:'var(--glass-bg)',
          backdropFilter:'blur(32px) saturate(180%)',
          WebkitBackdropFilter:'blur(32px) saturate(180%)',
          border:'1px solid var(--glass-border)',
          boxShadow:'0 30px 60px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.35)'
        }" @click.stop>
        <div class="flex items-center gap-3 px-4 h-[54px] border-b border-black/10 dark:border-white/10">
          <Icon name="spotlight" :size="20" />
          <input
            v-if="ui.spotlightMode === 'search'"
            ref="inputEl"
            v-model="input"
            class="flex-1 bg-transparent outline-none text-[18px]"
            placeholder="Search or Ask"
          />
          <input
            v-else
            ref="inputEl"
            v-model="siriInput"
            class="flex-1 bg-transparent outline-none text-[18px]"
            placeholder="问 Siri 任何事…"
          />
          <div v-if="ui.spotlightMode !== 'siri'" class="text-[11px] opacity-60 whitespace-nowrap">⌘ 空格</div>
          <button v-else class="text-[12px] px-2 py-0.5 rounded-md bg-white/15 hover:bg-white/25" @click="backToSearch">返回</button>
        </div>

        <div v-if="ui.spotlightMode==='search'" class="max-h-[52vh] overflow-auto p-2">
          <div v-if="!input" class="px-3 py-4 text-[12px] opacity-70">输入 App、文件或问题，或直接「问 Siri」。</div>
          <template v-if="matchedApps.length">
            <div class="px-3 pt-1 pb-1 text-[11px] opacity-60 uppercase tracking-wide">应用程序</div>
            <div v-for="(app,i) in matchedApps" :key="app.id"
              class="flex items-center gap-3 px-2 py-2 rounded-[8px] cursor-pointer"
              :class="selectedIdx===i ? 'bg-[rgba(10,132,255,0.18)]' : 'hover:bg-white/10'"
              @mouseenter="selectedIdx=i" @click="clickApp(app.id)">
              <Icon :name="app.icon" :size="28" />
              <div class="flex-1"><div class="text-[13px] font-medium">{{ app.name }}</div><div class="text-[11px] opacity-60">应用程序</div></div>
            </div>
          </template>
          <template v-if="matchedFiles.length">
            <div class="px-3 pt-3 pb-1 text-[11px] opacity-60 uppercase tracking-wide">文件</div>
            <div v-for="(f,fi) in matchedFiles" :key="f.id"
              class="flex items-center gap-3 px-2 py-2 rounded-[8px] cursor-pointer"
              :class="selectedIdx===matchedApps.length+fi ? 'bg-[rgba(10,132,255,0.18)]' : 'hover:bg-white/10'"
              @mouseenter="selectedIdx=matchedApps.length+fi" @click="activateSelected">
              <Icon name="doc" :size="28" />
              <div class="flex-1"><div class="text-[13px] font-medium">{{ f.name }}</div><div class="text-[11px] opacity-60">{{ f.kind }}</div></div>
            </div>
          </template>
          <div
            class="flex items-center gap-3 px-2 py-2 rounded-[8px] cursor-pointer mt-2"
            :class="selectedIdx===totalItems-1 ? 'bg-[rgba(10,132,255,0.18)]' : 'hover:bg-white/10'"
            @mouseenter="selectedIdx=totalItems-1" @click="enterSiri">
            <Icon name="siri" :size="28" />
            <div class="flex-1"><div class="text-[13px] font-medium">问 Siri</div><div class="text-[11px] opacity-60">直接在搜索框中提问</div></div>
          </div>
        </div>

        <div v-else class="max-h-[52vh] overflow-auto p-3">
          <div v-for="m in siriMessages" :key="m.id" class="flex mb-2" :class="m.role==='user' ? 'justify-end' : 'justify-start'">
            <div class="max-w-[78%] px-3 py-2 rounded-[12px] text-[13px] leading-relaxed"
              :class="m.role==='user' ? 'bg-[#0A84FF] text-white rounded-br-[4px]' : 'bg-white/15 rounded-bl-[4px]'">
              {{ m.text }}
              <span v-if="m.role==='assistant' && siriTyping && m.id===siriMessages[siriMessages.length-1].id" class="inline-block w-1.5 h-3 bg-current align-middle ml-0.5 animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </Transition>
</template>

<style scoped>
.sp-fade-enter-active,.sp-fade-leave-active{transition:opacity .2s, transform .25s cubic-bezier(0.25,.1,.25,1);}
.sp-fade-enter-from,.sp-fade-leave-to{opacity:0;transform:translateY(-8px) scale(.98);}
</style>
