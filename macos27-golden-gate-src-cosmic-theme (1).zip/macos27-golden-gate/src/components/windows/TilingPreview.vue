<script setup lang="ts">
/**
 * TilingPreview 窗口吸附预览
 */
import { computed } from 'vue'
import { useUIStore } from '@/stores/ui'

const ui = useUIStore()
const areas = computed(() => [
  { key:'left' as const, style:'left:0; top:24px; width:50%; height:calc(100% - 24px);' },
  { key:'full' as const, style:'left:0; top:24px; width:100%; height:calc(100% - 24px);' },
  { key:'right' as const, style:'left:50%; top:24px; width:50%; height:calc(100% - 24px);' }
])
</script>

<template>
  <div v-if="ui.tilingPreview" class="pointer-events-none fixed inset-0" style="z-index:8500;">
    <div v-for="a in areas" :key="a.key"
      class="absolute rounded-[10px] transition-all duration-150"
      :class="ui.tilingPreview===a.key ? 'bg-[rgba(10,132,255,0.25)] border-2 border-[#0A84FF]' : 'bg-[rgba(255,255,255,0.06)] border border-[rgba(255,255,255,0.18)]'"
      :style="a.style" />
  </div>
</template>
