<script setup lang="ts">
/**
 * WindowManager —— 遍历窗口渲染 WindowBase
 */
import { computed, defineAsyncComponent } from 'vue'
import { useWindowStore } from '@/stores/windows'
import { getAppById } from '@/utils/appRegistry'
import WindowBase from './WindowBase.vue'

const winStore = useWindowStore()

const appComponents: Record<string, ReturnType<typeof defineAsyncComponent>> = {
  FinderApp: defineAsyncComponent(() => import('@/components/apps/FinderApp.vue')),
  SafariApp: defineAsyncComponent(() => import('@/components/apps/SafariApp.vue')),
  NotesApp: defineAsyncComponent(() => import('@/components/apps/NotesApp.vue')),
  SettingsApp: defineAsyncComponent(() => import('@/components/apps/SettingsApp.vue')),
  CalculatorApp: defineAsyncComponent(() => import('@/components/apps/CalculatorApp.vue')),
  TerminalApp: defineAsyncComponent(() => import('@/components/apps/TerminalApp.vue'))
}

const windowsToRender = computed(() => winStore.windows.filter((w) => !w.closed))
</script>

<template>
  <WindowBase v-for="w in windowsToRender" :key="w.id" :win="w">
    <component :is="appComponents[getAppById(w.appId)?.component ?? 'FinderApp']" :win-id="w.id" />
  </WindowBase>
</template>
