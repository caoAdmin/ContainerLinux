<script setup lang="ts">
/**
 * WindowBase 通用窗口容器
 */
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useWindowStore } from '@/stores/windows'
import { useUIStore } from '@/stores/ui'
import { useSystemStore } from '@/stores/system'
import Icon from '@/components/common/Icon.vue'
import type { WindowState } from '@/types'

const props = defineProps<{ win: WindowState }>()
const winStore = useWindowStore()
const ui = useUIStore()
const sys = useSystemStore()

const hoverTraffic = ref(false)

const drag = ref({ active: false, startX: 0, startY: 0, origX: 0, origY: 0 })
function onTitleMouseDown(e: MouseEvent) {
  if ((e.target as HTMLElement).closest('[data-no-drag]')) return
  if (props.win.maximized) return
  winStore.activateWindow(props.win.id)
  drag.value = { active: true, startX: e.clientX, startY: e.clientY, origX: props.win.x, origY: props.win.y }
  e.preventDefault()
}
function onDblClickTitle() { winStore.zoomWindow(props.win.id) }

const resize = ref({ active: false, dir: '', startX: 0, startY: 0, origX: 0, origY: 0, origW: 0, origH: 0 })
type RD = 'n'|'s'|'e'|'w'|'ne'|'nw'|'se'|'sw'
function startResize(e: MouseEvent, dir: RD) {
  if (props.win.maximized || !props.win.resizable) return
  winStore.activateWindow(props.win.id)
  resize.value = { active:true, dir, startX:e.clientX, startY:e.clientY, origX:props.win.x, origY:props.win.y, origW:props.win.width, origH:props.win.height }
  e.preventDefault(); e.stopPropagation()
}

function onMouseMove(e: MouseEvent) {
  if (drag.value.active) {
    const dx = e.clientX - drag.value.startX
    const dy = e.clientY - drag.value.startY
    winStore.moveWindow(props.win.id, drag.value.origX + dx, drag.value.origY + dy)
    if (e.altKey) {
      if (e.clientX < 30) ui.setTilingPreview('left')
      else if (e.clientX > window.innerWidth - 30) ui.setTilingPreview('right')
      else if (e.clientY < 30) ui.setTilingPreview('full')
      else ui.setTilingPreview(null)
    } else ui.setTilingPreview(null)
  }
  if (resize.value.active) {
    const dx = e.clientX - resize.value.startX
    const dy = e.clientY - resize.value.startY
    let { origX, origY, origW, origH } = resize.value
    let x = origX, y = origY, w = origW, h = origH
    const d = resize.value.dir
    if (d.includes('e')) w = origW + dx
    if (d.includes('s')) h = origH + dy
    if (d.includes('w')) { w = origW - dx; x = origX + dx }
    if (d.includes('n')) { h = origH - dy; y = origY + dy }
    winStore.resizeWindow(props.win.id, { x, y, width: w, height: h })
  }
}
function onMouseUp(e: MouseEvent) {
  if (drag.value.active && e.altKey && ui.tilingPreview) {
    winStore.tileWindow(props.win.id, ui.tilingPreview); ui.setTilingPreview(null)
  }
  drag.value.active = false; resize.value.active = false
}

function onClose() { winStore.closeWindow(props.win.id) }
function onMinimize() { winStore.minimizeWindow(props.win.id) }
function onMaximize() { winStore.toggleMaximize(props.win.id) }
function onFrameMouseDown() { if (!props.win.focused) winStore.activateWindow(props.win.id) }

onMounted(() => { window.addEventListener('mousemove', onMouseMove); window.addEventListener('mouseup', onMouseUp) })
onUnmounted(() => { window.removeEventListener('mousemove', onMouseMove); window.removeEventListener('mouseup', onMouseUp) })

const frameStyle = computed(() => {
  const w = props.win
  if (w.minimized) {
    return { transform: 'translateY(calc(100vh)) scale(0.1)', opacity: 0, transition: 'transform .35s cubic-bezier(0.25,.1,.25,1), opacity .25s', pointerEvents: 'none' as const }
  }
  return {}
})
</script>

<template>
  <div
    ref="frame"
    v-show="!win.closed"
    class="window-base absolute flex flex-col overflow-hidden"
    :class="win.focused ? 'is-focused' : 'is-blurred'"
    :style="{
      left: win.x + 'px', top: win.y + 'px',
      width: win.width + 'px', height: win.height + 'px',
      zIndex: win.zIndex,
      borderRadius: '10px',
      background: 'var(--window-toolbar-bg)',
      backdropFilter: 'blur(24px) saturate(180%)',
      WebkitBackdropFilter: 'blur(24px) saturate(180%)',
      border: '1px solid var(--glass-border)',
      boxShadow: win.focused
        ? '0 20px 40px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.35)'
        : '0 8px 20px rgba(0,0,0,0.14), inset 0 1px 0 rgba(255,255,255,0.25)',
      filter: win.focused
        ? `saturate(1) drop-shadow(0 0 ${sys.settings.hdrGlow*6}px rgba(255,255,255,0.35))`
        : 'saturate(0.9)',
      ...frameStyle
    }"
    @mousedown="onFrameMouseDown"
    @mouseenter="hoverTraffic = true"
    @mouseleave="hoverTraffic = false"
  >
    <!-- 工具栏 -->
    <div class="relative flex items-center h-[38px] px-3 select-none cursor-grab"
      style="border-bottom:1px solid var(--divider);"
      @mousedown="onTitleMouseDown" @dblclick="onDblClickTitle">
      <div class="flex items-center gap-2" data-no-drag>
        <button class="w-3 h-3 rounded-full flex items-center justify-center transition-colors"
          :class="hoverTraffic || win.focused ? 'bg-[#FF5F57]' : 'bg-[rgba(0,0,0,0.18)]'"
          aria-label="关闭" @click.stop="onClose">
          <svg v-if="hoverTraffic" width="8" height="8" viewBox="0 0 8 8"><path d="M1.5 1.5l5 5M6.5 1.5l-5 5" stroke="#4d0000" stroke-width="1.2" stroke-linecap="round"/></svg>
        </button>
        <button class="w-3 h-3 rounded-full flex items-center justify-center transition-colors"
          :class="hoverTraffic || win.focused ? 'bg-[#FEBC2E]' : 'bg-[rgba(0,0,0,0.18)]'"
          aria-label="最小化" @click.stop="onMinimize">
          <svg v-if="hoverTraffic" width="8" height="8" viewBox="0 0 8 8"><path d="M1.5 4h5" stroke="#5c3e00" stroke-width="1.2" stroke-linecap="round"/></svg>
        </button>
        <button class="w-3 h-3 rounded-full flex items-center justify-center transition-colors"
          :class="hoverTraffic || win.focused ? 'bg-[#28C840]' : 'bg-[rgba(0,0,0,0.18)]'"
          aria-label="最大化" @click.stop="onMaximize">
          <svg v-if="hoverTraffic" width="8" height="8" viewBox="0 0 8 8"><path d="M1.5 2.5h5M6.5 1.5v5M6.5 5.5h-5M1.5 6.5v-5" stroke="#003d0a" stroke-width="1.2" stroke-linecap="round"/></svg>
        </button>
      </div>
      <div class="absolute left-0 right-0 top-0 bottom-0 flex items-center justify-center gap-2 pointer-events-none">
        <Icon :name="win.icon" :size="16" />
        <span class="text-[13px] font-medium opacity-85">{{ win.title }}</span>
      </div>
    </div>

    <!-- 内容 -->
    <div class="flex-1 min-h-0 overflow-hidden" data-no-drag>
      <slot />
    </div>

    <!-- 缩放热区 -->
    <template v-if="win.resizable && !win.maximized">
      <div class="absolute top-0 left-2 right-2 h-1 cursor-n-resize" @mousedown="startResize($event,'n')" />
      <div class="absolute bottom-0 left-2 right-2 h-1 cursor-s-resize" @mousedown="startResize($event,'s')" />
      <div class="absolute left-0 top-2 bottom-2 w-1 cursor-w-resize" @mousedown="startResize($event,'w')" />
      <div class="absolute right-0 top-2 bottom-2 w-1 cursor-e-resize" @mousedown="startResize($event,'e')" />
      <div class="absolute top-0 left-0 w-3 h-3 cursor-nw-resize" @mousedown="startResize($event,'nw')" />
      <div class="absolute top-0 right-0 w-3 h-3 cursor-ne-resize" @mousedown="startResize($event,'ne')" />
      <div class="absolute bottom-0 left-0 w-3 h-3 cursor-sw-resize" @mousedown="startResize($event,'sw')" />
      <div class="absolute bottom-0 right-0 w-3 h-3 cursor-se-resize" @mousedown="startResize($event,'se')" />
    </template>
  </div>
</template>

<style scoped>
.window-base{will-change:transform,left,top,width,height;}
</style>
