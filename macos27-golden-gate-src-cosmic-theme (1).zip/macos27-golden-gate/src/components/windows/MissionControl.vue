<script setup lang="ts">
/**
 * Mission Control 调度中心
 */
import { computed } from 'vue'
import { useWindowStore } from '@/stores/windows'
import { getAppById } from '@/utils/appRegistry'
import Icon from '@/components/common/Icon.vue'

const winStore = useWindowStore()

const allVisible = computed(() => winStore.windows.filter((w) => !w.closed))
const grouped = computed(() => {
  const map = new Map<string, typeof allVisible.value>()
  allVisible.value.forEach((w) => { const arr = map.get(w.appId) ?? []; arr.push(w); map.set(w.appId, arr) })
  return Array.from(map.entries()).map(([appId, wins]) => ({
    appId, name: getAppById(appId)?.name ?? appId, icon: getAppById(appId)?.icon ?? 'finder', wins
  }))
})

function pickWin(id: string) { winStore.closeMissionControl(id) }
function close() { winStore.closeMissionControl() }
</script>

<template>
  <Transition name="mc-fade">
    <div v-if="winStore.missionControlActive" class="fixed inset-0 z-[9850] overflow-hidden" @click.self="close">
      <div class="absolute inset-0" style="backdrop-filter: blur(30px) saturate(140%); background: rgba(0,0,0,0.22);" />
      <div class="absolute top-6 left-0 right-0 text-center text-white/90 text-sm font-medium">调度中心 · 点击任意窗口返回</div>
      <div class="absolute inset-x-0 top-20 bottom-28 px-10 overflow-auto">
        <div v-for="g in grouped" :key="g.appId" class="mb-8">
          <div class="flex items-center gap-2 mb-3 text-white/90 text-[13px]">
            <Icon :name="g.icon" :size="18" /><span>{{ g.name }}</span>
            <span class="opacity-60">（{{ g.wins.length }} 个窗口）</span>
          </div>
          <div class="flex flex-wrap gap-4">
            <div v-for="w in g.wins" :key="w.id"
              class="cursor-pointer rounded-[10px] overflow-hidden"
              :class="w.minimized ? 'opacity-60' : ''"
              style="background: rgba(255,255,255,0.15); border:1px solid rgba(255,255,255,0.25); box-shadow:0 10px 30px rgba(0,0,0,0.4); transition: transform .2s;"
              @click="pickWin(w.id)">
              <div class="relative overflow-hidden"
                :style="{
                  width: Math.min(280, w.width*0.32)+'px',
                  height: Math.min(180, w.height*0.32)+'px',
                  background:'linear-gradient(135deg, rgba(255,255,255,0.6), rgba(240,240,242,0.8))'
                }">
                <div class="h-7 flex items-center px-2 gap-1.5 border-b border-black/10">
                  <span class="w-2.5 h-2.5 rounded-full bg-[#FF5F57]/80" />
                  <span class="w-2.5 h-2.5 rounded-full bg-[#FEBC2E]/80" />
                  <span class="w-2.5 h-2.5 rounded-full bg-[#28C840]/80" />
                  <span class="ml-2 text-[11px] opacity-70">{{ w.title }}</span>
                </div>
                <div class="p-2 text-[10px] opacity-50 leading-tight">{{ g.name }} 窗口内容预览</div>
                <div v-if="w.minimized" class="absolute inset-0 flex items-center justify-center text-white/90 text-xs">已最小化</div>
              </div>
              <div class="h-6 px-2 flex items-center text-xs text-white/90 bg-black/20">{{ w.title }}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="absolute bottom-6 inset-x-0 flex justify-center gap-3">
        <div class="h-20 w-36 rounded-[10px] relative overflow-hidden cursor-pointer"
          style="background: linear-gradient(160deg,#f4b560,#d26a2a 60%,#5a2b15); border:1.5px solid #fff; box-shadow:0 6px 18px rgba(0,0,0,0.4);"
          @click="close">
          <div class="absolute bottom-1 left-1 right-1 text-white text-xs font-medium text-center">桌面 1</div>
        </div>
        <div class="h-20 w-36 rounded-[10px] flex items-center justify-center cursor-pointer text-white/90 text-sm"
          style="background: rgba(255,255,255,0.15); border:1px dashed rgba(255,255,255,0.4);">+ 添加桌面</div>
      </div>
    </div>
  </Transition>
</template>

<style scoped>
.mc-fade-enter-active,.mc-fade-leave-active{transition:opacity .28s cubic-bezier(0.25,.1,.25,1);}
.mc-fade-enter-from,.mc-fade-leave-to{opacity:0;}
</style>
