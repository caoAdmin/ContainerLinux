<script setup lang="ts">
/**
 * 关于本机对话框
 */
import { useUIStore } from '@/stores/ui'
import Icon from './Icon.vue'
const ui = useUIStore()
</script>

<template>
  <Transition name="pop-fade">
    <div
      v-if="ui.aboutOpen"
      class="fixed inset-0 z-[9800] flex items-center justify-center"
      @click.self="ui.closeAbout()"
    >
      <div
        class="w-[420px] rounded-[10px] p-6 text-center"
        :style="{
          background: 'var(--glass-bg)',
          backdropFilter: 'blur(28px) saturate(180%)',
          border: '1px solid var(--glass-border)',
          boxShadow: '0 20px 40px rgba(0,0,0,0.3)'
        }"
      >
        <div class="flex justify-center mb-3">
          <Icon name="apple" :size="56" />
        </div>
        <div class="text-[22px] font-semibold">macOS 27</div>
        <div class="text-[14px] opacity-70 mb-4">Golden Gate</div>
        <div class="text-[12px] opacity-70 leading-relaxed">
          版本 27.0（Build 27A100）<br />
          © 2026 Apple Inc. 保留所有权利。<br />
          <span class="opacity-60">本页面为前端复刻演示，非 Apple 官方产品。</span>
        </div>
        <button
          class="mt-5 px-5 py-1.5 rounded-[6px] text-[13px] bg-[#0A84FF] text-white hover:brightness-110"
          @click="ui.closeAbout()"
        >好</button>
      </div>
    </div>
  </Transition>
</template>

<style scoped>
.pop-fade-enter-active,.pop-fade-leave-active{transition:opacity .2s, transform .25s cubic-bezier(0.25,.1,.25,1);}
.pop-fade-enter-from,.pop-fade-leave-to{opacity:0;transform:scale(.96);}
</style>
