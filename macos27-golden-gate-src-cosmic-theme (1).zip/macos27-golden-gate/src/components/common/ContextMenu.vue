<script setup lang="ts">
/**
 * 全局右键菜单（毛玻璃）
 */
import { useUIStore, type ContextMenuItem } from '@/stores/ui'
const ui = useUIStore()

function handleClick(item: ContextMenuItem) {
  if (item.disabled) return
  item.action?.()
  ui.closeContextMenu()
}
</script>

<template>
  <Teleport to="body">
    <Transition name="ctx-fade">
      <div
        v-if="ui.contextMenu"
        class="fixed min-w-[200px] py-1 rounded-[8px] text-[13px]"
        :style="{
          left: ui.contextMenu.x + 'px',
          top: ui.contextMenu.y + 'px',
          zIndex: 10000,
          background: 'var(--glass-bg)',
          backdropFilter: 'blur(20px) saturate(180%)',
          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
          border: '1px solid var(--glass-border)',
          boxShadow: '0 10px 30px rgba(0,0,0,0.25)'
        }"
        @contextmenu.prevent
      >
        <template v-for="(it, i) in ui.contextMenu.items" :key="i">
          <div v-if="it.separator" class="h-px my-1 bg-black/10 dark:bg-white/10" />
          <div
            v-else
            class="px-3 py-1 mx-1 rounded-[5px] flex items-center justify-between gap-6"
            :class="it.disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer hover:bg-[var(--hover-bg)]'"
            @click="handleClick(it)"
          >
            <span>{{ it.label }}</span>
            <span v-if="it.shortcut" class="text-[11px] opacity-60">{{ it.shortcut }}</span>
          </div>
        </template>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.ctx-fade-enter-active,.ctx-fade-leave-active{transition:opacity .12s, transform .15s cubic-bezier(0.25,.1,.25,1);}
.ctx-fade-enter-from,.ctx-fade-leave-to{opacity:0;transform:translateY(-4px) scale(.98);}
</style>
