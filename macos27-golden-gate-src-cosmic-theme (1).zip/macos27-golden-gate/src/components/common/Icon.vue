<script setup lang="ts">
import { computed } from 'vue'
// Remix Icon（webfont）：覆盖单色系统图标，ri- 前缀（作为 Fluent 缺失时的回退）
import '@/assets/remixicon/remixicon.css'
// 外部 SVG 图标库（gitcode 等独立 SVG 文件），命名约定 gc-<key>
import launchpadGcUrl from '@/assets/icons/launchpad-gitcode.svg'
// Fluent 图标映射表：ri-* 名 -> Fluent symbolic 基础名（由 build 脚本生成）
import fluentMap from '@/assets/fluent/map.json'

// Fluent symbolic SVG（单色，以 mask + currentColor 渲染，贴合玻璃单色风）
// 由 urls.ts 显式引入（自动生成，规避 glob 相对路径解析问题）
import fluentUrls from '@/assets/fluent/urls'

const props = withDefaults(defineProps<{
  name: string; size?: number; color?: string; className?: string
}>(), { size: 20, color: 'currentColor', className: '' })

// 外部 SVG 图标映射表
const externalIcons: Record<string, string> = {
  'gc-launchpad': launchpadGcUrl,
}

const isRemix = computed(() => props.name.startsWith('ri-'))
const isExternal = computed(() => props.name.startsWith('gc-'))
const externalSrc = computed(() => externalIcons[props.name] ?? '')

// Fluent：仅当 ri-* 命中映射时启用
const fluentTarget = computed(() => (isRemix.value ? (fluentMap as Record<string, string>)[props.name] : undefined))
const fluentUrl = computed(() => (fluentTarget.value ? fluentUrls[fluentTarget.value] : ''))
const useFluent = computed(() => isRemix.value && !!fluentUrl.value)

const style = computed<Record<string, string>>(() => {
  const s: Record<string, string> = { color: props.color }
  if (isRemix.value) {
    // Remix 是 webfont，用 font-size 控制尺寸
    s.fontSize = `${props.size}px`
    s.lineHeight = '1'
    s.display = 'inline-block'
  } else {
    s.width = `${props.size}px`
    s.height = `${props.size}px`
  }
  return s
})

// Fluent 单色渲染：用 SVG 作 mask，背景色取 currentColor，从而可染色且保持单色轮廓
const fluentStyle = computed<Record<string, string>>(() => ({
  width: `${props.size}px`,
  height: `${props.size}px`,
  backgroundColor: props.color,
  display: 'inline-block',
  verticalAlign: 'middle',
  maskImage: `url("${fluentUrl.value}")`,
  webkitMaskImage: `url("${fluentUrl.value}")`,
  maskRepeat: 'no-repeat',
  webkitMaskRepeat: 'no-repeat',
  maskSize: 'contain',
  webkitMaskSize: 'contain',
  maskPosition: 'center',
  webkitMaskPosition: 'center',
}))
</script>

<template>
  <!-- 1) Fluent symbolic 图标（命中映射的 ri-* 系统图标，单色可染色） -->
  <i v-if="useFluent" class="fluent-icon" :class="className" :style="fluentStyle" aria-hidden="true" />
  <!-- 2) Remix Icon（webfont，ri- 前缀；Fluent 未覆盖时回退） -->
  <i v-else-if="isRemix" :class="[name, className]" :style="style" aria-hidden="true" />
  <!-- 3) 外部 SVG 图标库（gitcode 等，gc- 前缀） -->
  <img v-else-if="isExternal" :src="externalSrc" :style="style" :class="className" aria-hidden="true" />
  <!-- 4) 手绘内联 SVG（macOS 专属 / 品牌图标兜底） -->
  <svg v-else :style="style" :class="className" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" fill="currentColor" aria-hidden="true">
    <!-- Apple -->
    <g v-if="name==='apple'">
      <path d="M43 18c-1.5 1.7-3.8 3-6 2.8-.2-2.3.9-4.7 2.3-6.2 1.5-1.6 4-2.8 6-2.9.2 2.4-.8 4.6-2.3 6.3z" fill="currentColor"/>
      <path d="M49 32.5c0-5 4-7.5 4.3-7.7-2.3-3.4-6-3.9-7.3-4-3.1-.3-6 1.8-7.6 1.8s-4-1.8-6.6-1.7c-3.4 0-6.5 2-8.2 5-3.5 6-0.9 14.9 2.5 19.8 1.7 2.4 3.7 5.1 6.3 5 2.5-.1 3.5-1.6 6.5-1.6s3.9 1.6 6.6 1.6c2.7 0 4.4-2.4 6.1-4.8 1.9-2.7 2.7-5.4 2.7-5.5-.1-.1-5.3-2-5.3-7.9z" fill="currentColor"/>
    </g>
    <!-- Finder (笑脸 + 蓝白脸) -->
    <g v-else-if="name==='finder'">
      <rect x="4" y="4" width="56" height="56" rx="12" fill="#5AA8FF"/>
      <path d="M18 28v10c0 8 6 14 14 14s14-6 14-14V28z" fill="#fff"/>
      <path d="M26 24a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm12 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" fill="#000"/>
      <path d="M24 36c2-2 6-3 8-3s6 1 8 3-3 3-8 3-10-1-8-3z" fill="#000"/>
      <path d="M22 16l-4 8h4zM42 16l4 8h-4z" fill="#fff"/>
    </g>
    <!-- 火箭 Launchpad -->
    <g v-else-if="name==='launchpad'">
      <rect x="4" y="4" width="56" height="56" rx="14" fill="#A0A0A5"/>
      <g fill="#fff">
        <rect x="20" y="22" width="6" height="6" rx="1"/>
        <rect x="30" y="22" width="6" height="6" rx="1"/>
        <rect x="40" y="22" width="6" height="6" rx="1"/>
        <rect x="20" y="30" width="6" height="6" rx="1"/>
        <rect x="30" y="30" width="6" height="6" rx="1"/>
        <rect x="40" y="30" width="6" height="6" rx="1"/>
        <rect x="20" y="38" width="6" height="6" rx="1"/>
        <rect x="30" y="38" width="6" height="6" rx="1"/>
        <rect x="40" y="38" width="6" height="6" rx="1"/>
      </g>
    </g>
    <!-- Safari 罗盘 -->
    <g v-else-if="name==='safari'">
      <circle cx="32" cy="32" r="28" fill="#1C7BEC"/>
      <circle cx="32" cy="32" r="24" fill="#fff"/>
      <circle cx="32" cy="32" r="22" fill="#E8EEF4"/>
      <path d="M32 14L28 32l20-8L32 14z" fill="#FF3B30"/>
      <path d="M32 50l4-18-20 8 16 10z" fill="#fff" stroke="#ccc" stroke-width="0.5"/>
      <circle cx="32" cy="32" r="2" fill="#333"/>
    </g>
    <!-- 邮件 -->
    <g v-else-if="name==='mail'">
      <rect x="6" y="14" width="52" height="36" rx="6" fill="#34A7FF"/>
      <path d="M6 20l26 16L58 20" stroke="#fff" stroke-width="2" fill="none"/>
      <path d="M6 18l20 16M58 18L44 34" stroke="#fff" stroke-width="1.5" fill="none" opacity="0.5"/>
    </g>
    <!-- 信息 -->
    <g v-else-if="name==='messages'">
      <rect x="6" y="8" width="52" height="40" rx="12" fill="#5BE25B"/>
      <path d="M14 48l8-8h24" fill="#5BE25B"/>
      <path d="M20 24h24M20 30h16" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
    </g>
    <!-- 地图 -->
    <g v-else-if="name==='maps'">
      <rect x="4" y="4" width="56" height="56" rx="12" fill="#E8F0E8"/>
      <path d="M8 20l16-6 16 6 16-6v32l-16 6-16-6-16 6z" fill="#A8D8A8"/>
      <path d="M24 20v28M40 20v28" stroke="#6BA86B" stroke-width="1"/>
      <path d="M32 16c-4 0-7 3-7 7 0 6 7 14 7 14s7-8 7-14c0-4-3-7-7-7z" fill="#FF3B30"/>
      <circle cx="32" cy="23" r="2.5" fill="#fff"/>
    </g>
    <!-- 照片 -->
    <g v-else-if="name==='photos'">
      <rect x="4" y="4" width="56" height="56" rx="12" fill="#fff"/>
      <g>
        <circle cx="32" cy="20" r="8" fill="#FFCC00"/>
        <circle cx="46" cy="32" r="8" fill="#FF9500"/>
        <circle cx="32" cy="44" r="8" fill="#FF3B30"/>
        <circle cx="18" cy="32" r="8" fill="#AF52DE"/>
        <circle cx="26" cy="24" r="8" fill="#FF2D55"/>
        <circle cx="38" cy="24" r="8" fill="#34C759"/>
        <circle cx="38" cy="40" r="8" fill="#0A84FF"/>
        <circle cx="26" cy="40" r="8" fill="#5AC8FA"/>
      </g>
    </g>
    <!-- 音乐 -->
    <g v-else-if="name==='music'">
      <rect x="4" y="4" width="56" height="56" rx="12" fill="#FA233B"/>
      <path d="M26 18l16-4v22a8 8 0 1 1-4-7V22l-10 3v18a8 8 0 1 1-4-7V18z" fill="#fff"/>
    </g>
    <!-- 日历 -->
    <g v-else-if="name==='calendar'">
      <rect x="6" y="8" width="52" height="48" rx="6" fill="#fff"/>
      <rect x="6" y="8" width="52" height="12" rx="6" fill="#F5F5F5"/>
      <text x="32" y="44" text-anchor="middle" font-size="22" font-weight="700" fill="#FF3B30">3</text>
      <rect x="14" y="11" width="2" height="6" rx="1" fill="#FF3B30"/>
      <rect x="48" y="11" width="2" height="6" rx="1" fill="#FF3B30"/>
    </g>
    <!-- 备忘录 -->
    <g v-else-if="name==='notes'">
      <rect x="8" y="6" width="48" height="52" rx="4" fill="#FCE68A"/>
      <rect x="8" y="6" width="48" height="12" fill="#F7D74A"/>
      <rect x="14" y="26" width="36" height="2" fill="#C9A71F"/>
      <rect x="14" y="34" width="36" height="2" fill="#C9A71F"/>
      <rect x="14" y="42" width="24" height="2" fill="#C9A71F"/>
    </g>
    <!-- 设置 -->
    <g v-else-if="name==='settings'">
      <rect x="4" y="4" width="56" height="56" rx="14" fill="#8E8E93"/>
      <g fill="#D1D1D6">
        <circle cx="32" cy="32" r="10"/>
        <rect x="30" y="8" width="4" height="10" rx="2"/>
        <rect x="30" y="46" width="4" height="10" rx="2"/>
        <rect x="8" y="30" width="10" height="4" rx="2"/>
        <rect x="46" y="30" width="10" height="4" rx="2"/>
        <rect x="15" y="15" width="10" height="4" rx="2" transform="rotate(45 20 17)"/>
        <rect x="40" y="40" width="10" height="4" rx="2" transform="rotate(45 45 42)"/>
        <rect x="39" y="15" width="10" height="4" rx="2" transform="rotate(-45 44 17)"/>
        <rect x="15" y="40" width="10" height="4" rx="2" transform="rotate(-45 20 42)"/>
      </g>
      <circle cx="32" cy="32" r="4" fill="#8E8E93"/>
    </g>
    <!-- 废纸篓 -->
    <g v-else-if="name==='trash'">
      <rect x="12" y="18" width="40" height="36" rx="4" fill="#B0BEC5"/>
      <rect x="8" y="14" width="48" height="6" rx="2" fill="#90A4AE"/>
      <rect x="24" y="10" width="16" height="4" rx="2" fill="#90A4AE"/>
      <path d="M22 24v24M32 24v24M42 24v24" stroke="#78909C" stroke-width="2"/>
    </g>
    <!-- 文件夹 -->
    <g v-else-if="name==='folder'">
      <path d="M8 20a4 4 0 0 1 4-4h12l4 4h20a4 4 0 0 1 4 4v24a4 4 0 0 1-4 4H12a4 4 0 0 1-4-4V20z" fill="#65B3FF"/>
      <path d="M8 24h48v20a4 4 0 0 1-4 4H12a4 4 0 0 1-4-4V24z" fill="#4799E8"/>
    </g>
    <!-- 文件 -->
    <g v-else-if="name.startsWith('file')">
      <path d="M16 8h24l12 12v32a4 4 0 0 1-4 4H16a4 4 0 0 1-4-4V12a4 4 0 0 1 4-4z" fill="#fff" stroke="#C8C8CC" stroke-width="1"/>
      <path d="M40 8v12h12" fill="#E8E8ED"/>
      <rect v-if="name==='file-doc'" x="18" y="28" width="28" height="3" fill="#559"/>
      <rect v-if="name==='file-doc'" x="18" y="34" width="28" height="2" fill="#aaa"/>
      <rect v-if="name==='file-doc'" x="18" y="40" width="22" height="2" fill="#aaa"/>
      <rect v-if="name==='file-image'" x="18" y="28" width="28" height="20" fill="#65B3FF"/>
      <circle v-if="name==='file-image'" cx="26" cy="34" r="3" fill="#FFD700"/>
      <path v-if="name==='file-image'" d="M18 48l10-10 8 8 10-10v10H18z" fill="#4CD964"/>
    </g>
    <!-- 通用文稿（Finder 中非文件夹/图片文件的兜底图标） -->
    <g v-else-if="name==='doc'">
      <path d="M16 8h24l12 12v32a4 4 0 0 1-4 4H16a4 4 0 0 1-4-4V12a4 4 0 0 1 4-4z" fill="#fff" stroke="#C8C8CC" stroke-width="1"/>
      <path d="M40 8v12h12" fill="#E8E8ED"/>
      <rect x="18" y="28" width="28" height="3" rx="1" fill="#8E8E93"/>
      <rect x="18" y="35" width="28" height="2" rx="1" fill="#C7C7CC"/>
      <rect x="18" y="41" width="20" height="2" rx="1" fill="#C7C7CC"/>
    </g>
    <!-- 显示器亮度（控制中心 / 设置-显示器） -->
    <g v-else-if="name==='brightness'">
      <circle cx="32" cy="32" r="9" fill="currentColor"/>
      <g stroke="currentColor" stroke-width="3.5" stroke-linecap="round" opacity="0.85">
        <line x1="32" y1="6" x2="32" y2="14"/>
        <line x1="32" y1="50" x2="32" y2="58"/>
        <line x1="6" y1="32" x2="14" y2="32"/>
        <line x1="50" y1="32" x2="58" y2="32"/>
        <line x1="14" y1="14" x2="20" y2="20"/>
        <line x1="44" y1="44" x2="50" y2="50"/>
        <line x1="14" y1="50" x2="20" y2="44"/>
        <line x1="44" y1="20" x2="50" y2="14"/>
      </g>
    </g>
    <!-- 音符（菜单栏 / 音乐） -->
    <g v-else-if="name==='music-note'">
      <path d="M24 46a7 7 0 1 1-4-6.3V16l24-5v25.7a7 7 0 1 1-4-6.3V20l-16 3.3z" fill="currentColor"/>
    </g>
    <!-- Spotlight 放大镜（菜单栏） -->
    <g v-else-if="name==='spotlight'">
      <circle cx="27" cy="27" r="15" fill="none" stroke="currentColor" stroke-width="4.5"/>
      <path d="M38 38l14 14" stroke="currentColor" stroke-width="6" stroke-linecap="round"/>
      <path d="M21 22a8 8 0 0 1 7-5" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round" opacity="0.55"/>
    </g>
    <!-- 程序坞分隔线 -->
    <g v-else-if="name==='divider'">
      <rect x="30" y="10" width="3" height="44" rx="1.5" fill="currentColor" opacity="0.45"/>
    </g>
    <!-- 菜单图标通用 -->
    <g v-else-if="name==='search'"><circle cx="26" cy="26" r="12" fill="none" stroke="currentColor" stroke-width="4"/><path d="M36 36l12 12" stroke="currentColor" stroke-width="5" stroke-linecap="round"/></g>
    <g v-else-if="name==='wifi'"><path d="M32 48a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" fill="currentColor"/><path d="M14 28a24 24 0 0 1 36 0" stroke="currentColor" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M21 36a14 14 0 0 1 22 0" stroke="currentColor" stroke-width="4" fill="none" stroke-linecap="round"/></g>
    <g v-else-if="name==='bluetooth'"><path d="M32 10v44M32 10l16 18-16 14M32 28l12 10" stroke="currentColor" stroke-width="3" fill="none" stroke-linejoin="round"/></g>
    <g v-else-if="name==='battery'"><rect x="8" y="22" width="42" height="20" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><rect x="50" y="28" width="4" height="8" rx="1" fill="currentColor"/><rect x="11" y="25" width="30" height="14" rx="1" fill="currentColor"/></g>
    <g v-else-if="name==='volume'"><path d="M14 24h10l12-10v36L24 40H14z" fill="currentColor"/><path d="M42 22a14 14 0 0 1 0 20" stroke="currentColor" stroke-width="3" fill="none"/></g>
    <g v-else-if="name==='volume-muted'"><path d="M14 24h10l12-10v36L24 40H14z" fill="currentColor"/><path d="M40 24l12 12M52 24L40 36" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></g>
    <g v-else-if="name==='control-center'"><circle cx="22" cy="22" r="10" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="42" cy="22" r="10" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="22" cy="42" r="10" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="42" cy="42" r="10" fill="currentColor"/></g>
    <g v-else-if="name==='siri'"><circle cx="32" cy="32" r="20" fill="#FF3B30"/><circle cx="26" cy="28" r="3" fill="#fff"/><circle cx="38" cy="28" r="3" fill="#fff"/><path d="M24 38c4 4 12 4 16 0" stroke="#fff" stroke-width="2.5" fill="none" stroke-linecap="round"/></g>
    <g v-else-if="name==='sun'"><circle cx="32" cy="32" r="10" fill="currentColor"/><g stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="32" y1="8" x2="32" y2="16"/><line x1="32" y1="48" x2="32" y2="56"/><line x1="8" y1="32" x2="16" y2="32"/><line x1="48" y1="32" x2="56" y2="32"/><line x1="14" y1="14" x2="20" y2="20"/><line x1="44" y1="44" x2="50" y2="50"/><line x1="14" y1="50" x2="20" y2="44"/><line x1="44" y1="20" x2="50" y2="14"/></g></g>
    <g v-else-if="name==='moon'"><path d="M42 34a16 16 0 0 1-16-20 18 18 0 1 0 16 20z" fill="currentColor"/></g>
    <g v-else-if="name==='close-x'"><path d="M18 18l28 28M46 18L18 46" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></g>
    <g v-else-if="name==='minus'"><line x1="18" y1="32" x2="46" y2="32" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></g>
    <g v-else-if="name==='maximize'"><path d="M18 20h26v26H18z" fill="none" stroke="currentColor" stroke-width="2.5"/></g>
    <g v-else-if="name==='plus'"><line x1="32" y1="18" x2="32" y2="46" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><line x1="18" y1="32" x2="46" y2="32" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></g>
    <g v-else-if="name==='chevron-left'"><path d="M38 18L22 32l16 14" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></g>
    <g v-else-if="name==='chevron-right'"><path d="M26 18l16 14-16 14" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></g>
    <g v-else-if="name==='user'"><circle cx="32" cy="26" r="10" fill="#C8C8CC"/><path d="M12 54c2-10 10-16 20-16s18 6 20 16" fill="#C8C8CC"/></g>
    <g v-else-if="name==='airdrop'"><circle cx="32" cy="32" r="22" fill="none" stroke="currentColor" stroke-width="3"/><path d="M32 20l-10 14h6v8h8v-8h6z" fill="currentColor"/></g>
    <g v-else-if="name==='focus'"><path d="M32 10l6 16 16 2-12 12 4 16-14-8-14 8 4-16-12-12 16-2z" fill="currentColor"/></g>
    <g v-else-if="name==='play'"><path d="M22 16v32l24-16z" fill="currentColor"/></g>
    <g v-else-if="name==='pause'"><rect x="20" y="18" width="8" height="28" fill="currentColor"/><rect x="36" y="18" width="8" height="28" fill="currentColor"/></g>
    <g v-else-if="name==='skip-backward'"><path d="M14 16v32h6V32l16 16V16L20 32V16z" fill="currentColor"/></g>
    <g v-else-if="name==='skip-forward'"><path d="M50 16v32h-6V32L28 48V16l16 16V16z" fill="currentColor"/></g>
    <g v-else-if="name==='refresh'"><path d="M48 32a16 16 0 1 1-5-11.5" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M48 14v8h-8" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/></g>
    <g v-else-if="name==='share'"><path d="M32 10v28M20 22l12-12 12 12M14 36v12a4 4 0 0 0 4 4h28a4 4 0 0 0 4-4V36" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></g>
    <g v-else-if="name==='sidebar-left'"><rect x="10" y="14" width="44" height="36" rx="3" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="10" y="14" width="14" height="36" fill="currentColor"/></g>
    <g v-else-if="name==='shield'"><path d="M32 8l18 6v14c0 14-8 22-18 28-10-6-18-14-18-28V14z" fill="currentColor"/></g>
    <g v-else-if="name==='display'"><rect x="8" y="12" width="48" height="32" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M24 48h16M32 44v4" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></g>
    <g v-else-if="name==='keyboard'"><rect x="8" y="16" width="48" height="32" rx="4" fill="none" stroke="currentColor" stroke-width="3"/><g fill="currentColor"><circle cx="18" cy="28" r="2"/><circle cx="26" cy="28" r="2"/><circle cx="34" cy="28" r="2"/><circle cx="42" cy="28" r="2"/><circle cx="22" cy="36" r="2"/><circle cx="30" cy="36" r="2"/><circle cx="38" cy="36" r="2"/><rect x="42" y="34" width="8" height="4" rx="1"/></g></g>
    <g v-else-if="name==='trash-empty'"><g><rect x="12" y="18" width="40" height="36" rx="4" fill="#B0BEC5"/><rect x="8" y="14" width="48" height="6" rx="2" fill="#90A4AE"/></g></g>
    <g v-else-if="name==='preview'"><rect x="8" y="10" width="48" height="44" rx="4" fill="#fff" stroke="#aaa" stroke-width="1"/><circle cx="24" cy="26" r="6" fill="#5AC8FA"/><rect x="14" y="36" width="36" height="12" fill="#4CD964"/></g>
    <!-- Calculator -->
    <g v-else-if="name==='calculator'">
      <rect x="10" y="6" width="44" height="52" rx="8" fill="#1C1C1E"/>
      <rect x="14" y="10" width="36" height="10" rx="2" fill="#000"/>
      <text x="48" y="18" text-anchor="end" font-size="7" fill="#fff">0</text>
      <g fill="#505050">
        <circle cx="18" cy="26" r="3"/><circle cx="26" cy="26" r="3"/><circle cx="34" cy="26" r="3"/>
        <circle cx="18" cy="33" r="3"/><circle cx="26" cy="33" r="3"/><circle cx="34" cy="33" r="3"/>
        <circle cx="18" cy="40" r="3"/><circle cx="26" cy="40" r="3"/><circle cx="34" cy="40" r="3"/>
        <circle cx="18" cy="47" r="3"/><circle cx="26" cy="47" r="3"/>
      </g>
      <g fill="#FF9500">
        <circle cx="42" cy="26" r="3"/><circle cx="42" cy="33" r="3"/><circle cx="42" cy="40" r="3"/><circle cx="42" cy="47" r="3"/>
      </g>
    </g>
    <!-- Terminal -->
    <g v-else-if="name==='terminal'">
      <rect x="6" y="10" width="52" height="44" rx="6" fill="#1E1E1E"/>
      <rect x="6" y="10" width="52" height="10" rx="6" fill="#2D2D2D"/>
      <circle cx="12" cy="15" r="1.5" fill="#FF5F57"/>
      <circle cx="17" cy="15" r="1.5" fill="#FEBC2E"/>
      <circle cx="22" cy="15" r="1.5" fill="#28C840"/>
      <text x="10" y="28" font-family="monospace" font-size="6" fill="#fff">user@mac:~$</text>
      <rect x="10" y="30" width="2" height="3" fill="#fff"/>
    </g>
    <!-- Clarus the Dogcow（彩蛋） -->
    <g v-else-if="name==='clarus'">
      <ellipse cx="32" cy="38" rx="18" ry="10" fill="#5D3A1A"/>
      <rect x="44" y="22" width="10" height="14" rx="3" fill="#5D3A1A"/>
      <ellipse cx="30" cy="28" rx="12" ry="8" fill="#7B4D26"/>
      <circle cx="46" cy="28" r="1.2" fill="#000"/>
      <rect x="18" y="44" width="3" height="8" fill="#5D3A1A"/>
      <rect x="28" y="44" width="3" height="8" fill="#5D3A1A"/>
      <rect x="38" y="44" width="3" height="8" fill="#5D3A1A"/>
      <rect x="46" y="44" width="3" height="8" fill="#5D3A1A"/>
      <rect x="50" y="20" width="2" height="4" fill="#5D3A1A"/>
      <text x="32" y="60" text-anchor="middle" font-size="6" fill="#5D3A1A" font-weight="700">Moof!</text>
    </g>
    <!-- 默认 -->
    <g v-else>
      <rect x="8" y="8" width="48" height="48" rx="10" fill="#8E8E93"/>
      <text x="32" y="38" text-anchor="middle" font-size="12" fill="#fff">?</text>
    </g>
  </svg>
</template>
