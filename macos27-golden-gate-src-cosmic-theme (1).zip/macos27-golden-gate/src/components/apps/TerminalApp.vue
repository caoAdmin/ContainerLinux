<script setup lang="ts">
/**
 * 终端 Terminal（演示）
 */
import { ref, nextTick, onMounted } from 'vue'
import { uid } from '@/utils'

interface Line { id: string; kind: 'out' | 'in' | 'prompt'; text: string }
const lines = ref<Line[]>([
  { id: uid('l'), kind: 'out', text: 'Last login: ' + new Date().toLocaleString('zh-CN') },
  { id: uid('l'), kind: 'prompt', text: 'user@mac ~ %' }
])
const input = ref('')
const termEl = ref<HTMLDivElement | null>(null)

function exec(cmd: string) {
  lines.value.push({ id: uid('l'), kind: 'in', text: cmd })
  let out = ''
  const c = cmd.trim()
  if (c === 'help') out = '可用命令: help, ls, pwd, whoami, date, echo <text>, clear, neofetch'
  else if (c === 'ls') out = 'Desktop   Documents  Downloads  Pictures  GoldenGate.app'
  else if (c === 'pwd') out = '/Users/user'
  else if (c === 'whoami') out = 'user'
  else if (c === 'date') out = new Date().toString()
  else if (c.startsWith('echo ')) out = c.slice(5)
  else if (c === 'clear') { lines.value = [] }
  else if (c === 'neofetch') { out = '\n        .--.          user@mac\n       |o_o |         ---------\n       |:_/ |         OS: macOS 27 Golden Gate (demo)\n      //   \\ \\        Shell: zsh\n     (|     | )       Resolution: ' + window.innerWidth + 'x' + window.innerHeight + '\n    /\'\\_   _/`\\\n    \\___)=(___/' }
  else if (c === '') out = ''
  else out = 'zsh: command not found: ' + c
  if (out) lines.value.push({ id: uid('l'), kind: 'out', text: out })
  lines.value.push({ id: uid('l'), kind: 'prompt', text: 'user@mac ~ %' })
}

function onKey(e: KeyboardEvent) {
  if (e.key === 'Enter') {
    e.preventDefault()
    exec(input.value)
    input.value = ''
    nextTick(() => { termEl.value?.scrollTo(0, termEl.value.scrollHeight) })
  }
}
onMounted(() => nextTick(() => termEl.value?.scrollTo(0, termEl.value.scrollHeight)))
</script>

<template>
  <div ref="termEl" class="h-full w-full overflow-auto p-3 font-mono text-[12px] leading-relaxed"
    style="background:rgba(0,0,0,0.88); color:#30D158;"
    @click="$event.target === $event.currentTarget && ($refs.input as HTMLInputElement)?.focus()">
    <div v-for="l in lines" :key="l.id" class="whitespace-pre-wrap">
      <span v-if="l.kind==='prompt'" class="text-white">{{ l.text }} </span>
      <span v-else>{{ l.text }}</span>
    </div>
    <div class="flex">
      <span class="text-white">user@mac ~ % </span>
      <input
        ref="input"
        v-model="input"
        class="flex-1 bg-transparent outline-none text-[#30D158] font-mono"
        autofocus
        @keydown="onKey"
      />
    </div>
  </div>
</template>
