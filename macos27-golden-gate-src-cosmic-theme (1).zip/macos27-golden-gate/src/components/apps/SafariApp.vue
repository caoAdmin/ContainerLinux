<script setup lang="ts">
/**
 * Safari 浏览器
 * - 标签页栏：新建/关闭/切换
 * - 地址栏、前进/后退
 * - 书签栏；无网络时显示内置默认起始页
 */
import { ref, computed } from 'vue'
import Icon from '@/components/common/Icon.vue'

interface Tab { id: string; title: string; url: string; active: boolean }

const tabs = ref<Tab[]>([
  { id: 't1', title: '起始页', url: 'favorites://start', active: true },
  { id: 't2', title: 'Apple', url: 'https://www.apple.com/', active: false }
])
const addressInput = ref('')

const active = computed(() => tabs.value.find((t) => t.active) ?? tabs.value[0])

function select(id: string) {
  tabs.value.forEach((t) => t.active = t.id === id)
  addressInput.value = active.value.url
}
function newTab() {
  const id = 't' + Date.now()
  tabs.value.forEach((t) => t.active = false)
  tabs.value.push({ id, title: '新建标签页', url: 'favorites://start', active: true })
  addressInput.value = 'favorites://start'
}
function closeTab(id: string) {
  const idx = tabs.value.findIndex((t) => t.id === id)
  if (idx < 0) return
  tabs.value.splice(idx, 1)
  if (tabs.value.length === 0) {
    tabs.value.push({ id:'t'+Date.now(), title:'起始页', url:'favorites://start', active:true })
  }
  tabs.value[Math.max(0, idx-1)].active = true
  addressInput.value = active.value.url
}
function go(e: Event) {
  e.preventDefault()
  if (active.value) {
    active.value.url = addressInput.value
    active.value.title = addressInput.value.replace(/^https?:\/\//, '').split('/')[0] || '起始页'
  }
}
function back() {}
function fwd() {}

const favorites = [
  { name: 'Apple', url: 'https://www.apple.com', color: '#000' },
  { name: 'GitHub', url: 'https://github.com', color: '#24292e' },
  { name: 'Wikipedia', url: 'https://wikipedia.org', color: '#000' },
  { name: 'Bilibili', url: 'https://bilibili.com', color: '#FB7299' }
]
</script>

<template>
  <div class="flex flex-col h-full w-full">
    <!-- 标签页栏 -->
    <div class="flex items-end gap-1 px-2 h-9 overflow-hidden" style="background: var(--toolbar-bg); border-bottom:1px solid var(--divider);">
      <button
        v-for="t in tabs" :key="t.id"
        class="group flex items-center gap-2 px-3 h-7 max-w-[200px] rounded-t-[8px] text-[12px] transition-colors"
        :class="t.active ? 'bg-[var(--tab-active-bg)] shadow-sm' : 'opacity-70 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/5'"
        @click="select(t.id)"
      >
        <Icon name="safari" :size="12" />
        <span class="truncate flex-1">{{ t.title }}</span>
        <button class="opacity-0 group-hover:opacity-100 w-4 h-4 rounded-full hover:bg-black/10 flex items-center justify-center"
          @click.stop="closeTab(t.id)">
          <Icon name="ri-close-line" :size="8" />
        </button>
      </button>
      <button class="w-6 h-6 rounded-full hover:bg-black/10 dark:hover:bg-white/10 flex items-center justify-center ml-1"
        @click="newTab" aria-label="新建标签页">
        <Icon name="ri-add-line" :size="12" />
      </button>
    </div>

    <!-- 地址栏 -->
    <div class="flex items-center gap-2 h-[40px] px-3" style="border-bottom:1px solid var(--divider);" data-no-drag>
      <button class="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-60" @click="back"><Icon name="ri-arrow-left-s-line" :size="16" /></button>
      <button class="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-60" @click="fwd"><Icon name="ri-arrow-right-s-line" :size="16" /></button>
      <form class="flex-1 flex items-center gap-2 h-6 px-3 rounded-[6px] text-[12px] bg-black/5 dark:bg-white/10" @submit="go">
        <Icon name="ri-search-line" :size="12" />
        <input v-model="addressInput" class="flex-1 bg-transparent outline-none" placeholder="搜索或输入网站名称" />
      </form>
    </div>

    <!-- 书签栏 -->
    <div class="flex items-center gap-3 h-7 px-3 text-[11px] overflow-x-auto" style="background: var(--toolbar-bg); border-bottom:1px solid var(--divider);">
      <span v-for="f in favorites" :key="f.name" class="opacity-80 hover:opacity-100 cursor-pointer whitespace-nowrap"
        @click="() => { if(active) { active.url=f.url; active.title=f.name; addressInput=f.url } }">
        {{ f.name }}
      </span>
    </div>

    <!-- 内容：内置起始页 -->
    <div class="flex-1 overflow-auto p-8" v-if="active && active.url.startsWith('favorites://')"
      style="background: linear-gradient(180deg,#f6f6f8,#e9e9ef);">
      <div class="max-w-[640px] mx-auto">
        <div class="text-[28px] font-semibold mb-6">个人收藏</div>
        <div class="grid grid-cols-4 gap-4">
          <div v-for="f in favorites" :key="f.name"
            class="flex flex-col items-center gap-2 cursor-pointer hover:scale-105 transition-transform"
            @click="() => { if(active) { active.url=f.url; active.title=f.name; addressInput=f.url } }">
            <div class="w-14 h-14 rounded-[12px] flex items-center justify-center text-white font-semibold text-[18px]"
              :style="{ background: f.color }">{{ f.name[0] }}</div>
            <span class="text-[12px]">{{ f.name }}</span>
          </div>
        </div>
        <div class="text-[11px] opacity-60 mt-10 text-center">
          Safari 仅为演示：实际网页不会加载，点击书签会切换到对应 URL 标签。
        </div>
      </div>
    </div>
    <div v-else class="flex-1 flex items-center justify-center text-[13px] opacity-60 p-8 text-center">
      无网络环境，无法加载 {{ active?.url }}<br />返回「起始页」体验内置内容。
    </div>
  </div>
</template>

<style scoped>
:root { --tab-active-bg: rgba(255,255,255,0.8); }
:root.dark { --tab-active-bg: rgba(60,60,64,0.8); }
</style>
