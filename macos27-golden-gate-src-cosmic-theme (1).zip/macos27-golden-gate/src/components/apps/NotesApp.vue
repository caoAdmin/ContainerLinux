<script setup lang="ts">
/**
 * 备忘录 Notes
 * - 左侧笔记列表 + 右侧编辑区
 * - localStorage 持久化
 * - 标题自动取首行
 */
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import Icon from '@/components/common/Icon.vue'
import { uid } from '@/utils'

interface Note { id: string; content: string; updated: number }

const STORAGE_KEY = 'macos27-notes'
const notes = ref<Note[]>([])
const activeId = ref<string | null>(null)

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) notes.value = JSON.parse(raw)
  } catch { /* ignore */ }
  if (notes.value.length === 0) {
    notes.value = [
      { id: uid('note'), content: '欢迎使用备忘录\n\n这是 macOS 27 Golden Gate 的备忘录复刻。开始输入吧……', updated: Date.now() }
    ]
    activeId.value = notes.value[0].id
    save()
  }
  if (!activeId.value) activeId.value = notes.value[0]?.id ?? null
}
function save() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(notes.value)) } catch { /* ignore */ }
}
/* 输入时不要每个字符都同步写一次 localStorage（阻塞主线程，长笔记会明显卡顿）：
   立即写改成 350ms 去抖；显式动作（新建/删除）仍走同步 save。 */
let saveTimer = 0
function scheduleSave() {
  window.clearTimeout(saveTimer)
  saveTimer = window.setTimeout(save, 350)
}

const active = computed(() => notes.value.find((n) => n.id === activeId.value) ?? null)
function titleOf(n: Note) {
  const first = n.content.split('\n')[0]?.trim()
  return first || '新建备忘录'
}
function previewOf(n: Note) {
  const lines = n.content.split('\n').slice(1).join(' ').trim()
  return lines.slice(0, 40) || '没有其他文本'
}
function timeOf(n: number) {
  const d = new Date(n)
  return `${d.getMonth()+1}月${d.getDate()}日 ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}
function newNote() {
  const n: Note = { id: uid('note'), content: '', updated: Date.now() }
  notes.value.unshift(n); activeId.value = n.id; save()
}
function delNote(id: string) {
  const idx = notes.value.findIndex((n) => n.id === id)
  if (idx >= 0) { notes.value.splice(idx, 1); activeId.value = notes.value[0]?.id ?? null; save() }
}

watch(notes, scheduleSave, { deep: true })
onMounted(load)
onUnmounted(() => { window.clearTimeout(saveTimer) })
</script>

<template>
  <div class="flex h-full w-full">
    <aside class="w-[220px] h-full flex flex-col" style="background:var(--sidebar-bg); border-right:1px solid var(--divider);">
      <div class="flex items-center justify-between px-3 py-2" style="border-bottom:1px solid var(--divider);">
        <div class="flex items-center gap-2"><Icon name="notes" :size="16" /><span class="text-[13px] font-medium">备忘录</span></div>
        <button class="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10" @click="newNote" aria-label="新建">
          <Icon name="ri-add-line" :size="14" />
        </button>
      </div>
      <div class="flex-1 overflow-auto">
        <button
          v-for="n in notes" :key="n.id"
          class="w-full text-left px-3 py-2 text-[13px] border-b border-black/5 dark:border-white/5"
          :class="activeId===n.id ? 'bg-[#F8D34A]/80 text-black' : 'hover:bg-black/5 dark:hover:bg-white/10'"
          @click="activeId = n.id"
        >
          <div class="flex items-center justify-between">
            <div class="font-medium truncate">{{ titleOf(n) }}</div>
            <button class="opacity-60 hover:opacity-100 text-[11px]" @click.stop="delNote(n.id)">×</button>
          </div>
          <div class="text-[11px] opacity-70 truncate">
            {{ timeOf(n.updated) }} · {{ previewOf(n) }}
          </div>
        </button>
      </div>
    </aside>
    <section class="flex-1 flex flex-col min-w-0 p-4">
      <div v-if="active" class="text-[11px] opacity-60 mb-2">{{ timeOf(active.updated) }}</div>
      <textarea
        v-if="active"
        v-model="active.content"
        class="flex-1 w-full resize-none bg-transparent outline-none text-[14px] leading-relaxed"
        placeholder="开始输入…"
      />
      <div v-else class="flex-1 flex items-center justify-center text-[13px] opacity-50">
        没有笔记。点左上角 ＋ 新建一条。
      </div>
    </section>
  </div>
</template>
