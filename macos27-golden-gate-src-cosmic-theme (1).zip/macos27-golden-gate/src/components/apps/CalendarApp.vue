<script setup lang="ts">
import { ref } from 'vue'
const today = new Date()
const year = today.getFullYear()
const month = today.getMonth()
const todayDate = today.getDate()
const firstDay = new Date(year, month, 1).getDay()
const daysInMonth = new Date(year, month + 1, 0).getDate()
const cells: (number | null)[] = []
for (let i = 0; i < firstDay; i++) cells.push(null)
for (let d = 1; d <= daysInMonth; d++) cells.push(d)
const weeks = ['日','一','二','三','四','五','六']
const monthNames = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月']
const selected = ref(todayDate)
</script>
<template>
  <div class="flex flex-col h-full p-4">
    <div class="text-[22px] font-semibold text-red-500 mb-1">{{ monthNames[month] }}</div>
    <div class="text-[13px] opacity-60 mb-4">{{ year }}年</div>
    <div class="grid grid-cols-7 gap-1 text-center text-[12px] opacity-60 mb-2">
      <div v-for="w in weeks" :key="w" class="py-1">{{ w }}</div>
    </div>
    <div class="grid grid-cols-7 gap-1 flex-1 text-[13px]">
      <template v-for="(d,i) in cells" :key="i">
        <div v-if="d===null"></div>
        <div v-else class="flex items-center justify-center rounded-full cursor-pointer h-8"
          :class="d===selected?'bg-[#FF3B30] text-white':(d===todayDate?'text-red-500 font-semibold':'hover:bg-[var(--hover-bg)]')"
          @click="selected=d">{{ d }}</div>
      </template>
    </div>
  </div>
</template>
