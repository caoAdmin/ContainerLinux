<script setup lang="ts">
import Icon from '@/components/common/Icon.vue'
</script>
<template>
  <div class="flex flex-col items-center justify-center h-full text-[14px] opacity-70">
    <Icon name="photos" :size="72" class="mb-4" />
    <div class="text-[18px] font-medium">照片</div>
    <div class="text-[12px] opacity-60 mt-1">图库正在同步…</div>
  </div>
</template>
