<script setup lang="ts">
import Icon from '@/components/common/Icon.vue'
</script>
<template>
  <div class="flex flex-col items-center justify-center h-full text-[14px] opacity-70">
    <Icon name="mail" :size="72" class="mb-4" />
    <div class="text-[18px] font-medium">邮件</div>
    <div class="text-[12px] opacity-60 mt-1">收件箱暂无新邮件</div>
  </div>
</template>
