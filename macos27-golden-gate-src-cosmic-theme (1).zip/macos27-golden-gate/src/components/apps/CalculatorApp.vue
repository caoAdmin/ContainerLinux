<script setup lang="ts">
/**
 * 计算器（演示用）
 */
import { ref } from 'vue'
const display = ref('0')

function press(k: string) {
  if (display.value === '0' || display.value === 'Error') display.value = ''
  display.value += k
}
function clear() { display.value = '0' }
function equals() {
  try {
    const expr = display.value.replace(/×/g, '*').replace(/÷/g, '/')
    // eslint-disable-next-line no-new-func
    const fn = new Function('return (' + expr + ')')
    display.value = String(fn())
  } catch {
    display.value = 'Error'
  }
}
const keys = [
  ['AC','±','%','÷'],
  ['7','8','9','×'],
  ['4','5','6','-'],
  ['1','2','3','+'],
  ['0','.','=']
]
</script>

<template>
  <div class="h-full flex flex-col p-2" style="background:#1C1C1E; color:#fff;">
    <div class="flex-1 flex items-end justify-end px-3 text-[36px] font-light overflow-hidden">{{ display }}</div>
    <div class="grid gap-1.5 p-1" style="grid-template-columns: repeat(4, 1fr);">
      <template v-for="(row, ri) in keys" :key="ri">
        <button
          v-for="(k, ki) in row" :key="k"
          class="h-11 rounded-full text-[18px] transition-colors"
          :class="ki === row.length-1 ? 'bg-[#FF9F0A] hover:brightness-110 text-white' : (ri===0 ? 'bg-[#505050] text-white' : 'bg-[#333] text-white hover:bg-[#444]')"
          :style="k==='0' ? 'grid-column: span 2; border-radius:999px;' : ''"
          @click="k==='AC' ? clear() : (k==='=' ? equals() : press(k))"
        >{{ k }}</button>
      </template>
    </div>
  </div>
</template>
