<script setup lang="ts">
import Icon from '@/components/common/Icon.vue'
</script>
<template>
  <div class="flex flex-col items-center justify-center h-full text-[14px] opacity-70 relative">
    <div class="absolute inset-0" style="background:linear-gradient(180deg,#a8d8e8 0%,#c8e8c8 60%,#e8dcb8 100%);"></div>
    <div class="relative z-10 flex flex-col items-center">
      <Icon name="maps" :size="72" class="mb-4" />
      <div class="text-[18px] font-medium text-white drop-shadow">地图</div>
      <div class="text-[12px] text-white/90 mt-1 drop-shadow">定位您的位置</div>
    </div>
  </div>
</template>
