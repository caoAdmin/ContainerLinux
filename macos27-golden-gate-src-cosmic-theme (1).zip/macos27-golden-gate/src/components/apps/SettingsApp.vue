<script setup lang="ts">
/**
 * 系统设置 Settings
 * - 左侧贴边侧边栏 edge-to-edge
 * - 外观：Liquid Glass 透明度滑块（三档吸附 + Clarus 彩蛋）
 * - 桌面与程序坞：Dock 大小/放大/自动隐藏
 * - 墙纸：Day/Evening 切换
 */
import { ref, computed, watch } from 'vue'
import { useSystemStore } from '@/stores/system'
import Icon from '@/components/common/Icon.vue'

const sys = useSystemStore()
const search = ref('')
const activePane = ref<'appearance' | 'dock' | 'wallpaper' | 'display' | 'sound' | 'battery' | 'keyboard' | 'privacy'>('appearance')

const panes: Array<{ id: typeof activePane.value; name: string; icon: string }> = [
  { id: 'appearance', name: '外观', icon: 'moon' },
  { id: 'dock', name: '桌面与程序坞', icon: 'safari' },
  { id: 'wallpaper', name: '墙纸', icon: 'photos' },
  { id: 'display', name: '显示器', icon: 'brightness' },
  { id: 'sound', name: '声音', icon: 'volume' },
  { id: 'battery', name: '电池', icon: 'battery' },
  { id: 'keyboard', name: '键盘', icon: 'terminal' },
  { id: 'privacy', name: '隐私与安全性', icon: 'folder' }
]

const filteredPanes = computed(() => {
  const k = search.value.trim().toLowerCase()
  if (!k) return panes
  return panes.filter((p) => p.name.toLowerCase().includes(k) || p.id.includes(k))
})

// ===== Liquid Glass 滑块（核心） =====
// 三档吸附：0（最通透）/ 0.5（中等）/ 1（最不透明）
const overScroll = ref(0) // 彩蛋：滚到底后继续下滑
const clarusShown = ref(false)

function onGlassInput(e: Event) {
  const v = Number((e.target as HTMLInputElement).value)
  // 拖动时不吸附，松手才吸附
  sys.settings.glassOpacity = v
}
function onGlassChange(e: Event) {
  const v = Number((e.target as HTMLInputElement).value)
  // 三档吸附：在三档附近 0.15 范围内吸附
  const snaps = [0, 0.5, 1]
  let snapped = v
  for (const s of snaps) {
    if (Math.abs(v - s) < 0.15) { snapped = s; break }
  }
  sys.settings.glassOpacity = snapped
}

// 滚动彩蛋：在外观页滚到底再继续下滑
function onScroll(e: Event) {
  if (activePane.value !== 'appearance') return
  const el = e.target as HTMLDivElement
  const max = el.scrollHeight - el.clientHeight
  if (el.scrollTop >= max - 1) {
    overScroll.value += 1
    if (overScroll.value > 30) clarusShown.value = true
  } else {
    overScroll.value = 0
  }
}
function hideClarus() { clarusShown.value = false }

watch(activePane, () => { overScroll.value = 0; clarusShown.value = false })
</script>

<template>
  <div class="flex h-full w-full text-[13px]">
    <!-- 贴边侧边栏 -->
    <aside class="w-[210px] h-full flex flex-col"
      style="background: var(--sidebar-bg); border-right: 1px solid var(--divider);">
      <div class="p-2">
        <div class="flex items-center gap-2 h-7 px-2 rounded-[6px] bg-black/5 dark:bg-white/10">
          <Icon name="ri-search-line" :size="14" />
          <input v-model="search" class="flex-1 bg-transparent outline-none text-[12px]" placeholder="搜索" />
        </div>
      </div>
      <div class="flex-1 overflow-auto px-2 pb-2">
        <button
          v-for="p in filteredPanes" :key="p.id"
          class="w-full flex items-center gap-2 px-2 py-1.5 rounded-[6px] text-left text-[13px]"
          :class="activePane === p.id ? 'bg-[#0A84FF] text-white' : 'hover:bg-black/5 dark:hover:bg-white/10'"
          @click="activePane = p.id"
        >
          <Icon :name="p.icon" :size="16" :color="activePane===p.id ? '#fff' : 'currentColor'" />
          <span>{{ p.name }}</span>
        </button>
      </div>
    </aside>

    <!-- 内容区 -->
    <section class="flex-1 overflow-auto p-6" @scroll="onScroll">
      <!-- 外观页 -->
      <div v-if="activePane === 'appearance'">
        <h2 class="text-[20px] font-semibold mb-4">外观</h2>

        <!-- 外观模式 -->
        <div class="rounded-[10px] p-4 mb-4" style="background:rgba(0,0,0,0.04); border:1px solid var(--divider);">
          <div class="text-[12px] opacity-70 mb-2">外观模式</div>
          <div class="flex gap-3">
            <button
              v-for="m in (['light','dark','auto'] as const)" :key="m"
              class="flex-1 h-20 rounded-[8px] flex flex-col items-center justify-center gap-1 text-[12px] transition-all"
              :class="sys.settings.appearance===m
                ? 'ring-2 ring-[#0A84FF] bg-white/60 dark:bg-white/10'
                : 'bg-white/40 dark:bg-white/5 hover:bg-white/60'"
              @click="sys.setAppearance(m)"
            >
              <Icon :name="m==='dark'?'moon':(m==='auto'?'siri':'sun')" :size="22" />
              <span>{{ m==='light'?'浅色':(m==='dark'?'深色':'自动') }}</span>
            </button>
          </div>
        </div>

        <!-- Liquid Glass 滑块 -->
        <div class="rounded-[10px] p-4 mb-4" style="background:rgba(0,0,0,0.04); border:1px solid var(--divider);">
          <div class="flex items-baseline justify-between mb-2">
            <div class="text-[12px] opacity-70">Liquid Glass 透明度</div>
            <div class="text-[11px] opacity-60">当前：{{ Math.round(sys.settings.glassOpacity*100) }}%</div>
          </div>
          <div class="relative py-2">
            <!-- 三档刻度 -->
            <div class="absolute left-0 right-0 top-1/2 -translate-y-1/2 flex justify-between px-1 pointer-events-none">
              <span v-for="t in [0,0.5,1]" :key="t" class="w-1 h-1 rounded-full bg-current opacity-40" />
            </div>
            <input
              type="range" min="0" max="1" step="0.01"
              :value="sys.settings.glassOpacity"
              @input="onGlassInput"
              @change="onGlassChange"
              class="glass-slider w-full"
            />
          </div>
          <div class="flex justify-between text-[11px] opacity-60 mt-1">
            <span>最通透</span><span>中等</span><span>最不透明</span>
          </div>
          <div class="text-[11px] opacity-60 mt-3">
            调整菜单栏、Dock、窗口与浮层的玻璃着色强度。拖到靠近刻度会自动吸附。
          </div>
        </div>

        <!-- HDR 泛光 -->
        <div class="rounded-[10px] p-4 mb-4" style="background:rgba(0,0,0,0.04); border:1px solid var(--divider);">
          <div class="flex items-center justify-between mb-2">
            <div class="text-[12px]">HDR 高光泛光</div>
            <span class="text-[11px] opacity-60">{{ Math.round(sys.settings.hdrGlow*100) }}%</span>
          </div>
          <input type="range" min="0" max="1" step="0.01" v-model.number="sys.settings.hdrGlow" class="glass-slider w-full" />
        </div>

        <!-- 彩蛋占位（留高以便滚动触发） -->
        <div class="h-[300px]" />
        <div class="h-2" />
      </div>

      <!-- 桌面与程序坞 -->
      <div v-else-if="activePane === 'dock'">
        <h2 class="text-[20px] font-semibold mb-4">桌面与程序坞</h2>
        <div class="rounded-[10px] p-4 mb-3 space-y-3" style="background:rgba(0,0,0,0.04); border:1px solid var(--divider);">
          <label class="flex items-center justify-between">
            <span class="text-[13px]">程序坞大小</span>
            <span class="text-[11px] opacity-60">{{ sys.settings.dockSize }}px</span>
          </label>
          <input type="range" min="40" max="80" step="1" v-model.number="sys.settings.dockSize" class="glass-slider w-full" />
          <label class="flex items-center justify-between">
            <span class="text-[13px]">放大</span>
            <input type="checkbox" v-model="sys.settings.dockMagnification" />
          </label>
          <div v-if="sys.settings.dockMagnification">
            <input type="range" min="1" max="1.8" step="0.05" v-model.number="sys.settings.dockMagnificationLevel" class="glass-slider w-full" />
          </div>
          <label class="flex items-center justify-between">
            <span class="text-[13px]">自动隐藏和显示程序坞</span>
            <input type="checkbox" v-model="sys.settings.dockAutoHide" />
          </label>
        </div>
      </div>

      <!-- 墙纸 -->
      <div v-else-if="activePane === 'wallpaper'">
        <h2 class="text-[20px] font-semibold mb-4">墙纸</h2>
        <div class="grid grid-cols-2 gap-4">
          <button
            v-for="wp in ([
              {id:'golden-gate-evening', name:'Golden Gate Evening', grad:'linear-gradient(160deg,#f4b560,#d26a2a 55%,#5a2b15)'},
              {id:'golden-gate-day', name:'Golden Gate Day', grad:'linear-gradient(160deg,#82bde6,#e6d4b0 60%,#826450)'}
            ] as const)" :key="wp.id"
            class="rounded-[10px] overflow-hidden text-left"
            :class="sys.settings.wallpaper===wp.id ? 'ring-2 ring-[#0A84FF]' : ''"
            style="border:1px solid var(--divider);"
            @click="sys.setWallpaper(wp.id)"
          >
            <div class="h-32" :style="{ background: wp.grad }" />
            <div class="p-2 text-[12px]">{{ wp.name }}</div>
          </button>
        </div>
      </div>

      <!-- 其它设置页（占位） -->
      <div v-else>
        <h2 class="text-[20px] font-semibold mb-4">{{ panes.find(p=>p.id===activePane)?.name }}</h2>
        <div class="rounded-[10px] p-4 text-[12px] opacity-70" style="background:rgba(0,0,0,0.04); border:1px solid var(--divider);">
          该设置项为静态演示占位。
        </div>
      </div>
    </section>

    <!-- Clarus the Dogcow 彩蛋 -->
    <Transition name="clarus-pop">
      <div
        v-if="clarusShown"
        class="fixed inset-0 z-[100] flex items-center justify-center"
        style="background: rgba(0,0,0,0.4); backdrop-filter: blur(10px);"
        @click="hideClarus"
      >
        <div
          class="rounded-[14px] p-6 text-center"
          style="background: var(--glass-bg); backdrop-filter: blur(20px); border:1px solid var(--glass-border);"
        >
          <Icon name="clarus" :size="120" />
          <div class="mt-2 text-[14px] font-medium">Moof!</div>
          <div class="text-[11px] opacity-60 mt-1">你发现了 Clarus the Dogcow —— macOS 经典彩蛋</div>
          <button class="mt-4 px-5 py-1 rounded-[6px] bg-[#0A84FF] text-white text-[13px]" @click="hideClarus">好</button>
        </div>
      </div>
    </Transition>
  </div>
</template>

<style scoped>
.glass-slider{-webkit-appearance:none;appearance:none;height:4px;background:rgba(0,0,0,.15);border-radius:999px;}
:root.dark .glass-slider{background:rgba(255,255,255,.2);}
.glass-slider::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 2px 6px rgba(0,0,0,.3);cursor:pointer;border:1px solid rgba(0,0,0,.1);}
.clarus-pop-enter-active,.clarus-pop-leave-active{transition:opacity .2s, transform .3s cubic-bezier(0.25,.1,.25,1);}
.clarus-pop-enter-from,.clarus-pop-leave-to{opacity:0;transform:scale(.8);}
</style>
