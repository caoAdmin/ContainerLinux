<script setup lang="ts">
import { ref } from 'vue'
import Icon from '@/components/common/Icon.vue'
const playing = ref(false)
</script>
<template>
  <div class="flex flex-col h-full">
    <div class="flex-1 flex items-center justify-center text-white" style="background:linear-gradient(135deg,#FA233B,#ff6b9d);">
      <div class="text-center">
        <Icon name="music" :size="96" class="mx-auto mb-4" />
        <div class="text-[22px] font-bold">Golden Hour</div>
        <div class="text-[13px] opacity-80">JVKE</div>
      </div>
    </div>
    <div class="h-20 flex items-center justify-center gap-6" style="background:var(--window-toolbar-bg)">
      <Icon name="ri-rewind-line" :size="22" class="cursor-pointer" />
      <div class="w-10 h-10 rounded-full flex items-center justify-center bg-[#FA233B] text-white cursor-pointer" @click="playing=!playing">
        <Icon :name="playing?'pause':'play'" :size="20" />
      </div>
      <Icon name="ri-skip-forward-line" :size="22" class="cursor-pointer" />
    </div>
  </div>
</template>
