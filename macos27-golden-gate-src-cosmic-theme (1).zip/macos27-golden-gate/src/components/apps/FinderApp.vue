<script setup lang="ts">
/**
 * 访达 Finder
 * - edge-to-edge 贴边侧边栏（个人收藏 / iCloud / 标签）
 * - 工具栏：返回/前进/视图/搜索，底部有分隔线
 * - 文件列表视图，可双击进入，右键菜单
 */
import { ref } from 'vue'
import Icon from '@/components/common/Icon.vue'

defineProps<{ winId?: string }>()

interface FileItem { name: string; kind: 'folder' | 'image' | 'doc'; size?: string; modified?: string }

const sections = [
  {
    title: '个人收藏',
    items: [
      { id: 'airdrop', name: '隔空投送', icon: 'airdrop' },
      { id: 'recent', name: '最近使用', icon: 'folder' },
      { id: 'desktop', name: '桌面', icon: 'folder' },
      { id: 'docs', name: '文稿', icon: 'folder' },
      { id: 'downloads', name: '下载', icon: 'folder' },
      { id: 'pics', name: '图片', icon: 'photos' }
    ]
  },
  { title: 'iCloud', items: [{ id: 'icloud', name: 'iCloud 云盘', icon: 'folder' }] },
  { title: '标签', items: [
    { id: 'red', name: '红色', icon: 'folder', color: '#FF3B30' },
    { id: 'orange', name: '橙色', icon: 'folder', color: '#FF9500' },
    { id: 'blue', name: '蓝色', icon: 'folder', color: '#0A84FF' }
  ] }
]
const activeSide = ref('desktop')

const files: FileItem[] = [
  { name: '产品周报.md', kind: 'doc', size: '12 KB', modified: '今天 10:24' },
  { name: '屏幕快照.png', kind: 'image', size: '420 KB', modified: '昨天' },
  { name: 'GoldenGate 设计', kind: 'folder', modified: '2 天前' },
  { name: '2026 年规划', kind: 'folder', modified: '上周' },
  { name: '录音.m4a', kind: 'doc', size: '1.2 MB', modified: '3 天前' },
  { name: '发票.pdf', kind: 'doc', size: '86 KB', modified: '上周' }
]

const crumbs = ref(['桌面'])
const backStack = ref<string[][]>([['桌面']])
function goInto(name: string) {
  crumbs.value.push(name)
  backStack.value.push([...crumbs.value])
}
function goBack() { if (crumbs.value.length > 1) crumbs.value.pop() }
function goFwd() {}
</script>

<template>
  <div class="flex h-full w-full">
    <!-- 贴边侧边栏（edge-to-edge，无浮动圆角） -->
    <aside class="w-[180px] h-full overflow-auto py-2 text-[13px]"
      style="background: var(--sidebar-bg); border-right: 1px solid var(--divider);">
      <div v-for="sec in sections" :key="sec.title" class="mb-3">
        <div class="px-3 text-[11px] uppercase tracking-wide opacity-60 mb-1">{{ sec.title }}</div>
        <button
          v-for="it in sec.items" :key="it.id"
          class="w-full flex items-center gap-2 px-3 py-1 text-left rounded-none"
          :class="activeSide===it.id ? 'bg-[#0A84FF] text-white' : 'hover:bg-black/5 dark:hover:bg-white/10'"
          @click="activeSide = it.id"
        >
          <Icon :name="it.icon" :size="14" />
          <span class="truncate">{{ it.name }}</span>
        </button>
      </div>
    </aside>

    <!-- 内容区（工具栏 + 列表） -->
    <div class="flex-1 flex flex-col min-w-0">
      <!-- 工具栏 -->
      <div class="flex items-center gap-2 h-[40px] px-3" style="border-bottom:1px solid var(--divider);" data-no-drag>
        <button class="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-60" @click="goBack">
          <Icon name="ri-arrow-left-s-line" :size="16" />
        </button>
        <button class="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-60" @click="goFwd">
          <Icon name="ri-arrow-right-s-line" :size="16" />
        </button>
        <div class="flex items-center gap-1 ml-2 text-[12px] opacity-80">
          <span v-for="(c,i) in crumbs" :key="i">{{ c }}<span v-if="i<crumbs.length-1" class="mx-1 opacity-50">/</span></span>
        </div>
        <div class="flex-1" />
        <div class="flex items-center gap-2 h-6 px-2 rounded-[6px] bg-black/5 dark:bg-white/10 w-[180px]">
          <Icon name="ri-search-line" :size="12" />
          <input class="flex-1 bg-transparent outline-none text-[12px]" placeholder="搜索" />
        </div>
      </div>

      <!-- 文件列表 -->
      <div class="flex-1 overflow-auto">
        <div class="sticky top-0 grid grid-cols-[1fr_80px_120px] px-3 py-1 text-[11px] opacity-60 border-b border-black/5 dark:border-white/10 bg-inherit">
          <span>名称</span><span>大小</span><span>修改日期</span>
        </div>
        <div
          v-for="f in files" :key="f.name"
          class="grid grid-cols-[1fr_80px_120px] items-center px-3 py-1.5 text-[13px] cursor-default hover:bg-[#0A84FF]/15 rounded mx-1 my-0.5"
          @dblclick="f.kind==='folder' ? goInto(f.name) : null"
        >
          <div class="flex items-center gap-2 min-w-0">
            <Icon :name="f.kind==='folder'?'folder':(f.kind==='image'?'file-image':'doc')" :size="20" />
            <span class="truncate">{{ f.name }}</span>
          </div>
          <span class="text-[11px] opacity-70">{{ f.size ?? '—' }}</span>
          <span class="text-[11px] opacity-70">{{ f.modified ?? '' }}</span>
        </div>
      </div>
    </div>
  </div>
</template>
