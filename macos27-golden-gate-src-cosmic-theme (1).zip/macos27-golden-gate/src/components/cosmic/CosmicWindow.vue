<script setup lang="ts">
/**
 * CosmicWindow —— COSMIC（libcosmic）风格窗口装饰
 * 圆角 + 右侧窗口控制钮 + 标题栏拖拽 + 八向缩放
 *
 * 动画：
 *   1. 打开：从 Dock 对应图标的位置「长」出来（transform-origin 落在图标上）
 *   2. 全屏 / 还原：位置尺寸做补间，不再瞬间跳变
 *   3. 最小化 / 还原：macOS「精灵」漏斗 —— 形状每帧由 utils/genie.ts 采样
 *      （算法抄自 Chad Etzel 的 MeshWarpEffect / fenxer 的 genie-web），详见下方 §3
 */
import { computed, nextTick, onMounted, onUnmounted, provide, ref, watch } from 'vue'
import { useCosmicStore, type CosmicWindowState } from '@/stores/cosmic'
import { useLayoutStore } from '@/stores/layout'
import { genieFrame, inferAxis, timelineEase, warpMapUrl, type GenieAxis, type GenieFrame, type Rect } from '@/utils/genie'
import { fullyCovered, intersect, rectOf, type ORect } from '@/utils/occlusion'
import CosmicAppBar from './CosmicAppBar.vue'

const props = defineProps<{ win: CosmicWindowState }>()
const store = useCosmicStore()
const layout = useLayoutStore()

/** 每个窗口一套位移滤镜（id 用窗口 id 保证唯一） */
const warpId = computed(() => `cw-warp-${props.win.id}`)
const warpMap = warpMapUrl()
const dispEl = ref<SVGFEDisplacementMapElement | null>(null)
/** 位移只作用于靠近 Dock 的下半部分（上半部分本来也不该压缩）。
 *  贴图与位移用**同一个**子区域，贴图的 v 就在这个区域内从 0 重新算起，
 *  于是压缩率在分界线处自然从 0 长起来，不会出现突兀的折角。 */
const warpTop = computed(() => Math.round(props.win.height * 0.45))
const warpHeight = computed(() => props.win.height - warpTop.value)

/** 应用内部可通过 inject('cosmicWinId') 拿到自己的窗口 id（用于改标题等） */
provide('cosmicWinId', props.win.id)
/** ContainerLinux 系统应用（CtApp）通过 inject('ctAppId') 取自己的应用定义 */
provide('ctAppId', props.win.appId)

const isActive = computed(() => store.activeId === props.win.id)

/**
 * 拖拽位移的基准点。
 * 拖动时 left/top 冻结在起点、位移改由 CSS `translate` 表达 ——
 * 后者只动合成层，不会像 left/top 那样每帧把整棵窗口子树重新布局一遍。
 * 松开时把 left/top 一次性写回终点、translate 归零，视觉上没有跳变。
 */
const dragBase = ref<{ x: number; y: number } | null>(null)

// 最大化会瞬间改 x/y/宽高，基准点必须作废，否则 left/top 会停在旧位置
watch(
  () => props.win.maximized,
  () => (dragBase.value = null)
)

/* ── 遮挡：被压在下面就不渲染 ── */
/**
 * 谁盖住了我：z 更高、正显示、没最小化/关闭的窗口。
 * 只留「交集矩形」——判断是否整块被盖住只需要这些。
 */
const occluders = computed(() => {
  // 精灵动画期间不参与遮挡判定：还原时窗口是「从 Dock 里长出来」的，
  // 这一路都在别的窗口下面，若判成被遮挡就会飞出一个空漏斗。
  if (props.win.minimized || props.win.closing || genieRunning.value) return []
  const me = rectOf(props.win)
  const out: ORect[] = []
  for (const o of store.windows) {
    if (o.id === props.win.id) continue
    if (o.minimized || o.closing) continue
    if (o.zIndex <= props.win.zIndex) continue
    if (!store.isVisible(o)) continue
    const r = intersect(me, rectOf(o))
    if (r) out.push(r)
  }
  return out
})

/** 整块都被盖住：内容停渲染，只留窗口自己的底衬（occluders 空时天然为 false） */
const fullyOccluded = computed(() => fullyCovered(rectOf(props.win), occluders.value))

/**
 * 「这个窗口此刻真的在画吗」——应用内部的重绘（比如播放器的频谱条）
 * 可以据此停摆：最小化、关闭中、被完全盖住时都不用再算。
 * 用 ref 传下去，应用侧 watch 一下即可，不用改它们的结构。
 */
const winVisible = computed(
  () => !props.win.minimized && !props.win.closing && !fullyOccluded.value
)
provide('cosmicWinVisible', winVisible)

/** 开场动画只在刚挂载时跑一次，随后摘掉 —— 否则每次还原动画结束、动画属性回落时它会被重新触发 */
const justOpened = ref(true)
let openTimer = 0

/* ── 1. 打开动画的原点：Dock 图标中心（换算到逻辑画布坐标）── */
const openOrigin = ref('50% 50%')
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v))

function dockTile(): HTMLElement | null {
  return document.querySelector(`[data-dock-app="${props.win.appId}"] .dock-app-tile`) as HTMLElement | null
}

function computeOpenOrigin() {
  const tile = dockTile()
  const canvas = document.querySelector('.stage-canvas') as HTMLElement | null
  if (!tile || !canvas) return
  const cr = canvas.getBoundingClientRect()
  const tr = tile.getBoundingClientRect()
  if (!tr.width) return
  const sx = layout.scaleX || 1
  const sy = layout.scaleY || 1
  const lx = (tr.left + tr.width / 2 - cr.left) / sx
  const ly = (tr.top + tr.height / 2 - cr.top) / sy
  openOrigin.value =
    `${clamp(((lx - props.win.x) / props.win.width) * 100, -70, 170)}% ` +
    `${clamp(((ly - props.win.y) / props.win.height) * 100, -90, 190)}%`
}

/* ── 3. 最小化 / 还原：macOS「精灵」动画（genie）── */
/**
 * 形状（漏斗轮廓 + 平移 + 压缩）全部由 utils/genie.ts 采样 —— 那套数学抄自
 * Chad Etzel 的 MeshWarpEffect（逐帧回放 macOS 录屏逆向）与 fenxer/genie-web。
 * 这里只做两件事：
 *   ① 动画开始前快照「窗口矩形」和「Dock 图标矩形」（都换算到舞台逻辑坐标）
 *   ② 用 rAF 逐帧把采样出的 clip-path / transform 写进元素
 * 不用 CSS @keyframes 是因为网格轮廓是「靠 Dock 那端收得更狠」的非线性形状，
 * keyframes 里只能拿百分比硬插，做不出随窗口高度 / 距离自适应的曲线。
 */
const GENIE_DURATION = 420
// curve 用 'cosine'：抄 hbi99/genie.js 的驱动曲线，侧壁比 quadInOut 更圆
// bar* 是应用栏（CosmicAppBar）相对窗口的悬挂几何 —— 和那边 CSS 里的数字保持一致
const BAR = { height: 46, top: -56, gap: 10, skirt: 30 } as const
const GENIE_OPTS = {
  rows: 16,
  curve: 'cosine',
  slideEnd: 0.5,
  translateStart: 0.38,
  barHeight: BAR.height,
  barTop: BAR.top,
  barGap: BAR.gap,
  barSkirt: BAR.skirt
} as const

const frame = ref<GenieFrame | null>(null)
/** 动画进行中（决定元素在「已最小化」期间是否仍可见） */
const genieRunning = ref(false)
let genieRaf = 0
let setup: { win: Rect; dock: Rect; axis: GenieAxis } | null = null

function stageCanvas() {
  return document.querySelector('.stage-canvas') as HTMLElement | null
}

/** 视口矩形 → 舞台逻辑坐标（外层 stage 带 scale，窗口坐标用的是逻辑值） */
function toLogicalRect(r: DOMRect): Rect | null {
  const c = stageCanvas()
  if (!c) return null
  const cr = c.getBoundingClientRect()
  const sx = layout.scaleX || 1
  const sy = layout.scaleY || 1
  return {
    left: (r.left - cr.left) / sx,
    top: (r.top - cr.top) / sy,
    right: (r.right - cr.left) / sx,
    bottom: (r.bottom - cr.top) / sy
  }
}

/** 快照窗口与 Dock 图标的矩形；Dock 方向不合法时退回「屏幕底部中央」 */
function captureGenie() {
  const win: Rect = {
    left: props.win.x,
    top: props.win.y,
    right: props.win.x + props.win.width,
    bottom: props.win.y + props.win.height
  }
  const tr = dockTile()?.getBoundingClientRect()
  let dock = tr && tr.width > 0 ? toLogicalRect(tr) : null
  let axis: GenieAxis = 'y'

  if (dock) {
    axis = inferAxis(win, dock)
    // genie 的数学要求目标在窗口的正方向（右 / 下）；反向就先退回竖直向下
    const dx = (dock.left + dock.right) / 2 - (win.left + win.right) / 2
    const dy = (dock.top + dock.bottom) / 2 - (win.top + win.bottom) / 2
    if ((axis === 'x' && dx < 0) || (axis === 'y' && dy < 0)) dock = null
  }
  if (!dock) {
    // Dock 被隐藏 / 收起 / 位于窗口反方向：收进屏幕底部中央
    dock = {
      left: layout.canvasW / 2 - 26,
      top: layout.canvasH - 10,
      right: layout.canvasW / 2 + 26,
      bottom: layout.canvasH + 42
    }
    axis = 'y'
  }
  return { win, dock, axis }
}

function drawGenie(p: number) {
  if (!setup) return
  const f = genieFrame(p, setup.win, setup.dock, GENIE_OPTS, setup.axis)
  frame.value = f
  // 压缩强度直接写到滤镜上（不走响应式，省掉一次组件 patch）
  dispEl.value?.setAttribute('scale', f.warp.toFixed(1))
}

/** progress：0 = 完整窗口，1 = 收进 Dock 图标 */
function playGenie(from: number, to: number, done: () => void) {
  cancelAnimationFrame(genieRaf)
  genieRunning.value = true
  if (!store.settings.animations) {
    drawGenie(to)
    done()
    return
  }
  const t0 = performance.now()
  const step = (now: number) => {
    const raw = clamp((now - t0) / GENIE_DURATION, 0, 1)
    // 时间线走 linear（同 genie-web 默认）：漏斗形状本身已经是非线性的，
    // 再叠一层 easeInOut 会让前 1/3 时间几乎不动，点了最小化像没反应。
    drawGenie(from + (to - from) * timelineEase(raw, 'linear'))
    if (raw < 1) {
      genieRaf = requestAnimationFrame(step)
    } else {
      drawGenie(to)
      done()
    }
  }
  genieRaf = requestAnimationFrame(step)
}

watch(
  () => props.win.minimized,
  (m, wasMin) => {
    wobAbort() // 精灵动画要接管外层 transform，果冻让位
    if (m) {
      setup = captureGenie()
      // 动画停在「收拢态」（p=1）；元素随后由 .cw--min 的 visibility 接管隐藏
      playGenie(0, 1, () => (genieRunning.value = false))
    } else if (wasMin && setup) {
      playGenie(1, 0, () => {
        genieRunning.value = false
        frame.value = null // 交回常规样式
        setup = null
      })
    }
  }
)

/* ── 4. KDE 果冻窗口（Wobbly Windows）── */
/**
 * 思路抄自 KWin 的 WobblyEffect：把窗口当成一张有弹性的膜，四周布一组控制点，
 * 每个点用「弹簧 + 阻尼」追踪它在窗口**目标矩形**上的位置。
 * 拖动时让离鼠标最近的那个点直接跟手，其余点被弹簧"拉"过去 —— 窗口就被扯到变形；
 * 松手后所有点一起欠阻尼振荡，自己抖几下再归位。
 * 形状用 clip-path 画（8 个控制点的实际位置），内容用左上/右上/左下三点拟合的仿射矩阵跟随。
 */
const WOB_ANCHORS: ReadonlyArray<readonly [number, number]> = [
  [0, 0], [0.5, 0], [1, 0], [1, 0.5], [1, 1], [0.5, 1], [0, 1], [0, 0.5]
]
/** 弹簧刚度。阻尼不写死，按 c = 2ζ√k 逐点算 —— 见 wobTick */
const WOB_K = 280
/** 阻尼比。ζ<1 才有回弹（果冻的来源），取 0.78：弹一两下就收住。
 *  这里不能用固定阻尼系数：各点刚度不同，固定 c 会让「软」的点（对角）变成过阻尼，
 *  而过阻尼系统的慢根 s = −c/2 + √(c²/4 − k) 反而拖得极慢 —— 实测尾巴能拖到 2.6s 以上。 */
const WOB_ZETA = 0.78
/** 刚度随「离抓取点的距离」衰减的幅度：离得越远的点越软、滞后越明显 —— 这才是被扯变形的来源。
 *  如果所有点刚度相同，它们会同步滞后，看起来只是"整体跟在鼠标后面"，不会有形变。
 *  0.8 让各方向的形变量更接近（0.7 时纵向拖动明显偏弱，因为上排三点里只有中间那个在跟手）。 */
const WOB_FALLOFF = 0.8
/** 松手后的兜底：万一某个点数值上迟迟不收敛，到点强制交回常规样式（此时偏差已肉眼不可见）。
 *  只在「松手之后」计时 —— 拖拽过程中绝不能设时长上限，
 *  否则按住慢慢晃超过这个时间，果冻会凭空消失（之前就是从按下开始计时的，这是个 bug）。 */
const WOB_SETTLE_LIMIT = 1500

interface WobPoint {
  x: number
  y: number
  vx: number
  vy: number
}

const wobPoints = ref<WobPoint[] | null>(null)
/**
 * clip-path 节流：果冻轮廓（窗口 + 应用栏）每帧变化会触发整窗重栅格，
 * 这是拖拽掉帧的头号原因。这里把「剪影」的更新频率压到 ~45fps，
 * 而外层仿射 matrix 形变仍按每帧（~60fps）平滑更新 —— 内容跟着手走依然顺，
 * 只是轮廓边缘的刷新慢一点（果冻本身就是软边，几乎看不出）。
 * 这样把最贵的「重画整窗」次数砍掉约三分之一。
 */
const clipThrottle = ref<{ clip: string; bar: string }>({ clip: '', bar: '' })
let lastClipT = 0
let wobRaf = 0
let wobLast = 0
/** 松手时刻；0 = 仍在拖拽中 */
let wobReleasedAt = 0
let wobGrabIdx = 1
let wobDragging = false

/** 第 i 个控制点「应该在」的位置（跟随窗口目标矩形） */
function wobAnchor(i: number) {
  const u = WOB_ANCHORS[i][0]
  const v = WOB_ANCHORS[i][1]
  return {
    x: props.win.x + u * props.win.width,
    y: props.win.y + v * props.win.height
  }
}

function wobTick(now: number) {
  const pts = wobPoints.value
  if (!pts) return
  const dt = Math.min((now - wobLast) / 1000, 0.032)
  wobLast = now
  let alive = false

  for (let i = 0; i < pts.length; i++) {
    const p = pts[i]
    const t = wobAnchor(i)
    if (wobDragging && i === wobGrabIdx) {
      p.x = t.x
      p.y = t.y
      p.vx = 0
      p.vy = 0
      alive = true
      continue
    }
    // 刚度按「离抓取点的归一化距离」衰减：抓取点附近几乎跟手、对角最软，于是整张膜被扯变形
    const du = WOB_ANCHORS[i][0] - WOB_ANCHORS[wobGrabIdx][0]
    const dv = WOB_ANCHORS[i][1] - WOB_ANCHORS[wobGrabIdx][1]
    const dist = Math.min(Math.hypot(du, dv) / Math.SQRT2, 1)
    const k = WOB_K * (1 - WOB_FALLOFF * dist)
    // 临界阻尼 c = 2√k；乘 ζ 得到统一的阻尼比 —— 每个点都「弹一两下就停」
    const c = 2 * WOB_ZETA * Math.sqrt(k)

    p.vx += ((t.x - p.x) * k - p.vx * c) * dt
    p.vy += ((t.y - p.y) * k - p.vy * c) * dt
    p.x += p.vx * dt
    p.y += p.vy * dt
    // 静止阈值：换算成像素速度与位移，肉眼看不出来就收工
    if (
      Math.abs(t.x - p.x) > 0.4 ||
      Math.abs(t.y - p.y) > 0.4 ||
      Math.abs(p.vx) > 6 ||
      Math.abs(p.vy) > 6
    ) {
      alive = true
    }
  }

  // 剪影轮廓按 ~45fps 节流更新（首帧立即写，避免开局闪一下整矩形）
  const g = wobGeo.value
  if (g && (now - lastClipT >= 22 || lastClipT === 0)) {
    lastClipT = now
    clipThrottle.value = { clip: g.clip || '', bar: g.bar || '' }
  }

  // 兜底只看「松手后」；拖拽中要一直跟着演算
  const overtime = !wobDragging && wobReleasedAt > 0 && now - wobReleasedAt > WOB_SETTLE_LIMIT
  if (alive && !overtime) {
    wobRaf = requestAnimationFrame(wobTick)
  } else {
    wobPoints.value = null // 完全静止 → 交回常规样式
    clipThrottle.value = { clip: '', bar: '' }
    wobRaf = 0
  }
}

/** 开始拖拽：布好控制点，并挑出离抓取位置最近的那个跟手 */
function wobStart(grabU: number, grabV: number) {
  if (!store.settings.animations) return
  wobPoints.value = WOB_ANCHORS.map(([u, v]) => ({
    x: props.win.x + u * props.win.width,
    y: props.win.y + v * props.win.height,
    vx: 0,
    vy: 0
  }))
  let best = 0
  let bestD = Infinity
  WOB_ANCHORS.forEach(([u, v], i) => {
    const d = (u - grabU) ** 2 + (v - grabV) ** 2
    if (d < bestD) {
      bestD = d
      best = i
    }
  })
  wobGrabIdx = best
  wobDragging = true
  wobReleasedAt = 0
  wobLast = performance.now()
  lastClipT = 0 // 首帧立即写一次节流剪影，避免开局闪整矩形
  clipThrottle.value = { clip: '', bar: '' }
  cancelAnimationFrame(wobRaf)
  wobRaf = requestAnimationFrame(wobTick)
}

/** 立刻终止果冻（窗口几何被外部改变时用 —— 比如最大化，尺寸突变不该被弹簧去追） */
function wobAbort() {
  cancelAnimationFrame(wobRaf)
  wobRaf = 0
  wobPoints.value = null
  wobDragging = false
  wobReleasedAt = 0
}

/** 松手：不再有跟手点，剩下全靠弹簧振荡收尾 */
function wobEnd() {
  wobDragging = false
  wobReleasedAt = performance.now()
}

/* ── 2. 全屏 / 还原：临时开启 left/top/width/height 补间 ── */
const maxAnim = ref(false)
let maxAnimTimer = 0
watch(
  () => props.win.maximized,
  () => {
    // 全屏 / 还原会让窗口矩形突变，果冻必须让路：否则弹簧会拽着窗口追十几帧，
    // 而且 .cw--wob 的 transition:none 会把全屏补间一起吃掉
    wobAbort()
    if (!store.settings.animations) return
    maxAnim.value = true
    window.clearTimeout(maxAnimTimer)
    maxAnimTimer = window.setTimeout(() => (maxAnim.value = false), 480)
  }
)

onMounted(() => {
  nextTick(computeOpenOrigin)
  openTimer = window.setTimeout(() => (justOpened.value = false), 540)
})
onUnmounted(() => {
  window.clearTimeout(maxAnimTimer)
  window.clearTimeout(openTimer)
  cancelAnimationFrame(genieRaf)
  cancelAnimationFrame(wobRaf)
})

/** 果冻的几何：仿射矩阵（内外两层共用）+ 轮廓多边形（只有内层用）。
 *  分成两份是有意的 —— 外层要拿矩阵去变换 box-shadow，但绝不能拿到 clip-path。 */
const wobGeo = computed(() => {
  const pts = wobPoints.value
  if (!pts) return null
  const W = Math.max(props.win.width, 1)
  const H = Math.max(props.win.height, 1)
  const p0 = pts[0]
  const p2 = pts[2]
  const p6 = pts[6]
  // 用「左上 / 右上 / 左下」三点拟合仿射：覆盖缩放、旋转、剪切
  const a = (p2.x - p0.x) / W
  const b = (p2.y - p0.y) / W
  const c = (p6.x - p0.x) / H
  const d = (p6.y - p0.y) / H
  const det = a * d - b * c
  const transform =
    `matrix(${a.toFixed(4)}, ${b.toFixed(4)}, ${c.toFixed(4)}, ${d.toFixed(4)}, ` +
    `${(p0.x - props.win.x).toFixed(2)}, ${(p0.y - props.win.y).toFixed(2)})`
  let clip = ''
  let bar = ''
  if (Math.abs(det) > 1e-4) {
    // 世界 → 元素局部：参考点必须是 p0（仿射把自己的局部原点映到了那里），
    // 不是窗口布局原点 —— 减错的话，拖动时膜相对窗口的「拖尾」会整个漏进轮廓，
    // 顶边中点被仿射预测「吃干净」，看起来顶边笔直不变形。
    const toLocal = (pt: { x: number; y: number }) => {
      const dx = pt.x - p0.x
      const dy = pt.y - p0.y
      return { x: (d * dx - c * dy) / det, y: (-b * dx + a * dy) / det }
    }
    // clip-path 走元素局部坐标系（transform 之前），所以把控制点的世界坐标逆变换回去
    clip = `polygon(${pts
      .map((pt) => {
        const l = toLocal(pt)
        return `${((l.x / W) * 100).toFixed(2)}% ${((l.y / H) * 100).toFixed(2)}%`
      })
      .join(', ')})`
    // 应用栏轮廓：只取顶边三点（p0/p1/p2），上下边各平移 56 / 10（栏挂在窗口外侧上方），
    // 换算进栏自身盒子（宽 = 窗口宽、高 46）的百分比 —— 窗口顶边怎么弯，栏顶就怎么弯。
    // 栏盒子在窗口局部 (0, −56)-(W, −10)，所以「膜顶点 −56」正好落在栏自身 0%、
    // 「膜顶点 −10」落在 100%；下边整体再压低一个裙边（30px）保住胶囊投影。
    const barPts = [pts[0], pts[1], pts[2]].map((pt) => {
      const l = toLocal(pt)
      return { x: (l.x / W) * 100, y: (l.y / BAR.height) * 100 }
    })
    const f = (n: number) => n.toFixed(2)
    const skirtPct = (BAR.skirt / BAR.height) * 100
    bar =
      `polygon(${barPts.map((p) => `${f(p.x)}% ${f(p.y)}%`).join(', ')}, ` +
      `${barPts
        .slice()
        .reverse()
        .map((p) => `${f(p.x)}% ${f(p.y + 100 + skirtPct)}%`)
        .join(', ')})`
  }
  return { transform, clip, bar }
})

/** 应用栏本帧的形变：果冻多边形 / 精灵漏斗（CosmicAppBar 直接绑成根元素样式）。
 *  果冻期间同样走节流的 clipThrottle。 */
const barClip = computed(() => wobGeo.value ? (clipThrottle.value.bar || '') : (frame.value?.bar || ''))
/** 应用栏本帧的额外平移（仅横向 genie：栏顶骑着顶边中点下潜进 Dock） */
const barY = computed(() => frame.value?.barY || 0)

/** 外层 .cw：位置尺寸 + 投影 + 仿射变换（阴影跟着一起动） */
/**
 * 样式拆两层绑定（很关键）：
 *   · boxStyle —— 布局框：位置、尺寸、层级、圆角。拖动期间被 dragBase 钉住，
 *     引用稳定，Vue 不会每帧重写这几条样式；
 *   · moveStyle —— 只放每帧会变的位移 / 形变。
 * 拆开以后拖动每帧只写 1~2 个属性，而不是 8 个一起重写。
 */
const boxStyle = computed(() => {
  const base = dragBase.value
  return {
    left: (base ? base.x : props.win.x) + 'px',
    top: (base ? base.y : props.win.y) + 'px',
    width: props.win.width + 'px',
    height: props.win.height + 'px',
    zIndex: String(props.win.zIndex),
    borderRadius: props.win.maximized ? '0px' : `${store.settings.radius + 14}px`
  }
})

const moveStyle = computed(() => {
  const base = dragBase.value
  const s: Record<string, string> = {}
  if (base) s.translate = `${props.win.x - base.x}px ${props.win.y - base.y}px`
  const g = wobGeo.value
  if (g) {
    s.transformOrigin = '0 0'
    s.transform = g.transform
  } else if (frame.value) {
    s.transformOrigin = '0 0'
    s.transform = frame.value.transform
    s.opacity = String(frame.value.opacity)
  } else if (!base) {
    s.transformOrigin = openOrigin.value
  }
  return s
})

/** 当前形变的轮廓（果冻多边形 / 精灵漏斗）。
 *  果冻期间用节流的 clipThrottle（~45fps），把整窗重栅格次数砍掉约 1/3；
 *  精灵（genie）不用节流，照常每帧。 */
const clipValue = computed(() => {
  if (wobGeo.value) return clipThrottle.value.clip || ''
  return frame.value ? frame.value.clip : ''
})

/** 内层 .cw-clip：真正把窗口「剪」成漏斗 / 果冻轮廓的那一层，外加内容压缩滤镜 */
const innerStyle = computed(() => {
  const s: Record<string, string> = {}
  const c = clipValue.value
  if (c) s.clipPath = c
  // 内容跟着横向压缩（位移贴图）；强度每帧写到 feDisplacementMap 上
  if (frame.value && frame.value.warp > 0) s.filter = `url(#${warpId.value})`
  return s
})

const dirs = ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'] as const
type Dir = (typeof dirs)[number]

function onPointerDown() {
  store.focus(props.win.id)
}

/** 双击应用栏空白处 = 最大化 / 还原（落在按钮上时不生效） */
function onBarDblClick(e: MouseEvent) {
  if ((e.target as HTMLElement).closest('button')) return
  store.toggleMaximize(props.win.id)
}

function startDrag(e: PointerEvent) {
  // 应用栏上任何按下都先把这个窗口提到最前
  store.focus(props.win.id)
  // 落在按钮上就不是拖窗口
  if ((e.target as HTMLElement).closest('button')) return
  if (props.win.maximized) return

  // 记下鼠标抓在窗口的哪个相对位置 —— 果冻效果靠它挑出「跟手的控制点」
  const box = (e.currentTarget as HTMLElement).closest('.cw')?.getBoundingClientRect()
  let grabU = 0.5
  let grabV = 0.5
  if (box && box.width > 0 && box.height > 0) {
    grabU = (e.clientX - box.left) / box.width
    grabV = (e.clientY - box.top) / box.height
  }

  const sx = e.clientX
  const sy = e.clientY
  const ox = props.win.x
  const oy = props.win.y
  let wobOn = false
  dragBase.value = { x: ox, y: oy }

  /**
   * rAF 合并：pointermove 在一帧里可能连发好几次（高刷鼠标 / 事件合并），
   * 每发一次就同步改一次 store 会触发 N 次响应式重算与重绘。攒到下一帧只写一次，
   * 把每帧的 store 写入、computed 重算、重绘都压到 1 次 —— 窗口越多收益越明显。
   */
  let dragRAF = 0
  let dragPending: { x: number; y: number } | null = null
  const move = (ev: PointerEvent) => {
    // 真的动起来才启用果冻：双击标题栏最大化也是两次 pointerdown，
    // 若在 pointerdown 就启动，点会被初始化在旧矩形上，而紧接着窗口尺寸突变，
    // 弹簧就会把窗口"扯"着追十几帧（实测满屏后还在跳 1.6s）。
    if (!wobOn && Math.hypot(ev.clientX - sx, ev.clientY - sy) > 3) {
      wobOn = true
      wobStart(grabU, grabV)
    }
    dragPending = { x: ev.clientX, y: ev.clientY }
    if (!dragRAF) dragRAF = requestAnimationFrame(applyDrag)
  }
  const applyDrag = () => {
    dragRAF = 0
    const p = dragPending
    dragPending = null
    if (!p) return
    // 物理像素位移要换算回逻辑画布像素（外层有 transform 缩放）
    const d = layout.toLogicalDelta(p.x - sx, p.y - sy)
    store.move(props.win.id, ox + d.x, oy + d.y)
  }
  const flushDrag = () => {
    if (dragRAF) {
      cancelAnimationFrame(dragRAF)
      dragRAF = 0
    }
    // 松手时若还有一帧位移没落库，立刻补齐，避免窗口停在旧位置
    if (dragPending) applyDrag()
  }
  const up = () => {
    window.removeEventListener('pointermove', move)
    window.removeEventListener('pointerup', up)
    if (wobOn) wobEnd()
    flushDrag()
    // 提交位移：left/top 一次写回终点（只重排一帧），translate 归零
    dragBase.value = null
  }
  window.addEventListener('pointermove', move)
  window.addEventListener('pointerup', up)
}

function startResize(e: PointerEvent, dir: Dir) {
  if (props.win.maximized) return
  store.focus(props.win.id)
  const sx = e.clientX
  const sy = e.clientY
  const { x, y, width, height, minWidth, minHeight } = props.win
  const move = (ev: PointerEvent) => {
    const d = layout.toLogicalDelta(ev.clientX - sx, ev.clientY - sy)
    const dx = d.x
    const dy = d.y
    let nx = x
    let ny = y
    let nw = width
    let nh = height
    if (dir.includes('e')) nw = Math.max(minWidth, width + dx)
    if (dir.includes('s')) nh = Math.max(minHeight, height + dy)
    if (dir.includes('w')) {
      nw = Math.max(minWidth, width - dx)
      nx = x + (width - nw)
    }
    if (dir.includes('n')) {
      nh = Math.max(minHeight, height - dy)
      ny = y + (height - nh)
    }
    store.resize(props.win.id, { x: nx, y: ny, width: nw, height: nh })
  }
  const up = () => {
    window.removeEventListener('pointermove', move)
    window.removeEventListener('pointerup', up)
  }
  window.addEventListener('pointermove', move)
  window.addEventListener('pointerup', up)
}
</script>

<template>
  <div
    class="cw"
    :class="{
      'cw--open': justOpened,
      'cw--max': win.maximized,
      'cw--max-anim': maxAnim,
      'cw--closing': win.closing,
      'cw--active': isActive,
      'cw--min': win.minimized,
      'cw--genie': genieRunning,
      'cw--wob': !!wobPoints,
      'cw--drag': !!dragBase,
      'cw--occluded': fullyOccluded,
      'cw--exclusive': store.exclusiveId === win.id
    }"
    :style="[boxStyle, moveStyle]"
    @pointerdown="onPointerDown"
  >
    <!-- 位移滤镜定义：feDisplacementMap 靠它把窗口内容逐行压向中心（强度每帧写在 scale 上）。
         · width/height 必须是显式像素：写成 100% 时 Chrome 不渲染这张贴图；
         · 位移只作用于靠近 Dock 的下半部分（上半部分本来也不该压缩），
           再用 feMerge 叠回原图 —— 计算量少了近一半。 -->
    <svg class="cw-warp" aria-hidden="true">
      <filter :id="warpId" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
        <feImage
          :href="warpMap"
          result="cwmap"
          x="0"
          :y="warpTop"
          :width="win.width"
          :height="warpHeight"
          preserveAspectRatio="none"
        />
        <feDisplacementMap
          ref="dispEl"
          in="SourceGraphic"
          in2="cwmap"
          scale="0"
          x="0"
          :y="warpTop"
          :width="win.width"
          :height="warpHeight"
          result="warped"
          xChannelSelector="R"
          yChannelSelector="G"
        />
        <feMerge>
          <feMergeNode in="SourceGraphic" />
          <feMergeNode in="warped" />
        </feMerge>
      </filter>
    </svg>

    <!-- 形变层：clip-path（果冻 / 精灵漏斗）只作用在这一层。 -->
    <div class="cw-clip" :style="innerStyle">
      <div class="cw-body">
        <slot />
      </div>
    </div>

    <!-- 悬浮应用栏：不占布局，浮在窗口内容之上（拖动/双击由这里透传到 .cw）。
         形变（果冻轮廓 / 精灵漏斗）由本组件算好后用 barClip / barY 传进来，
         和应用窗口共用同一套几何 —— 顶边怎么弯、怎么收窄，栏就怎么跟着动。 -->
    <CosmicAppBar
      :win="win"
      :bar-clip="barClip"
      :bar-y="barY"
      @pointerdown="startDrag"
      @dblclick="onBarDblClick"
    />

    <template v-if="!win.maximized">
      <div
        v-for="d in dirs"
        :key="d"
        class="cw-rz"
        :class="`cw-rz--${d}`"
        @pointerdown.stop="startResize($event, d)"
      />
    </template>
  </div>
</template>

<style scoped>
.cw {
  position: absolute;
  /* 每个窗口是一块独立的布局岛：内部怎么变都不牵连外面的排版 */
  contain: layout;
  /* 拖拽把手：禁用触摸手势（滚动 / 缩放手势），避免移动端拖拽被浏览器抢走 */
  touch-action: none;
  color: var(--c-text);
  box-shadow:
    0 22px 60px rgba(0, 0, 0, 0.55),
    0 2px 8px rgba(0, 0, 0, 0.35);
  /* transform 的补间用于「收进 Dock / 从 Dock 还原」；
     box-shadow 的补间让形变收尾时影子淡回来，而不是硬切。 */
  transition:
    opacity 0.22s ease,
    transform 0.5s cubic-bezier(0.32, 0.72, 0, 1),
    box-shadow 0.22s ease;
}
/* 拖动中：位移写在 translate 上，给它一个合成层，移动时不重绘 */
.cw--drag {
  will-change: transform;
  /* 拖动时把 60px 的大模糊投影降级成轻投影：每帧移动若带那坨大阴影，
     软件光栅（无 GPU 环境）每帧都要重画它，是拖拽掉帧的隐形元凶之一。
     松手后 .cw--wob 的 box-shadow:none（果冻态）或常规阴影会接管。 */
  box-shadow: 0 8px 22px rgba(0, 0, 0, 0.4);
  /* 应用栏药丸（.cab-pill 在 CosmicAppBar 组件里）同样把重投影降级，
     它们每帧也跟着果冻形变一起重绘 */
}
.cw--drag :deep(.cab-pill) {
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.28);
}

/* 形变层。clip-path 一旦挂在元素上，元素自己的 box-shadow 也一并被裁掉 ——
   所以背景 / 边框 / 裁剪统统下沉到这层，投影留在 .cw，
   这样果冻、精灵漏斗全程都还有影子，不会「变完形过一会儿才冒出来」。 */
.cw-clip {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  /* 把重绘钉死在这层：果冻 clip-path 每帧只让本层失效，不会连累祖先 /
     兄弟层一起重画（也顺带把溢出裁干净，和应用栏等兄弟节点互不污染） */
  contain: paint;
  border-radius: inherit;
  /* 窗口本体：纯平实底，对齐 GNOME/libadwaita 的 window_bg_color（#222226）。
     原设计是 78% 玻璃底 + 斜向/顶部白色柔光渐变，但渐变会把窗口上半截
     提亮到 #2e–#33（实测），与标准色的均匀平涂明显不符。现已全部去掉，
     只保留 1px 棱边线。 */
  background-color: var(--c-surface);
  background-image: none;
  /* 上缘 1px 亮线 + 下缘暗边：玻璃棱边的厚度感（纯 CSS，零成本） */
  box-shadow:
    inset 0 1px 0 rgba(255, 255, 255, 0.11),
    inset 0 -1px 0 rgba(0, 0, 0, 0.28);
  border: 1px solid var(--c-border);
}
/* 打开：从小放大 + 上浮 + 去虚化，配合 transform-origin 落在 Dock 图标上。
   只挂在 cw--open 上、放完就摘掉：否则后面做还原动画时会把它重新触发、闪一下。 */
.cw--open {
  animation: cw-open 0.46s cubic-bezier(0.16, 1, 0.3, 1) backwards;
}
@keyframes cw-open {
  from {
    opacity: 0;
    transform: scale(0.88) translateY(22px);
    filter: blur(10px);
  }
}
.cw--max {
  animation: none;
}
/* 全屏 / 还原：只在这段时间内给位置与尺寸加补间，拖拽时不受影响 */
.cw--max-anim {
  transition:
    left 0.46s cubic-bezier(0.32, 0.72, 0, 1),
    top 0.46s cubic-bezier(0.32, 0.72, 0, 1),
    width 0.46s cubic-bezier(0.32, 0.72, 0, 1),
    height 0.46s cubic-bezier(0.32, 0.72, 0, 1),
    border-radius 0.46s ease,
    box-shadow 0.3s ease;
}
/* 圆角现在落在这层（border-radius: inherit），补间要跟着一起走，否则全屏时会跳变 */
.cw--max-anim .cw-clip {
  transition: border-radius 0.46s ease;
}
.cw--closing {
  opacity: 0;
  transform: scale(0.97);
  transition:
    opacity 0.16s ease,
    transform 0.16s ease;
}
/* ═══ macOS「精灵」最小化 / 还原 ═══
   形状不再由 keyframes 决定 —— utils/genie.ts 每帧采样出真正的漏斗轮廓（clip-path）
   与整体平移 / 压缩（transform），这里只管「动画期间可见、不吃鼠标、不要补间」。 */
.cw--min {
  pointer-events: none;
  visibility: hidden;
}
/* 动画进行中必须可见，否则一点最小化就被藏了、看不到过程；
   写在 .cw--min 之后并加 !important 才能盖住它的 visibility。
   还必须干掉 transition —— 逐帧写进去的是最终值，再交给浏览器补间会糊成一团。 */
.cw--genie {
  visibility: visible !important;
  pointer-events: none;
  transition: none;
  will-change: transform, opacity;
}
.cw--genie .cw-clip {
  will-change: clip-path;
}

/* 非激活窗口：阴影收一点。
   用 :where() 把特异性压回 0,1,0 —— 否则它会盖掉下面形变期间那条 box-shadow: none。 */
.cw:where(:not(.cw--active)) {
  box-shadow:
    0 14px 40px rgba(0, 0, 0, 0.45),
    0 2px 6px rgba(0, 0, 0, 0.3);
}

/* ═══ 形变期间：不收投影 ═══
   box-shadow 画在元素盒外侧，挂在被裁剪的元素上会被 clip-path 一起裁掉；
   挂在没有裁剪的外层，它就变成一块矩形透明板跟着动 —— 果冻、精灵都会看到。
   那能不能改成跟随轮廓的 drop-shadow？实测代价太大：只要滤镜在线，
   每帧的 clip-path 变化都要重跑一遍滤镜合成，果冻从 60fps 掉到 23fps
   （降频更新形状、换成 blur、缩小滤镜作用范围都试过，无用）。
   所以形变这几百毫秒里直接不投影，收尾时再让 box-shadow 淡回来。 */
.cw--wob,
.cw--genie {
  box-shadow: none;
}

/* ═══ KDE 果冻窗口（Wobbly Windows）═══
   形状与位置每帧都由弹簧物理算出并写成内联样式，所以必须关掉 transition ——
   否则每帧的目标值会被浏览器再插值一次，物理手感全被抹平。 */
.cw--wob {
  transition: none;
  will-change: transform;
}
.cw--wob .cw-clip {
  will-change: clip-path;
}

/* 位移滤镜的定义容器：不参与渲染，只是给 filter: url(#…) 提供引用 */
.cw-warp {
  position: absolute;
  width: 0;
  height: 0;
  overflow: hidden;
}

/* 应用栏已抽成 CosmicAppBar 组件 —— 它挂在窗口**外侧上方**（top: -56px），
   不占窗口内容、也不遮内容，所以这里不需要任何避让。 */
.cw-body {
  flex: 1;
  min-height: 0;
  display: flex;
  overflow: hidden;
}

/* 看不见的窗口里，CSS 动画也一并停掉（转圈、呼吸灯这类）——
   它们虽然不画了，但每秒还在跑动画时钟。 */
.cw--occluded .cw-body *,
.cw--min .cw-body * {
  animation-play-state: paused !important;
}

/* 整块都被盖住：内容停渲染，只留窗口底衬（反正在最上层窗口后面，看不见）。
   用 visibility 而不是 display：布局、滚动位置、输入焦点全部原样保留，
   上层窗口一挪开就能立刻恢复，不会跳。 */
.cw--occluded .cw-body {
  visibility: hidden;
}
/* 投影也一起收掉：完全被盖住时它本来就照不到任何地方，还白占一层合成。
   .cw 自己的 box-shadow 有 0.22s 过渡，揭开时会淡回来，不会硬切。 */
.cw--occluded {
  box-shadow: none;
}

/* 缩放把手 */
.cw-rz {
  position: absolute;
  z-index: 5;
}
.cw-rz--n { top: -3px; left: 10px; right: 10px; height: 7px; cursor: ns-resize; }
.cw-rz--s { bottom: -3px; left: 10px; right: 10px; height: 7px; cursor: ns-resize; }
.cw-rz--w { left: -3px; top: 10px; bottom: 10px; width: 7px; cursor: ew-resize; }
.cw-rz--e { right: -3px; top: 10px; bottom: 10px; width: 7px; cursor: ew-resize; }
.cw-rz--nw { top: -3px; left: -3px; width: 14px; height: 14px; cursor: nwse-resize; }
.cw-rz--ne { top: -3px; right: -3px; width: 14px; height: 14px; cursor: nesw-resize; }
.cw-rz--sw { bottom: -3px; left: -3px; width: 14px; height: 14px; cursor: nesw-resize; }
.cw-rz--se { bottom: -3px; right: -3px; width: 14px; height: 14px; cursor: nwse-resize; }
</style>
