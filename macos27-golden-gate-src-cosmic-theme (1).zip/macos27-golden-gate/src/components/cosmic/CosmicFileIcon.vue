<script setup lang="ts">
/**
 * CosmicFileIcon —— 文件管理器里的文件 / 文件夹图标。
 * 图标取自当前图标主题（默认 Crule Dark，设置里可切 Crule 浅色 / Linuxfx 11）。
 */
import { computed } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { imgForNode, type VNode } from '@/utils/cosmicVfs'

const props = defineProps<{ node: VNode; size: number }>()
const sys = useCosmicSystemStore()
const img = computed(() => imgForNode(props.node, sys.appearance.iconTheme))
</script>

<template>
  <img
    class="cfi-img"
    :src="img"
    :style="{ width: size + 'px', height: size + 'px' }"
    :alt="node.name"
    draggable="false"
  />
</template>

<style scoped>
.cfi-img {
  display: block;
  flex: none;
  object-fit: contain;
}
</style>
