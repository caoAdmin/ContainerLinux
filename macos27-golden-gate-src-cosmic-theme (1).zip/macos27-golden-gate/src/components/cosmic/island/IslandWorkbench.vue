<script setup lang="ts">
/**
 * IslandWorkbench —— 信息岛展开后的工作台
 * 左侧分组导航（按外观设置里的开关与排序渲染）+ 右侧功能页。
 * 同一份组件既被胶囊堆叠以浮层形式复用，也被「信息岛」应用窗口复用。
 */
import { computed, onMounted, onUnmounted, ref, type Component } from 'vue'
import { useIslandHubStore, type PageDef } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

import PageHome from './pages/PageHome.vue'
import PageTodos from './pages/PageTodos.vue'
import PageCalendar from './pages/PageCalendar.vue'
import PageFocus from './pages/PageFocus.vue'
import PageClipboard from './pages/PageClipboard.vue'
import PageMessages from './pages/PageMessages.vue'
import PageTranslate from './pages/PageTranslate.vue'
import PageShelf from './pages/PageShelf.vue'
import PageAI from './pages/PageAI.vue'
import PageSystem from './pages/PageSystem.vue'
import PageAppearance from './pages/PageAppearance.vue'
import PageUpdates from './pages/PageUpdates.vue'

const props = withDefaults(defineProps<{ windowed?: boolean }>(), { windowed: false })
const emit = defineEmits<{ (e: 'close'): void }>()
const s = useIslandHubStore()

const comps: Record<string, Component> = {
  home: PageHome, todos: PageTodos, calendar: PageCalendar, focus: PageFocus,
  clipboard: PageClipboard, messages: PageMessages, translate: PageTranslate,
  shelf: PageShelf, ai: PageAI, system: PageSystem, appearance: PageAppearance, updates: PageUpdates
}
const groups = computed(() => {
  const out: { name: string; items: PageDef[] }[] = []
  for (const p of s.enabledPages) {
    let g = out.find((x) => x.name === p.group)
    if (!g) { g = { name: p.group, items: [] }; out.push(g) }
    g.items.push(p)
  }
  return out
})
const current = computed(() => comps[s.activePage] ?? PageHome)
const title = computed(() => s.pages.find((p) => p.id === s.activePage)?.label ?? '今日概览')

function go(page: string) { s.activePage = page }

const hhmm = ref('')
let timer = 0
function tick() {
  hhmm.value = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: !s.settings.clock24 })
}
onMounted(() => { tick(); timer = window.setInterval(tick, 1000) })
onUnmounted(() => window.clearInterval(timer))
</script>

<template>
  <section
    class="ih-root ih-workbench"
    :class="[`ih-skin-${s.settings.skin}`, { 'ih-font-pixel': s.settings.font === 'pixel', 'ih-workbench--window': props.windowed }]"
    :style="{ '--ih-accent': s.settings.accent, opacity: s.settings.opacity / 100 }"
  >
    <!-- 左侧导航 -->
    <aside class="ih-wb-side">
      <div class="ih-wb-brand">
        <span class="ih-wb-brand-ico"><Icon name="ri-apps-2-line" :size="16" color="#fff" /></span>
        <div><b>信息岛</b><span>Island Hub · {{ s.update.version }}</span></div>
      </div>

      <template v-for="g in groups" :key="g.name">
        <div class="ih-wb-group">{{ g.name }}</div>
        <button
          v-for="p in g.items" :key="p.id" class="ih-wb-nav" :class="{ on: s.activePage === p.id }"
          @click="go(p.id)"
        >
          <Icon :name="p.icon" :size="14" color="currentColor" />
          <span>{{ p.label }}</span>
          <span v-if="p.id === 'messages' && s.unreadCount" class="ih-nav-badge">{{ s.unreadCount }}</span>
          <span v-else-if="p.id === 'focus' && s.focus.running" class="ih-nav-badge" style="background:#7b5cf0">●</span>
        </button>
      </template>

      <div class="ih-wb-side-foot">
        音乐播放仍由桌面灵动岛承担<br />数据保存在本机 · 不上传
      </div>
    </aside>

    <!-- 右侧主区 -->
    <div class="ih-wb-main">
      <header class="ih-wb-head">
        <h2>{{ title }}</h2>
        <span class="ih-wb-clock">{{ hhmm }}</span>
        <button v-if="!props.windowed" class="ih-wb-close" title="收起" @click="emit('close')"><Icon name="ri-close-line" :size="16" color="currentColor" /></button>
      </header>
      <div class="ih-wb-body">
        <component :is="current" @go="go" />
      </div>
    </div>

    <Transition name="ih-toast">
      <div v-if="s.toast" class="ih-toast">{{ s.toast }}</div>
    </Transition>
  </section>
</template>
