<script setup lang="ts">
/**
 * IslandStack —— 「合一」后的灵动胶囊堆叠
 *
 * 与音乐灵动岛是同一摞：音乐胶囊是最上层清晰主卡（CosmicDesktop, z 9400），
 * 本组件只负责压在它下方、逐层错位 / 收窄 / 虚化的信息卡（最多露 2 层，
 * 合计 3 层）。卡片总数不限，滚轮 / 圆点换卡；点击任意层直接展开工作台。
 *
 * 全岛没有材质 / 配色特例：音乐胶囊、信息胶囊、展开卡一律挂同一块
 * LgSheet liquid 官方液态玻璃，一律读 <html data-ih-skin> 上的 --ih-* 令牌；
 * 换肤、切磨砂、滚轮轮转对所有卡片一视同仁，不再读取专辑封面主题色。
 */
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import { useCosmicStore } from '@/stores/cosmic'
import Icon from '@/components/common/Icon.vue'
import LgSheet from '../glass/LgSheet.vue'
import IslandCompact from './IslandCompact.vue'

const props = withDefaults(defineProps<{ musicOpen?: boolean }>(), { musicOpen: false })

const s = useIslandHubStore()
const cosmic = useCosmicStore()

const hostEl = ref<HTMLElement | null>(null)
const stackEl = ref<HTMLElement | null>(null)

/** 全部卡片都渲染，按环上槽位套类名：
      top / mid / low 是三个可见槽位，offUp / offDown 是「已移出可见区」的
      两个待命槽 —— 元素始终在 DOM 里，只是移出 + 透明。

      ⚠️ 两条铁律（都踩过）：
      ① 绝不按可见性 v-if 卸载：元素重新挂载后 transition 从第一帧就是终值，
         切换会完全没有过渡动画；
      ② 绝不按槽位排序：卡片是 absolute 定位、层级由 z-index 决定，排序对
         视觉毫无影响，但 v-for 顺序一变 Vue 就要 insertBefore 移动 DOM 节点，
         而 DOM 移动会打断该元素正在进行的 CSS 过渡 —— 表现为「滑到一半突然
         到位」。这里严格按环上位置 pos 的固定顺序渲染。 */
const layers = computed(() =>
  s.ringCards.map((r) => ({ card: r.card, slot: r.slot, rel: r.rel, key: r.card.id }))
)
const isOnStage = (slot: string) => slot === 'top' || slot === 'mid' || slot === 'low'

/* 宿主位置由 CSS 硬绑定在 top:13px（与音乐岛同轴），不再读
   持久化的 topOffset —— 旧值 62/70 曾把整摞推到半屏之外。
   scale / opacity 仍由外观设置控制。 */
const hostStyle = computed(() => {
  /* 默认态绝不下发 transform / opacity<1：宿主一旦带这两者就会创建
     层叠上下文，卡片就无法与音乐胶囊按槽位插层（牌堆夹心）。
     用户真的调了缩放 / 透明度时只能牺牲夹心 —— 给宿主一个中间层 z，
     保证整摞至少还压在壁纸装饰之上。 */
  const st: Record<string, string> = { '--ih-gap': s.settings.topOffset + 'px' }
  if (s.settings.scale !== 100) st.transform = `scale(${s.settings.scale / 100})`
  if (s.settings.opacity !== 100) st.opacity = String(s.settings.opacity / 100)
  if (st.transform || st.opacity) st.zIndex = '9430'
  return st
})

/** 自动避让：启动台铺满全屏（z 9500）时把信息岛收拢，别让它的玻璃层
   在启动台背后继续采样 / 发光。通知条只占左侧 24~408px、控制中心只占
   右侧 1080~1420px，居中的岛（589~851px）与两者都不相交，避让它们只会
   让精心调好的两层折叠台阶凭空消失 —— 所以这里只看 launcherOpen。 */
const tucked = computed(() => s.settings.autoTuck && cosmic.launcherOpen)
const hidden = computed(() => cosmic.isFullscreen && s.settings.autoTuck)

function onDocPointerDown(e: PointerEvent) {
  if (!s.stackOpen) return
  if (hostEl.value && !hostEl.value.contains(e.target as Node)) s.closeStack()
}
watch(() => s.stackOpen, (v) => {
  if (v) document.addEventListener('pointerdown', onDocPointerDown, true)
  else {
    document.removeEventListener('pointerdown', onDocPointerDown, true)
    peekSuppressUntil = Date.now() + 380
    setPeek(false, 0)
  }
})
/* 避让 / 全屏时整摞本来就淡出收起了，别把展开态一直挂着 */
watch([tucked, hidden], ([t, h]) => { if (t || h) setPeek(false, 0) })

/** 滚轮换卡：一挡一张，带冷却防惯性连翻 */
let wheelLockAt = 0
function onWheel(e: WheelEvent) {
  if (s.stackOpen || s.stackCards.length < 2) return
  const t = Date.now()
  if (t < wheelLockAt) return
  if (Math.abs(e.deltaY) < 4) return
  wheelLockAt = t + 260
  pinPeek(900)
  s.nextCard(e.deltaY > 0 ? 1 : -1)
}

/** 玻璃高光：跟着鼠标走的中性白光（与皮肤无关，纯材质反射） */
const glow = ref({ x: 50, y: 50 })
function onMove(e: MouseEvent) {
  if (!stackEl.value) return
  const r = stackEl.value.getBoundingClientRect()
  glow.value = { x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 }
}
const glowStyle = computed(() => ({
  background: `radial-gradient(circle at ${glow.value.x}% ${glow.value.y}%, rgba(255,255,255,0.16), transparent 62%)`
}))

/* ═══ 折叠 / 悬停展开 ═══════════════════════════════════════════
   平时只完整显示顶卡，二三两层各往下让出一条底边（几何在 island.css 的
   --ih-y2 / --ih-y3 / --ih-s2 / --ih-s3）。指针进入整摞热区才展开成三层，
   移开自动回缩。

   判定不能用 :hover：卡片只有露出那几像素能命中，指针一往下走就掉出热区，
   于是「展开 → 立刻收起 → 又展开」地抽搐。这里改用几何热区 + 全局
   pointermove：热区高度跟着状态走（折叠态只到两条底边，展开后放到整摞），
   所以指针能自然地一路往下走，也不会挡住下方桌面的点击。

   状态挂在 <html data-ih-peek> 上：下沉的音乐胶囊与信息卡堆是两棵不同的
   DOM，只有公共祖先能同时命中它们 —— 两者永远同一姿态，不会一层展开、
   一层还团着。 */
const peek = ref(false)
let peekTimer = 0
/* 刚收起展开卡时指针往往还停在原地（原来那张大卡的位置 = 卡堆热区），
   不抑制一下就会「刚收起又自己展开」。留一个小窗口，等指针挪开。 */
let peekSuppressUntil = 0
/* 点导航圆点 / 箭头换卡时把整摞钉住一会儿：那排按钮浮在 100px 处，
   已在折叠热区之外，不钉住的话换卡动画会在完全团着的状态下播完，
   用户根本看不见刚才换了什么。 */
let peekPinnedUntil = 0
const FOLD_DELAY = 170

function applyPeek(v: boolean) {
  peek.value = v
  const el = document.documentElement
  if (v) el.dataset.ihPeek = '1'
  else delete el.dataset.ihPeek
}
function setPeek(v: boolean, delay = FOLD_DELAY) {
  window.clearTimeout(peekTimer)
  if (v === peek.value) return
  hostRectAt = 0 // 展开/收起会改变壳体高度，缓存作废
  if (v) applyPeek(true)
  else peekTimer = window.setTimeout(() => applyPeek(false), delay)
}
/** 换卡时短暂展开：让轮转动画在看得见的状态下播完 */
function pinPeek(ms = 1100) {
  peekPinnedUntil = Date.now() + ms
  applyPeek(true)
  window.clearTimeout(peekTimer)
  peekTimer = window.setTimeout(() => {
    if (Date.now() < peekPinnedUntil) return
    const host = hostEl.value
    if (!host) return
    const r = host.getBoundingClientRect()
    const p = lastPoint
    if (!p || p.x < r.left - 8 || p.x > r.right + 8 || p.y < r.top - 6 || p.y > r.top + 122) applyPeek(false)
  }, ms + 20)
}
let lastPoint: { x: number; y: number } | null = null
/* 悬停热区判定：pointermove 可能一帧内连发多次（高刷鼠标 / 事件合并）。
   1) 用 rAF 合并成一帧一次；
   2) 宿主矩形缓存 250ms —— 每次 pointermove 都 getBoundingClientRect 会与
      「光源跟随指针」写根 CSS 变量的操作交错，形成 layout thrash（强制重排）。 */
let moveRAF = 0
let hostRect: DOMRect | null = null
let hostRectAt = 0
function invalidateHostRect() { hostRectAt = 0 }
function hostRectNow(host: HTMLElement): DOMRect {
  const t = performance.now()
  if (!hostRect || t - hostRectAt > 250) {
    hostRect = host.getBoundingClientRect()
    hostRectAt = t
  }
  return hostRect
}
function onPointerMove(e: PointerEvent) {
  lastPoint = { x: e.clientX, y: e.clientY }
  if (!moveRAF) moveRAF = requestAnimationFrame(applyHover)
}
function applyHover() {
  moveRAF = 0
  const host = hostEl.value
  const p = lastPoint
  if (!host || !p) return
  if (s.stackOpen || props.musicOpen || tucked.value || hidden.value) { setPeek(false, 0); return }
  if (Date.now() < peekSuppressUntil) return
  if (Date.now() < peekPinnedUntil) return
  const r = hostRectNow(host)
  // 展开后底槽下探到 ~115px；折叠态是顶卡 + 两片薄台阶（~56px），
  // 热区收到 66px —— 免得指针还悬在主卡下方一片空白里就提前炸开。
  const bottom = r.top + (peek.value ? 122 : 66)
  const inside =
    p.x >= r.left - 8 && p.x <= r.right + 8 &&
    p.y >= r.top - 6 && p.y <= bottom
  setPeek(inside)
}

function openCard(cardId: string, page: string) {
  const i = s.stackCards.findIndex((c) => c.id === cardId)
  if (i >= 0) { s.activeCard = i; s.topIsMusic = false }
  s.openStack(page)
}
/* 导航换卡：先钉住展开，换卡动画才不会在团着的状态下白播 */
function stepCard(dir: number) { pinPeek(); s.nextCard(dir) }
function topCard(i: number | 'music') { pinPeek(); s.goTop(i) }
function onKeydown(e: KeyboardEvent) {
  if (e.key === 'Escape' && s.stackOpen) s.closeStack()
  if ((e.altKey || e.metaKey) && e.key.toLowerCase() === 'c' && !s.stackOpen) {
    e.preventDefault()
    s.openStack('clipboard')
  }
}
onMounted(() => {
  s.bindGlobal()
  window.addEventListener('keydown', onKeydown)
  window.addEventListener('pointermove', onPointerMove, { passive: true })
  window.addEventListener('resize', invalidateHostRect)
})
onUnmounted(() => {
  s.unbindGlobal()
  document.removeEventListener('pointerdown', onDocPointerDown, true)
  window.removeEventListener('keydown', onKeydown)
  window.removeEventListener('pointermove', onPointerMove)
  window.removeEventListener('resize', invalidateHostRect)
  window.clearTimeout(peekTimer)
  if (moveRAF) cancelAnimationFrame(moveRAF)
  delete document.documentElement.dataset.ihPeek
})
</script>

<template>
  <div
    ref="hostEl"
    class="ih-root ih-host"
    :class="[
      `ih-host--${s.settings.dock}`,
      `ih-skin-${s.settings.skin}`,
      `ih-shape-${s.settings.shape}`,
      {
        'ih-font-pixel': s.settings.font === 'pixel',
        'ih-host--tucked': tucked,
        'ih-host--hidden': hidden,
        'ih-host--music-open': props.musicOpen,
        'ih-host--open': s.stackOpen,
        'ih-host--info-top': !s.topIsMusic
      }
    ]"
    :style="hostStyle"
    @wheel.prevent="onWheel"
    @mousemove="onMove"
  >
    <!-- ═══ 压在音乐胶囊下方的虚化信息卡 ═══ -->
    <div ref="stackEl" class="ih-stack">
      <button
        v-for="l in layers"
        :key="l.key"
        class="ih-card-stack ih-card-stack--sub"
        :class="`ih-card-stack--${l.slot}`"
        :tabindex="isOnStage(l.slot) ? 0 : -1"
        :title="'点击展开 · ' + l.card.label"
        @click.stop="isOnStage(l.slot) && openCard(l.card.id, l.card.page)"
      >
        <!-- 全岛统一材质：与音乐灵动岛 .island 一样挂官方 LiquidGlass，
             同一份参数、同一张壁纸、同一层折射 / 色散 / sheen。
             off 槽（已移出可见区）不挂玻璃实例：全环 8 张卡如果每张都挂一份
             WebGL 液态玻璃，光初始化就够卡掉整段动画。它们在动画开始时
             opacity 为 0，进入可见槽位的那一帧才挂上玻璃，肉眼无感。 -->
        <LgSheet v-if="isOnStage(l.slot)" liquid />
        <span class="ih-cloud-glow" :style="glowStyle" />
        <span class="ih-cs-ico"><Icon :name="l.card.icon" :size="15" color="currentColor" /></span>
        <span class="ih-cs-text">
          <b v-if="s.settings.showTitle">{{ l.card.label }}</b>
          <b v-else>信息岛</b>
          <i v-if="!s.settings.minimal">{{ l.card.sub }}</i>
        </span>
        <span v-if="l.slot === 'top'" class="ih-cs-arrow">›</span>
        <span v-if="l.card.badge && l.slot === 'top'" class="ih-cs-badge">{{ l.card.badge }}</span>
      </button>
    </div>

    <!-- 换卡导航：3 层只是视觉层数，卡片总数不限 -->
    <div v-if="s.stackCards.length > 1" class="ih-stack-nav">
      <button class="ih-nav-btn" title="上一张" @click.stop="stepCard(-1)">‹</button>
      <button class="ih-nav-dot" :class="{ on: s.topIsMusic }" title="音乐" @click.stop="topCard('music')" />
      <button
        v-for="(c, i) in s.stackCards" :key="c.id" class="ih-nav-dot"
        :class="{ on: !s.topIsMusic && i === s.activeCard }" :title="c.label"
        @click.stop="topCard(i)"
      />
      <button class="ih-nav-btn" title="下一张" @click.stop="stepCard(1)">›</button>
    </div>

    <!-- ═══ 点击后「就地展开」成与音乐播放器完全同构的玻璃卡片 ═══
         同轴、同宽(328)、同高(168)、同一块 LgSheet liquid、同一条
         0.52s 宽高过渡曲线。不弹侧边栏大工作台、不使用 fixed 遮罩。 ═══ -->
    <Transition name="ih-expand">
      <IslandCompact v-if="s.stackOpen" @close="s.closeStack()" />
    </Transition>
  </div>
</template>

<style scoped>
/* 玻璃高光层：铺满卡片，跟着鼠标走 */
.ih-cloud-glow {
  position: absolute;
  inset: 0;
  pointer-events: none;
  transition: background 0.12s linear;
}
/* 只抬升内容元素：LgSheet 渲染的官方玻璃层是卡片直接子元素，
   必须保留它自己的 absolute 定位，否则 fill 模式会塌缩 / 错位。 */
.ih-card-stack > .ih-cs-ico,
.ih-card-stack > .ih-cs-text,
.ih-card-stack > .ih-cs-arrow,
.ih-card-stack > .ih-cs-badge {
  position: relative;
  z-index: 1;
}
</style>
