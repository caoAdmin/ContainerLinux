<script setup lang="ts">
/**
 * IslandCompact —— 「合一」后的胶囊展开卡片
 *
 * 与 CosmicDesktop 里的音乐播放器 .island / .island-player 完全同构：
 *   · 同一位置（顶部居中 13px）、同一收起尺寸 262×44 → 展开 328×168
 *   · 同一块 LgSheet liquid 官方液态玻璃（同一张壁纸、同一套折射色散）
 *   · 同一条 0.52s cubic-bezier(.32,.72,0,1) 壳体宽高过渡
 *   · 同一套内容缩放：固定 168px 高、scale 0.262 → 1、transform-origin 22px 0
 *   · 同一套收起方式：点击卡片空白处 / 收起按钮 / 岛外 / Esc
 *
 * 本卡片是音乐播放器的「信息页孪生体」：同一块官方液态玻璃、同一套
 * --ih-* 令牌、同一条展开曲线，没有任何专属材质或配色分支。
 * 展开后与音乐播放器处在同一个位置、盖住胶囊，视觉上就是胶囊就地长成一张玻璃卡片。
 * 这里只放每页 3~4 条轻量信息，绝不把 748×508 的侧边栏工作台塞进来。
 */
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useIslandHubStore, SKINS } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'
import LgSheet from '../glass/LgSheet.vue'

const emit = defineEmits<{ (e: 'close'): void }>()
const s = useIslandHubStore()

const page = computed(() => s.pages.find((p) => p.id === s.activePage))
const title = computed(() => page.value?.label ?? '今日概览')
const icon = computed(() => page.value?.icon ?? 'ri-dashboard-3-line')

const hhmm = ref('')
let timer = 0
function tick() {
  hhmm.value = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: !s.settings.clock24 })
}
onMounted(() => { tick(); timer = window.setInterval(tick, 1000) })
onUnmounted(() => window.clearInterval(timer))

const translateInput = ref('')
function doTranslate() {
  if (!translateInput.value.trim()) return
  s.translate(translateInput.value.trim())
  translateInput.value = ''
}

/** 底部圆点换卡：同步 activeCard 与 activePage，展开态不关闭 */
function goCard(pageId: string) {
  const i = s.stackCards.findIndex((c) => c.page === pageId)
  if (i >= 0) { s.activeCard = i; s.topIsMusic = false }
  s.activePage = pageId
}
function goPage(p: string) { s.activePage = p }
/** 回到音乐胶囊：把它放回顶层并收起功能卡 */
function backToMusic() { s.goTop('music'); emit('close') }

const mmss = computed(() => `${Math.floor(s.focus.remaining / 60)}:${String(s.focus.remaining % 60).padStart(2, '0')}`)
const fmtSize = (n: number) => (n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : Math.round(n / 1000) + ' KB')
const unread = computed(() => s.messages.filter((m) => m.unread).slice(0, 3))
</script>

<template>
  <section class="ih-compact lg-host ih-root" @click.stop="emit('close')">
    <!-- 与音乐播放器 .island 同一块官方液态玻璃，展开/收起全程同源。 -->
    <LgSheet liquid />

    <div class="ihc-inner">
      <!-- 头部：与音乐播放器 .ip-head 同款（封面圆块 + 两行文字 + 时钟 + 收起） -->
      <header class="ihc-head">
        <span
          class="ihc-art"
          :style="{ background: `linear-gradient(140deg, ${s.settings.accent}, color-mix(in srgb, ${s.settings.accent} 38%, #08080a))` }"
        >
          <Icon :name="icon" :size="19" color="#fff" />
        </span>
        <span class="ihc-title">
          <b>{{ title }}</b>
          <i>{{ page?.group ?? '日常' }} · 信息岛</i>
        </span>
        <span class="ihc-clock">{{ hhmm }}</span>
      </header>

      <!-- 主体：每页 3~4 条轻量信息，不放大工作台。
           不拦截点击 —— 与音乐播放器一致，点卡片任意非控件处即收起。 -->
      <div class="ihc-body">
        <!-- 今日概览 -->
        <template v-if="s.activePage === 'home'">
          <div class="ihc-stats">
            <div class="ihc-stat"><b>{{ s.todayDone }}/{{ s.todos.length }}</b><i>待办</i></div>
            <div class="ihc-stat"><b>{{ s.todayEvents.length }}</b><i>日程</i></div>
            <div class="ihc-stat"><b>{{ s.focus.sessions }}</b><i>专注轮</i></div>
            <div class="ihc-stat"><b>{{ s.unreadCount }}</b><i>未读</i></div>
          </div>
          <div class="ihc-line"><Icon name="ri-sun-line" :size="13" /><span>{{ s.currentTodo?.text ?? '今天没有待办' }}</span></div>
          <div class="ihc-line dim"><Icon name="ri-quill-pen-line" :size="13" /><span>{{ s.note }}</span></div>
        </template>

        <!-- 待办 -->
        <template v-else-if="s.activePage === 'todos'">
          <button v-for="t in s.todos.slice(0, 3)" :key="t.id" class="ihc-row" @click.stop="s.toggleTodo(t.id)">
            <Icon :name="t.done ? 'ri-checkbox-circle-fill' : 'ri-checkbox-blank-circle-line'" :size="14" :color="t.done ? '#2ec27e' : 'rgba(255,255,255,.62)'" />
            <span :class="{ done: t.done }">{{ t.text }}</span>
            <i>{{ t.remind || '—' }}</i>
          </button>
          <div class="ihc-line dim" style="margin-top: 4px">每日笔记：{{ s.note }}</div>
        </template>

        <!-- 日历 -->
        <template v-else-if="s.activePage === 'calendar'">
          <div v-for="e in s.todayEvents.slice(0, 3)" :key="e.id" class="ihc-row">
            <span class="ihc-bar" :style="{ background: e.color }" />
            <span>{{ e.title }}</span>
            <i>{{ e.allDay ? '全天' : e.start + '–' + e.end }}</i>
          </div>
        </template>

        <!-- 专注与饮水 -->
        <template v-else-if="s.activePage === 'focus'">
          <div class="ihc-focus">
            <div class="ihc-timer">{{ mmss }}</div>
            <div class="ihc-focus-side">
              <button class="ihc-btn primary" @click.stop="s.startFocus()">{{ s.focus.running ? '暂停' : '开始专注' }}</button>
              <button class="ihc-btn" @click.stop="s.drink()">+ 一杯水</button>
              <span class="ihc-dim">今日 {{ s.waterTotal }} / {{ s.water.goal }} ml</span>
            </div>
          </div>
        </template>

        <!-- 剪贴板 -->
        <template v-else-if="s.activePage === 'clipboard'">
          <button v-for="c in s.clips.slice(0, 3)" :key="c.id" class="ihc-row" @click.stop="s.copyText(c.content)">
            <Icon :name="c.type === 'image' ? 'ri-image-line' : 'ri-file-text-line'" :size="14" />
            <span>{{ c.note || c.content }}</span>
            <Icon v-if="c.favorite" name="ri-star-fill" :size="12" color="#ffd25e" />
          </button>
        </template>

        <!-- 消息与验证码 -->
        <template v-else-if="s.activePage === 'messages'">
          <button v-for="m in unread" :key="m.id" class="ihc-row" @click.stop="s.readMessage(m.id)">
            <Icon :name="m.source === 'mail' ? 'ri-mail-line' : m.source === 'qq' ? 'ri-qq-line' : 'ri-wechat-line'" :size="14" />
            <span>{{ m.from }}</span>
            <i>{{ m.preview }}</i>
          </button>
          <div v-if="s.visibleOtps.length" class="ihc-line">
            <Icon name="ri-shield-keyhole-line" :size="13" />
            <span>验证码 {{ s.visibleOtps[0].revealed ? s.visibleOtps[0].code : '••••••' }}</span>
            <button class="ihc-mini" @click.stop="s.revealOtp(s.visibleOtps[0].id)">{{ s.visibleOtps[0].revealed ? '复制' : '显示' }}</button>
          </div>
        </template>

        <!-- 翻译 -->
        <template v-else-if="s.activePage === 'translate'">
          <div class="ihc-line">
            <span>{{ s.translateHistory[0]?.src ?? '今天天气很好' }}</span>
            <Icon name="ri-arrow-right-line" :size="13" />
            <b>{{ s.translateHistory[0]?.dst ?? 'The weather is nice today' }}</b>
          </div>
          <div class="ihc-input">
            <input v-model="translateInput" placeholder="输入要翻译的内容…" @click.stop @keydown.enter="doTranslate" />
            <button class="ihc-btn primary" @click.stop="doTranslate">翻译</button>
          </div>
        </template>

        <!-- 置物架 -->
        <template v-else-if="s.activePage === 'shelf'">
          <div v-for="f in s.shelf.slice(0, 3)" :key="f.id" class="ihc-row">
            <Icon name="ri-file-3-line" :size="14" />
            <span>{{ f.name }}</span>
            <i>{{ fmtSize(f.size) }}</i>
          </div>
        </template>

        <!-- AI 状态与额度 -->
        <template v-else-if="s.activePage === 'ai'">
          <div class="ihc-line">
            <span class="ihc-pulse" />
            <b>{{ s.runningAgent?.name ?? '无运行中任务' }}</b>
            <i>{{ s.runningAgent?.task ?? '所有 Agent 空闲' }}</i>
          </div>
          <div v-for="q in s.quotas.slice(0, 2)" :key="q.id" class="ihc-quota">
            <span>{{ q.name }}</span>
            <div class="ihc-qbar"><i :style="{ width: (q.total ? (q.used / q.total) * 100 : 0) + '%', background: q.color }" /></div>
            <b>{{ q.used }}{{ q.unit }}</b>
          </div>
        </template>

        <!-- 系统状态 -->
        <template v-else-if="s.activePage === 'system'">
          <div v-for="h in s.sysHints.slice(0, 3)" :key="h.id" class="ihc-row">
            <Icon :name="h.icon" :size="14" :color="h.tone" />
            <span>{{ h.text }}</span>
          </div>
          <div class="ihc-line dim">音量 {{ s.volume }}% · {{ s.inputLang }} · 大写锁定 {{ s.capsLock ? '开' : '关' }}</div>
        </template>

        <!-- 外观 -->
        <template v-else-if="s.activePage === 'appearance'">
          <div class="ihc-skins">
            <button
              v-for="k in SKINS" :key="k.id" class="ihc-skin"
              :class="{ on: s.settings.skin === k.id }"
              :style="{ background: k.swatch }" :title="k.name"
              @click.stop="s.settings.skin = k.id"
            />
          </div>
          <div class="ihc-seg">
            <button :class="{ on: s.settings.shape === 'capsule' }" @click.stop="s.settings.shape = 'capsule'">胶囊</button>
            <button :class="{ on: s.settings.shape === 'notch' }" @click.stop="s.settings.shape = 'notch'">刘海</button>
            <span class="ihc-dim">{{ s.settings.scale }}%</span>
            <input v-model.number="s.settings.scale" class="ihc-range" type="range" min="80" max="120" step="5" @click.stop @pointerdown.stop />
          </div>
        </template>

        <!-- 关于与更新 -->
        <template v-else>
          <div class="ihc-line"><Icon name="ri-download-cloud-2-line" :size="14" /><b>信息岛 {{ s.update.version }}</b><i>数据保存在本机</i></div>
          <button class="ihc-btn primary" @click.stop="s.checkUpdate()">{{ s.update.checking ? '检查中…' : '检查更新' }}</button>
          <div class="ihc-line dim">{{ s.update.state === 'latest' ? '已是最新版本' : s.update.state === 'found' ? '发现新版本，可一键安装' : '' }}</div>
        </template>
      </div>

      <!-- 底部：换卡圆点 + 快捷入口（卡片总数不限，视觉只露三层） -->
      <footer class="ihc-foot">
        <button class="ihc-nav" title="上一张" @click.stop="s.nextCard(-1)">‹</button>
        <div class="ihc-dots">
          <button
            v-for="c in s.stackCards" :key="c.id" class="ihc-dot"
            :class="{ on: c.page === s.activePage }" :title="c.label"
            @click.stop="goCard(c.page)"
          />
        </div>
        <button class="ihc-nav" title="下一张" @click.stop="s.nextCard(1)">›</button>
        <span class="ihc-spacer" />
        <button class="ihc-more" @click.stop="backToMusic">音乐</button>
        <button class="ihc-more" @click.stop="goPage('appearance')">外观</button>
        <button class="ihc-more" @click.stop="goPage('home')">概览</button>
      </footer>
    </div>
  </section>
</template>
