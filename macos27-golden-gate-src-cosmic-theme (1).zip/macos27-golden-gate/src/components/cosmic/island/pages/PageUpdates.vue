<script setup lang="ts">
/** 关于与更新：应用内检查更新、下载校验、更新日志 */
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const logs = [
  { v: 'v1.4.0', d: '新增灵动胶囊堆叠、文件置物架、AI 额度面板与像素字体', t: '当前版本' },
  { v: 'v1.3.0', d: '新增快捷翻译、验证码自动隐藏、月历时间线', t: '2 天前' },
  { v: 'v1.2.0', d: '新增番茄专注、饮水提醒、每日笔记归档与自动结转', t: '1 周前' },
  { v: 'v1.1.0', d: '新增剪贴板历史、消息三源切换、Agent 状态灯', t: '2 周前' },
  { v: 'v1.0.0', d: '信息岛首个版本：五款皮肤、形态与三边停靠', t: '1 个月前' }
]
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">关于与更新</h2>
    <p class="ih-sub">桌面信息岛 · 功能取材自 fly-island 与岛仔 Daozai，音乐播放仍由原生灵动岛承担。</p>

    <div class="ih-hero" style="margin-bottom:16px">
      <h3>信息岛 {{ s.update.version }}</h3>
      <p>轻量、常驻、可折叠的桌面信息中心。待办、剪贴板、消息、日程、专注与 AI 状态，一叠胶囊全部收进手边。</p>
      <div class="ih-hero-tags"><span>12 个功能页</span><span>5 款皮肤</span><span>3 边停靠</span><span>本地存储</span></div>
    </div>

    <div class="ih-card">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
        <div style="flex:1">
          <b style="font-size:12.5px">{{ s.update.checking ? '正在检查更新…' : s.update.state === 'found' ? '发现新版本 v1.5.0' : s.update.state === 'done' ? '已是最新版本' : '当前已是最新版本' }}</b>
          <div style="font-size:10.5px;color:var(--ih-mute);margin-top:3px">上次检查：今天 {{ s.clock(Date.now()) }}</div>
        </div>
        <button class="ih-btn ih-btn--primary ih-btn--sm" :disabled="s.update.checking" @click="s.checkUpdate()">
          <Icon name="ri-refresh-line" :size="12" color="#fff" />检查更新
        </button>
      </div>
      <div v-if="s.update.checking" class="ih-bar"><i :style="{ width: s.update.progress + '%' }" /></div>
      <div v-if="s.update.state === 'found'" class="ih-btn-row" style="margin-top:11px">
        <button class="ih-btn ih-btn--sm ih-btn--primary" @click="s.installUpdate()"><Icon name="ri-download-2-line" :size="12" color="#fff" />下载并安装</button>
        <span style="font-size:10.5px;color:var(--ih-mute)">校验 SHA256 后重启更新，保留全部设置与数据</span>
      </div>
    </div>

    <p class="ih-sec-title">更新记录</p>
    <div v-for="l in logs" :key="l.v" class="ih-row">
      <span class="ih-tag ih-tag--on">{{ l.v }}</span>
      <div class="ih-row-main"><b>{{ l.d }}</b><span>{{ l.t }}</span></div>
    </div>

    <p class="ih-sec-title">数据与隐私</p>
    <div class="ih-card" style="font-size:11px;line-height:1.8;color:var(--ih-dim)">
      所有待办、笔记、剪贴板历史、置物架记录与外观设置都保存在本机浏览器，不上传任何服务器。<br />
      消息、邮件、AI 额度与验证码均为本地演示数据，不连接真实账号；验证码到时自动隐藏。<br />
      像素字体 Fusion Pixel 12px 采用 SIL OFL 1.1 许可，许可证见项目 assets/fonts 目录。
    </div>
  </div>
</template>
