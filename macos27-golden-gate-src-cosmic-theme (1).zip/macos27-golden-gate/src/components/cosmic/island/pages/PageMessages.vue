<script setup lang="ts">
/** 消息：微信 / QQ / QQ 邮箱三源切换、未读红点、正文阅读、验证码卡片 */
import { computed, ref, watch } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const reading = ref<number | null>(null)

const sources = [
  { id: 'wechat' as const, label: '微信', letter: '微', color: '#07c160' },
  { id: 'qq' as const, label: 'QQ', letter: 'Q', color: '#12b7f5' },
  { id: 'mail' as const, label: '邮箱', letter: '@', color: '#5b8def' }
]
const list = computed(() => s.messages.filter((m) => m.source === s.msgSource).slice(0, 20))
const opened = computed(() => s.messages.find((m) => m.id === reading.value) ?? null)
watch(() => s.msgSource, () => (reading.value = null))

function open(m: { id: number }) {
  reading.value = m.id
  s.readMessage(m.id)
}
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">消息与验证码</h2>
    <p class="ih-sub">同一行品牌导航切换微信、QQ 和邮箱；各保留最近 20 项，邮件可在岛内打开正文并返回列表。</p>

    <div class="ih-brand-tabs">
      <button
        v-for="b in sources" :key="b.id" class="ih-brand-tab" :class="{ on: s.msgSource === b.id }"
        @click="s.msgSource = b.id"
      >
        <span class="ih-brand-logo" :style="{ background: b.color }">{{ b.letter }}</span>{{ b.label }}
        <span v-if="s.unreadBySource[b.id]" class="ih-brand-badge">{{ s.unreadBySource[b.id] }}</span>
      </button>
    </div>

    <div v-if="s.visibleOtps.length" style="margin-bottom:12px">
      <p class="ih-sec-title">验证码 · 自动隐藏</p>
      <div v-for="o in s.visibleOtps" :key="o.id" class="ih-otp-card">
        <div style="display:flex;align-items:center;gap:12px">
          <div style="flex:1;min-width:0">
            <div style="font-size:10.5px;color:var(--ih-dim)">{{ o.from }} · {{ Math.max(0, o.hideAfter - Math.floor((Date.now() - o.time) / 1000)) }}s 后隐藏</div>
            <div class="ih-otp-code">{{ o.revealed ? o.code : '••••••' }}</div>
          </div>
          <div class="ih-btn-row">
            <button class="ih-btn ih-btn--sm" @click="s.revealOtp(o.id)"><Icon :name="o.revealed ? 'ri-eye-off-line' : 'ri-eye-line'" :size="12" color="currentColor" /></button>
            <button class="ih-btn ih-btn--sm ih-btn--primary" @click="s.copyText(o.code, '验证码已复制')">复制</button>
            <button class="ih-btn ih-btn--sm ih-btn--ghost" @click="s.dismissOtp(o.id)"><Icon name="ri-close-line" :size="12" color="currentColor" /></button>
          </div>
        </div>
      </div>
    </div>

    <template v-if="opened">
      <div class="ih-btn-row" style="margin-bottom:10px">
        <button class="ih-btn ih-btn--sm" @click="reading = null"><Icon name="ri-arrow-left-s-line" :size="13" color="currentColor" />返回列表</button>
      </div>
      <div class="ih-card">
        <div style="display:flex;align-items:center;gap:9px;margin-bottom:12px">
          <div><b style="font-size:14px">{{ opened.title }}</b><div style="font-size:10.5px;color:var(--ih-mute);margin-top:2px">{{ opened.from }} · {{ s.clock(opened.time) }}{{ opened.account ? ' · ' + opened.account : '' }}</div></div>
        </div>
        <div class="ih-mail-body">{{ s.previewEnabled ? opened.body : opened.body.slice(0, 24) + '…（正文预览已隐藏，可在下方开启）' }}</div>
        <div class="ih-btn-row" style="margin-top:14px">
          <button class="ih-btn ih-btn--sm" @click="s.copyText(opened.body, '正文已复制')">复制正文</button>
          <label style="display:flex;align-items:center;gap:7px;font-size:11px;color:var(--ih-dim);margin-left:auto;cursor:pointer">
            <button class="ih-switch" :class="{ on: s.previewEnabled }" @click="s.previewEnabled = !s.previewEnabled"><i /></button>显示通知正文
          </label>
        </div>
      </div>
    </template>

    <template v-else>
      <div v-for="m in list" :key="m.id" class="ih-row" style="cursor:pointer" @click="open(m)">
        <span class="ih-dot" :style="{ background: m.unread ? '#ff4d4f' : 'transparent' }" />
        <div class="ih-row-main">
          <b :class="{ 'ih-unread': m.unread }">{{ m.from }} · {{ m.title }}</b>
          <span>{{ s.previewEnabled ? m.preview : '•••••• 内容已隐藏' }}{{ m.account ? ' · ' + m.account : '' }}</span>
        </div>
        <span class="ih-row-time">{{ s.clock(m.time) }}</span>
      </div>
      <div v-if="!list.length" class="ih-empty"><Icon name="ri-message-3-line" :size="24" color="currentColor" />这个来源暂时没有消息</div>
      <div class="ih-btn-row" style="margin-top:12px">
        <button class="ih-btn ih-btn--sm" @click="s.markAllRead(s.msgSource)">全部标为已读</button>
        <label style="display:flex;align-items:center;gap:7px;font-size:11px;color:var(--ih-dim);margin-left:auto;cursor:pointer">
          <button class="ih-switch" :class="{ on: s.previewEnabled }" @click="s.previewEnabled = !s.previewEnabled"><i /></button>显示通知正文
        </label>
      </div>
    </template>
  </div>
</template>
