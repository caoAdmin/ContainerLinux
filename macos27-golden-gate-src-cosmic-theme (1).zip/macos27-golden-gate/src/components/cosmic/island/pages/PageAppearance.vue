<script setup lang="ts">
/** 外观与布局：五款皮肤 × 两种形态、三边停靠、大小/透明度/颜色、预设、功能页开关与排序 */
import { ref } from 'vue'
import { useIslandHubStore, SKINS } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const presetName = ref('')
const swatches = ['#8ab4f8', '#1f6b46', '#7b5cf0', '#3584e4', '#25c2a0', '#e5a50a', '#e01b24', '#e45b9c', '#2f3440']
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">外观与布局</h2>
    <p class="ih-sub">六款皮肤与刘海 / 胶囊形态自由搭配，可停靠三边、调整大小与透明度，并保存最多 6 个自定义样式预设。</p>

    <div class="ih-card" style="margin-bottom:14px;border-color:color-mix(in srgb, var(--ih-accent) 40%, transparent)">
      <b style="font-size:12px">全岛统一配色</b>
      <p style="font-size:11px;color:var(--ih-dim);line-height:1.7;margin:6px 0 0">
        信息岛与音乐灵动岛是同一个岛：所选皮肤会同时应用到音乐胶囊壳体、播放器文字、下方虚化信息卡和本工作台，
        不会各用各的。默认的「灵动玻璃」直接沿用音乐岛的玻璃 / 磨砂材质；其余五款为自定义主题，
        主题色只作为全岛共用的一层点缀，不取专辑封面色。
      </p>
    </div>

    <p class="ih-sec-title">皮肤</p>
    <div class="ih-skin-grid">
      <button v-for="k in SKINS" :key="k.id" class="ih-skin-item" :class="{ on: s.settings.skin === k.id }" @click="s.settings.skin = k.id">
        <div class="ih-skin-swatch" :style="{ background: k.swatch }" />{{ k.name }}
      </button>
    </div>

    <p class="ih-sec-title">形态与停靠</p>
    <div class="ih-card">
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>岛体形态</b><span>刘海在胶囊顶部多出两只小角</span></div>
        <div class="ih-set-ctl"><div class="ih-seg"><button :class="{ on: s.settings.shape === 'capsule' }" @click="s.settings.shape = 'capsule'">胶囊</button><button :class="{ on: s.settings.shape === 'notch' }" @click="s.settings.shape = 'notch'">刘海</button></div></div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>停靠位置</b><span>顶部与音乐岛合一 / 左侧 / 右侧</span></div>
        <div class="ih-set-ctl"><div class="ih-seg"><button :class="{ on: s.settings.dock === 'top' }" @click="s.settings.dock = 'top'">合一</button><button :class="{ on: s.settings.dock === 'left' }" @click="s.settings.dock = 'left'">左侧</button><button :class="{ on: s.settings.dock === 'right' }" @click="s.settings.dock = 'right'">右侧</button></div></div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>岛体大小</b><span>80% – 140%</span></div>
        <div class="ih-set-ctl"><input v-model.number="s.settings.scale" class="ih-range" type="range" min="80" max="140" step="5" /><b style="font-size:11px;width:38px;text-align:right">{{ s.settings.scale }}%</b></div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>整体透明度</b><span>数值越小越通透</span></div>
        <div class="ih-set-ctl"><input v-model.number="s.settings.opacity" class="ih-range" type="range" min="40" max="100" step="5" /><b style="font-size:11px;width:38px;text-align:right">{{ s.settings.opacity }}%</b></div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>层叠错位</b><span>下层卡片相对音乐胶囊的下移量；整摞始终贴着胶囊，不会分家</span></div>
        <div class="ih-set-ctl"><input v-model.number="s.settings.topOffset" class="ih-range" type="range" min="8" max="28" step="2" /><b style="font-size:11px;width:38px;text-align:right">{{ s.settings.topOffset }}</b></div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>主题色</b><span>全岛共用的点缀色（图标 / 强调控件 / 进度）</span></div>
        <div class="ih-set-ctl" style="gap:5px;flex-wrap:wrap;justify-content:flex-end">
          <button v-for="c in swatches" :key="c" style="width:17px;height:17px;border:2px solid transparent;border-radius:50%;padding:0" :style="{ background: c, borderColor: s.settings.accent === c ? '#fff' : 'transparent' }" @click="s.settings.accent = c" />
        </div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>字体</b><span>系统字体 / 像素字体（Fusion Pixel）</span></div>
        <div class="ih-set-ctl"><div class="ih-seg"><button :class="{ on: s.settings.font === 'system' }" @click="s.settings.font = 'system'">系统</button><button :class="{ on: s.settings.font === 'pixel' }" @click="s.settings.font = 'pixel'">像素</button></div></div>
      </div>
    </div>

    <p class="ih-sec-title">显示与行为</p>
    <div class="ih-card">
      <div v-for="row in [
        { k: 'minimal', b: '极简模式', s: '收起时只显示图标与红点，隐藏辅助文本' },
        { k: 'clock24', b: '24 小时制', s: '关闭后使用 12 小时制' },
        { k: 'showTitle', b: '显示标题', s: '在胶囊上显示功能名称' },
        { k: 'autostart', b: '开机自启动', s: '随桌面启动（演示偏好）' },
        { k: 'autoTuck', b: '自动避让', s: '启动台或全屏应用展开时收拢信息岛，让开画面' }
      ] as const" :key="row.k" class="ih-setting-row">
        <div class="ih-set-label"><b>{{ row.b }}</b><span>{{ row.s }}</span></div>
        <div class="ih-set-ctl"><button class="ih-switch" :class="{ on: s.settings[row.k] }" @click="(s.settings[row.k] as boolean) = !(s.settings[row.k] as boolean)"><i /></button></div>
      </div>
    </div>

    <p class="ih-sec-title">样式预设 · {{ s.presets.length }}/6</p>
    <div class="ih-grid ih-grid--3" style="margin-bottom:10px">
      <div v-for="p in s.presets" :key="p.id" class="ih-preset">
        <button class="ih-preset-x" @click="s.removePreset(p.id)">×</button>
        <b>{{ p.name }}</b><span>{{ SKINS.find((k) => k.id === p.skin)?.name }} · {{ p.shape === 'notch' ? '刘海' : '胶囊' }} · {{ p.scale }}%</span>
        <button class="ih-btn ih-btn--sm" style="margin-top:7px;width:100%" @click="s.applyPreset(p)">应用</button>
      </div>
    </div>
    <div style="display:flex;gap:7px">
      <input v-model="presetName" class="ih-input" placeholder="给当前样式起个名字…" @keydown.enter="s.savePreset(presetName); presetName = ''" />
      <button class="ih-btn ih-btn--primary" :disabled="s.presets.length >= 6" @click="s.savePreset(presetName); presetName = ''"><Icon name="ri-add-line" :size="13" color="#fff" />保存预设</button>
    </div>

    <p class="ih-sec-title">功能页面开关与排序</p>
    <div v-for="(p, i) in s.pages" :key="p.id" class="ih-page-order">
      <Icon :name="p.icon" :size="14" color="currentColor" />
      <b>{{ p.label }}</b>
      <span class="ih-tag">{{ p.group }}</span>
      <button class="ih-btn ih-btn--sm ih-btn--ghost" :disabled="i === 0" @click="s.movePage(p.id, -1)"><Icon name="ri-arrow-up-s-line" :size="13" color="currentColor" /></button>
      <button class="ih-btn ih-btn--sm ih-btn--ghost" :disabled="i === s.pages.length - 1" @click="s.movePage(p.id, 1)"><Icon name="ri-arrow-down-s-line" :size="13" color="currentColor" /></button>
      <button class="ih-switch" :class="{ on: p.enabled }" @click="s.togglePage(p.id)"><i /></button>
    </div>
  </div>
</template>
