<script setup lang="ts">
/** AI 状态灯 + 8 家服务额度面板：订阅额度、重置时间、积分与余额 */
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const STATE: Record<string, { label: string; color: string }> = {
  idle: { label: '空闲', color: '#8b93a5' },
  running: { label: '运行中', color: '#2ec27e' },
  done: { label: '已完成', color: '#3584e4' },
  attention: { label: '需要关注', color: '#e5a50a' }
}
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">AI 状态与额度</h2>
    <p class="ih-sub">Codex / Claude Code 生命周期状态灯，以及各家服务的订阅额度、重置时间、套餐积分与 API 余额。</p>

    <p class="ih-sec-title">Agent 状态灯</p>
    <div class="ih-grid ih-grid--2">
      <button v-for="a in s.agents" :key="a.id" class="ih-card" style="text-align:left;color:var(--ih-fg)" @click="s.cycleAgent(a.id)">
        <div style="display:flex;align-items:center;gap:9px">
          <span class="ih-quota-logo" :style="{ background: STATE[a.state].color }"><Icon name="ri-brain-line" :size="14" color="#fff" /></span>
          <b style="flex:1;font-size:12.5px">{{ a.name }}</b>
          <span class="ih-agent-state"><i :style="{ background: STATE[a.state].color }" />{{ STATE[a.state].label }}</span>
        </div>
        <div style="font-size:10.5px;color:var(--ih-mute);margin-top:8px">{{ a.task || '暂无任务' }} · {{ s.clock(a.time) }}</div>
        <div style="font-size:9.5px;color:var(--ih-mute);margin-top:4px;opacity:0.7">点击切换状态（演示钩子回调）</div>
      </button>
    </div>

    <p class="ih-sec-title">服务额度 · {{ s.quotas.length }} 家</p>
    <div class="ih-grid ih-grid--2">
      <div v-for="q in s.quotas" :key="q.id" class="ih-card ih-quota-card">
        <div class="ih-quota-head">
          <span class="ih-quota-logo" :style="{ background: q.color }">{{ q.name.slice(0, 1) }}</span>
          <b>{{ q.name }}</b><span>{{ q.plan }}</span>
        </div>
        <div v-if="q.balance" class="ih-quota-num">{{ q.balance }}</div>
        <template v-else>
          <div class="ih-quota-num">{{ q.used }}<small> / {{ q.total }} {{ q.unit }}</small></div>
          <div class="ih-bar" style="margin:8px 0"><i :style="{ width: Math.min(100, (q.used / q.total) * 100) + '%', background: q.color }" /></div>
        </template>
        <div style="display:flex;align-items:center;gap:8px;margin-top:9px">
          <span style="font-size:10px;color:var(--ih-mute);flex:1">{{ q.account }} · {{ q.reset }} 重置</span>
          <button class="ih-btn ih-btn--sm" @click="s.refreshQuota(q.id)"><Icon name="ri-refresh-line" :size="11" color="currentColor" />刷新</button>
        </div>
      </div>
    </div>
  </div>
</template>
