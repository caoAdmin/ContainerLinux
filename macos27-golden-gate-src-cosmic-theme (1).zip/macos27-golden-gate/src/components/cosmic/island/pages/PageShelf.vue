<script setup lang="ts">
/** 文件置物架：拖入文件临时收集、点击、拖出、移除（不删除原文件） */
import { ref } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const over = ref(false)
const fileEl = ref<HTMLInputElement | null>(null)

function onDrop(e: DragEvent) {
  over.value = false
  if (e.dataTransfer?.files?.length) s.addShelfFiles(e.dataTransfer.files)
}
function onPick(e: Event) {
  const el = e.target as HTMLInputElement
  if (el.files?.length) s.addShelfFiles(el.files)
  el.value = ''
}
function kb(n: number) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.round(n / 1024) + ' KB' }
function onDragStart(e: DragEvent, name: string) {
  e.dataTransfer?.setData('text/plain', name)
  e.dataTransfer?.setData('application/x-island-file', name)
}
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">文件置物架</h2>
    <p class="ih-sub">拖入文件临时收集，点击可打开、拖出到其他应用。移除记录不会删除原文件。</p>

    <div
      class="ih-drop" :class="{ over }"
      @dragover.prevent="over = true" @dragleave.prevent="over = false" @drop.prevent="onDrop"
      @click="fileEl?.click()"
    >
      <div style="font-size:26px;margin-bottom:6px"><Icon name="ri-upload-cloud-2-line" :size="26" color="currentColor" /></div>
      <div>把文件拖到这里，或点击选择</div>
      <div style="font-size:10px;margin-top:5px;opacity:0.7">仅记录文件名与大小，不上传文件内容</div>
      <input ref="fileEl" type="file" multiple style="display:none" @change="onPick" />
    </div>

    <p class="ih-sec-title">已收集 · {{ s.shelf.length }}</p>
    <div
      v-for="f in s.shelf" :key="f.id" class="ih-row" draggable="true"
      style="cursor:grab" @dragstart="onDragStart($event, f.name)" @click="s.say('已选中 ' + f.name)"
    >
      <span class="ih-clip-thumb" style="width:32px;height:32px;display:grid;place-items:center;background:var(--ih-card-hover);color:var(--ih-dim);border-radius:8px">
        <Icon name="ri-file-3-line" :size="16" color="currentColor" />
      </span>
      <div class="ih-row-main"><b>{{ f.name }}</b><span>{{ f.type.toUpperCase() }} · {{ kb(f.size) }} · {{ s.clock(f.time) }}</span></div>
      <button class="ih-btn ih-btn--sm ih-btn--ghost" title="移除记录" @click.stop="s.removeShelf(f.id)"><Icon name="ri-close-line" :size="13" color="currentColor" /></button>
    </div>
    <div v-if="!s.shelf.length" class="ih-empty"><Icon name="ri-archive-line" :size="24" color="currentColor" />置物架是空的</div>
  </div>
</template>
