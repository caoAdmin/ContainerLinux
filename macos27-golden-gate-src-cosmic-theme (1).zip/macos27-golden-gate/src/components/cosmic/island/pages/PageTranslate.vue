<script setup lang="ts">
/** 快捷翻译：自动判中英或手动指定、剪贴板填入、复制译文、历史记录 */
import { ref, computed } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const src = ref('')
const result = ref<{ dst: string; dir: string }>({ dst: '', dir: '' })
const dirs = [
  { id: 'auto' as const, label: '自动识别' },
  { id: 'zh2en' as const, label: '中 → 英' },
  { id: 'en2zh' as const, label: '英 → 中' }
]
const canPaste = computed(() => typeof navigator !== 'undefined' && !!navigator.clipboard?.readText)

function run() {
  result.value = s.translate(src.value)
  if (result.value.dst) s.commitTranslate(src.value, result.value.dst, result.value.dir)
}
async function fromClipboard() {
  try { src.value = await navigator.clipboard.readText(); run() }
  catch { s.say('剪贴板读取被浏览器拒绝，可直接粘贴') }
}
function swap() {
  if (s.translateDir === 'zh2en') s.translateDir = 'en2zh'
  else if (s.translateDir === 'en2zh') s.translateDir = 'zh2en'
  src.value = result.value.dst || src.value
  run()
}
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">快捷翻译</h2>
    <p class="ih-sub">自动判断中英方向或手动指定；可从剪贴板填入原文并一键复制译文。纯前端内置演示词典，不上传任何文本。</p>

    <div class="ih-seg" style="margin-bottom:12px">
      <button v-for="d in dirs" :key="d.id" :class="{ on: s.translateDir === d.id }" @click="s.translateDir = d.id; if (src) run()">{{ d.label }}</button>
    </div>

    <div class="ih-grid" style="grid-template-columns:1fr 1fr;gap:11px">
      <div class="ih-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <b style="font-size:11.5px">原文</b>
          <div class="ih-btn-row">
            <button class="ih-btn ih-btn--sm" :disabled="!canPaste" @click="fromClipboard"><Icon name="ri-clipboard-line" :size="11" color="currentColor" />粘贴</button>
            <button class="ih-btn ih-btn--sm ih-btn--ghost" :disabled="!src" @click="src = ''; result = { dst: '', dir: '' }">清空</button>
          </div>
        </div>
        <textarea v-model="src" class="ih-textarea" style="min-height:112px" placeholder="输入要翻译的内容…" @input="result = { dst: '', dir: '' }" />
        <div class="ih-btn-row" style="margin-top:9px">
          <button class="ih-btn ih-btn--primary" :disabled="!src.trim()" @click="run()"><Icon name="ri-translate-2" :size="13" color="#fff" />翻译</button>
          <button class="ih-btn" :disabled="!result.dst" @click="swap()"><Icon name="ri-arrow-left-right-line" :size="13" color="currentColor" />交换</button>
        </div>
      </div>
      <div class="ih-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <b style="font-size:11.5px">译文 <span class="ih-tag" style="margin-left:6px">{{ result.dir || '—' }}</span></b>
          <button class="ih-btn ih-btn--sm" :disabled="!result.dst" @click="s.copyText(result.dst, '译文已复制')"><Icon name="ri-file-copy-line" :size="11" color="currentColor" />复制</button>
        </div>
        <div style="min-height:112px;font-size:12.5px;line-height:1.75;color:var(--ih-fg)">{{ result.dst || '译文会显示在这里' }}</div>
      </div>
    </div>

    <p class="ih-sec-title">翻译历史</p>
    <div v-for="h in s.translateHistory" :key="h.id" class="ih-row">
      <div class="ih-row-main"><b>{{ h.src }}</b><span>{{ h.dst }}</span></div>
      <span class="ih-tag">{{ h.dir }}</span>
      <button class="ih-btn ih-btn--sm ih-btn--ghost" @click="s.copyText(h.dst, '译文已复制')"><Icon name="ri-file-copy-line" :size="12" color="currentColor" /></button>
    </div>
    <div v-if="!s.translateHistory.length" class="ih-empty">还没有翻译记录</div>
  </div>
</template>
