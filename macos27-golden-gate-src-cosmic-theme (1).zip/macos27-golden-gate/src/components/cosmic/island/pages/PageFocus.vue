<script setup lang="ts">
/** 番茄专注 + 饮水提醒：可配置时长、休息轮次、每日目标与撤销 */
import { computed } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const total = computed(() => (s.focus.mode === 'focus' ? s.focus.focusMin : s.focus.breakMin) * 60)
const pct = computed(() => Math.max(0, Math.min(100, ((total.value - s.focus.remaining) / total.value) * 100)))
const mmss = computed(() => `${String(Math.floor(s.focus.remaining / 60)).padStart(2, '0')}:${String(s.focus.remaining % 60).padStart(2, '0')}`)
const waterPct = computed(() => Math.min(100, (s.waterTotal / s.water.goal) * 100))
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">专注与饮水</h2>
    <p class="ih-sub">专注与休息计时，收起时也能查看进度；每日饮水目标、单次饮水量可调，记错可撤销。</p>

    <div class="ih-grid" style="grid-template-columns:1fr 1fr;gap:16px">
      <div class="ih-card">
        <div class="ih-seg" style="margin-bottom:16px">
          <button :class="{ on: s.focus.mode === 'focus' }" @click="s.focus.mode = 'focus'; s.resetFocus()">专注</button>
          <button :class="{ on: s.focus.mode === 'break' }" @click="s.focus.mode = 'break'; s.resetFocus()">休息</button>
        </div>
        <div class="ih-focus-ring" :style="{ '--ih-ring': pct + '%' }">
          <div class="ih-focus-inner"><b>{{ mmss }}</b><span>{{ s.focus.mode === 'focus' ? '专注中' : '休息中' }}</span></div>
        </div>
        <div class="ih-btn-row" style="justify-content:center;margin-top:18px">
          <button class="ih-btn ih-btn--primary" @click="s.startFocus()">
            <Icon :name="s.focus.running ? 'ri-pause-fill' : 'ri-play-fill'" :size="14" color="#fff" />{{ s.focus.running ? '暂停' : '开始' }}
          </button>
          <button class="ih-btn" @click="s.resetFocus()"><Icon name="ri-restart-line" :size="13" color="currentColor" />重置</button>
        </div>
        <div style="margin-top:16px;display:flex;gap:8px;align-items:center;font-size:11px;color:var(--ih-dim)">
          <span>专注</span>
          <input v-model.number="s.focus.focusMin" class="ih-input" type="number" min="1" max="120" style="width:64px;height:26px" @change="s.resetFocus()" />
          <span>分 · 休息</span>
          <input v-model.number="s.focus.breakMin" class="ih-input" type="number" min="1" max="60" style="width:64px;height:26px" @change="s.resetFocus()" />
          <span>分</span>
        </div>
        <div style="margin-top:10px;font-size:10.5px;color:var(--ih-mute);text-align:center">今日已完成 {{ s.focus.sessions }} 轮专注</div>
      </div>

      <div class="ih-card">
        <div style="display:flex;align-items:center;gap:9px;margin-bottom:14px">
          <span class="ih-hint-ico" style="background:#3584e422;color:#3584e4"><Icon name="ri-drop-line" :size="15" color="#3584e4" /></span>
          <div><b style="font-size:13px">今日饮水</b><div style="font-size:10.5px;color:var(--ih-mute)">目标 {{ s.water.goal }} ml</div></div>
        </div>
        <div style="font-size:29px;font-weight:700;font-variant-numeric:tabular-nums">{{ s.waterTotal }}<small style="font-size:12px;font-weight:400;color:var(--ih-mute)"> ml</small></div>
        <div class="ih-bar" style="margin:9px 0 14px"><i :style="{ width: waterPct + '%', background: '#3584e4' }" /></div>
        <div class="ih-btn-row">
          <button class="ih-btn ih-btn--primary" @click="s.drink()"><Icon name="ri-add-line" :size="13" color="#fff" />喝一杯 {{ s.water.cup }} ml</button>
          <button class="ih-btn" :disabled="!s.waterRecords.length" @click="s.undoWater()"><Icon name="ri-arrow-go-back-line" :size="13" color="currentColor" />撤销</button>
        </div>
        <div style="margin-top:14px;display:flex;gap:8px;align-items:center;font-size:11px;color:var(--ih-dim)">
          <span>单次</span><input v-model.number="s.water.cup" class="ih-input" type="number" min="50" step="50" style="width:76px;height:26px" />
          <span>ml · 目标</span><input v-model.number="s.water.goal" class="ih-input" type="number" min="500" step="100" style="width:84px;height:26px" /><span>ml</span>
        </div>
        <p class="ih-sec-title">今日记录</p>
        <div v-for="r in s.waterRecords.slice().reverse()" :key="r.id" style="display:flex;justify-content:space-between;font-size:11px;color:var(--ih-dim);padding:4px 0">
          <span>{{ s.clock(r.time) }} · {{ r.ml }} ml</span><span>{{ Math.round((r.ml / s.water.goal) * 100) }}%</span>
        </div>
        <div v-if="!s.waterRecords.length" style="font-size:11px;color:var(--ih-mute);padding:8px 0">还没有记录</div>
      </div>
    </div>
  </div>
</template>
