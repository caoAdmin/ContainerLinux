<script setup lang="ts">
/** 系统状态提示：电源电量 / 网络 / 音量 / 大写锁定 / 输入语言 / 蓝牙 */
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const cards = [
  { icon: 'ri-battery-line', label: '电源与电量', value: '76% · 正在充电', tone: '#2ec27e' },
  { icon: 'ri-wifi-line', label: '网络', value: 'COSMIC-5G · 802.11ax', tone: '#3584e4' },
  { icon: 'ri-volume-up-line', label: '音量', value: '内置扬声器', tone: '#7b5cf0' },
  { icon: 'ri-keyboard-line', label: '大写锁定', value: '', tone: '#e5a50a' },
  { icon: 'ri-translate-2', label: '输入语言', value: '', tone: '#25c2a0' },
  { icon: 'ri-bluetooth-line', label: '蓝牙设备', value: 'AirPods Pro · 已连接', tone: '#5b8def' }
]
function dynamic(i: number) {
  if (i === 1) return navigator.onLine ? cards[i].value : '网络已断开'
  if (i === 2) return s.volume + '% · 内置扬声器'
  if (i === 3) return s.capsLock ? '已开启' : '已关闭'
  if (i === 4) return s.inputLang
  return cards[i].value
}
function act(i: number) {
  if (i === 3) { s.capsLock = !s.capsLock; s.pushHint('ri-keyboard-line', `大写锁定已${s.capsLock ? '开启' : '关闭'}`, '#e5a50a') }
  else if (i === 4) { const list = ['简体中文', 'English (US)', '日本語']; s.inputLang = list[(list.indexOf(s.inputLang) + 1) % list.length]; s.pushHint('ri-translate-2', `输入语言切换为 ${s.inputLang}`, '#25c2a0') }
  else if (i === 2) { s.volume = s.volume >= 100 ? 0 : Math.min(100, s.volume + 10); s.pushHint('ri-volume-up-line', `音量调整为 ${s.volume}%`, '#7b5cf0') }
  else if (i === 1) s.pushHint('ri-wifi-line', navigator.onLine ? '网络已连接' : '网络已断开', navigator.onLine ? '#2ec27e' : '#e01b24')
  else s.pushHint(cards[i].icon, cards[i].label + '状态已刷新', cards[i].tone)
}
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">系统状态</h2>
    <p class="ih-sub">电源与电量、网络变化、音量、大写锁定、输入语言、蓝牙设备状态，都会在小岛上提示。点击卡片可模拟状态变化。</p>

    <div class="ih-grid ih-grid--2">
      <button v-for="(c, i) in cards" :key="c.label" class="ih-card" style="text-align:left;color:var(--ih-fg);display:flex;gap:10px;align-items:center" @click="act(i)">
        <span class="ih-hint-ico" :style="{ background: c.tone + '22', color: c.tone }"><Icon :name="c.icon" :size="15" :color="c.tone" /></span>
        <div style="flex:1;min-width:0"><b style="display:block;font-size:12px">{{ c.label }}</b><span style="font-size:10.5px;color:var(--ih-mute)">{{ dynamic(i) }}</span></div>
      </button>
    </div>

    <div class="ih-card" style="margin-top:14px">
      <div style="display:flex;align-items:center;gap:9px;margin-bottom:9px"><b style="font-size:12px">音量</b><span style="margin-left:auto;font-size:11px;color:var(--ih-dim)">{{ s.volume }}%</span></div>
      <input v-model.number="s.volume" class="ih-range" type="range" min="0" max="100" />
    </div>

    <p class="ih-sec-title">状态事件记录</p>
    <div class="ih-card" style="padding:4px 12px;max-height:200px;overflow-y:auto">
      <div v-for="h in s.sysHints" :key="h.id" class="ih-hint-row">
        <span class="ih-hint-ico" :style="{ background: h.tone + '22', color: h.tone }"><Icon :name="h.icon" :size="13" :color="h.tone" /></span>
        <b>{{ h.text }}</b><span>{{ s.clock(h.time) }}</span>
      </div>
    </div>
  </div>
</template>
