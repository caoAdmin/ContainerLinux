<script setup lang="ts">
/** 待办与每日笔记：单次 / 每天 / 每周重复、当前任务、自动结转、Markdown 归档 */
import { computed, ref } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const draft = ref('')
const repeat = ref<'once' | 'daily' | 'weekly'>('once')
const tab = ref<'todo' | 'archive'>('todo')

const repeatLabel: Record<string, string> = { once: '单次', daily: '每天', weekly: '每周' }
const openCount = computed(() => s.todos.filter((t) => !t.done).length)

function add() {
  s.addTodo(draft.value, repeat.value)
  draft.value = ''
}
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">待办与笔记</h2>
    <p class="ih-sub">当天任务可标记完成、设为当前任务；未完成项支持自动结转到次日，每日笔记可归档并以 Markdown 导出。</p>

    <div class="ih-seg" style="margin-bottom:14px">
      <button :class="{ on: tab === 'todo' }" @click="tab = 'todo'">今日待办 · {{ openCount }}</button>
      <button :class="{ on: tab === 'archive' }" @click="tab = 'archive'">历史归档 · {{ s.archives.length }}</button>
    </div>

    <template v-if="tab === 'todo'">
      <div style="display:flex;gap:7px;margin-bottom:10px">
        <input v-model="draft" class="ih-input" placeholder="添加一条待办，回车确认…" @keydown.enter="add" />
        <select v-model="repeat" class="ih-select" style="width:92px;flex:none">
          <option value="once">单次</option><option value="daily">每天</option><option value="weekly">每周</option>
        </select>
        <button class="ih-btn ih-btn--primary" @click="add"><Icon name="ri-add-line" :size="14" color="#fff" />添加</button>
      </div>

      <div v-for="t in s.todos" :key="t.id" class="ih-row">
        <button class="ih-check" :class="{ on: t.done }" @click="s.toggleTodo(t.id)"><Icon name="ri-check-line" :size="11" color="currentColor" /></button>
        <div class="ih-row-main" style="cursor:pointer" @click="s.setCurrent(t.id)">
          <b :style="{ textDecoration: t.done ? 'line-through' : undefined, opacity: t.done ? 0.5 : 1 }">{{ t.text }}</b>
          <span>{{ repeatLabel[t.repeat] }}{{ t.remind ? ' · 提醒 ' + t.remind : '' }}{{ t.current ? ' · 当前任务' : '' }}</span>
        </div>
        <span v-if="t.current && !t.done" class="ih-tag ih-tag--on">进行中</span>
        <button class="ih-btn ih-btn--sm ih-btn--ghost" title="删除" @click="s.removeTodo(t.id)"><Icon name="ri-close-line" :size="13" color="currentColor" /></button>
      </div>
      <div v-if="!s.todos.length" class="ih-empty"><Icon name="ri-checkbox-circle-line" :size="24" color="currentColor" />今天还没有待办</div>

      <div class="ih-btn-row" style="margin-top:12px">
        <button class="ih-btn ih-btn--sm" @click="s.clearDone()">清除已完成</button>
        <button class="ih-btn ih-btn--sm" @click="s.exportMarkdown()"><Icon name="ri-download-2-line" :size="12" color="currentColor" />导出 Markdown</button>
        <label style="display:flex;align-items:center;gap:7px;font-size:11px;color:var(--ih-dim);margin-left:auto;cursor:pointer">
          <button class="ih-switch" :class="{ on: s.carryOver }" @click="s.carryOver = !s.carryOver"><i /></button>自动结转未完成任务
        </label>
      </div>

      <p class="ih-sec-title">每日笔记</p>
      <textarea v-model="s.note" class="ih-textarea" placeholder="随手记点什么…" />
      <div class="ih-btn-row" style="margin-top:9px">
        <button class="ih-btn ih-btn--primary ih-btn--sm" @click="s.saveArchive()">归档今天</button>
        <span style="font-size:10.5px;color:var(--ih-mute)">归档后{{ s.carryOver ? '未完成任务会结转到今天' : '清空笔记' }}</span>
      </div>
    </template>

    <template v-else>
      <div v-for="a in s.archives" :key="a.date" class="ih-card">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:7px">
          <b style="font-size:12.5px">{{ a.date }}</b>
          <span class="ih-tag">{{ a.done }}/{{ a.total }} 已完成</span>
        </div>
        <div style="font-size:11.5px;line-height:1.7;color:var(--ih-dim);white-space:pre-wrap">{{ a.text || '（无笔记）' }}</div>
      </div>
      <div v-if="!s.archives.length" class="ih-empty">还没有归档记录</div>
    </template>
  </div>
</template>
