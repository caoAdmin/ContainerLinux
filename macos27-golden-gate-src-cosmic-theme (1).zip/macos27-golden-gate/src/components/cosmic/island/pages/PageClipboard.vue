<script setup lang="ts">
/** 图文剪贴板历史：搜索、备注、收藏、删除、一键复制、上限与真实复制监听 */
import { computed, ref } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const q = ref('')
const onlyFav = ref(false)
const filter = ref<'all' | 'text' | 'image'>('all')
const showSettings = ref(false)

const list = computed(() => s.clips.filter((c) => {
  if (onlyFav.value && !c.favorite) return false
  if (filter.value !== 'all' && c.type !== filter.value) return false
  const k = q.value.trim().toLowerCase()
  return !k || c.content.toLowerCase().includes(k) || c.note.toLowerCase().includes(k)
}))
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">剪贴板历史</h2>
    <p class="ih-sub">记录复制过的文本与图片，可搜索内容或备注、收藏常用项、添加备注，点一下重新复制回剪贴板。</p>

    <div style="display:flex;gap:7px;margin-bottom:10px">
      <input v-model="q" class="ih-input" placeholder="搜索内容或备注…" />
      <div class="ih-seg" style="flex:none">
        <button :class="{ on: filter === 'all' }" @click="filter = 'all'">全部</button>
        <button :class="{ on: filter === 'text' }" @click="filter = 'text'">文本</button>
        <button :class="{ on: filter === 'image' }" @click="filter = 'image'">图片</button>
      </div>
      <button class="ih-btn" :class="{ 'ih-btn--primary': onlyFav }" title="只看收藏" @click="onlyFav = !onlyFav"><Icon name="ri-star-line" :size="13" :color="onlyFav ? '#fff' : 'currentColor'" /></button>
      <button class="ih-btn" title="设置" @click="showSettings = !showSettings"><Icon name="ri-settings-3-line" :size="13" color="currentColor" /></button>
    </div>

    <div v-if="showSettings" class="ih-card" style="margin-bottom:12px">
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>自动记录复制内容</b><span>监听系统复制事件，自动写入历史</span></div>
        <div class="ih-set-ctl"><button class="ih-switch" :class="{ on: s.settings.captureCopy }" @click="s.settings.captureCopy = !s.settings.captureCopy"><i /></button></div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>记录图片</b><span>复制图片时生成一条记录</span></div>
        <div class="ih-set-ctl"><button class="ih-switch" :class="{ on: s.settings.captureImages }" @click="s.settings.captureImages = !s.settings.captureImages"><i /></button></div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>历史条数上限</b><span>超出后自动丢弃最旧的记录</span></div>
        <div class="ih-set-ctl"><input v-model.number="s.settings.clipMax" class="ih-range" type="range" min="10" max="100" step="5" /><b style="font-size:11px;width:26px;text-align:right">{{ s.settings.clipMax }}</b></div>
      </div>
      <div class="ih-setting-row">
        <div class="ih-set-label"><b>全局唤出快捷键</b><span>在桌面任意位置唤起剪贴板</span></div>
        <div class="ih-set-ctl"><span class="ih-tag">{{ s.settings.clipShortcut }}</span></div>
      </div>
    </div>

    <div v-for="c in list" :key="c.id" class="ih-card" style="padding:10px 12px">
      <div style="display:flex;gap:10px;align-items:flex-start">
        <span v-if="c.type === 'image'" class="ih-clip-thumb" :style="{ background: c.content }" />
        <span v-else class="ih-clip-thumb" style="display:grid;place-items:center;background:var(--ih-card-hover);color:var(--ih-dim)"><Icon name="ri-file-text-line" :size="18" color="currentColor" /></span>
        <div style="flex:1;min-width:0">
          <div class="ih-clip-preview">{{ c.type === 'image' ? '图片 · ' + c.content : c.content }}</div>
          <input :value="c.note" class="ih-input" style="height:24px;font-size:10.5px;margin-top:7px" placeholder="添加备注…" @change="s.setClipNote(c.id, ($event.target as HTMLInputElement).value)" />
        </div>
        <span class="ih-row-time">{{ s.clock(c.time) }}</span>
      </div>
      <div class="ih-btn-row" style="margin-top:8px;justify-content:flex-end">
        <button class="ih-btn ih-btn--sm" @click="s.toggleFav(c.id)"><Icon :name="c.favorite ? 'ri-star-fill' : 'ri-star-line'" :size="12" color="currentColor" />{{ c.favorite ? '已收藏' : '收藏' }}</button>
        <button class="ih-btn ih-btn--sm ih-btn--primary" @click="s.copyText(c.type === 'image' ? c.content : c.content)">复制</button>
        <button class="ih-btn ih-btn--sm ih-btn--ghost" @click="s.removeClip(c.id)"><Icon name="ri-delete-bin-line" :size="12" color="currentColor" /></button>
      </div>
    </div>
    <div v-if="!list.length" class="ih-empty"><Icon name="ri-clipboard-line" :size="24" color="currentColor" />没有匹配的剪贴板记录</div>

    <div class="ih-btn-row" style="margin-top:12px">
      <button class="ih-btn ih-btn--sm" @click="s.addClip('手动添加的一条记录 · ' + new Date().toLocaleTimeString('zh-CN'))">添加示例</button>
      <button class="ih-btn ih-btn--sm" :disabled="!s.clips.length" @click="s.clearClips()">清空历史</button>
      <span style="margin-left:auto;font-size:10.5px;color:var(--ih-mute)">共 {{ s.clips.length }} 条</span>
    </div>
  </div>
</template>
