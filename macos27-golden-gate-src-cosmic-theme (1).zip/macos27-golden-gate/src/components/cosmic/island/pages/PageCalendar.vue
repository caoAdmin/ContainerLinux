<script setup lang="ts">
/** 月历与当日时间线：全天 / 重复 / 多日历 / 会议提醒 */
import { computed, ref } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const s = useIslandHubStore()
const y = computed(() => s.calCursor.getFullYear())
const m = computed(() => s.calCursor.getMonth())
const today = s.dayKey()

const cells = computed(() => {
  const first = new Date(y.value, m.value, 1)
  const start = new Date(first)
  start.setDate(1 - ((first.getDay() + 6) % 7))
  return Array.from({ length: 42 }, (_, i) => {
    const d = new Date(start)
    d.setDate(start.getDate() + i)
    return { key: s.dayKey(d), day: d.getDate(), out: d.getMonth() !== m.value }
  })
})
const wd = ['一', '二', '三', '四', '五', '六', '日']
function hasEvent(k: string) { return s.events.some((e) => e.date === k) }

const adding = ref(false)
const form = ref({ title: '', start: '10:00', end: '11:00', allDay: false, repeat: 'once' as 'once'|'daily'|'weekly', calendar: '工作', color: '#7b5cf0', remind: 15 })
function submit() {
  if (!form.value.title.trim()) return
  s.addEvent({ ...form.value, date: s.calSelected, title: form.value.title.trim() })
  form.value.title = ''
  adding.value = false
  s.say('日程已添加')
}
</script>

<template>
  <div class="ih-p">
    <h2 class="ih-h1">日历与日程</h2>
    <p class="ih-sub">月历与当日时间线，支持全天、重复日程、多日历合并与会议提前提醒。</p>

    <div class="ih-grid" style="grid-template-columns:1fr 1fr;gap:16px">
      <div>
        <div class="ih-cal-head">
          <b>{{ y }} 年 {{ m + 1 }} 月</b>
          <button class="ih-btn ih-btn--icon" @click="s.shiftMonth(-1)"><Icon name="ri-arrow-left-s-line" :size="14" color="currentColor" /></button>
          <button class="ih-btn ih-btn--icon" @click="s.shiftMonth(1)"><Icon name="ri-arrow-right-s-line" :size="14" color="currentColor" /></button>
        </div>
        <div class="ih-cal-grid">
          <div v-for="w in wd" :key="w" class="ih-cal-wd">{{ w }}</div>
          <button
            v-for="c in cells" :key="c.key" class="ih-cal-day"
            :class="{ out: c.out, today: c.key === today, on: c.key === s.calSelected }"
            @click="s.calSelected = c.key"
          >
            {{ c.day }}<i v-if="hasEvent(c.key)" />
          </button>
        </div>
        <p class="ih-sec-title">日历来源</p>
        <div class="ih-btn-row">
          <span v-for="c in s.calendars" :key="c" class="ih-tag ih-tag--on">{{ c }}</span>
          <button class="ih-btn ih-btn--sm" @click="s.calendars.push('日历 ' + (s.calendars.length + 1))"><Icon name="ri-add-line" :size="12" color="currentColor" />添加</button>
        </div>
      </div>

      <div>
        <div class="ih-cal-head">
          <b>{{ s.calSelected }} 时间线</b>
          <button class="ih-btn ih-btn--sm ih-btn--primary" @click="adding = !adding"><Icon name="ri-add-line" :size="12" color="#fff" />新建</button>
        </div>

        <div v-if="adding" class="ih-card" style="margin-bottom:12px">
          <input v-model="form.title" class="ih-input" placeholder="日程标题" style="margin-bottom:8px" @keydown.enter="submit" />
          <div style="display:flex;gap:7px;margin-bottom:8px">
            <input v-model="form.start" class="ih-input" type="time" :disabled="form.allDay" style="width:105px" />
            <input v-model="form.end" class="ih-input" type="time" :disabled="form.allDay" style="width:105px" />
          </div>
          <div style="display:flex;gap:7px;margin-bottom:8px">
            <select v-model="form.repeat" class="ih-select"><option value="once">不重复</option><option value="daily">每天</option><option value="weekly">每周</option></select>
            <select v-model.number="form.remind" class="ih-select"><option :value="5">提前 5 分</option><option :value="15">提前 15 分</option><option :value="60">提前 1 小时</option></select>
          </div>
          <div class="ih-btn-row">
            <label style="display:flex;align-items:center;gap:6px;font-size:11px;color:var(--ih-dim)"><button class="ih-switch" :class="{on:form.allDay}" @click="form.allDay = !form.allDay"><i /></button>全天</label>
            <button class="ih-btn ih-btn--sm ih-btn--primary" style="margin-left:auto" @click="submit">保存</button>
          </div>
        </div>

        <div class="ih-timeline">
          <div v-for="e in s.todayEvents" :key="e.id" class="ih-tl-row">
            <div class="ih-tl-time">{{ e.allDay ? '全天' : e.start }}</div>
            <span class="ih-tl-dot" :style="{ background: e.color }" />
            <div class="ih-tl-body">
              <b>{{ e.title }}</b>
              <span>{{ e.calendar }} · {{ e.allDay ? '全天' : e.start + '–' + e.end }} · 提前 {{ e.remind }} 分提醒{{ e.repeat !== 'once' ? ' · 重复' : '' }}</span>
              <button class="ih-btn ih-btn--sm ih-btn--ghost" style="margin-top:5px" @click="s.removeEvent(e.id)">删除</button>
            </div>
          </div>
          <div v-if="!s.todayEvents.length" class="ih-empty"><Icon name="ri-calendar-line" :size="24" color="currentColor" />这一天没有安排</div>
        </div>
      </div>
    </div>
  </div>
</template>
