<script setup lang="ts">
/** 今日概览：把两项目的「收起态信息」汇总到一屏，并给出各功能入口 */
import { computed, ref, onMounted, onUnmounted } from 'vue'
import { useIslandHubStore } from '@/stores/islandHub'
import Icon from '@/components/common/Icon.vue'

const emit = defineEmits<{ (e: 'go', page: string): void }>()
const s = useIslandHubStore()
const hhmm = ref('')
let timer = 0
function tick() {
  hhmm.value = new Date().toLocaleTimeString('zh-CN', {
    hour: '2-digit', minute: '2-digit', hour12: !s.settings.clock24
  })
}
onMounted(() => { tick(); timer = window.setInterval(tick, 1000) })
onUnmounted(() => window.clearInterval(timer))

const greeting = computed(() => {
  const h = new Date().getHours()
  return h < 6 ? '夜深了' : h < 11 ? '早上好' : h < 14 ? '中午好' : h < 18 ? '下午好' : '晚上好'
})
const shortcuts = computed(() => [
  { id: 'todos', label: '待办', icon: 'ri-checkbox-circle-line' },
  { id: 'calendar', label: '日程', icon: 'ri-calendar-line' },
  { id: 'clipboard', label: '剪贴板', icon: 'ri-clipboard-line' },
  { id: 'messages', label: '消息', icon: 'ri-message-3-line' },
  { id: 'translate', label: '翻译', icon: 'ri-translate-2' },
  { id: 'shelf', label: '置物架', icon: 'ri-archive-line' },
  { id: 'ai', label: 'AI 额度', icon: 'ri-brain-line' },
  { id: 'appearance', label: '外观', icon: 'ri-palette-line' }
])
</script>

<template>
  <div class="ih-p">
    <div class="ih-hero">
      <h3>{{ greeting }}，{{ hhmm }}</h3>
      <p v-if="s.currentTodo">当前任务 · {{ s.currentTodo.text }}</p>
      <p v-else>今天没有待办，享受清爽的一天。</p>
      <div class="ih-hero-tags">
        <span>待办 {{ s.todayDone }}/{{ s.todos.length }}</span>
        <span>日程 {{ s.todayEvents.length }} 项</span>
        <span>专注 {{ s.focus.sessions }} 轮</span>
        <span>饮水 {{ s.waterTotal }} ml</span>
      </div>
    </div>

    <div class="ih-grid ih-grid--4">
      <button class="ih-stat" style="text-align:left" @click="emit('go','messages')">
        <b :style="{ color: s.unreadCount ? '#ff6b6b' : undefined }">{{ s.unreadCount }}</b>
        <span>未读消息</span><i>微信 / QQ / 邮箱</i>
      </button>
      <button class="ih-stat" style="text-align:left" @click="emit('go','ai')">
        <b :style="{ color: s.runningAgent ? '#2ec27e' : undefined }">{{ s.runningAgent ? '运行中' : '空闲' }}</b>
        <span>Agent 状态</span><i>{{ s.runningAgent?.task || '暂无运行任务' }}</i>
      </button>
      <button class="ih-stat" style="text-align:left" @click="emit('go','focus')">
        <b>{{ Math.floor(s.focus.remaining / 60) }}:{{ String(s.focus.remaining % 60).padStart(2,'0') }}</b>
        <span>{{ s.focus.mode === 'focus' ? '专注剩余' : '休息剩余' }}</span><i>{{ s.focus.running ? '计时中' : '已暂停' }}</i>
      </button>
      <button class="ih-stat" style="text-align:left" @click="emit('go','clipboard')">
        <b>{{ s.clips.length }}</b><span>剪贴板记录</span><i>{{ s.shelf.length }} 个置物文件</i>
      </button>
    </div>

    <p class="ih-sec-title">快捷入口</p>
    <div class="ih-grid ih-grid--4">
      <button v-for="q in shortcuts" :key="q.id" class="ih-btn" style="height:42px;flex-direction:column;gap:3px" @click="emit('go', q.id)">
        <Icon :name="q.icon" :size="15" color="currentColor" />
        <span>{{ q.label }}</span>
      </button>
    </div>

    <p class="ih-sec-title">验证码</p>
    <div v-if="s.visibleOtps.length" class="ih-otp-card">
      <div style="display:flex;align-items:center;gap:12px">
        <div style="flex:1;min-width:0">
          <div style="font-size:10.5px;color:var(--ih-dim)">{{ s.visibleOtps[0].from }} · {{ s.visibleOtps[0].hideAfter }}s 后自动隐藏</div>
          <div class="ih-otp-code">{{ s.visibleOtps[0].revealed ? s.visibleOtps[0].code : '••••••' }}</div>
        </div>
        <div class="ih-btn-row">
          <button class="ih-btn ih-btn--sm" @click="s.revealOtp(s.visibleOtps[0].id)">{{ s.visibleOtps[0].revealed ? '隐藏' : '显示' }}</button>
          <button class="ih-btn ih-btn--sm ih-btn--primary" @click="s.copyText(s.visibleOtps[0].code,'验证码已复制')">复制</button>
        </div>
      </div>
    </div>
    <div v-else class="ih-card" style="font-size:11.5px;color:var(--ih-mute)">暂无待处理的验证码</div>

    <p class="ih-sec-title">最近动态</p>
    <div class="ih-card" style="padding:4px 12px">
      <div v-for="h in s.sysHints.slice(0, 4)" :key="h.id" class="ih-hint-row">
        <span class="ih-hint-ico" :style="{ background: h.tone + '22', color: h.tone }"><Icon :name="h.icon" :size="13" :color="h.tone" /></span>
        <b>{{ h.text }}</b><span>{{ s.clock(h.time) }}</span>
      </div>
    </div>
  </div>
</template>
