<script setup lang="ts">
/**
 * CosmicAppIcon —— COSMIC 应用图标（Dock / 启动台 / 应用栏 / 设置 / 商店共用）。
 * 图标取自当前图标主题（默认 Crule Dark，设置里可切 Crule 浅色 / Linuxfx 11）；
 * 主题里没有这个应用时退回「渐变圆角底 + Remix 字形」的老样式，
 * 保证新增应用不用改这里也有图标。
 * 外框尺寸由调用方通过 :size 指定；站点自己的类名（圆角 / 投影 / hover）
 * 会随属性透传到根元素上，与组件的内联尺寸合并生效。
 */
import { computed, type CSSProperties } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { appIconUrl } from '@/utils/iconThemes'
import Icon from '@/components/common/Icon.vue'

/** 与 CosmicAppDef 结构兼容的最小字段集（商店目录等复用） */
export interface AppIconLike {
  /** 注册表里的应用 id：图标主题按它取图 */
  id?: string
  name: string
  icon: string
  /** 旧字段：直接指定一张图（主题里找不到这个应用时的兜底） */
  img?: string
  from: string
  to: string
}

const props = withDefaults(
  defineProps<{
    app: AppIconLike
    /** 外框边长（px） */
    size: number
    /** 兜底 Remix 字形相对外框的比例 */
    glyph?: number
    /** 指定主题（设置页的预览卡片用）；不传则跟随当前设置 */
    theme?: string
  }>(),
  { glyph: 0.5 }
)

const sys = useCosmicSystemStore()

const themeId = computed(() => props.theme ?? sys.appearance.iconTheme)
/** 主题里的图标优先；主题缺这个应用时才看 app.img */
const src = computed(() => appIconUrl(props.app.id, themeId.value) ?? props.app.img)

const tileStyle = computed<CSSProperties>(() => ({
  width: `${props.size}px`,
  height: `${props.size}px`,
  background: src.value ? 'transparent' : `linear-gradient(140deg, ${props.app.from}, ${props.app.to})`
}))
</script>

<template>
  <span class="cai" :style="tileStyle">
    <img v-if="src" class="cai-img" :src="src" :alt="app.name" draggable="false" />
    <Icon v-else :name="app.icon" :size="Math.round(size * glyph)" color="#fff" />
  </span>
</template>

<style scoped>
.cai {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  /* 位图图标按外框圆角裁切，和渐变底的形状保持一致 */
  overflow: hidden;
}
.cai-img {
  width: 100%;
  height: 100%;
  display: block;
}
</style>
