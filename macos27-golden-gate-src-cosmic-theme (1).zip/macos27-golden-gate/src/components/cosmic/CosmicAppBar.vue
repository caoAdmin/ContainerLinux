<script setup lang="ts">
/**
 * CosmicAppBar —— 悬浮于应用窗口之上的应用栏。
 * 按用户给的 m3e-canvas 设计稿实现：三段胶囊，48 高、全圆角（shape: full），
 * 浮在窗口内容之上（position: absolute，不占布局）。
 *
 *   ① 左「工具」  surfaceContainerHigh → --c-surface-3
 *        · 全屏独占（left）
 *        · 应用快捷操作（＋ 带文字的 filled 钮，展开菜单）
 *        · 置顶（favourite）
 *   ② 中「标识」  surfaceContainerHigh → --c-surface-3，应用图标 + 窗口标题（居中，吃掉剩余宽度）
 *       · 最大化时从两头往中间收，缩进灵动岛（应用名在岛里滑入）
 *   ③ 右「控制」  surfaceContainerHigh → --c-surface-3
 *        · 最小化 / 最大化·还原 / 关闭  —— 三大金刚键
 *
 * 设计稿的 x 坐标换算出：胶囊间隙 12–14px、容器内 padding 8px、按钮 32px。
 * 胶囊之间的空白区域留给父组件当拖动把手（pointerdown 会透传到 .cw）。
 */
import { computed, nextTick, onMounted, onUnmounted, ref, watch, type CSSProperties } from 'vue'
import { useCosmicStore, type CosmicWindowState } from '@/stores/cosmic'
import LgSheet from '@/components/cosmic/glass/LgSheet.vue'
import { useLayoutStore } from '@/stores/layout'
import { getCosmicApp } from '@/utils/cosmicApps'
import Icon from '@/components/common/Icon.vue'
import CosmicAppIcon from './CosmicAppIcon.vue'

const props = defineProps<{
  win: CosmicWindowState
  /** 窗口算好的本帧形变（clip-path，坐标系 = 本组件根盒子：x% 相对窗口宽、y% 相对栏高 46） */
  barClip?: string
  /** 窗口算好的本帧额外平移（仅横向 genie：栏顶骑着顶边中点下潜） */
  barY?: number
}>()
const store = useCosmicStore()
const layout = useLayoutStore()

const def = computed(() => getCosmicApp(props.win.appId))
const isExclusive = computed(() => store.exclusiveId === props.win.id)
/** 最大化时应用栏并进顶栏那一行（应用名会挪到灵动岛里，所以这里只留左右两组） */
const isTray = computed(() => props.win.maximized && !isExclusive.value)

/* ── 并进顶栏时，左右两组要贴到顶栏左组 / 右组的内侧 ──
   顶栏两组的宽度随主题、分辨率变化，量出来最稳。 */
const trayPad = ref({ l: 16, r: 16 })

function measureTray() {
  if (!isTray.value) return
  const sx = layout.scaleX || 1
  const L = document.querySelector('.dd-bar .pillB')
  const R = document.querySelector('.dd-bar .pill-right')
  const l = L ? L.getBoundingClientRect().right / sx : 0
  const r = R ? R.getBoundingClientRect().left / sx : 0
  trayPad.value = {
    l: Math.round(l + 12),
    r: Math.round(layout.canvasW - r + 12)
  }
}

const trayStyle = computed(() =>
  isTray.value
    ? { paddingLeft: trayPad.value.l + 'px', paddingRight: trayPad.value.r + 'px' }
    : {}
)

/** 形变样式：clip-path 让栏跟着窗口顶边一起弯 / 一起收窄；
 *  transform 只在横向 genie 时出现（竖向由父级 transform 负责，这里不能覆盖）。
 *  两个属性都不进 transition —— 逐帧写进去的是最终值，补间会糊成一团。 */
const shapeStyle = computed<CSSProperties>(() => {
  const s: CSSProperties = {}
  if (props.barClip) s.clipPath = props.barClip
  if (props.barY) s.transform = `translateY(${props.barY}px)`
  return s
})

watch(isTray, (t) => t && nextTick(measureTray))
onMounted(() => {
  measureTray()
  window.addEventListener('resize', measureTray)
})
onUnmounted(() => window.removeEventListener('resize', measureTray))

/** 全屏独占时，鼠标靠近屏幕顶边就把应用栏滑出来（和顶栏 / Dock 同一套「边缘唤出」）。
 *  独占态下窗口铺满整块画布，应用栏的外侧上方就是画布外 —— 所以它平时整个滑到
 *  画布外藏起来，唤出时落回到与灵动岛同一行（top:13），只留左右两组
 *  （中间的应用标识已并进顶栏逻辑，独占时不再显示，避免压到灵动岛）。 */
const peek = ref(false)
/** 画布顶边在视口里的位置（缩放 / 留黑边时不是 0），缓存起来避免每帧 layout */
let canvasTop = 0
function measureCanvas() {
  const c = document.querySelector('.stage-canvas')
  canvasTop = c ? c.getBoundingClientRect().top : 0
}
function onMove(e: MouseEvent) {
  if (!isExclusive.value) {
    if (peek.value) peek.value = false
    return
  }
  // 打开阈值与顶栏边缘感应区（7px）一致；打开后放宽到 70px，
  // 覆盖整条应用栏（视口 13–59），鼠标移上去点按钮不会把它又收回去。
  const near = e.clientY - canvasTop <= (peek.value ? 70 : 8)
  if (near !== peek.value) peek.value = near
}
/** 鼠标移出浏览器窗口时也收起，避免应用栏一直挂在外面 */
function onLeave() {
  if (peek.value) peek.value = false
}
onMounted(() => {
  measureCanvas()
  window.addEventListener('mousemove', onMove)
  window.addEventListener('resize', measureCanvas)
  document.addEventListener('mouseleave', onLeave)
})
onUnmounted(() => {
  window.removeEventListener('mousemove', onMove)
  window.removeEventListener('resize', measureCanvas)
  document.removeEventListener('mouseleave', onLeave)
})

/* ── 应用快捷操作菜单 ── */
const opsOpen = ref(false)

const ops = computed(() => [
  {
    id: 'new',
    icon: 'ri-add-line',
    label: '新开一个窗口',
    disabled: !!def.value?.singleton
  },
  {
    id: 'center',
    icon: 'ri-focus-3-line',
    label: '窗口移到屏幕中央',
    disabled: props.win.maximized
  },
  {
    id: 'reset',
    icon: 'ri-aspect-ratio-line',
    label: '恢复默认大小',
    disabled: props.win.maximized
  },
  {
    id: 'closeOthers',
    icon: 'ri-close-circle-line',
    label: `关闭其它 ${def.value?.name ?? ''} 窗口`,
    disabled: !store.windows.some((w) => w.appId === props.win.appId && w.id !== props.win.id)
  }
])

function runOp(id: string) {
  opsOpen.value = false
  const w = props.win
  const d = def.value
  if (id === 'new') {
    store.openApp(w.appId)
  } else if (id === 'center') {
    store.move(
      w.id,
      Math.round((layout.canvasW - w.width) / 2),
      Math.round((layout.canvasH - w.height) / 2)
    )
  } else if (id === 'reset' && d) {
    const width = Math.min(d.width, layout.canvasW)
    const height = Math.min(d.height, layout.canvasH)
    store.resize(w.id, {
      x: Math.round((layout.canvasW - width) / 2),
      y: Math.round((layout.canvasH - height) / 2),
      width,
      height
    })
  } else if (id === 'closeOthers') {
    store.windows
      .filter((x) => x.appId === w.appId && x.id !== w.id)
      .forEach((x) => store.close(x.id))
  }
}

/** 点空白处关掉菜单（捕获阶段，赶在拖动之前） */
function onDocDown(e: PointerEvent) {
  if (opsOpen.value && !(e.target as HTMLElement).closest('.cab-ops, .cab-op')) {
    opsOpen.value = false
  }
}
onMounted(() => document.addEventListener('pointerdown', onDocDown, true))
onUnmounted(() => document.removeEventListener('pointerdown', onDocDown, true))
watch(() => props.win.minimized, (m) => m && (opsOpen.value = false))
</script>

<template>
  <div
    class="cab"
    :class="{
      'cab--inside': isExclusive,
      'cab--peek': isExclusive && peek,
      'cab--tray': isTray
    }"
    :style="[trayStyle, shapeStyle]"
  >
    <!-- ① 左 · 工具 -->
    <div class="cab-pill cab-pill--tools lg-host" :class="{ 'cab-pill--idle': store.activeId !== win.id }">
      <LgSheet v-if="store.activeId === win.id" liquid />
      <button
        class="cab-ib"
        :class="{ 'cab-ib--on': isExclusive }"
        :title="isExclusive ? '退出全屏独占' : '全屏独占'"
        @click.stop="store.toggleExclusive(win.id)"
      >
        <Icon name="ri-fullscreen-line" :size="17" />
      </button>

      <button class="cab-op" title="应用快捷操作" @click.stop="opsOpen = !opsOpen">
        <Icon name="ri-add-line" :size="16" color="#fff" />
        <span>操作</span>
      </button>

      <button
        class="cab-ib"
        :class="{ 'cab-ib--on': win.pinned }"
        :title="win.pinned ? '取消置顶' : '置顶'"
        @click.stop="store.togglePin(win.id)"
      >
        <Icon :name="win.pinned ? 'ri-heart-3-fill' : 'ri-heart-3-line'" :size="17" />
      </button>

      <!-- 快捷操作菜单 -->
      <Transition name="cab-pop">
        <div v-if="opsOpen" class="cab-ops">
          <button
            v-for="op in ops"
            :key="op.id"
            class="cab-ops-item"
            :class="{ 'is-off': op.disabled }"
            :disabled="op.disabled"
            @click.stop="runOp(op.id)"
          >
            <Icon :name="op.icon" :size="15" />
            <span>{{ op.label }}</span>
          </button>
        </div>
      </Transition>
    </div>

    <!-- ② 中 · 应用标识（最大化 / 全屏独占时并进灵动岛那一行，这里就不重复了） -->
    <Transition name="cab-ident">
      <div v-if="!isTray && !isExclusive" class="cab-pill cab-pill--ident lg-host" :class="{ 'cab-pill--idle': store.activeId !== win.id }">
        <LgSheet v-if="store.activeId === win.id" liquid />
        <CosmicAppIcon v-if="def" class="cab-icon" :app="def" :size="32" />
        <span class="cab-name">{{ win.title }}</span>
      </div>
    </Transition>

    <!-- ③ 右 · 三大金刚键 -->
    <div class="cab-pill cab-pill--ctl lg-host" :class="{ 'cab-pill--idle': store.activeId !== win.id }">
      <LgSheet v-if="store.activeId === win.id" liquid />
      <button class="cab-ib" title="最小化" @click.stop="store.minimize(win.id)">
        <Icon name="ri-subtract-line" :size="17" />
      </button>
      <button
        class="cab-ib"
        :title="win.maximized ? '还原' : '最大化'"
        @click.stop="store.toggleMaximize(win.id)"
      >
        <Icon
          :name="win.maximized ? 'ri-checkbox-multiple-blank-line' : 'ri-checkbox-blank-line'"
          :size="17"
        />
      </button>
      <button class="cab-ib cab-ib--close" title="关闭" @click.stop="store.close(win.id)">
        <Icon name="ri-close-line" :size="18" />
      </button>
    </div>
  </div>
</template>

<style scoped>
/* ═══ 应用栏挂在窗口**外侧上方**（不是窗口内部） ═══
   默认状态下它是「与窗口等宽」的三段：左组贴窗口左边、右组贴右边，
   中间的应用标识吃掉剩余宽度，所以整条宽度和窗口完全一致。
   父组件把 pointerdown 透传到 .cw 上做拖拽，所以这里不能锁 pointer-events。 */
.cab {
  position: absolute;
  top: -56px;
  left: 0;
  right: 0;
  height: 46px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  z-index: 40;
  user-select: none;
  color: var(--c-text);
  font-size: 13px;
  /* AppBar 是桌面级浮层（和顶栏 / 灵动岛 / Dock 同一层），不该随窗口内部的
     M3 明暗主题翻色。窗口在设置里切成浅色时 --c-surface-3 = #e6e6ec，
     失焦胶囊的 58% 实底就变成一块白塑料，文字也跟着变深色 ——
     这就是「交互时 AppBar 有时变白」。这里只在 .cab 子树内重定义外观令牌，
     窗口内容（.cw 内部）完全不受影响。 */
  --c-surface-3: #24252b;
  --c-border: rgba(255, 255, 255, 0.12);
  --c-text: #f5f7fa;
  --c-text-dim: rgba(245, 247, 250, 0.72);
  --c-text-mute: rgba(245, 247, 250, 0.48);
  --c-hover: rgba(255, 255, 255, 0.07);
  --c-active: rgba(255, 255, 255, 0.14);
  /* 并进顶栏时左右两组要挪到顶栏内侧 —— 和窗口的 0.46s 宽度补间同曲线，
     这样它们是被窗口「推」过去的，而不是硬跳过去。 */
  transition:
    padding-left 0.46s cubic-bezier(0.32, 0.72, 0, 1),
    padding-right 0.46s cubic-bezier(0.32, 0.72, 0, 1);
}

/* 最大化：并进顶栏那一行。应用名挪去了灵动岛，这里只剩左右两组，
   靠实测的 padding 贴到顶栏左组 / 右组的内侧。 */
.cab--tray {
  left: 0;
  right: 0;
}

/* 全屏独占：窗口铺满整块画布，外侧没有位置了 —— 不再塞回窗口内部，
   而是和顶栏 / Dock 一样滑到画布外，鼠标靠近屏幕顶边再唤出来。
   唤出时的落点：应用栏默认挂在 top:-56，平移 69px 后落在 top:13，
   正好和灵动岛组成同一行（左右两组各占一端，中间让给灵动岛）。 */
.cab--inside {
  transform: translateY(-130%);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 0.42s cubic-bezier(0.32, 0.72, 0, 1),
    opacity 0.24s ease;
}
.cab--peek {
  transform: translateY(69px);
  opacity: 1;
  pointer-events: auto;
}

.cab-pill {
  position: relative;
  isolation: isolate;
  height: 46px;
  display: flex;
  align-items: center;
  border-radius: 23px;
  flex: none;
}
html[data-glass='webgl'] .cab-pill {
  /* 兜底底色：canvas 未就绪/上下文丢失时仍是合理的玻璃观感，不会闪成透明 */
  background: color-mix(in srgb, var(--c-surface-3) 12%, transparent);
  border-color: transparent;
  box-shadow: none;
}
/* 非激活窗口的 AppBar 不挂玻璃层（省一份克隆 + 滤镜），但仍要有个面：
   纯透明会变成「浮在壁纸上的三个空按钮」，也就是原来的透明塑料感。
   这里给薄底 + 实模糊，观感接近玻璃，代价只是每个 pill 一次 backdrop。
   ⚠️ .cab-pill 的 isolation 会让 backdrop 采不到壁纸，故这条用填充色承担，
   模糊只是锦上添花（背后是壁纸时能透出云影）。 */
/* 省电档（手机 / 小窗）：浮层玻璃不挂官方组件（每面一份全屏壁纸克隆太贵），
   AppBar 就只剩被 .lg-host 清空的透明底 —— 看起来像浮在壁纸上的空按钮。
   这里直接把面补回来，比低档的岛 / Dock 更实（背后是壁纸，需要挡住）。 */
html[data-perf='low'] .cab-pill:not(.cab-pill--idle) {
  background: color-mix(in srgb, var(--c-surface-3) 74%, transparent) !important;
  border: 1px solid color-mix(in srgb, var(--c-border) 58%, transparent);
}
html[data-glass='webgl'] .cab-pill--idle {
  background: color-mix(in srgb, var(--c-surface-3) 58%, transparent) !important;
  border: 1px solid color-mix(in srgb, var(--c-border) 55%, transparent);
  -webkit-backdrop-filter: blur(16px) saturate(140%);
  backdrop-filter: blur(16px) saturate(140%);
}
.cab-pill > *:not(.glass-sheet) {
  position: relative;
  z-index: 1;
}

/* ① 工具组（surfaceContainerHigh） */
.cab-pill--tools {
  position: relative;
  gap: 4px;
  padding: 0 7px;
  background: var(--c-surface-3);
  border: 1px solid color-mix(in srgb, var(--c-border) 40%, transparent);
  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.28);
}

/* ③ 控制组（surfaceContainerHigh） */
.cab-pill--ctl {
  gap: 4px;
  padding: 0 7px;
  background: var(--c-surface-3);
  border: 1px solid color-mix(in srgb, var(--c-border) 40%, transparent);
  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.28);
}

/* ② 应用标识 —— 与左右两组同色（不再用紫色强调块），应用图标 + 名称整体居中 */
.cab-pill--ident {
  flex: 1 1 0;
  min-width: 0;
  max-width: 100%;
  justify-content: center;
  gap: 10px;
  padding: 0 14px;
  background: var(--c-surface-3);
  border: 1px solid color-mix(in srgb, var(--c-border) 40%, transparent);
  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.28);
  overflow: hidden;
}
.cab-icon {
  width: 32px;
  height: 32px;
  flex: none;
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.24);
}
.cab-name {
  flex: none;
  min-width: 0;
  font-weight: 650;
  letter-spacing: 0.2px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 最大化：两头一起往中间收，缩进灵动岛。
   .cab 是 space-between —— 中间这块一收窄就自动居中，所以两端的收缩量天然对称。
   岛内的应用名滑入接在同一个时间轴上。 */
.cab-ident-leave-active {
  transition:
    max-width 0.46s cubic-bezier(0.32, 0.72, 0, 1),
    opacity 0.34s ease 0.06s;
  will-change: max-width;
}
.cab-ident-leave-to {
  max-width: 0;
  opacity: 0;
}
/* 还原：等岛里那块先收回去，这一块再从中间撑开 */
.cab-ident-enter-active {
  transition:
    max-width 0.5s cubic-bezier(0.22, 1, 0.36, 1) 0.1s,
    opacity 0.3s ease 0.1s;
}
.cab-ident-enter-from {
  max-width: 0;
  opacity: 0;
}

/* 图标按钮（tonal） */
.cab-ib {
  width: 32px;
  height: 32px;
  flex: none;
  border: none;
  border-radius: 50%;
  background: var(--c-hover);
  color: var(--c-text-dim);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.13s ease, color 0.13s ease;
}
.cab-ib:hover {
  background: var(--c-active);
  color: var(--c-text);
}
.cab-ib--on {
  background: var(--c-accent-soft);
  color: var(--c-accent);
}
.cab-ib--close:hover {
  background: #d94b4b;
  color: #fff;
}

/* 应用快捷操作（filled） */
.cab-op {
  height: 32px;
  padding: 0 14px 0 10px;
  border: none;
  border-radius: 16px;
  background: var(--c-accent);
  color: #fff;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font: inherit;
  font-size: 13px;
  font-weight: 650;
  white-space: nowrap;
  cursor: pointer;
  transition: filter 0.13s ease;
}
.cab-op:hover {
  filter: brightness(1.13);
}

/* ── 快捷操作菜单 ── */
.cab-ops {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  min-width: 216px;
  padding: 6px;
  display: flex;
  flex-direction: column;
  gap: 2px;
  border-radius: 16px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border-strong);
  box-shadow: 0 20px 48px var(--c-shadow);
  z-index: 60;
}
.cab-ops-item {
  height: 34px;
  padding: 0 10px;
  border: none;
  border-radius: 10px;
  background: transparent;
  color: var(--c-text);
  display: flex;
  align-items: center;
  gap: 9px;
  font: inherit;
  font-size: 12.5px;
  text-align: left;
  white-space: nowrap;
  cursor: pointer;
}
.cab-ops-item:hover:not(.is-off) {
  background: var(--c-hover);
}
.cab-ops-item.is-off {
  opacity: 0.38;
  cursor: default;
}

.cab-pop-enter-active,
.cab-pop-leave-active {
  transition: opacity 0.16s ease, transform 0.16s cubic-bezier(0.2, 0.9, 0.3, 1);
}
.cab-pop-enter-from,
.cab-pop-leave-to {
  opacity: 0;
  transform: translateY(-6px) scale(0.97);
}
</style>
