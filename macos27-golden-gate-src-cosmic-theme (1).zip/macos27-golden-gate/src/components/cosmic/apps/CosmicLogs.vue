<script setup lang="ts">
/**
 * COSMIC Logs —— 系统日志
 * 分级（错误/警告/信息/调试）过滤 + 关键字搜索 + 实时追加 + 清空/暂停。
 */
import { computed, onMounted, onUnmounted, ref, nextTick } from 'vue'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

type Level = 'error' | 'warn' | 'info' | 'debug'
interface Entry {
  id: number
  t: string
  unit: string
  level: Level
  msg: string
}

const LEVELS: Array<{ id: Level; label: string; color: string }> = [
  { id: 'error', label: '错误', color: '#ff5b63' },
  { id: 'warn', label: '警告', color: '#f0b64a' },
  { id: 'info', label: '信息', color: '#5ec8f2' },
  { id: 'debug', label: '调试', color: '#8b93a5' }
]

const UNITS = ['cosmic-session', 'cosmic-comp', 'cosmic-panel', 'systemd', 'kernel', 'NetworkManager', 'pipewire', 'xdg-desktop-portal']
const SAMPLES: Array<[Level, string]> = [
  ['info', 'session started, seat0 attached'],
  ['debug', 'compositor: surface commit #%N (damage 1280x720)'],
  ['warn', 'xdg-output: refresh rate mismatch, using 60Hz'],
  ['info', 'app library indexed %N desktop entries'],
  ['error', 'portal: file chooser request timed out after 5000ms'],
  ['info', 'pipewire: default sink changed to "Built-in Audio"'],
  ['debug', 'input: pointer motion coalesced %N events'],
  ['warn', 'battery: capacity below 20%, enabling power saver'],
  ['info', 'network: connected to "COSMIC-5G" (802.11ax)'],
  ['debug', 'text-input: keyboard layout switched to "us"']
]

const entries = ref<Entry[]>([])
const active = ref<Record<Level, boolean>>({ error: true, warn: true, info: true, debug: true })
const query = ref('')
const paused = ref(false)
const follow = ref(true)
const listEl = ref<HTMLElement | null>(null)
let seq = 1
let timer = 0

function stamp(d = new Date()) {
  return d.toLocaleTimeString('zh-CN', { hour12: false }) + '.' + String(d.getMilliseconds()).padStart(3, '0')
}

function push(level: Level, msg: string) {
  const unit = UNITS[Math.floor(Math.random() * UNITS.length)]
  entries.value.push({
    id: seq++,
    t: stamp(),
    unit,
    level,
    msg: msg.replace('%N', String(Math.floor(Math.random() * 900) + 10))
  })
  if (entries.value.length > 500) entries.value.splice(0, entries.value.length - 500)
  if (follow.value) nextTick(scrollBottom)
}

function scrollBottom() {
  const el = listEl.value
  if (el) el.scrollTop = el.scrollHeight
}

function tick() {
  if (paused.value) return
  const roll = Math.random()
  const level: Level = roll > 0.93 ? 'error' : roll > 0.78 ? 'warn' : roll > 0.35 ? 'info' : 'debug'
  const pool = SAMPLES.filter((s) => s[0] === level)
  const msg = pool[Math.floor(Math.random() * pool.length)]?.[1] ?? 'event'
  push(level, msg)
}

const filtered = computed(() => {
  const q = query.value.trim().toLowerCase()
  return entries.value.filter(
    (e) => active.value[e.level] && (!q || e.msg.toLowerCase().includes(q) || e.unit.includes(q))
  )
})

const counts = computed(() => {
  const c: Record<Level, number> = { error: 0, warn: 0, info: 0, debug: 0 }
  for (const e of entries.value) c[e.level]++
  return c
})

function clear() {
  entries.value = []
}

onMounted(() => {
  for (let i = 0; i < 28; i++) tick()
  timer = window.setInterval(tick, 900)
})
onUnmounted(() => clearInterval(timer))
</script>

<template>
  <M3AppShell fabIcon="ri-delete-bin-6-line" @fab="clear">
    <template #rail>
      <aside class="c-sidebar">
        <div class="c-side-title">级别</div>
        <button
          v-for="l in LEVELS"
          :key="l.id"
          class="c-side-item"
          :class="{ active: active[l.id] }"
          :style="{ '--lv': l.color }"
          @click="active[l.id] = !active[l.id]"
        >
          <i class="logs-dot" />
          <span>{{ l.label }}</span>
          <b class="logs-count">{{ counts[l.id] }}</b>
        </button>
        <div class="c-side-title">操作</div>
        <button class="c-side-item" :class="{ active: !paused }" @click="paused = !paused">
          <Icon :name="paused ? 'ri-play-line' : 'ri-pause-line'" :size="17" />
          <span>{{ paused ? '继续' : '暂停' }}</span>
        </button>
        <button class="c-side-item" @click="clear">
          <Icon name="ri-delete-bin-6-line" :size="17" />
          <span>清空</span>
        </button>
      </aside>
    </template>

    <div class="logs">
    <div class="c-toolbar logs-bar">
      <div class="logs-search">
        <Icon name="ri-search-line" :size="14" color="var(--c-text-dim)" />
        <input v-model="query" placeholder="过滤日志…" spellcheck="false" />
      </div>
      <button
        v-for="l in LEVELS"
        :key="l.id"
        class="logs-chip"
        :class="{ on: active[l.id] }"
        :style="{ '--lv': l.color }"
        @click="active[l.id] = !active[l.id]"
      >
        <i />{{ l.label }} <b>{{ counts[l.id] }}</b>
      </button>
      <div class="logs-gap" />
      <button class="c-iconbtn" :title="paused ? '继续' : '暂停'" @click="paused = !paused">
        <Icon :name="paused ? 'ri-play-line' : 'ri-pause-line'" :size="15" />
      </button>
      <button class="c-iconbtn" :title="follow ? '停止跟随' : '跟随最新'" :class="{ active: follow }" @click="follow = !follow; follow && scrollBottom()">
        <Icon name="ri-arrow-down-line" :size="15" />
      </button>
      <button class="c-iconbtn" title="清空" @click="clear">
        <Icon name="ri-delete-bin-6-line" :size="15" />
      </button>
    </div>

    <div ref="listEl" class="logs-list c-scroll">
      <div v-if="!filtered.length" class="logs-empty">没有匹配的日志</div>
      <div v-for="e in filtered" :key="e.id" class="logs-row" :class="'logs-row--' + e.level">
        <span class="logs-t">{{ e.t }}</span>
        <span class="logs-lv" :style="{ color: LEVELS.find((l) => l.id === e.level)?.color }">{{ e.level.toUpperCase() }}</span>
        <span class="logs-unit">{{ e.unit }}</span>
        <span class="logs-msg">{{ e.msg }}</span>
      </div>
    </div>

    <div class="logs-foot">
      <span>{{ filtered.length }} 条 · 共 {{ entries.length }} 条</span>
      <span v-if="paused" class="logs-paused">已暂停</span>
    </div>
  </div>
  </M3AppShell>
</template>

<style scoped>
.logs {
  height: 100%;
  display: flex;
  flex-direction: column;
  min-height: 0;
}
.logs-bar { gap: 8px; }
.logs-search {
  display: flex;
  align-items: center;
  gap: 6px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border);
  border-radius: 8px;
  padding: 0 8px;
  height: 28px;
  min-width: 150px;
}
.logs-search input {
  border: none;
  outline: none;
  background: transparent;
  color: var(--c-text);
  font-size: 12px;
  width: 120px;
}
.logs-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 26px;
  padding: 0 9px;
  border-radius: 999px;
  border: 1px solid var(--c-border);
  background: transparent;
  color: var(--c-text-dim);
  font-size: 11.5px;
  cursor: pointer;
  opacity: 0.55;
}
.logs-chip.on { opacity: 1; color: var(--c-text); background: color-mix(in srgb, var(--lv) 16%, transparent); border-color: color-mix(in srgb, var(--lv) 40%, transparent); }
.logs-chip i { width: 6px; height: 6px; border-radius: 50%; background: var(--lv); }
.logs-chip b { font-weight: 600; opacity: 0.7; }
.logs-gap { flex: 1; }
/* 左栏级别圆点 / 计数 */
.logs-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--lv);
  flex: none;
}
.logs-count {
  margin-left: auto;
  font-weight: 600;
  font-size: 11px;
  opacity: 0.7;
}
.logs-list {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  font-family: 'JetBrains Mono', ui-monospace, monospace;
  font-size: 11.5px;
  line-height: 1.75;
  padding: 4px 0;
}
.logs-empty { padding: 22px; text-align: center; color: var(--c-text-mute); font-family: inherit; }
.logs-row {
  display: grid;
  grid-template-columns: 96px 60px 140px 1fr;
  gap: 10px;
  padding: 1px 14px;
  border-left: 2px solid transparent;
}
.logs-row:hover { background: var(--c-surface-2); }
.logs-row--error { border-left-color: #ff5b63; background: rgba(255, 91, 99, 0.06); }
.logs-row--warn { border-left-color: #f0b64a; }
.logs-t { color: var(--c-text-mute); }
.logs-lv { font-weight: 700; letter-spacing: 0.04em; }
.logs-unit { color: var(--c-text-dim); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.logs-msg { color: var(--c-text); }
.logs-foot {
  flex: none;
  display: flex;
  justify-content: space-between;
  padding: 6px 14px;
  border-top: 1px solid var(--c-border);
  font-size: 11px;
  color: var(--c-text-mute);
}
.logs-paused { color: #f0b64a; }
</style>
