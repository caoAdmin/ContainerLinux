<script setup lang="ts">
/**
 * CtApp —— ContainerLinux 系统应用的统一外壳
 * 数据驱动：ctAppMap[appId] → pages → blocks，由 CtBlock 渲染。
 * 沿用 M3AppShell 单边框框架：左侧独立圆角导航 + 右侧平铺 + 左下 FAB。
 * 提供 ctConfirm / ctToast 给交互型 block（时间轴回滚、蜂群管理、对话）。
 */
import { computed, inject, nextTick, provide, ref } from 'vue'
import M3AppShell from '../M3AppShell.vue'
import LgSheet from '../glass/LgSheet.vue'
import CtBlock from './CtBlock.vue'
import CtComponentManager from './CtComponentManager.vue'
import Icon from '@/components/common/Icon.vue'
import { ctAppMap, ctApps } from '@/data/ct/ctApps'

const appId = inject<string>('ctAppId', '')
const app = computed(() => ctAppMap[appId] || ctApps[0])

const pageIdx = ref(0)
const page = computed(() => app.value.pages[pageIdx.value] || app.value.pages[0])
const scroller = ref<HTMLElement | null>(null)
const tick = ref(0)
const synced = ref(false)
const stamp = ref('')

function selectPage(i: number) {
  pageIdx.value = i
  nextTick(() => scroller.value?.scrollTo({ top: 0, behavior: 'smooth' }))
}

let toastTimer = 0
function refresh() {
  tick.value++
  const d = new Date()
  stamp.value = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`
  synced.value = true
  window.clearTimeout(toastTimer)
  toastTimer = window.setTimeout(() => (synced.value = false), 1600)
}

/* ── 通用 toast ── */
const toastMsg = ref('')
let toastTimer2 = 0
function showToast(msg: string) {
  toastMsg.value = msg
  window.clearTimeout(toastTimer2)
  toastTimer2 = window.setTimeout(() => (toastMsg.value = ''), 2400)
}

/* ── 确认弹层 ── */
const confirmState = ref({
  show: false,
  title: '确认操作',
  text: '',
  confirmLabel: '确认',
  cancelLabel: '取消',
  resolve: (_v: boolean) => {}
})
function openConfirm(opts: { title?: string; text?: string; confirmLabel?: string; cancelLabel?: string }) {
  return new Promise<boolean>((resolve) => {
    confirmState.value = {
      show: true,
      title: opts.title || '确认操作',
      text: opts.text || '',
      confirmLabel: opts.confirmLabel || '确认',
      cancelLabel: opts.cancelLabel || '取消',
      resolve
    }
  })
}
function resolveConfirm(v: boolean) {
  confirmState.value.resolve(v)
  confirmState.value.show = false
}

provide('ctToast', showToast)
provide('ctConfirm', openConfirm)
</script>

<template>
  <M3AppShell :fab-icon="app.fabIcon || 'ri-refresh-line'" @fab="refresh">
    <!-- ── 左导航：每个应用自己的页面 ── -->
    <template #rail>
      <aside class="c-sidebar ct-rail lg-host">
        <LgSheet />
        <div class="ct-brand">
          <span class="ct-brand-ic" :style="{ background: `linear-gradient(135deg, ${app.from}, ${app.to})` }">
            <Icon :name="app.icon" :size="22" />
          </span>
          <div class="ct-brand-txt">
            <div class="ct-brand-n">{{ app.name }}</div>
            <div class="ct-brand-s">{{ app.sub }}</div>
          </div>
        </div>

        <div class="ct-rail-label">页面导航</div>
        <nav class="ct-nav">
          <button
            v-for="(p, i) in app.pages"
            :key="p.id"
            class="ct-nav-i"
            :class="{ on: i === pageIdx }"
            type="button"
            @click="selectPage(i)"
          >
            <Icon :name="p.icon || 'ri-file-list-3-line'" :size="16" />
            <span>{{ p.label }}</span>
            <!-- 组件管理器的分区页 blocks 恒为空（内容由交互组件渲染），0 徽标无意义 -->
            <span v-if="app.id !== 'ct-plugins'" class="ct-nav-n">{{ p.blocks.length }}</span>
          </button>
        </nav>

        <div class="ct-rail-sp" />

        <div class="ct-rail-meta">
          <div class="ct-rm-row"><span>分组</span><b>{{ app.group }}</b></div>
          <div class="ct-rm-row"><span>状态</span><b class="ct-rm-ok"><i />{{ app.status }}</b></div>
          <div class="ct-rm-row"><span>版本</span><b>v6.1 / D38</b></div>
        </div>
      </aside>
    </template>

    <!-- ── 主内容：平铺在窗口框内 ── -->
    <div class="ct-main">
      <!-- 组件管理器有自己的分区内容，不再渲染这层大标题头部 -->
      <header v-if="app.id !== 'ct-plugins'" class="ct-head">
        <div class="ct-head-l">
          <div class="ct-crumb">{{ app.group }} <span>/</span> {{ page.label }}</div>
          <h1 class="ct-h1">{{ app.name }}</h1>
          <p class="ct-desc">{{ app.desc }}</p>
        </div>
        <div class="ct-head-r">
          <span class="ct-status"><i />{{ app.status }}</span>
          <span class="ct-ver">ContainerLinux v6.1</span>
        </div>
      </header>

      <div ref="scroller" class="ct-scroll c-scroll">
        <div :key="app.id === 'ct-plugins' ? app.id : `${app.id}-${pageIdx}-${tick}`" class="ct-page">
          <!-- 组件管理器：一个应用五个平级分区（内核 / 插件 / 原子 / 发行版 / 镜像包）；
               左侧页面导航（app.pages）与内部分区 tab 双向联动 pageIdx -->
          <CtComponentManager
            v-if="app.id === 'ct-plugins'"
            :section="pageIdx"
            @update:section="pageIdx = $event"
          />
          <template v-else>
            <CtBlock v-for="(b, i) in page.blocks" :key="i" :block="b" />
            <div class="ct-end">
              <Icon name="ri-book-2-line" :size="13" />
              内容取自《ContainerLinux 文档合集》v6.1 / D38 · {{ app.pages.length }} 个页面
            </div>
          </template>
        </div>
      </div>

      <footer class="ct-foot">
        <span><i class="ct-dot" />系统运行正常</span>
        <span>{{ stamp ? `上次同步 ${stamp}` : '数据已加载' }}</span>
      </footer>

      <transition name="ct-toast">
        <div v-if="synced" class="ct-toast"><Icon name="ri-check-line" :size="14" /> 状态已刷新</div>
      </transition>
      <transition name="ct-toast">
        <div v-if="toastMsg" class="ct-toast ct-toast2"><Icon name="ri-check-line" :size="14" /> {{ toastMsg }}</div>
      </transition>

      <transition name="ct-modal">
        <div v-if="confirmState.show" class="ct-modal-mask" @click.self="resolveConfirm(false)">
          <div class="ct-modal">
            <h3>{{ confirmState.title }}</h3>
            <p v-if="confirmState.text">{{ confirmState.text }}</p>
            <div class="ct-modal-btns">
              <button class="ct-m-cancel" type="button" @click="resolveConfirm(false)">{{ confirmState.cancelLabel }}</button>
              <button class="ct-m-ok" type="button" @click="resolveConfirm(true)">{{ confirmState.confirmLabel }}</button>
            </div>
          </div>
        </div>
      </transition>
    </div>
  </M3AppShell>
</template>

<style scoped>
/* ── 左导航 ── */
.ct-rail {
  display: flex;
  flex-direction: column;
  gap: 0;
  padding: 16px 12px 80px !important;
}
.ct-brand { display: flex; align-items: center; gap: 10px; padding: 2px 4px 16px; border-bottom: 1px solid var(--c-border); margin-bottom: 14px; }
.ct-brand-ic {
  flex: none; width: 38px; height: 38px; border-radius: 11px; display: grid; place-items: center;
  color: #fff; box-shadow: 0 3px 10px var(--c-shadow);
}
.ct-brand-txt { min-width: 0; }
.ct-brand-n { font-size: 13px; font-weight: 700; color: var(--c-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.ct-brand-s { font-size: 10.5px; color: var(--c-text-mute); margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.ct-rail-label { font-size: 10px; font-weight: 600; letter-spacing: 1px; color: var(--c-text-mute); text-transform: uppercase; padding: 0 8px 8px; }
.ct-nav { display: flex; flex-direction: column; gap: 3px; min-height: 0; overflow-y: auto; }
.ct-nav-i {
  display: flex; align-items: center; gap: 9px; width: 100%; text-align: left;
  padding: 9px 10px; border: 0; border-radius: 10px; background: transparent;
  color: var(--c-text-dim); font-size: 12.5px; cursor: pointer; transition: all .15s;
}
.ct-nav-i:hover { background: var(--c-hover); color: var(--c-text); }
.ct-nav-i.on { background: var(--c-accent-soft, color-mix(in srgb, var(--c-accent) 16%, transparent)); color: var(--c-accent); font-weight: 650; }
.ct-nav-i span:first-of-type { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ct-nav-n { font-size: 10px; color: var(--c-text-mute); font-variant-numeric: tabular-nums; }
.ct-nav-i.on .ct-nav-n { color: var(--c-accent); }
.ct-rail-sp { flex: 1 1 0; min-height: 12px; }
.ct-rail-meta { border-top: 1px solid var(--c-border); padding-top: 12px; display: flex; flex-direction: column; gap: 7px; }
.ct-rm-row { display: flex; justify-content: space-between; font-size: 10.5px; color: var(--c-text-mute); padding: 0 4px; }
.ct-rm-row b { font-weight: 600; color: var(--c-text-dim); }
.ct-rm-ok { display: inline-flex; align-items: center; gap: 5px; color: #4fb783 !important; }
.ct-rm-ok i { width: 6px; height: 6px; border-radius: 50%; background: #4fb783; }

/* ── 主内容 ── */
.ct-main { display: flex; flex-direction: column; min-width: 0; min-height: 0; flex: 1 1 0; }
.ct-head {
  flex: none; display: flex; justify-content: space-between; align-items: flex-start; gap: 16px;
  padding: 18px 24px 15px; border-bottom: 1px solid var(--c-border);
}
.ct-crumb { font-size: 11px; color: var(--c-text-mute); margin-bottom: 6px; }
.ct-crumb span { margin: 0 5px; opacity: .5; }
.ct-h1 { margin: 0 0 5px; font-size: 19px; font-weight: 700; color: var(--c-text); letter-spacing: -.3px; }
.ct-desc { margin: 0; font-size: 11.5px; color: var(--c-text-dim); line-height: 1.5; }
.ct-head-r { flex: none; display: flex; flex-direction: column; align-items: flex-end; gap: 7px; }
.ct-status {
  display: inline-flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 600;
  color: #4fb783; background: rgba(79,183,131,.12); padding: 4px 10px; border-radius: 20px;
}
.ct-status i { width: 6px; height: 6px; border-radius: 50%; background: #4fb783; }
.ct-ver { font-size: 10.5px; color: var(--c-text-mute); }

.ct-scroll { flex: 1 1 0; min-height: 0; overflow-y: auto; padding: 18px 24px 24px; }
.ct-page { max-width: 1000px; }
.ct-end {
  display: flex; align-items: center; gap: 7px; font-size: 10.5px; color: var(--c-text-mute);
  border-top: 1px dashed var(--c-border); padding-top: 14px; margin-top: 6px;
}
.ct-foot {
  flex: none; display: flex; justify-content: space-between; align-items: center; padding: 8px 24px;
  /* 底栏需要明确的"状态栏"表面：原 --c-sidebar(#1c1c20) 与内容区 --c-surface(#212125)
     在深色下仅差 5/5/5，对比度≈1.04:1，肉眼几乎不可辨，看起来仍像透明平涂。
     改用更亮的面板色 --c-surface-2 + 更清晰的 --c-border-strong 顶边 + 向上投影，
     用边缘与景深把底栏和内容区明确分开（深浅主题通用）。 */
  background: var(--c-surface-2);
  border-top: 1px solid var(--c-border-strong);
  box-shadow: 0 -5px 12px -7px rgba(0,0,0,.55);
  position: relative; z-index: 1;
  font-size: 10.5px; color: var(--c-text-mute);
}
.ct-foot span { display: inline-flex; align-items: center; gap: 6px; }
.ct-dot { width: 6px; height: 6px; border-radius: 50%; background: #4fb783; }

.ct-toast {
  position: absolute; right: 22px; bottom: 22px; z-index: 9;
  display: inline-flex; align-items: center; gap: 7px;
  padding: 9px 15px; border-radius: 11px; font-size: 12px; font-weight: 600; color: #fff;
  background: var(--c-accent); box-shadow: 0 8px 24px var(--c-shadow);
}
.ct-toast2 { right: 22px; background: #2f9e6e; }
.ct-toast-enter-active, .ct-toast-leave-active { transition: opacity .2s, transform .2s; }
.ct-toast-enter-from, .ct-toast-leave-to { opacity: 0; transform: translateY(8px); }

/* ── 确认弹层 ── */
.ct-modal-mask {
  position: absolute; inset: 0; z-index: 20; display: grid; place-items: center;
  background: rgba(0,0,0,.32); backdrop-filter: blur(2px);
}
.ct-modal {
  width: min(380px, 80%); padding: 20px 20px 16px; border-radius: 16px;
  background: var(--c-surface, #1c1c1e); border: 1px solid var(--c-border, rgba(255,255,255,.12));
  box-shadow: 0 24px 60px var(--c-shadow); text-align: left;
}
.ct-modal h3 { margin: 0 0 8px; font-size: 15px; font-weight: 700; color: var(--c-text); }
.ct-modal p { margin: 0 0 16px; font-size: 12.5px; line-height: 1.6; color: var(--c-text-dim); }
.ct-modal-btns { display: flex; justify-content: flex-end; gap: 9px; }
.ct-m-cancel {
  border: 1px solid var(--c-border, rgba(255,255,255,.18)); background: transparent;
  color: var(--c-text-dim); font-size: 12.5px; font-weight: 600; padding: 8px 16px; border-radius: 10px; cursor: pointer;
}
.ct-m-cancel:hover { background: var(--c-hover); color: var(--c-text); }
.ct-m-ok {
  border: 0; background: var(--c-accent); color: #fff; font-size: 12.5px; font-weight: 650;
  padding: 8px 16px; border-radius: 10px; cursor: pointer; box-shadow: 0 4px 14px var(--c-shadow);
}
.ct-m-ok:hover { filter: brightness(1.06); }
.ct-modal-enter-active, .ct-modal-leave-active { transition: opacity .18s; }
.ct-modal-enter-from, .ct-modal-leave-to { opacity: 0; }
.ct-modal-enter-active .ct-modal, .ct-modal-leave-active .ct-modal { transition: transform .18s; }
.ct-modal-enter-from .ct-modal, .ct-modal-leave-to .ct-modal { transform: scale(.94); }
</style>
