<script setup lang="ts">
/** 设置 · 通知 —— 勿扰、横幅、锁屏、按应用开关 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const n = sys.notif
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">通知</h1>
    <p class="set-sub">勿扰模式、横幅与按应用开关</p>

    <div class="set-card">
      <div class="set-card-title">勿扰模式</div>
      <div class="set-row">
        <div class="set-label"><b>开启勿扰</b><span>{{ n.dnd ? `静音至 ${n.dndEnd}` : '所有通知正常弹出' }}</span></div>
        <button class="set-switch" :class="{ on: n.dnd }" @click="n.dnd = !n.dnd"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自动勿扰时段</b><span>{{ n.dndStart }} — {{ n.dndEnd }}</span></div>
        <div style="display: flex; gap: 8px; margin-left: auto">
          <input v-model="n.dndStart" type="time" class="set-select" style="min-width: 110px" />
          <input v-model="n.dndEnd" type="time" class="set-select" style="min-width: 110px" />
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">弹出方式</div>
      <div class="set-row">
        <div class="set-label"><b>顶部横幅</b><span>通知到达时短暂弹出</span></div>
        <button class="set-switch" :class="{ on: n.banner }" @click="n.banner = !n.banner"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>锁屏显示通知</b><span>在锁屏界面展示内容</span></div>
        <button class="set-switch" :class="{ on: n.onLockScreen }" @click="n.onLockScreen = !n.onLockScreen"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>通知声音</b><span>弹出时播放提示音</span></div>
        <button class="set-switch" :class="{ on: n.sounds }" @click="n.sounds = !n.sounds"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">应用通知</div>
      <div v-for="a in n.apps" :key="a.name" class="set-item">
        <span class="set-ico"><Icon :name="a.icon" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ a.name }}</b>
          <span>{{ a.on ? '允许通知' : '已关闭' }}</span>
        </div>
        <div class="set-item-ctl">
          <button class="set-switch" :class="{ on: a.on }" @click="a.on = !a.on"><i /></button>
        </div>
      </div>
    </div>
  </div>
</template>
