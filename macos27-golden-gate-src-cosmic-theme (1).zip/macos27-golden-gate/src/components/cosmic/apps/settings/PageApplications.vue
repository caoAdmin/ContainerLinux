<script setup lang="ts">
/** 设置 · 应用程序 —— 默认应用、启动器行为、已安装应用 */
import { useCosmicStore } from '@/stores/cosmic'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { cosmicApps } from '@/utils/cosmicApps'
import Icon from '@/components/common/Icon.vue'
import CosmicAppIcon from '../../CosmicAppIcon.vue'

const store = useCosmicStore()
const sys = useCosmicSystemStore()
const d = sys.defaults
const apps = sys.applications

const kinds = [
  { key: 'browser', label: '网页浏览器', icon: 'ri-global-line', options: ['COSMIC Browser', 'Firefox', 'Chromium'] },
  { key: 'mail', label: '电子邮件', icon: 'ri-mail-line', options: ['Thunderbird', 'Geary', 'COSMIC Mail'] },
  { key: 'files', label: '文件管理器', icon: 'ri-folders-line', options: ['COSMIC Files', 'Nautilus'] },
  { key: 'image', label: '图片查看器', icon: 'ri-image-2-line', options: ['COSMIC Viewer', 'Loupe'] },
  { key: 'music', label: '音乐播放器', icon: 'ri-music-2-line', options: ['COSMIC Player', 'Rhythmbox'] },
  { key: 'video', label: '视频播放器', icon: 'ri-movie-2-line', options: ['COSMIC Player', 'mpv'] },
  { key: 'terminal', label: '终端模拟器', icon: 'ri-terminal-box-line', options: ['COSMIC Terminal', 'Alacritty', 'kitty'] },
  { key: 'textEditor', label: '文本编辑器', icon: 'ri-file-edit-line', options: ['COSMIC Edit', 'Vim', 'Helix'] }
]

function getDefault(key: string): string {
  return (d as unknown as Record<string, string>)[key] ?? ''
}
function setDefault(key: string, value: string) {
  ;(d as unknown as Record<string, string>)[key] = value
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">应用程序</h1>
    <p class="set-sub">默认打开方式与启动器行为</p>

    <div class="set-card">
      <div class="set-card-title">默认应用</div>
      <div v-for="k in kinds" :key="k.key" class="set-row">
        <span class="set-ico"><Icon :name="k.icon" :size="16" /></span>
        <div class="set-label"><b>{{ k.label }}</b><span>双击对应类型文件时使用</span></div>
        <select
          class="set-select"
          :value="getDefault(k.key)"
          @change="setDefault(k.key, ($event.target as HTMLSelectElement).value)"
        >
          <option v-for="o in k.options" :key="o">{{ o }}</option>
        </select>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">启动器</div>
      <div class="set-row">
        <div class="set-label"><b>输入即搜索</b><span>打开启动器后直接键入关键字</span></div>
        <button class="set-switch" :class="{ on: apps.launcherSearch }" @click="apps.launcherSearch = !apps.launcherSearch"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>显示分类标签</b><span>在应用库顶部显示分类</span></div>
        <button class="set-switch" :class="{ on: apps.launcherCategories }" @click="apps.launcherCategories = !apps.launcherCategories"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>记住最近使用</b><span>在启动器优先展示</span></div>
        <button class="set-switch" :class="{ on: apps.rememberRecent }" @click="apps.rememberRecent = !apps.rememberRecent"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>最近项数量</b><span>{{ apps.recentCount }} 个</span></div>
        <input v-model.number="apps.recentCount" type="range" min="4" max="16" step="2" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>呼出快捷键</b><span>打开应用库</span></div>
        <span class="c-kbd">Ctrl + Space</span>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">已安装的 COSMIC 应用 · {{ cosmicApps.length }}</div>
      <div v-for="a in cosmicApps" :key="a.id" class="set-item">
        <CosmicAppIcon class="set-ico" :app="a" :size="34" :glyph="0.44" />
        <div class="set-item-text"><b>{{ a.name }}</b><span>{{ a.description }}</span></div>
        <div class="set-item-ctl">
          <button class="c-btn" style="height: 28px; font-size: 12px" @click="store.openApp(a.id)">
            <Icon name="ri-external-link-line" :size="13" /> 打开
          </button>
        </div>
      </div>
      <div class="set-actions">
        <button class="c-btn c-btn--primary" @click="store.openApp('store')">
          <Icon name="ri-store-3-line" :size="15" /> 从软件商店安装更多
        </button>
      </div>
    </div>
  </div>
</template>
