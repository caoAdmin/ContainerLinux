<script setup lang="ts">
/** 设置 · 电源 —— 电源模式、电池、挂起与熄屏 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const p = sys.power

const modes = [
  { id: 'performance', label: '性能优先', desc: '风扇更积极，续航下降', icon: 'ri-rocket-2-line' },
  { id: 'balanced', label: '平衡', desc: '性能与续航兼顾', icon: 'ri-scales-3-line' },
  { id: 'saver', label: '省电优先', desc: '限制频率，续航最长', icon: 'ri-leaf-line' }
] as const
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">电源</h1>
    <p class="set-sub">电源模式、电池与自动化</p>

    <div class="set-card">
      <div class="set-item" style="padding: 16px 0">
        <span class="set-ico" style="width: 52px; height: 52px; border-radius: 16px; background: var(--c-accent-soft)">
          <Icon name="ri-battery-charge-line" :size="26" />
        </span>
        <div class="set-item-text">
          <b style="font-size: 20px">{{ p.battery }}%</b>
          <span>{{ p.charging ? '正在充电 · 预计 42 分钟充满' : '剩余约 5 小时 20 分钟' }}</span>
        </div>
        <div class="set-item-ctl" style="min-width: 160px">
          <div class="set-progress" style="flex: 1"><i :style="{ width: p.battery + '%' }" /></div>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">电源模式</div>
      <div class="set-row col">
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px">
          <button v-for="m in modes" :key="m.id" class="set-mini" :class="{ active: p.mode === m.id }" @click="p.mode = m.id">
            <Icon :name="m.icon" :size="17" />
            <span class="set-mini-text"><b>{{ m.label }}</b><span>{{ m.desc }}</span></span>
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">自动化</div>
      <div class="set-row">
        <div class="set-label"><b>空闲熄屏</b><span>无操作后关闭屏幕</span></div>
        <select v-model.number="p.screenOffMin" class="set-select">
          <option :value="1">1 分钟</option>
          <option :value="5">5 分钟</option>
          <option :value="10">10 分钟</option>
          <option :value="15">15 分钟</option>
          <option :value="30">30 分钟</option>
          <option :value="0">从不</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自动挂起</b><span>无操作后进入睡眠</span></div>
        <select v-model.number="p.suspendMin" class="set-select">
          <option :value="15">15 分钟</option>
          <option :value="30">30 分钟</option>
          <option :value="60">1 小时</option>
          <option :value="120">2 小时</option>
          <option :value="0">从不</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>顶栏显示电量百分比</b><span>面板电池插件</span></div>
        <button class="set-switch" :class="{ on: p.showPercent }" @click="p.showPercent = !p.showPercent"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>使用电池时自动降低亮度</b><span>延长续航</span></div>
        <button class="set-switch" :class="{ on: p.dimOnBattery }" @click="p.dimOnBattery = !p.dimOnBattery"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">合盖与关机</div>
      <div class="set-row">
        <div class="set-label"><b>合上盖子时</b><span>接通电源与使用电池时可分别设置</span></div>
        <div class="set-seg">
          <button class="active">挂起</button>
          <button>关机</button>
          <button>不操作</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>电源按钮</b><span>短按行为</span></div>
        <select class="set-select">
          <option>显示电源菜单</option>
          <option>挂起</option>
          <option>关机</option>
        </select>
      </div>
    </div>
  </div>
</template>
