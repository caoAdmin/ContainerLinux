<script setup lang="ts">
/** 设置 · 外观 —— 真正驱动桌面令牌（深/浅、强调色、圆角、透明度、字体缩放…） */
import { computed } from 'vue'
import { useCosmicStore, ACCENTS } from '@/stores/cosmic'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { useLayoutStore, FIT_MODES } from '@/stores/layout'
import { ICON_THEMES, getIconTheme } from '@/utils/iconThemes'
import { cosmicApps } from '@/utils/cosmicApps'
import { perfTier, perfAuto, setPerfTier, resetPerfTier } from '@/utils/perfTier'
import { PALETTES, SHAPES, CONTRASTS, FONTS, type Contrast, type ShapeScale, type FontKey, type MotionScheme } from '@/utils/m3eTheme'
import CosmicAppIcon from '@/components/cosmic/CosmicAppIcon.vue'
import Icon from '@/components/common/Icon.vue'

const store = useCosmicStore()
const sys = useCosmicSystemStore()
const layout = useLayoutStore()
const s = store.settings
const a = sys.appearance

const fitModes = FIT_MODES

/** 主题卡片里露脸的几个应用（前四个正好覆盖常用区） */
const previewApps = cosmicApps.slice(0, 4)
const currentTheme = computed(() => getIconTheme(a.iconTheme))

function resetWindows() {
  store.closeAll()
}

/* ── M3E Expressive 主题（配色 / 对比度 / 形状 / 字体 / 动效 五轴） ── */
const m3e = store.settings.m3e
const m3eEnabled = computed(() => store.settings.m3eEnabled)
function pickPalette(key: string) {
  m3e.palette = key
  if (key !== 'custom') {
    const hit = PALETTES.find((p) => p.key === key)
    if (hit?.seed) m3e.seed = hit.seed
  }
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">外观</h1>
    <p class="set-sub">主题、配色、圆角与字体</p>

    <div class="set-card">
      <div class="set-card-title">主题模式</div>
      <div class="set-row">
        <div class="set-label">
          <b>配色模式</b>
          <span>深色适合夜间，浅色适合白天</span>
        </div>
        <div class="set-seg">
          <button :class="{ active: s.mode === 'dark' }" @click="s.mode = 'dark'">
            <Icon name="ri-moon-line" :size="13" /> 深色
          </button>
          <button :class="{ active: s.mode === 'light' }" @click="s.mode = 'light'">
            <Icon name="ri-sun-line" :size="13" /> 浅色
          </button>
        </div>
      </div>

      <div class="set-row">
        <div class="set-label">
          <b>玻璃材质</b>
          <span>液态为官方折射算法，磨砂为纯雾面玻璃，无玻璃为不透明实心底 · 全站同步并记忆选择</span>
        </div>
        <div class="set-seg">
          <button :class="{ active: s.glassMode === 'liquid' }" @click="s.glassMode = 'liquid'">
            <Icon name="ri-drop-line" :size="13" /> 液态
          </button>
          <button :class="{ active: s.glassMode === 'frosted' }" @click="s.glassMode = 'frosted'">
            <Icon name="ri-sparkling-2-line" :size="13" /> 磨砂
          </button>
          <button :class="{ active: s.glassMode === 'flat' }" @click="s.glassMode = 'flat'">
            <Icon name="ri-blur-off-line" :size="13" /> 无玻璃
          </button>
        </div>
      </div>

      <div class="set-row">
        <div class="set-label">
          <b>渲染档位</b>
          <span>
            完整 = 折射 + 壁纸克隆 + SVG 滤镜链；省电 = 单层磨砂。
            触屏小屏默认省电（当前 {{ perfTier }}）
          </span>
        </div>
        <div class="set-seg">
          <button :class="{ active: perfAuto }" @click="resetPerfTier()">
            <Icon name="ri-magic-line" :size="13" /> 自动
          </button>
          <button :class="{ active: !perfAuto && perfTier === 'high' }" @click="setPerfTier('high')">
            <Icon name="ri-sparkling-line" :size="13" /> 完整
          </button>
          <button :class="{ active: !perfAuto && perfTier === 'low' }" @click="setPerfTier('low')">
            <Icon name="ri-battery-charge-line" :size="13" /> 省电
          </button>
        </div>
      </div>

      <div class="set-row col">
        <div class="set-label">
          <b>强调色</b>
          <span>应用于按钮、选中项、进度条与窗口高亮（当前 {{ s.accent }}）</span>
        </div>
        <div style="display: flex; flex-wrap: wrap; gap: 10px">
          <button
            v-for="c in ACCENTS"
            :key="c.hex"
            class="cst-swatch"
            :style="{ background: c.hex }"
            :title="c.name"
            @click="s.accent = c.hex"
          >
            <Icon v-if="s.accent === c.hex" name="ri-check-line" :size="14" color="#fff" />
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">M3E Expressive 主题</div>
      <div class="set-row">
        <div class="set-label">
          <b>启用 M3E 主题引擎</b>
          <span>整套 Material 3 Expressive 色板替换桌面标准色（关闭 = 原 GNOME/libadwaita 色）</span>
        </div>
        <button class="set-switch" :class="{ on: store.settings.m3eEnabled }" @click="store.settings.m3eEnabled = !store.settings.m3eEnabled"><i /></button>
      </div>
      <template v-if="m3eEnabled">
        <div class="set-row col">
          <div class="set-label">
            <b>基准配色</b>
            <span>七套手写色板或自定义基准色，整套色板由基准色实时生成（移植自 m3e-canvas）</span>
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 10px">
            <button
              v-for="p in PALETTES"
              :key="p.key"
              class="cst-swatch"
              :style="{ background: p.primary }"
              :title="p.label"
              @click="pickPalette(p.key)"
            >
              <Icon v-if="m3e.palette === p.key" name="ri-check-line" :size="14" color="#fff" />
            </button>
            <label class="cst-swatch cst-custom" title="自定义基准色">
              <input v-model="m3e.seed" type="color" @change="m3e.palette = 'custom'" />
              <Icon v-if="m3e.palette === 'custom'" name="ri-check-line" :size="14" color="#fff" />
            </label>
          </div>
        </div>
        <div class="set-row">
          <div class="set-label"><b>对比度</b><span>Material Theme Builder 同款三档</span></div>
          <div class="set-seg">
            <button v-for="c in CONTRASTS" :key="c.key" :class="{ active: m3e.contrast === c.key }" @click="m3e.contrast = c.key as Contrast">
              {{ c.label }}
            </button>
          </div>
        </div>
        <div class="set-row">
          <div class="set-label"><b>圆角形状</b><span>Square 收敛 / Rounded 标准 / Full 加倍外扩</span></div>
          <div class="set-seg">
            <button v-for="sh in SHAPES" :key="sh.key" :class="{ active: m3e.shape === sh.key }" @click="m3e.shape = sh.key as ShapeScale">
              {{ sh.label }}
            </button>
          </div>
        </div>
        <div class="set-row">
          <div class="set-label"><b>界面字体</b><span>Google Fonts 按需加载，CJK 回落 Noto Sans SC</span></div>
          <div class="set-seg" style="flex-wrap: wrap; justify-content: flex-end">
            <button v-for="f in FONTS" :key="f.key" :class="{ active: m3e.font === f.key }" @click="m3e.font = f.key as FontKey">
              {{ f.label }}
            </button>
          </div>
        </div>
        <div class="set-row">
          <div class="set-label"><b>动效方案</b><span>Expressive = 富表现力弹簧曲线 + 更长落定</span></div>
          <div class="set-seg">
            <button :class="{ active: m3e.motion === 'standard' }" @click="m3e.motion = 'standard' as MotionScheme">Standard</button>
            <button :class="{ active: m3e.motion === 'expressive' }" @click="m3e.motion = 'expressive' as MotionScheme">Expressive</button>
          </div>
        </div>
      </template>
    </div>

    <div class="set-card">
      <div class="set-card-title">窗口与形状</div>
      <div class="set-row">
        <div class="set-label"><b>窗口圆角</b><span>{{ s.radius }} px</span></div>
        <input v-model.number="s.radius" type="range" min="0" max="26" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>界面透明度</b><span>{{ Math.round(a.transparency * 100) }}%</span></div>
        <input v-model.number="a.transparency" type="range" min="0.5" max="1" step="0.02" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>窗口阴影</b><span>关闭后窗口更扁平</span></div>
        <button class="set-switch" :class="{ on: a.windowShadow }" @click="a.windowShadow = !a.windowShadow"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>界面动画</b><span>窗口开关与过渡动效</span></div>
        <button class="set-switch" :class="{ on: s.animations }" @click="s.animations = !s.animations"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">字体与图标</div>
      <div class="set-row">
        <div class="set-label"><b>字体缩放</b><span>界面文字的整体大小</span></div>
        <div class="set-seg">
          <button
            v-for="f in [0.9, 1, 1.1, 1.25]"
            :key="f"
            :class="{ active: a.fontScale === f }"
            @click="a.fontScale = f"
          >
            {{ Math.round(f * 100) }}%
          </button>
        </div>
      </div>
      <div class="set-row col">
        <div class="set-label">
          <b>图标主题</b>
          <span>{{ currentTheme.hint }} · 作用于 Dock、启动台、应用栏与文件图标</span>
        </div>
        <div class="set-themes">
          <button
            v-for="t in ICON_THEMES"
            :key="t.id"
            class="set-theme"
            :class="{ active: a.iconTheme === t.id }"
            :title="t.hint"
            @click="a.iconTheme = t.id"
          >
            <span class="set-theme-shots">
              <CosmicAppIcon v-for="app in previewApps" :key="app.id" :app="app" :size="26" :theme="t.id" />
            </span>
            <span class="set-theme-name">
              {{ t.name }}
              <Icon v-if="a.iconTheme === t.id" name="ri-check-line" :size="12" />
            </span>
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>光标主题</b><span>鼠标指针样式</span></div>
        <select v-model="a.cursorTheme" class="set-select">
          <option>COSMIC</option>
          <option>Adwaita</option>
          <option>Bibata Modern</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>光标大小</b><span>{{ sys.a11y.cursorSize }} px</span></div>
        <input v-model.number="sys.a11y.cursorSize" type="range" min="16" max="48" class="set-slider" />
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">壁纸</div>
      <div class="set-row">
        <div class="set-label"><b>壁纸暗化</b><span>{{ Math.round(s.wallpaperDim * 100) }}%</span></div>
        <input v-model.number="s.wallpaperDim" type="range" min="0" max="0.6" step="0.02" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>跟随系统壁纸</b><span>使用 dotfiles 桌面自带的壁纸</span></div>
        <button class="set-switch on"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">屏幕适配</div>
      <div class="set-row">
        <div class="set-label">
          <b>缩放模式</b>
          <span>当前：{{ layout.fitSummary }}</span>
        </div>
        <div class="set-seg" style="flex-wrap: wrap; justify-content: flex-end">
          <button
            v-for="m in fitModes"
            :key="m.id"
            :class="{ active: layout.mode === m.id }"
            :title="m.desc"
            @click="layout.mode = m.id"
          >
            {{ m.label }}
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>显示缩放角标</b><span>右下角显示当前分辨率与缩放比例</span></div>
        <button class="set-switch" :class="{ on: layout.showBadge }" @click="layout.showBadge = !layout.showBadge"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>重置窗口布局</b><span>关闭全部已打开的 COSMIC 窗口</span></div>
        <button class="c-btn" @click="resetWindows"><Icon name="ri-restart-line" :size="14" /> 重置</button>
      </div>
      <div class="set-kv"><span>当前视口</span><b>{{ layout.vw }} × {{ layout.vh }}</b></div>
      <div class="set-kv"><span>布局画布</span><b>{{ layout.canvasW }} × {{ layout.canvasH }}</b></div>
      <div class="set-kv"><span>实际缩放</span><b>{{ layout.zoom }}%</b></div>
      <div class="set-kv">
        <span>状态</span>
        <b>{{ layout.needsScale ? '视口小于 1280×720，已等比缩放并延展铺满' : '未缩放，直接铺满' }}</b>
      </div>
    </div>

    <div class="set-note">
      <Icon name="ri-magic-line" :size="15" style="margin-top: 1px; flex: none" />
      <span>以上改动会立刻应用到所有已打开的 COSMIC 窗口与 Dock。</span>
    </div>
  </div>
</template>

<style scoped>
.cst-swatch {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  border: 2px solid transparent;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.14s ease;
}
.cst-swatch:hover {
  transform: scale(1.1);
}
/* 自定义基准色：隐藏的 color input 覆盖整个圆钮 */
.cst-custom {
  position: relative;
  overflow: hidden;
  background: conic-gradient(#f66, #fc6, #6f9, #6cf, #96f, #f66);
}
.cst-custom input[type='color'] {
  position: absolute;
  inset: -6px;
  opacity: 0;
  cursor: pointer;
}

/* 图标主题：三张卡片，各用本主题的图标做预览 */
.set-themes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
}
.set-theme {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 9px;
  padding: 12px;
  border-radius: 13px;
  border: 1px solid var(--c-border);
  background: var(--c-surface-2);
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition:
    border-color 0.14s ease,
    background 0.14s ease,
    transform 0.14s ease;
}
.set-theme:hover {
  transform: translateY(-1px);
  border-color: var(--c-border-strong);
}
.set-theme.active {
  border-color: var(--c-accent);
  background: var(--c-accent-soft);
}
.set-theme-shots {
  display: flex;
  gap: 6px;
}
.set-theme-name {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--c-text);
}
</style>
