<script setup lang="ts">
/** 设置 · 区域与语言 —— 语言、格式、时区、输入源 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'
import { ref } from 'vue'

const sys = useCosmicSystemStore()
const r = sys.region

const languages = ['简体中文', 'English (US)', '日本語', 'Deutsch', 'Français']
const formats = ['中国 (zh-CN)', '中国台湾 (zh-TW)', 'United States (en-US)', '日本 (ja-JP)']
const zones = ['Asia/Shanghai (GMT+8)', 'Asia/Tokyo (GMT+9)', 'Europe/Berlin (GMT+1)', 'America/New_York (GMT-5)']
const firstDays = ['星期一', '星期日']

const newSource = ref('')
const options = ['中文 (五笔)', '日本語 (かな入力)', 'Deutsch (QWERTZ)', '法语 (AZERTY)']

function addSource() {
  if (newSource.value && !r.inputSources.includes(newSource.value)) {
    r.inputSources.push(newSource.value)
  }
  newSource.value = ''
}
function removeSource(s: string) {
  r.inputSources = r.inputSources.filter((x) => x !== s)
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">区域与语言</h1>
    <p class="set-sub">语言、数字与日期格式、时区、输入源</p>

    <div class="set-card">
      <div class="set-card-title">语言与格式</div>
      <div class="set-row">
        <div class="set-label"><b>界面语言</b><span>重启会话后完全生效</span></div>
        <select v-model="r.language" class="set-select">
          <option v-for="l in languages" :key="l">{{ l }}</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>区域格式</b><span>决定数字、货币与日期写法</span></div>
        <select v-model="r.format" class="set-select">
          <option v-for="l in formats" :key="l">{{ l }}</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>每周首日</b><span>日历中的第一天</span></div>
        <div class="set-seg">
          <button v-for="d in firstDays" :key="d" :class="{ active: r.firstDay === d }" @click="r.firstDay = d">{{ d }}</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>拼写检查</b><span>在文本输入中标注错词</span></div>
        <button class="set-switch" :class="{ on: r.spellcheck }" @click="r.spellcheck = !r.spellcheck"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">时区</div>
      <div class="set-row">
        <div class="set-label"><b>时区</b><span>当前本地时间 {{ new Date().toLocaleTimeString('zh-CN') }}</span></div>
        <select v-model="r.timezone" class="set-select" style="min-width: 230px">
          <option v-for="z in zones" :key="z">{{ z }}</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自动时区</b><span>通过网络定位自动设置</span></div>
        <button class="set-switch" :class="{ on: sys.time.auto }" @click="sys.time.auto = !sys.time.auto"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">输入源 · {{ r.inputSources.length }}</div>
      <div v-for="s in r.inputSources" :key="s" class="set-item">
        <span class="set-ico"><Icon name="ri-translate-2" :size="16" /></span>
        <div class="set-item-text"><b>{{ s }}</b><span>可在面板插件中快速切换</span></div>
        <div class="set-item-ctl">
          <button class="c-iconbtn" title="移除" @click="removeSource(s)"><Icon name="ri-close-line" :size="15" /></button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>添加输入源</b><span>可先预览再添加</span></div>
        <div style="display: flex; gap: 8px; margin-left: auto">
          <select v-model="newSource" class="set-select">
            <option value="">选择…</option>
            <option v-for="o in options" :key="o">{{ o }}</option>
          </select>
          <button class="c-btn c-btn--primary" :disabled="!newSource" @click="addSource">
            <Icon name="ri-add-line" :size="15" /> 添加
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
