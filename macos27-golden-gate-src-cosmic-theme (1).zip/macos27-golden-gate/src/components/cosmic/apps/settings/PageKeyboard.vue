<script setup lang="ts">
/** 设置 · 键盘（独立分页，与「鼠标」「触控板」并列） */
import { computed } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const k = sys.keyboard

const previewDelay = computed(() => `${(k.repeatDelay / 1000).toFixed(2)} 秒`)

const layoutOptions = ['中文 (五笔)', '日本語 (かな)', 'Deutsch (QWERTZ)', 'Français (AZERTY)', 'Dvorak', 'Colemak']

function addLayout(l: string) {
  if (l && !k.layouts.includes(l)) k.layouts.push(l)
}
function removeLayout(l: string) {
  k.layouts = k.layouts.filter((x) => x !== l)
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">键盘</h1>
    <p class="set-sub">重复速率、布局、组合键与背光</p>

    <div class="set-card">
      <div class="set-card-title">按键行为</div>
      <div class="set-row">
        <div class="set-label"><b>重复延迟</b><span>按住按键后多久开始连发 · {{ k.repeatDelay }} ms</span></div>
        <input v-model.number="k.repeatDelay" type="range" min="100" max="600" step="10" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>重复速率</b><span>每秒连发 {{ k.repeatRate }} 次</span></div>
        <input v-model.number="k.repeatRate" type="range" min="5" max="60" step="1" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>输入测试</b><span>在此输入感受重复延迟（{{ previewDelay }}）</span></div>
        <input class="c-input" placeholder="按住某个键试试…" style="width: 220px" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>大写锁定键行为</b><span>Caps Lock 的用途</span></div>
        <select v-model="k.capsLockBehavior" class="set-select">
          <option>大写锁定</option>
          <option>Ctrl</option>
          <option>Esc</option>
          <option>禁用</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>组合键 (Compose)</b><span>输入特殊字符的前缀键</span></div>
        <select v-model="k.composeKey" class="set-select">
          <option>关闭</option>
          <option>右 Alt</option>
          <option>右 Ctrl</option>
          <option>Caps Lock</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>开机启用数字键盘</b><span>NumLock 默认状态</span></div>
        <button class="set-switch" :class="{ on: k.numLockOnBoot }" @click="k.numLockOnBoot = !k.numLockOnBoot"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">键盘布局 · {{ k.layouts.length }}</div>
      <div v-for="l in k.layouts" :key="l" class="set-item">
        <span class="set-ico"><Icon name="ri-keyboard-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ l }}</b>
          <span>可在面板插件中切换</span>
        </div>
        <div class="set-item-ctl">
          <button class="c-iconbtn" title="移除" @click="removeLayout(l)"><Icon name="ri-close-line" :size="15" /></button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>添加布局</b><span>选择后立即生效</span></div>
        <div class="set-seg" style="flex-wrap: wrap">
          <button v-for="o in layoutOptions" :key="o" :disabled="k.layouts.includes(o)" @click="addLayout(o)">{{ o }}</button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">屏幕键盘与背光</div>
      <div class="set-row">
        <div class="set-label"><b>屏幕键盘 (COSMIC OSK)</b><span>触屏或无障碍使用</span></div>
        <button class="set-switch" :class="{ on: k.osk }" @click="k.osk = !k.osk; sys.a11y.oskEnabled = k.osk"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自动弹出</b><span>聚焦文本输入时自动显示</span></div>
        <button class="set-switch" :class="{ on: sys.a11y.oskAutoShow }" @click="sys.a11y.oskAutoShow = !sys.a11y.oskAutoShow"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>键盘背光</b><span>{{ k.backlight }}%</span></div>
        <input v-model.number="k.backlight" type="range" min="0" max="100" class="set-slider" />
      </div>
    </div>
  </div>
</template>
