<script setup lang="ts">
/** 设置 · 工作区 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const w = sys.workspaces

const layoutItems = (n: number) =>
  Array.from({ length: Math.min(n, 6) }, (_, i) => i)
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">工作区</h1>
    <p class="set-sub">{{ w.count }} 个{{ w.dynamic ? '（动态）' : '' }}工作区 · {{ w.layout === 'vertical' ? '垂直' : '水平' }}排列</p>

    <div class="set-card">
      <div class="set-card-title">数量与排列</div>
      <div class="set-row">
        <div class="set-label"><b>工作区数量</b><span>{{ w.count }} 个</span></div>
        <div class="set-seg">
          <button v-for="n in [1, 2, 3, 4, 6, 8]" :key="n" :class="{ active: w.count === n }" @click="w.count = n">{{ n }}</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>排列方向</b><span>COSMIC 默认为垂直堆叠</span></div>
        <div class="set-seg">
          <button :class="{ active: w.layout === 'vertical' }" @click="w.layout = 'vertical'">垂直</button>
          <button :class="{ active: w.layout === 'horizontal' }" @click="w.layout = 'horizontal'">水平</button>
        </div>
      </div>
      <div class="set-row col">
        <div class="set-label"><b>布局预览</b><span>方块代表工作区，里面的条代表窗口</span></div>
        <div class="ws-preview" :class="w.layout">
          <div v-for="i in layoutItems(w.count)" :key="i" class="ws-cell" :class="{ active: i === 0 }">
            <span v-if="i === 0" class="ws-chip" />
            <span v-if="i === 1" class="ws-chip" style="width: 60%" />
            <span v-if="i === 2" class="ws-chip" style="width: 80%" />
            <b>{{ i + 1 }}</b>
          </div>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">行为</div>
      <div class="set-row">
        <div class="set-label"><b>动态工作区</b><span>按需在末尾自动增减</span></div>
        <button class="set-switch" :class="{ on: w.dynamic }" @click="w.dynamic = !w.dynamic"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>循环切换</b><span>在最后一个工作区继续下一步会回到第一个</span></div>
        <button class="set-switch" :class="{ on: w.wrapAround }" @click="w.wrapAround = !w.wrapAround"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>拖窗口到边缘时切换</b><span>把窗口拖到屏幕边缘自动跳工作区</span></div>
        <button class="set-switch" :class="{ on: w.switchOnDrag }" @click="w.switchOnDrag = !w.switchOnDrag"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>显示工作区名称</b><span>在面板插件中显示标签</span></div>
        <button class="set-switch" :class="{ on: w.showLabels }" @click="w.showLabels = !w.showLabels"><i /></button>
      </div>
      <div v-if="w.showLabels" class="set-row col">
        <div class="set-label"><b>名称</b><span>最多 {{ w.count }} 个</span></div>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 8px">
          <input
            v-for="n in w.count"
            :key="n"
            v-model="w.labels[n - 1]"
            class="c-input"
            :placeholder="`工作区 ${n}`"
          />
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">快捷键</div>
      <div class="set-kv"><span>上一个工作区</span><b><span class="c-kbd">Super</span> <span class="c-kbd">Ctrl</span> <span class="c-kbd">↑</span></b></div>
      <div class="set-kv"><span>下一个工作区</span><b><span class="c-kbd">Super</span> <span class="c-kbd">Ctrl</span> <span class="c-kbd">↓</span></b></div>
      <div class="set-kv"><span>工作区概览</span><b><span class="c-kbd">Super</span> <span class="c-kbd">W</span></b></div>
      <div class="set-kv"><span>把窗口移到相邻工作区</span><b><span class="c-kbd">Super</span> <span class="c-kbd">Shift</span> <span class="c-kbd">Ctrl</span> <span class="c-kbd">↑/↓</span></b></div>
    </div>

    <div class="set-note">
      <Icon name="ri-information-line" :size="15" style="margin-top: 1px; flex: none" />
      <span>COSMIC 的工作区由 cosmic-workspaces 提供，支持垂直堆叠与动态增减。</span>
    </div>
  </div>
</template>

<style scoped>
.ws-preview {
  display: flex;
  gap: 10px;
  height: 190px;
}
.ws-preview.horizontal {
  flex-direction: row;
}
.ws-preview.vertical {
  flex-direction: column;
}
.ws-cell {
  position: relative;
  flex: 1;
  border-radius: 10px;
  background: var(--c-surface-3);
  border: 1px solid var(--c-border);
  display: flex;
  flex-direction: column;
  gap: 5px;
  padding: 9px;
  overflow: hidden;
}
.ws-cell.active {
  border-color: var(--c-accent);
  background: var(--c-accent-soft);
}
.ws-cell b {
  position: absolute;
  right: 7px;
  bottom: 5px;
  font-size: 10.5px;
  color: var(--c-text-mute);
  font-weight: 600;
}
.ws-chip {
  height: 9px;
  border-radius: 4px;
  background: color-mix(in srgb, var(--c-text) 24%, transparent);
  width: 100%;
}
</style>
