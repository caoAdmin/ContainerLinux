<script setup lang="ts">
/** 设置 · 面板（COSMIC 顶栏）—— 位置、尺寸、插件 */
import { computed } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const p = sys.panel

const enabled = computed(() => p.plugins.filter((x) => x.on).length)

const available = [
  { id: 'battery', label: '电池详情', icon: 'ri-battery-charge-line' },
  { id: 'brightness', label: '亮度', icon: 'ri-sun-line' },
  { id: 'keyboard', label: '键盘布局', icon: 'ri-keyboard-line' },
  { id: 'clipboard', label: '剪贴板历史', icon: 'ri-file-copy-line' },
  { id: 'media', label: '媒体控制', icon: 'ri-music-2-line' }
]

function addPlugin(item: { id: string; label: string; icon: string }) {
  if (!p.plugins.some((x) => x.id === item.id)) {
    p.plugins.push({ ...item, on: true })
  }
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">面板</h1>
    <p class="set-sub">COSMIC 顶栏的位置、尺寸与插件（已启用 {{ enabled }} / {{ p.plugins.length }}）</p>

    <div class="set-card">
      <div class="set-card-title">外观</div>
      <div class="set-row">
        <div class="set-label"><b>位置</b><span>面板贴靠的屏幕边缘</span></div>
        <div class="set-seg">
          <button :class="{ active: p.position === 'top' }" @click="p.position = 'top'">顶部</button>
          <button :class="{ active: p.position === 'bottom' }" @click="p.position = 'bottom'">底部</button>
          <button :class="{ active: p.position === 'left' }" @click="p.position = 'left'">左侧</button>
          <button :class="{ active: p.position === 'right' }" @click="p.position = 'right'">右侧</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>尺寸</b><span>面板厚度</span></div>
        <div class="set-seg">
          <button v-for="sz in (['S', 'M', 'L'] as const)" :key="sz" :class="{ active: p.size === sz }" @click="p.size = sz">
            {{ sz }}
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>透明度</b><span>{{ Math.round(p.transparency * 100) }}%</span></div>
        <input v-model.number="p.transparency" type="range" min="0.5" max="1" step="0.02" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>智能自动隐藏</b><span>全屏应用时自动收起</span></div>
        <button class="set-switch" :class="{ on: p.autoHide }" @click="p.autoHide = !p.autoHide"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">已启用插件 · 拖动排序（示意）</div>
      <div v-for="pl in p.plugins" :key="pl.id" class="set-item">
        <Icon name="ri-drag-move-2-line" :size="15" color="var(--c-text-mute)" />
        <span class="set-ico"><Icon :name="pl.icon" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ pl.label }}</b>
          <span>{{ pl.id }}</span>
        </div>
        <div class="set-item-ctl">
          <button class="set-switch" :class="{ on: pl.on }" @click="pl.on = !pl.on"><i /></button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">可用插件</div>
      <div class="set-row col">
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 10px">
          <button v-for="a in available" :key="a.id" class="set-mini" @click="addPlugin(a)">
            <Icon :name="a.icon" :size="16" />
            <span class="set-mini-text"><b>{{ a.label }}</b><span>点击添加到面板</span></span>
            <Icon name="ri-add-line" :size="15" />
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
