<script setup lang="ts">
/** 设置 · 隐私 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const p = sys.privacy

const items = [
  { key: 'location', label: '定位服务', desc: '允许应用获取大致位置', icon: 'ri-map-pin-line' },
  { key: 'camera', label: '摄像头', desc: '允许应用访问摄像头', icon: 'ri-camera-3-line' },
  { key: 'microphone', label: '麦克风', desc: '允许应用录音', icon: 'ri-mic-line' },
  { key: 'screenRecording', label: '屏幕录制', desc: '允许应用捕获屏幕内容', icon: 'ri-computer-line' },
  { key: 'fileHistory', label: '文件历史', desc: '记录最近打开的文件', icon: 'ri-history-line' },
  { key: 'crashReports', label: '崩溃报告', desc: '匿名上报程序崩溃信息', icon: 'ri-bug-line' }
]

function isOn(key: string): boolean {
  return (p as unknown as Record<string, boolean>)[key] === true
}
function toggle(key: string) {
  ;(p as unknown as Record<string, boolean>)[key] = !isOn(key)
}

const appPerms = [
  { name: 'COSMIC Viewer', perm: '仅访问选定文件', icon: 'ri-image-2-fill' },
  { name: 'COSMIC Player', perm: '仅访问音乐与视频目录', icon: 'ri-play-circle-fill' },
  { name: 'COSMIC Files', perm: '完整文件系统访问', icon: 'ri-folders-fill' }
]
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">隐私</h1>
    <p class="set-sub">权限与数据收集</p>

    <div class="set-card">
      <div v-for="i in items" :key="i.key" class="set-item">
        <span class="set-ico"><Icon :name="i.icon" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ i.label }}</b>
          <span>{{ i.desc }}</span>
        </div>
        <div class="set-item-ctl">
          <button class="set-switch" :class="{ on: isOn(i.key) }" @click="toggle(i.key)">
            <i />
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">应用权限</div>
      <div v-for="a in appPerms" :key="a.name" class="set-item">
        <span class="set-ico"><Icon :name="a.icon" :size="16" /></span>
        <div class="set-item-text"><b>{{ a.name }}</b><span>{{ a.perm }}</span></div>
        <div class="set-item-ctl">
          <button class="c-btn" style="height: 28px; font-size: 12px">管理</button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">清除数据</div>
      <div class="set-row">
        <div class="set-label"><b>清除最近文件记录</b><span>共 42 条</span></div>
        <button class="c-btn c-btn--danger"><Icon name="ri-delete-bin-6-line" :size="14" /> 清除</button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>清除剪贴板历史</b><span>共 18 条</span></div>
        <button class="c-btn c-btn--danger"><Icon name="ri-delete-bin-6-line" :size="14" /> 清除</button>
      </div>
    </div>
  </div>
</template>
