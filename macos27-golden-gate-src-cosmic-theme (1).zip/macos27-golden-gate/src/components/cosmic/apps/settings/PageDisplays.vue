<script setup lang="ts">
/** 设置 · 显示 —— 亮度、分辨率、刷新率、缩放、夜间模式、HDR、多显示器 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const d = sys.display

const resolutions = ['1280 × 720', '1600 × 900', '1920 × 1080', '2560 × 1440', '3840 × 2160']
const rates = ['48.00 Hz', '59.94 Hz', '60.00 Hz', '120.00 Hz', '144.00 Hz']
const scales = ['100%', '125%', '150%', '175%', '200%']
const orientations = ['横向', '纵向', '横向（翻转）', '纵向（翻转）']
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">显示</h1>
    <p class="set-sub">2 台显示器已连接 · eDP-1 为主显示器</p>

    <div class="set-card">
      <div class="set-card-title">显示器排列</div>
      <div class="set-row col">
        <div style="display: flex; gap: 12px; align-items: flex-end">
          <div class="disp-box" style="width: 190px; height: 108px">
            <b>eDP-1</b><span>1920 × 1080</span><em>主</em>
          </div>
          <div class="disp-box ghost" style="width: 190px; height: 108px">
            <b>HDMI-A-1</b><span>3840 × 2160</span>
          </div>
        </div>
      </div>
      <div v-for="m in d.monitors" :key="m.name" class="set-item">
        <span class="set-ico"><Icon name="ri-computer-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ m.name }}</b>
          <span>{{ m.size }} · {{ m.res }} @ {{ m.refresh }}</span>
        </div>
        <div class="set-item-ctl">
          <span class="set-badge" :class="{ on: m.primary }">{{ m.primary ? '主显示器' : '扩展' }}</span>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">eDP-1 内置显示器</div>
      <div class="set-row">
        <div class="set-label"><b>亮度</b><span>{{ d.brightness }}%</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <Icon name="ri-sun-line" :size="15" color="var(--c-text-mute)" />
          <input v-model.number="d.brightness" type="range" min="10" max="100" class="set-slider" />
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>分辨率</b><span>刷新率与分辨率不匹配时可能黑屏</span></div>
        <select v-model="d.resolution" class="set-select">
          <option v-for="r in resolutions" :key="r">{{ r }}</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>刷新率</b><span>更高更顺滑，更耗电</span></div>
        <select v-model="d.refreshRate" class="set-select">
          <option v-for="r in rates" :key="r">{{ r }}</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>缩放</b><span>界面元素整体放大</span></div>
        <select v-model="d.scale" class="set-select">
          <option v-for="r in scales" :key="r">{{ r }}</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>方向</b><span>整块屏幕的旋转方向</span></div>
        <select v-model="d.orientation" class="set-select">
          <option v-for="r in orientations" :key="r">{{ r }}</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>可变刷新率 (VRR)</b><span>减少画面撕裂</span></div>
        <button class="set-switch" :class="{ on: d.vrr }" @click="d.vrr = !d.vrr"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">夜间模式</div>
      <div class="set-row">
        <div class="set-label"><b>开启夜间模式</b><span>降低蓝光，暖色显示</span></div>
        <button class="set-switch" :class="{ on: d.nightLight }" @click="d.nightLight = !d.nightLight"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>色温</b><span>{{ d.nightTemp }} K</span></div>
        <input v-model.number="d.nightTemp" type="range" min="2000" max="6500" step="100" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>生效时段</b><span>{{ d.nightStart }} — {{ d.nightEnd }}</span></div>
        <div style="display: flex; gap: 8px; margin-left: auto">
          <input v-model="d.nightStart" type="time" class="set-select" style="min-width: 110px" />
          <input v-model="d.nightEnd" type="time" class="set-select" style="min-width: 110px" />
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">高级</div>
      <div class="set-row">
        <div class="set-label"><b>HDR 高动态范围</b><span>需要显示器与线缆支持</span></div>
        <button class="set-switch" :class="{ on: d.hdr }" @click="d.hdr = !d.hdr"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>显卡驱动</b><span>AMD Radeon 780M · Mesa 24.2.0</span></div>
        <span class="set-badge">开源驱动</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.disp-box {
  border-radius: 9px;
  border: 2px solid var(--c-accent);
  background: var(--c-surface-3);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3px;
  position: relative;
}
.disp-box.ghost {
  border-color: var(--c-border-strong);
}
.disp-box b {
  font-size: 13px;
}
.disp-box span {
  font-size: 11px;
  color: var(--c-text-mute);
}
.disp-box em {
  position: absolute;
  top: 5px;
  right: 6px;
  font-style: normal;
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 8px;
  background: var(--c-accent);
  color: #fff;
}
</style>
