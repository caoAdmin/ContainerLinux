<script setup lang="ts">
/** 设置 · 鼠标 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const m = sys.mouse

const actions = ['主点击', '次点击', '中键点击', '返回', '前进', '无操作', '切换工作区', '打开应用库']
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">鼠标</h1>
    <p class="set-sub">指针速度、滚动与按键映射</p>

    <div class="set-card">
      <div class="set-card-title">指针</div>
      <div class="set-row">
        <div class="set-label"><b>指针速度</b><span>{{ Math.round(m.speed * 200) }}%</span></div>
        <input v-model.number="m.speed" type="range" min="0.1" max="1.5" step="0.05" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>指针加速</b><span>移动越快位移越大</span></div>
        <button class="set-switch" :class="{ on: m.accel }" @click="m.accel = !m.accel"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>双击速度</b><span>{{ m.doubleClick }} ms</span></div>
        <input v-model.number="m.doubleClick" type="range" min="200" max="900" step="20" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>主按键</b><span>用于主要操作</span></div>
        <div class="set-seg">
          <button :class="{ active: m.primaryButton === '左键' }" @click="m.primaryButton = '左键'">左键</button>
          <button :class="{ active: m.primaryButton === '右键' }" @click="m.primaryButton = '右键'">右键</button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">滚动</div>
      <div class="set-row">
        <div class="set-label"><b>自然滚动</b><span>滚轮方向与内容移动一致</span></div>
        <button class="set-switch" :class="{ on: m.naturalScroll }" @click="m.naturalScroll = !m.naturalScroll"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>滚动速度</b><span>{{ m.scrollSpeed.toFixed(1) }}×</span></div>
        <input v-model.number="m.scrollSpeed" type="range" min="0.3" max="3" step="0.1" class="set-slider" />
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">按键映射</div>
      <div v-for="(b, i) in m.buttons" :key="b.key" class="set-row">
        <span class="set-ico"><Icon name="ri-mouse-line" :size="16" /></span>
        <div class="set-label"><b>{{ b.key }}</b><span>当前动作</span></div>
        <select v-model="m.buttons[i].action" class="set-select">
          <option v-for="a in actions" :key="a">{{ a }}</option>
        </select>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">已识别设备</div>
      <div class="set-item">
        <span class="set-ico"><Icon name="ri-mouse-fill" :size="16" /></span>
        <div class="set-item-text"><b>Logitech MX Master 3S</b><span>蓝牙 · 4000 DPI · 电量 88%</span></div>
        <div class="set-item-ctl"><span class="set-badge on">已连接</span></div>
      </div>
      <div class="set-item">
        <span class="set-ico"><Icon name="ri-checkbox-blank-circle-line" :size="16" /></span>
        <div class="set-item-text"><b>ThinkPad 触控点</b><span>内置 · 已启用</span></div>
        <div class="set-item-ctl"><span class="set-badge on">已连接</span></div>
      </div>
    </div>
  </div>
</template>
