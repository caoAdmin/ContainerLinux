<script setup lang="ts">
/** 设置 · 网络与无线 —— Wi-Fi、有线、VPN、代理 */
import { ref } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const w = sys.wifi
const connecting = ref<string | null>(null)

function connect(ssid: string) {
  if (connecting.value === ssid) return
  connecting.value = ssid
  window.setTimeout(() => {
    w.connected = ssid
    const n = w.networks.find((x) => x.ssid === ssid)
    if (n) n.known = true
    connecting.value = null
  }, 1100)
}

function level(s: number): string {
  return s > 75 ? '信号极强' : s > 50 ? '信号良好' : s > 30 ? '信号一般' : '信号较弱'
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">网络与无线</h1>
    <p class="set-sub">Wi-Fi、有线连接、VPN 与代理</p>

    <div class="set-card">
      <div class="set-row">
        <span class="set-ico" :style="{ background: w.enabled ? 'var(--c-accent-soft)' : 'var(--c-surface-3)' }">
          <Icon name="ri-wifi-line" :size="17" />
        </span>
        <div class="set-label">
          <b>Wi-Fi</b>
          <span>{{ w.enabled ? `已连接到 ${w.connected} · ${w.ip}` : '已关闭' }}</span>
        </div>
        <button class="set-switch" :class="{ on: w.enabled }" @click="w.enabled = !w.enabled"><i /></button>
      </div>
    </div>

    <template v-if="w.enabled">
      <div class="set-card">
        <div class="set-card-title">可用网络</div>
        <div v-for="n in w.networks" :key="n.ssid" class="set-item">
          <span class="set-ico round">
            <Icon :name="n.strength > 50 ? 'ri-wifi-line' : 'ri-wifi-off-line'" :size="15" />
          </span>
          <div class="set-item-text">
            <b>{{ n.ssid }}</b>
            <span>{{ level(n.strength) }} · {{ n.strength }}%{{ n.known ? ' · 已保存' : '' }}</span>
          </div>
          <div class="set-item-ctl">
            <Icon v-if="n.secure" name="ri-lock-line" :size="14" color="var(--c-text-mute)" />
            <span v-if="w.connected === n.ssid" class="set-badge on">
              <Icon name="ri-check-line" :size="12" /> 已连接
            </span>
            <button v-else class="c-btn" style="height: 28px; font-size: 12px" @click="connect(n.ssid)">
              {{ connecting === n.ssid ? '连接中…' : '连接' }}
            </button>
          </div>
        </div>
      </div>

      <div class="set-card">
        <div class="set-card-title">已连接详情</div>
        <div class="set-kv"><span>SSID</span><b>{{ w.connected }}</b></div>
        <div class="set-kv"><span>IP 地址</span><b>{{ w.ip }}</b></div>
        <div class="set-kv"><span>MAC 地址</span><b>{{ w.mac }}</b></div>
        <div class="set-kv"><span>安全</span><b>WPA2/WPA3 个人</b></div>
        <div class="set-kv"><span>频段</span><b>5 GHz · 信道 149</b></div>
        <div class="set-kv"><span>速率</span><b>866 Mb/s</b></div>
      </div>
    </template>

    <div class="set-card">
      <div class="set-card-title">有线连接</div>
      <div class="set-item">
        <span class="set-ico"><Icon name="ri-router-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ sys.wired.name }}</b>
          <span>{{ sys.wired.connected ? `已连接 · ${sys.wired.speed} · ${sys.wired.ip}` : '网线未插入' }}</span>
        </div>
        <div class="set-item-ctl">
          <span class="set-badge" :class="{ on: sys.wired.connected }">{{ sys.wired.connected ? '已连接' : '未连接' }}</span>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">VPN</div>
      <div class="set-row">
        <div class="set-label"><b>启用 VPN</b><span>{{ sys.vpn.enabled ? '流量已加密' : '未启用' }}</span></div>
        <button class="set-switch" :class="{ on: sys.vpn.enabled }" @click="sys.vpn.enabled = !sys.vpn.enabled"><i /></button>
      </div>
      <div v-for="p in sys.vpn.profiles" :key="p" class="set-item">
        <span class="set-ico"><Icon name="ri-shield-keyhole-line" :size="16" /></span>
        <div class="set-item-text"><b>{{ p }}</b><span>OpenVPN · 已导入配置</span></div>
        <div class="set-item-ctl"><button class="c-btn" style="height: 28px; font-size: 12px">管理</button></div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">代理</div>
      <div class="set-row">
        <div class="set-label"><b>代理模式</b><span>手动模式需填写地址与端口</span></div>
        <div class="set-seg">
          <button :class="{ active: sys.proxy.mode === 'none' }" @click="sys.proxy.mode = 'none'">不使用</button>
          <button :class="{ active: sys.proxy.mode === 'auto' }" @click="sys.proxy.mode = 'auto'">自动</button>
          <button :class="{ active: sys.proxy.mode === 'manual' }" @click="sys.proxy.mode = 'manual'">手动</button>
        </div>
      </div>
      <div v-if="sys.proxy.mode === 'manual'" class="set-row">
        <div class="set-label"><b>代理地址</b><span>HTTP / HTTPS</span></div>
        <div style="display: flex; gap: 8px; margin-left: auto">
          <input v-model="sys.proxy.host" class="c-input" placeholder="127.0.0.1" style="width: 140px" />
          <input v-model.number="sys.proxy.port" class="c-input" type="number" style="width: 90px" />
        </div>
      </div>
    </div>
  </div>
</template>
