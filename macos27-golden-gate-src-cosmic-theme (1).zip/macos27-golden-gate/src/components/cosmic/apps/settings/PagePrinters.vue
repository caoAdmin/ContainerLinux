<script setup lang="ts">
/** 设置 · 打印机（CUPS） */
import { ref } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const p = sys.printers

const discovering = ref(false)

function discover() {
  discovering.value = true
  window.setTimeout(() => (discovering.value = false), 2000)
}

function setDefault(name: string) {
  p.list.forEach((x) => (x.default = x.name === name))
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">打印机</h1>
    <p class="set-sub">{{ p.list.length }} 台打印机 · 由 CUPS 管理</p>

    <div class="set-card">
      <div class="set-row">
        <div class="set-label">
          <b>{{ discovering ? '正在搜索网络打印机…' : '添加打印机' }}</b>
          <span>支持 IPP / 无驱动 / 手动选择 PPD</span>
        </div>
        <div style="display: flex; gap: 8px; margin-left: auto">
          <button class="c-btn" :disabled="discovering" @click="discover">
            <Icon name="ri-radar-line" :size="15" /> 搜索
          </button>
          <button class="c-btn c-btn--primary">
            <Icon name="ri-add-line" :size="15" /> 手动添加
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">已配置的打印机</div>
      <div v-for="pr in p.list" :key="pr.name" class="set-item">
        <span class="set-ico" :style="{ background: pr.default ? 'var(--c-accent-soft)' : 'var(--c-surface-3)' }">
          <Icon name="ri-printer-line" :size="16" />
        </span>
        <div class="set-item-text">
          <b>{{ pr.name }}</b>
          <span>{{ pr.state }} · {{ pr.driver }}</span>
          <span style="font-family: monospace">{{ pr.uri }}</span>
        </div>
        <div class="set-item-ctl">
          <span v-if="pr.default" class="set-badge on"><Icon name="ri-star-fill" :size="11" /> 默认</span>
          <button v-else class="c-btn" style="height: 28px; font-size: 12px" @click="setDefault(pr.name)">设为默认</button>
          <button class="c-btn" style="height: 28px; font-size: 12px">
            <Icon name="ri-file-list-3-line" :size="13" /> 属性
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">打印队列 · {{ p.jobs.length }}</div>
      <div v-for="j in p.jobs" :key="j.id" class="set-item">
        <span class="set-ico"><Icon name="ri-file-text-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ j.name }}</b>
          <span>#{{ j.id }} · {{ j.printer }} · {{ j.pages }} 页</span>
        </div>
        <div class="set-item-ctl">
          <span class="set-badge" :class="{ on: j.state === '打印中' }">{{ j.state }}</span>
          <button class="c-iconbtn" title="取消"><Icon name="ri-close-line" :size="15" /></button>
        </div>
      </div>
      <div v-if="!p.jobs.length" class="set-item" style="color: var(--c-text-mute)">队列为空</div>
    </div>

    <div class="set-card">
      <div class="set-card-title">服务器</div>
      <div class="set-kv"><span>CUPS 版本</span><b>2.4.7</b></div>
      <div class="set-kv"><span>服务器地址</span><b>localhost:631</b></div>
      <div class="set-kv"><span>共享本机打印机</span><b>已开启</b></div>
      <div class="set-kv"><span>允许远程管理</span><b>仅本机</b></div>
    </div>
  </div>
</template>
