<script setup lang="ts">
/** 设置 · Dock —— 位置/尺寸/自动隐藏/固定应用 + 悬停放大 / 弹跳 */
import { useCosmicStore } from '@/stores/cosmic'
import { cosmicApps } from '@/utils/cosmicApps'
import Icon from '@/components/common/Icon.vue'
import CosmicAppIcon from '../../CosmicAppIcon.vue'

const store = useCosmicStore()
const s = store.settings

/** 动画手感预设：写回「响应速度 ω / 阻尼比 ζ」两个底层参数 */
const FEELS = [
  { id: 'soft', label: '柔和', speed: 9, damping: 0.95 },
  { id: 'std', label: '标准', speed: 16, damping: 0.72 },
  { id: 'snap', label: '干脆', speed: 24, damping: 0.55 }
] as const

function feelOf(): string {
  const hit = FEELS.find(
    (f) => Math.abs(f.speed - s.dockMagnifySpeed) < 0.6 && Math.abs(f.damping - s.dockMagnifyDamping) < 0.02
  )
  return hit?.id ?? 'custom'
}
function applyFeel(id: 'soft' | 'std' | 'snap') {
  const f = FEELS.find((x) => x.id === id)
  if (!f) return
  s.dockMagnifySpeed = f.speed
  s.dockMagnifyDamping = f.damping
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">Dock</h1>
    <p class="set-sub">应用停靠栏的位置、尺寸与固定应用（改动立即生效）</p>

    <div class="set-card">
      <div class="set-card-title">行为</div>
      <div class="set-row">
        <div class="set-label"><b>显示 Dock</b><span>关闭后可用屏幕底部的小抓手唤回</span></div>
        <button class="set-switch" :class="{ on: s.showDock }" @click="s.showDock = !s.showDock"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自动隐藏</b><span>鼠标移到屏幕边缘时滑出</span></div>
        <button class="set-switch" :class="{ on: s.autoHideDock }" @click="s.autoHideDock = !s.autoHideDock"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>显示最近使用的应用</b><span>在固定应用之后追加最近项</span></div>
        <button class="set-switch on"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">外观</div>
      <div class="set-row">
        <div class="set-label"><b>停靠位置</b><span>Dock 贴靠的屏幕边缘</span></div>
        <div class="set-seg">
          <button :class="{ active: s.dockPosition === 'bottom' }" @click="s.dockPosition = 'bottom'">底部</button>
          <button :class="{ active: s.dockPosition === 'left' }" @click="s.dockPosition = 'left'">左侧</button>
          <button :class="{ active: s.dockPosition === 'right' }" @click="s.dockPosition = 'right'">右侧</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>图标尺寸</b><span>小 / 中 / 大</span></div>
        <div class="set-seg">
          <button v-for="sz in (['S', 'M', 'L'] as const)" :key="sz" :class="{ active: s.dockSize === sz }" @click="s.dockSize = sz">
            {{ sz }}
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>Dock 圆角</b><span>随「外观 → 窗口圆角」联动</span></div>
        <span class="set-badge">{{ store.settings.radius + 8 }} px</span>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">悬停放大</div>
      <div class="set-row">
        <div class="set-label"><b>放大图标</b><span>指针移到图标上时放大，并凸出胶囊上方</span></div>
        <button class="set-switch" :class="{ on: s.dockMagnify }" @click="s.dockMagnify = !s.dockMagnify"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>最大倍率</b><span>指针所在图标的放大倍率</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <input v-model.number="s.dockMagnifyMax" type="range" min="1.1" max="2.4" step="0.05" class="set-slider" />
          <span class="set-badge" style="min-width: 46px; justify-content: center">{{ s.dockMagnifyMax.toFixed(2) }}×</span>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>影响范围</b><span>以图标个数计，越大波及的邻居越多</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <input v-model.number="s.dockMagnifyRange" type="range" min="1" max="6" step="0.5" class="set-slider" />
          <span class="set-badge" style="min-width: 42px; justify-content: center">{{ s.dockMagnifyRange }} 个</span>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>动画手感</b><span>柔和 / 标准 / 干脆</span></div>
        <div class="set-seg">
          <button v-for="f in FEELS" :key="f.id" :class="{ active: feelOf() === f.id }" @click="applyFeel(f.id)">
            {{ f.label }}
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>响应速度</b><span>数值越大越跟手</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <input v-model.number="s.dockMagnifySpeed" type="range" min="6" max="28" step="1" class="set-slider" />
          <span class="set-badge" style="min-width: 42px; justify-content: center">{{ s.dockMagnifySpeed }}</span>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>阻尼回弹</b><span>数值越大越稳，越小越弹</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <input v-model.number="s.dockMagnifyDamping" type="range" min="0.45" max="1.1" step="0.01" class="set-slider" />
          <span class="set-badge" style="min-width: 42px; justify-content: center">{{ s.dockMagnifyDamping.toFixed(2) }}</span>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>邻位让位</b><span>放大时邻居让出的空间（0 = 允许重叠）</span></div>
        <input v-model.number="s.dockMagnifyNeighbor" type="range" min="0" max="100" step="5" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>浮起高度</b><span>放大图标脱离胶囊底边的程度</span></div>
        <input v-model.number="s.dockMagnifyLift" type="range" min="0" max="1" step="0.05" class="set-slider" />
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">图标弹跳</div>
      <div class="set-row">
        <div class="set-label"><b>应用弹跳</b><span>打开 / 最小化 / 还原时给点反馈</span></div>
        <button class="set-switch" :class="{ on: s.dockBounce }" @click="s.dockBounce = !s.dockBounce"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>仅新开时弹跳</b><span>聚焦已有窗口时不弹（对齐上游）</span></div>
        <button class="set-switch" :class="{ on: s.dockBounceLaunchOnly }" @click="s.dockBounceLaunchOnly = !s.dockBounceLaunchOnly"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>弹跳幅度</b><span>图标跳起的高度</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <input v-model.number="s.dockBounceHeight" type="range" min="4" max="28" step="1" class="set-slider" />
          <span class="set-badge" style="min-width: 42px; justify-content: center">{{ s.dockBounceHeight }}px</span>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>弹跳时长</b><span>一次完整弹跳的时间</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <input v-model.number="s.dockBounceDuration" type="range" min="300" max="1200" step="20" class="set-slider" />
          <span class="set-badge" style="min-width: 46px; justify-content: center">{{ s.dockBounceDuration }}ms</span>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">固定应用 · {{ cosmicApps.length }} 个</div>
      <div class="set-row col">
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(196px, 1fr)); gap: 10px">
          <div v-for="a in cosmicApps" :key="a.id" class="set-mini">
            <CosmicAppIcon class="set-ico" :app="a" :size="34" :glyph="0.44" />
            <span class="set-mini-text"><b>{{ a.name.replace('COSMIC ', '') }}</b><span>{{ a.category }}</span></span>
            <button class="c-iconbtn" title="打开" @click="store.openApp(a.id)">
              <Icon name="ri-external-link-line" :size="14" />
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
