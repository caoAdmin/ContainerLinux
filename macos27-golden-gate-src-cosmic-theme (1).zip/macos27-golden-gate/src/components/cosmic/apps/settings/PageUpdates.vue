<script setup lang="ts">
/** 设置 · 系统更新 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const u = sys.updates

let timer = 0

function check() {
  if (u.checking) return
  u.checking = true
  u.progress = 0
  window.clearInterval(timer)
  timer = window.setInterval(() => {
    u.progress += 8 + Math.random() * 10
    if (u.progress >= 100) {
      u.progress = 100
      window.clearInterval(timer)
      window.setTimeout(() => {
        u.checking = false
        u.progress = 0
        u.lastCheck = '刚刚'
      }, 420)
    }
  }, 90)
}

function installAll() {
  if (!u.available.length) return
  u.available = []
  u.history.unshift({ date: '刚刚', text: '已安装 3 个更新' })
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">系统更新</h1>
    <p class="set-sub">最近检查：{{ u.lastCheck }} · 当前版本 {{ u.current }}</p>

    <div class="set-card">
      <div class="set-item" style="padding: 16px 0">
        <span class="set-ico" style="width: 52px; height: 52px; border-radius: 16px; background: var(--c-accent-soft)">
          <Icon name="ri-download-cloud-2-line" :size="26" />
        </span>
        <div class="set-item-text">
          <b style="font-size: 16px">
            {{ u.available.length ? `${u.available.length} 个更新可用` : '系统已是最新' }}
          </b>
          <span>Pop!_OS 24.04 LTS · COSMIC Epoch {{ u.current }}</span>
        </div>
        <div class="set-item-ctl">
          <button v-if="u.available.length" class="c-btn c-btn--primary" @click="installAll">
            <Icon name="ri-download-2-line" :size="15" /> 全部更新
          </button>
          <button class="c-btn" :disabled="u.checking" @click="check">
            <Icon name="ri-refresh-line" :size="15" /> {{ u.checking ? '检查中…' : '检查更新' }}
          </button>
        </div>
      </div>
      <div v-if="u.checking" class="set-row">
        <div class="set-progress" style="flex: 1"><i :style="{ width: u.progress + '%' }" /></div>
        <span class="set-badge" style="min-width: 48px; justify-content: center">{{ Math.round(u.progress) }}%</span>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">可用更新 · {{ u.available.length }}</div>
      <div v-for="a in u.available" :key="a.name" class="set-item">
        <span class="set-ico"><Icon name="ri-archive-2-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ a.name }}</b>
          <span>{{ a.from }} → {{ a.to }}</span>
        </div>
        <div class="set-item-ctl">
          <button class="c-btn" style="height: 28px; font-size: 12px" @click="u.available = u.available.filter((x) => x.name !== a.name)">
            安装
          </button>
        </div>
      </div>
      <div v-if="!u.available.length" class="set-item" style="color: var(--c-text-mute)">
        <Icon name="ri-checkbox-circle-line" :size="16" /> 所有软件包都是最新的
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">更新选项</div>
      <div class="set-row">
        <div class="set-label"><b>更新通道</b><span>稳定 / 测试 / 尝鲜</span></div>
        <div class="set-seg">
          <button :class="{ active: u.channel === 'stable' }" @click="u.channel = 'stable'">稳定</button>
          <button :class="{ active: u.channel === 'beta' }" @click="u.channel = 'beta'">Beta</button>
          <button :class="{ active: u.channel === 'staging' }" @click="u.channel = 'staging'">Staging</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自动检查更新</b><span>每天后台检查一次</span></div>
        <button class="set-switch" :class="{ on: u.autoUpdate }" @click="u.autoUpdate = !u.autoUpdate"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自动下载</b><span>仅下载，安装前询问</span></div>
        <button class="set-switch" :class="{ on: u.autoDownload }" @click="u.autoDownload = !u.autoDownload"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自动重启安装</b><span>内核更新需要重启生效</span></div>
        <button class="set-switch"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">更新历史</div>
      <div v-for="h in u.history" :key="h.date + h.text" class="set-item">
        <span class="set-ico"><Icon name="ri-history-line" :size="16" /></span>
        <div class="set-item-text"><b>{{ h.text }}</b><span>{{ h.date }}</span></div>
      </div>
    </div>
  </div>
</template>
