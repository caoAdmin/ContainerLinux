<script setup lang="ts">
/** 设置 · 输入设备 —— 触控板与手势（键盘/鼠标/绘图板已独立成页） */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const t = sys.touchpad

const devices = [
  { name: 'ThinkPad 触控板 (Synaptics)', kind: '触控板', icon: 'ri-macbook-line', connected: true },
  { name: 'Logitech MX Master 3S', kind: '鼠标', icon: 'ri-mouse-fill', connected: true },
  { name: 'Wacom Intuos Pro M', kind: '绘图板', icon: 'ri-tablet-line', connected: true },
  { name: '内置键盘', kind: '键盘', icon: 'ri-keyboard-fill', connected: true },
  { name: 'WH-1000XM5 媒体键', kind: '多媒体键', icon: 'ri-headphone-fill', connected: false }
]

const gestures = [
  { name: '双指上滑', action: '打开应用库', keys: 2 },
  { name: '双指下滑', action: '打开通知中心', keys: 2 },
  { name: '三指左右滑', action: '切换工作区', keys: 3 },
  { name: '三指上滑', action: '窗口概览', keys: 3 },
  { name: '四指捏合', action: '显示桌面', keys: 4 }
]
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">输入设备</h1>
    <p class="set-sub">触控板、手势与已连接设备</p>

    <div class="set-card">
      <div class="set-card-title">触控板</div>
      <div class="set-row">
        <div class="set-label"><b>轻触点击</b><span>无需按下即可点击</span></div>
        <button class="set-switch" :class="{ on: t.tapToClick }" @click="t.tapToClick = !t.tapToClick"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>双指滚动</b><span>两指滑动滚动页面</span></div>
        <button class="set-switch" :class="{ on: t.twoFinger }" @click="t.twoFinger = !t.twoFinger"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>自然滚动</b><span>与触屏方向一致</span></div>
        <button class="set-switch" :class="{ on: t.naturalScroll }" @click="t.naturalScroll = !t.naturalScroll"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>指针速度</b><span>{{ Math.round(t.speed * 200) }}%</span></div>
        <input v-model.number="t.speed" type="range" min="0.1" max="1.5" step="0.05" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>打字时禁用触控板</b><span>防止手掌误触</span></div>
        <button class="set-switch" :class="{ on: t.disableWhileTyping }" @click="t.disableWhileTyping = !t.disableWhileTyping"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">手势</div>
      <div v-for="g in gestures" :key="g.name" class="set-item">
        <span class="set-ico"><Icon name="ri-drag-move-2-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ g.name }}</b>
          <span>{{ g.keys }} 指手势</span>
        </div>
        <div class="set-item-ctl">
          <span class="set-badge on">{{ g.action }}</span>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">已连接设备 · {{ devices.filter((d) => d.connected).length }}</div>
      <div v-for="d in devices" :key="d.name" class="set-item">
        <span class="set-ico" :style="{ background: d.connected ? 'var(--c-accent-soft)' : 'var(--c-surface-3)' }">
          <Icon :name="d.icon" :size="16" />
        </span>
        <div class="set-item-text">
          <b>{{ d.name }}</b>
          <span>{{ d.kind }}</span>
        </div>
        <div class="set-item-ctl">
          <span class="set-badge" :class="{ on: d.connected }">{{ d.connected ? '已连接' : '未连接' }}</span>
        </div>
      </div>
    </div>

    <div class="set-note">
      <Icon name="ri-information-line" :size="15" style="margin-top: 1px; flex: none" />
      <span>键盘、鼠标、绘图板的详细设置已拆分为独立分页，可在左侧导航中直接进入。</span>
    </div>
  </div>
</template>
