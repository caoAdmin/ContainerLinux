<script setup lang="ts">
/** 设置 · 绘图板（数位板 / 笔） */
import { computed } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const t = sys.tablet

const connected = computed(() => t.devices.filter((d) => d.connected).length)

const buttonActions = ['中键点击', '右键点击', '橡皮擦', '切换工具', '无操作']
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">绘图板</h1>
    <p class="set-sub">{{ connected }} 个设备已连接 · {{ t.name }}</p>

    <div class="set-card">
      <div class="set-row">
        <span class="set-ico" :style="{ background: t.enabled ? 'var(--c-accent-soft)' : 'var(--c-surface-3)' }">
          <Icon name="ri-pen-nib-line" :size="17" />
        </span>
        <div class="set-label"><b>启用绘图板支持</b><span>关闭后笔输入按普通鼠标处理</span></div>
        <button class="set-switch" :class="{ on: t.enabled }" @click="t.enabled = !t.enabled"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">设备</div>
      <div v-for="d in t.devices" :key="d.name" class="set-item">
        <span class="set-ico" :style="{ background: d.connected ? 'var(--c-accent-soft)' : 'var(--c-surface-3)' }">
          <Icon :name="d.kind === '笔' ? 'ri-pen-nib-fill' : d.kind === '遥控器' ? 'ri-gamepad-line' : 'ri-tablet-line'" :size="16" />
        </span>
        <div class="set-item-text">
          <b>{{ d.name }}</b>
          <span>{{ d.kind }}</span>
        </div>
        <div class="set-item-ctl">
          <span class="set-badge" :class="{ on: d.connected }">{{ d.connected ? '已连接' : '未连接' }}</span>
        </div>
      </div>
    </div>

    <template v-if="t.enabled">
      <div class="set-card">
        <div class="set-card-title">映射</div>
        <div class="set-row">
          <div class="set-label"><b>输入模式</b><span>绝对定位贴合屏幕，相对定位像鼠标</span></div>
          <div class="set-seg">
            <button :class="{ active: t.mode === 'absolute' }" @click="t.mode = 'absolute'">绝对</button>
            <button :class="{ active: t.mode === 'relative' }" @click="t.mode = 'relative'">相对</button>
          </div>
        </div>
        <div class="set-row">
          <div class="set-label"><b>映射范围</b><span>整块屏幕 / 指定显示器 / 自定义区域</span></div>
          <div class="set-seg">
            <button :class="{ active: t.mapping === 'full' }" @click="t.mapping = 'full'">全屏</button>
            <button :class="{ active: t.mapping === 'monitor' }" @click="t.mapping = 'monitor'">显示器</button>
            <button :class="{ active: t.mapping === 'custom' }" @click="t.mapping = 'custom'">自定义</button>
          </div>
        </div>
        <div v-if="t.mapping === 'monitor'" class="set-row">
          <div class="set-label"><b>目标显示器</b><span>笔活动的显示区域</span></div>
          <select v-model="t.targetMonitor" class="set-select">
            <option v-for="m in sys.display.monitors" :key="m.name">{{ m.name }}</option>
          </select>
        </div>
        <div class="set-row col">
          <div class="set-label"><b>映射预览</b><span>{{ t.mapping === 'custom' ? t.area : '与屏幕等比例' }}</span></div>
          <div class="tb-area">
            <div class="tb-screen" />
            <div class="tb-map" :style="t.mapping === 'custom' ? { inset: '18% 26%' } : { inset: '0' }" />
          </div>
        </div>
      </div>

      <div class="set-card">
        <div class="set-card-title">笔</div>
        <div class="set-row">
          <div class="set-label"><b>压感曲线</b><span>{{ t.pressureCurve }}% · 越靠右越灵敏</span></div>
          <input v-model.number="t.pressureCurve" type="range" min="0" max="100" class="set-slider" />
        </div>
        <div class="set-row">
          <div class="set-label"><b>笔尖按钮</b><span>侧键 1</span></div>
          <select v-model="t.penButton1" class="set-select">
            <option v-for="a in buttonActions" :key="a">{{ a }}</option>
          </select>
        </div>
        <div class="set-row">
          <div class="set-label"><b>笔身按钮</b><span>侧键 2</span></div>
          <select v-model="t.penButton2" class="set-select">
            <option v-for="a in buttonActions" :key="a">{{ a }}</option>
          </select>
        </div>
        <div class="set-row">
          <div class="set-label"><b>触控环</b><span>旋转或滑动调节画笔大小</span></div>
          <button class="set-switch" :class="{ on: t.touchRing }" @click="t.touchRing = !t.touchRing"><i /></button>
        </div>
        <div class="set-row">
          <div class="set-label"><b>快捷键数量</b><span>ExpressKey 遥控器</span></div>
          <span class="set-badge">{{ t.expressKeys }} 个按键</span>
        </div>
      </div>
    </template>
  </div>
</template>

<style scoped>
.tb-area {
  position: relative;
  width: 100%;
  height: 160px;
  border-radius: 11px;
  background: var(--c-surface-3);
  border: 1px solid var(--c-border);
  overflow: hidden;
}
.tb-screen {
  position: absolute;
  inset: 0;
  border: 1px dashed var(--c-border-strong);
}
.tb-map {
  position: absolute;
  background: var(--c-accent-soft);
  border: 1.5px solid var(--c-accent);
  border-radius: 6px;
  transition: inset 0.18s ease;
}
</style>
