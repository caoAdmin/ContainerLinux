<script setup lang="ts">
/** 设置 · 键盘快捷键 —— 分组列表 + 搜索 + 录制 */
import { computed, ref } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const s = sys.shortcuts

const q = ref('')

const filtered = computed(() => {
  const k = q.value.trim().toLowerCase()
  if (!k) return s.groups
  return s.groups
    .map((g) => ({ ...g, items: g.items.filter((i) => i.label.toLowerCase().includes(k)) }))
    .filter((g) => g.items.length)
})

function startRecord(label: string) {
  s.recording = label
  window.setTimeout(() => {
    if (s.recording === label) s.recording = null
  }, 2500)
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">键盘快捷键</h1>
    <p class="set-sub">共 {{ s.groups.reduce((n, g) => n + g.items.length, 0) }} 条快捷键</p>

    <div class="set-card">
      <div class="set-row">
        <div class="set-label"><b>搜索快捷键</b><span>按名称或功能过滤</span></div>
        <div style="display: flex; align-items: center; gap: 8px; margin-left: auto; width: 240px">
          <Icon name="ri-search-line" :size="15" color="var(--c-text-mute)" />
          <input v-model="q" class="c-input" placeholder="例如：截图、窗口…" style="flex: 1" />
        </div>
      </div>
    </div>

    <div v-for="g in filtered" :key="g.name" class="set-card">
      <div class="set-card-title">{{ g.name }}</div>
      <div v-for="it in g.items" :key="it.label" class="set-item">
        <div class="set-item-text">
          <b>{{ it.label }}</b>
          <span>{{ it.custom ? '自定义快捷键' : '系统默认' }}</span>
        </div>
        <div class="set-item-ctl">
          <button class="sc-keys" :class="{ recording: s.recording === it.label }" @click="startRecord(it.label)">
            <template v-if="s.recording === it.label">按下新组合键…</template>
            <template v-else>
              <span v-for="k in it.keys" :key="k" class="c-kbd">{{ k }}</span>
            </template>
          </button>
          <button class="c-iconbtn" title="重置"><Icon name="ri-refresh-line" :size="14" /></button>
        </div>
      </div>
    </div>

    <div v-if="!filtered.length" class="set-card">
      <div class="set-item" style="color: var(--c-text-mute)">没有匹配的快捷键</div>
    </div>

    <div class="set-note">
      <Icon name="ri-information-line" :size="15" style="margin-top: 1px; flex: none" />
      <span>点击右侧按键区进入录制状态，按下新组合键即可改绑（演示中 2.5 秒后自动结束）。</span>
    </div>
  </div>
</template>

<style scoped>
.sc-keys {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  min-width: 128px;
  justify-content: flex-end;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  background: var(--c-surface-3);
  border: 1px solid var(--c-border);
  color: var(--c-text-dim);
  font: inherit;
  font-size: 12px;
  cursor: pointer;
}
.sc-keys:hover {
  border-color: var(--c-border-strong);
  color: var(--c-text);
}
.sc-keys.recording {
  background: var(--c-accent);
  border-color: transparent;
  color: #fff;
}
</style>
