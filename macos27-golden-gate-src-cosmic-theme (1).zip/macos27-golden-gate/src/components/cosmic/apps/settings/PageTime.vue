<script setup lang="ts">
/** 设置 · 时间与日期 */
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const t = sys.time

const now = ref(new Date())
const syncing = ref(false)
let timer = 0

const clock = computed(() => {
  const d = now.value
  const p = (n: number) => String(n).padStart(2, '0')
  let h = d.getHours()
  const suffix = t.format === '12h' ? (h >= 12 ? ' PM' : ' AM') : ''
  if (t.format === '12h') h = h % 12 || 12
  const base = `${p(h)}:${p(d.getMinutes())}${t.showSeconds ? ':' + p(d.getSeconds()) : ''}`
  return base + suffix
})

const dateText = computed(() =>
  now.value.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' })
)

function sync() {
  syncing.value = true
  window.setTimeout(() => (syncing.value = false), 1500)
}

onMounted(() => {
  timer = window.setInterval(() => (now.value = new Date()), 1000)
})
onUnmounted(() => window.clearInterval(timer))
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">时间与日期</h1>
    <p class="set-sub">自动同步、时区与显示格式</p>

    <div class="set-card">
      <div class="set-item" style="padding: 18px 0">
        <span class="set-ico" style="width: 52px; height: 52px; border-radius: 16px; background: var(--c-accent-soft)">
          <Icon name="ri-time-line" :size="26" />
        </span>
        <div class="set-item-text">
          <b style="font-size: 24px; font-variant-numeric: tabular-nums">{{ clock }}</b>
          <span>{{ dateText }}</span>
        </div>
        <div class="set-item-ctl">
          <button class="c-btn" :disabled="syncing" @click="sync">
            <Icon name="ri-refresh-line" :size="15" /> {{ syncing ? '同步中…' : '立即同步' }}
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">自动设置</div>
      <div class="set-row">
        <div class="set-label"><b>自动同步时间</b><span>通过网络时间服务器校准</span></div>
        <button class="set-switch" :class="{ on: t.auto }" @click="t.auto = !t.auto"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>时间服务器</b><span>NTP 服务地址</span></div>
        <select class="set-select" :disabled="!t.auto">
          <option>ntp.ubuntu.com</option>
          <option>cn.pool.ntp.org</option>
          <option>time.apple.com</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>时区</b><span>与「区域与语言」联动</span></div>
        <select v-model="t.timezone" class="set-select" :disabled="t.auto" style="min-width: 200px">
          <option>Asia/Shanghai</option>
          <option>Asia/Tokyo</option>
          <option>Europe/Berlin</option>
          <option>America/New_York</option>
        </select>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">显示格式</div>
      <div class="set-row">
        <div class="set-label"><b>时间格式</b><span>顶栏时钟写法</span></div>
        <div class="set-seg">
          <button :class="{ active: t.format === '24h' }" @click="t.format = '24h'">24 小时</button>
          <button :class="{ active: t.format === '12h' }" @click="t.format = '12h'">12 小时</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>显示秒</b><span>精确到秒</span></div>
        <button class="set-switch" :class="{ on: t.showSeconds }" @click="t.showSeconds = !t.showSeconds"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>显示周数</b><span>在日历中标出第几周</span></div>
        <button class="set-switch" :class="{ on: t.showWeekNumber }" @click="t.showWeekNumber = !t.showWeekNumber"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>日期格式</b><span>桌面与文件管理器中的写法</span></div>
        <select class="set-select">
          <option>2026-10-11</option>
          <option>2026/10/11</option>
          <option>11/10/2026</option>
          <option>10月 11日, 2026</option>
        </select>
      </div>
    </div>
  </div>
</template>
