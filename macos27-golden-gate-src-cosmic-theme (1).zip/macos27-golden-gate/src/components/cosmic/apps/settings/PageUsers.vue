<script setup lang="ts">
/** 设置 · 用户 —— 账户、自动登录、指纹 */
import { ref } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const u = sys.users

const editing = ref(false)
const draftName = ref('')

function startRename(full: string) {
  draftName.value = full
  editing.value = true
}
function commit() {
  if (draftName.value.trim()) u.list[0].full = draftName.value.trim()
  editing.value = false
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">用户</h1>
    <p class="set-sub">{{ u.list.length }} 个账户 · 最近登录 {{ u.lastLogin }}</p>

    <div class="set-card">
      <div class="set-item" style="padding: 18px 0">
        <span class="set-avatar">C</span>
        <div class="set-item-text">
          <template v-if="editing">
            <input
              v-model="draftName"
              class="c-input"
              style="max-width: 220px"
              @keydown.enter="commit"
              @blur="commit"
            />
          </template>
          <template v-else>
            <b style="font-size: 16px">{{ u.list[0].full }}</b>
            <span>{{ u.list[0].name }} · {{ u.list[0].type }} · 在线</span>
          </template>
        </div>
        <div class="set-item-ctl">
          <button class="c-btn" @click="startRename(u.list[0].full)">
            <Icon name="ri-edit-line" :size="14" /> 修改名称
          </button>
          <button class="c-btn">
            <Icon name="ri-lock-password-line" :size="14" /> 修改密码
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">登录</div>
      <div class="set-row">
        <div class="set-label"><b>自动登录</b><span>开机后直接进入桌面，跳过登录界面</span></div>
        <button class="set-switch" :class="{ on: u.autoLogin }" @click="u.autoLogin = !u.autoLogin"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>指纹解锁</b><span>已录入 2 枚指纹</span></div>
        <button class="set-switch" :class="{ on: u.fingerprint }" @click="u.fingerprint = !u.fingerprint"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>锁屏后要求密码</b><span>唤醒时立刻锁定</span></div>
        <button class="set-switch on"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">其他账户</div>
      <div v-for="usr in u.list.slice(1)" :key="usr.name" class="set-item">
        <span class="set-ico round" style="background: var(--c-surface-3)">
          <Icon name="ri-user-3-line" :size="16" />
        </span>
        <div class="set-item-text"><b>{{ usr.full }}</b><span>{{ usr.name }} · {{ usr.type }}</span></div>
        <div class="set-item-ctl">
          <span class="set-badge">{{ usr.online ? '在线' : '离线' }}</span>
          <button class="c-iconbtn"><Icon name="ri-delete-bin-6-line" :size="15" /></button>
        </div>
      </div>
      <div class="set-actions">
        <button class="c-btn c-btn--primary"><Icon name="ri-user-add-line" :size="15" /> 添加用户</button>
      </div>
    </div>
  </div>
</template>
