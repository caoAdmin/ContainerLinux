<script setup lang="ts">
/** 设置 · 辅助功能 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const a = sys.a11y

const toggles = [
  { key: 'largeText', label: '大号文字', desc: '界面字体整体放大 15%', icon: 'ri-font-size-2' },
  { key: 'highContrast', label: '高对比度', desc: '增强前景与背景的对比', icon: 'ri-contrast-drop-2-line' },
  { key: 'reduceMotion', label: '减弱动画', desc: '关闭过渡与位移动效', icon: 'ri-speed-mini-line' },
  { key: 'screenReader', label: '屏幕阅读器', desc: '朗读界面元素（Orca）', icon: 'ri-speak-line' },
  { key: 'magnifier', label: '屏幕放大镜', desc: 'Super + = 放大局部', icon: 'ri-zoom-in-line' },
  { key: 'stickyKeys', label: '粘滞键', desc: '连按修饰键保持按下', icon: 'ri-keyboard-line' },
  { key: 'visualAlerts', label: '视觉提示', desc: '用闪烁代替系统提示音', icon: 'ri-flashlight-line' }
]

function isOn(key: string): boolean {
  return (a as unknown as Record<string, boolean>)[key] === true
}
function toggle(key: string) {
  ;(a as unknown as Record<string, boolean>)[key] = !isOn(key)
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">辅助功能</h1>
    <p class="set-sub">让桌面更易用</p>

    <div class="set-card">
      <div v-for="t in toggles" :key="t.key" class="set-item">
        <span class="set-ico"><Icon :name="t.icon" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ t.label }}</b>
          <span>{{ t.desc }}</span>
        </div>
        <div class="set-item-ctl">
          <button class="set-switch" :class="{ on: isOn(t.key) }" @click="toggle(t.key)">
            <i />
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">指针与光标</div>
      <div class="set-row">
        <div class="set-label"><b>光标大小</b><span>{{ a.cursorSize }} px</span></div>
        <input v-model.number="a.cursorSize" type="range" min="16" max="64" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>光标预览</b><span>按当前大小显示</span></div>
        <div class="cursor-preview" :style="{ width: a.cursorSize + 'px', height: a.cursorSize + 'px' }">
          <Icon name="ri-cursor-fill" :size="a.cursorSize * 0.7" />
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">缩放与字体</div>
      <div class="set-row">
        <div class="set-label"><b>字体缩放</b><span>与「外观」联动</span></div>
        <div class="set-seg">
          <button
            v-for="f in [0.9, 1, 1.1, 1.25, 1.5]"
            :key="f"
            :class="{ active: sys.appearance.fontScale === f }"
            @click="sys.appearance.fontScale = f"
          >
            {{ Math.round(f * 100) }}%
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>缩放预览</b><span>示例文本</span></div>
        <span :style="{ fontSize: sys.appearance.fontScale + 'em' }">COSMIC 桌面 示例文本</span>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">键盘导航</div>
      <div class="set-row">
        <div class="set-label"><b>Tab 键聚焦控件</b><span>用键盘遍历界面元素</span></div>
        <button class="set-switch on"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>焦点高亮</b><span>当前聚焦元素描边</span></div>
        <button class="set-switch on"><i /></button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.cursor-preview {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--c-text);
  transition: width 0.14s ease, height 0.14s ease;
}
</style>
