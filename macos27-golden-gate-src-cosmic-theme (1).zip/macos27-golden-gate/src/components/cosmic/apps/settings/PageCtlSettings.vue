<script setup lang="ts">
/**
 * PageCtlSettings —— ContainerLinux 系统设置（已并入 COSMIC Settings）
 * 承接原 CtSettings 面板：系统功能分组展示（可一键打开对应应用）+
 * 后台守护进程集中观察。左侧导航由 COSMIC Settings 统一提供，
 * 本页只负责「概览 / 分组 / 进程与守护」三块内容的内部切换。
 */
import { computed, ref } from 'vue'
import Icon from '@/components/common/Icon.vue'
import { useCosmicStore } from '@/stores/cosmic'
import { ctApps } from '@/data/ct/ctApps'

const store = useCosmicStore()

/** 保留为桌面独立应用（有入口）的 id —— 系统功能卡片上可跳转打开 */
const APP_IDS = new Set([
  'ct-overview', 'ct-kernel', 'ct-plugins', 'ct-appstore', 'ct-installer',
  'ct-distro', 'ct-timetravel', 'ct-swarm', 'ct-claw'
])

const systemApps = computed(() => ctApps.filter((a) => a.tier === 'system'))
const daemonApps = computed(() => ctApps.filter((a) => a.tier === 'daemon'))

const sysGroups = computed(() => {
  const m: Record<string, any[]> = {}
  systemApps.value.forEach((a) => {
    ;(m[a.group] = m[a.group] || []).push(a)
  })
  return Object.entries(m)
})

const nav = computed(() => [
  { id: 'overview', label: '概览', icon: 'ri-dashboard-3-line' },
  ...sysGroups.value.map(([g]) => ({ id: 'g:' + g, label: g, icon: 'ri-stack-line' })),
  { id: 'proc', label: '进程与守护', icon: 'ri-server-line' }
])

const pageIdx = ref(0)
const cur = computed(() => nav.value[pageIdx.value])
const currentGroup = computed(() => {
  const id = cur.value?.id || ''
  return id.startsWith('g:') ? id.slice(2) : ''
})
const currentItems = computed(
  () => sysGroups.value.find(([g]) => g === currentGroup.value)?.[1] || []
)

function gotoGroup(g: string) {
  const i = nav.value.findIndex((n) => n.id === 'g:' + g)
  if (i >= 0) pageIdx.value = i
}
function openApp(id: string) {
  store.openApp(id)
}
</script>

<template>
  <div class="set-wrap ctl">
    <!-- 内部子导航：概览 / 各分组 / 进程与守护 -->
    <div class="ctl-nav">
      <button
        v-for="(n, i) in nav"
        :key="n.id"
        class="ctl-nav-i"
        :class="{ on: i === pageIdx }"
        type="button"
        @click="pageIdx = i"
      >
        <Icon :name="n.icon" :size="15" />
        <span>{{ n.label }}</span>
      </button>
    </div>

    <!-- ═══ 概览 ═══ -->
    <div v-if="!cur || cur.id === 'overview'" class="ctl-page">
      <header class="cs-hero">
        <h1>ContainerLinux 系统设置</h1>
        <p>
          {{ systemApps.length }} 项系统功能与 {{ daemonApps.length }} 个后台守护集中管理。系统功能
          （网络、存储、安全、桌面等）通过对应设置项调节；底层守护进程在「进程与守护」中观察。
        </p>
      </header>
      <div class="cs-grid">
        <div
          v-for="([g, items]) in sysGroups"
          :key="g"
          class="cs-cat-card"
          @click="gotoGroup(g)"
        >
          <Icon :name="items[0].icon" :size="20" />
          <b>{{ g }}</b>
          <i>{{ items.length }} 项</i>
        </div>
        <div class="cs-cat-card" @click="pageIdx = nav.findIndex((n) => n.id === 'proc')">
          <Icon name="ri-server-line" :size="20" />
          <b>进程与守护</b>
          <i>{{ daemonApps.length }} 项</i>
        </div>
      </div>
    </div>

    <!-- ═══ 分组页（系统功能）═══ -->
    <div v-else-if="currentGroup" class="ctl-page">
      <header class="cs-head">
        <h1>{{ currentGroup }}</h1>
        <p>{{ currentItems.length }} 项系统功能</p>
      </header>
      <div class="cs-app-grid">
        <div v-for="a in currentItems" :key="a.id" class="cs-app-card">
          <div class="cs-app-ic" :style="{ background: `linear-gradient(135deg, ${a.from}, ${a.to})` }">
            <Icon :name="a.icon" :size="20" />
          </div>
          <div class="cs-app-main">
            <div class="cs-app-name">{{ a.name }}</div>
            <div class="cs-app-desc">{{ a.desc }}</div>
            <div class="cs-app-foot">
              <span class="cs-status"><i />{{ a.status }}</span>
              <button v-if="APP_IDS.has(a.id)" class="cs-open" type="button" @click="openApp(a.id)">
                <Icon name="ri-external-link-line" :size="13" /> 打开应用
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══ 进程与守护 ═══ -->
    <div v-else class="ctl-page">
      <header class="cs-head">
        <h1>进程与守护</h1>
        <p>{{ daemonApps.length }} 个后台守护进程</p>
      </header>
      <div class="cs-table">
        <div class="cs-tr cs-th"><span>守护进程</span><span>分组</span><span>状态</span><span>类型</span></div>
        <div v-for="a in daemonApps" :key="a.id" class="cs-tr">
          <span class="cs-td-name"><Icon :name="a.icon" :size="15" /> {{ a.name }}</span>
          <span>{{ a.group }}</span>
          <span><i class="cs-dot" />{{ a.status }}</span>
          <span class="cs-tag">后台守护</span>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* 内部子导航 */
.ctl-nav {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 18px;
}
.ctl-nav-i {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 7px 12px;
  border: 1px solid var(--c-border);
  border-radius: 10px;
  background: transparent;
  color: var(--c-text-dim);
  font-size: 12.5px;
  cursor: pointer;
  transition: all 0.15s;
}
.ctl-nav-i:hover { background: var(--c-hover); color: var(--c-text); }
.ctl-nav-i.on {
  background: var(--c-accent-soft, color-mix(in srgb, var(--c-accent) 16%, transparent));
  color: var(--c-accent);
  border-color: transparent;
  font-weight: 650;
}

/* ── 主内容 ── */
.ctl-page { max-width: 1040px; }
.cs-hero { padding: 6px 0 18px; border-bottom: 1px solid var(--c-border); margin-bottom: 18px; }
.cs-hero h1 { margin: 0 0 8px; font-size: 22px; font-weight: 700; color: var(--c-text); letter-spacing: -.3px; }
.cs-hero p { margin: 0; font-size: 13px; line-height: 1.65; color: var(--c-text-dim); max-width: 760px; }
.cs-head { margin-bottom: 14px; }
.cs-head h1 { margin: 0 0 4px; font-size: 19px; font-weight: 700; color: var(--c-text); }
.cs-head p { margin: 0; font-size: 12px; color: var(--c-text-dim); }

.cs-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; }
.cs-cat-card {
  background: var(--c-surface-2); border: 1px solid var(--c-border); border-radius: 14px;
  padding: 16px; cursor: pointer; display: flex; flex-direction: column; gap: 7px; transition: all .15s;
}
.cs-cat-card:hover { background: var(--c-hover); transform: translateY(-2px); border-color: var(--c-border-strong); }
.cs-cat-card b { font-size: 14px; color: var(--c-text); }
.cs-cat-card i { font-style: normal; font-size: 12px; color: var(--c-text-dim); }

.cs-app-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 12px; }
.cs-app-card {
  display: flex; gap: 12px; background: var(--c-surface-2); border: 1px solid var(--c-border);
  border-radius: 14px; padding: 14px; transition: all .15s;
}
.cs-app-card:hover { border-color: var(--c-border-strong); background: var(--c-hover); }
.cs-app-ic { width: 40px; height: 40px; border-radius: 11px; display: grid; place-items: center; color: #fff; flex: none; box-shadow: 0 3px 10px var(--c-shadow); }
.cs-app-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px; }
.cs-app-name { font-size: 14px; font-weight: 650; color: var(--c-text); }
.cs-app-desc { font-size: 12px; color: var(--c-text-dim); line-height: 1.5; }
.cs-app-foot { display: flex; align-items: center; justify-content: space-between; margin-top: 2px; }
.cs-status {
  display: inline-flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 600;
  color: #4fb783; background: rgba(79, 183, 131, .12); padding: 3px 9px; border-radius: 20px;
}
.cs-status i { width: 6px; height: 6px; border-radius: 50%; background: #4fb783; }
.cs-open {
  display: inline-flex; align-items: center; gap: 5px; font-size: 11.5px; font-weight: 600;
  color: var(--c-accent); background: var(--c-accent-soft, color-mix(in srgb, var(--c-accent) 16%, transparent));
  border: 0; border-radius: 9px; padding: 5px 10px; cursor: pointer;
}
.cs-open:hover { filter: brightness(1.05); }

.cs-table { margin-top: 4px; border: 1px solid var(--c-border); border-radius: 14px; overflow: hidden; }
.cs-tr {
  display: grid; grid-template-columns: 1.7fr 1fr 1fr .8fr; align-items: center;
  padding: 11px 16px; border-bottom: 1px solid var(--c-border); font-size: 13px; color: var(--c-text);
}
.cs-tr:last-child { border-bottom: 0; }
.cs-th { background: var(--c-surface-2); font-size: 11px; font-weight: 600; color: var(--c-text-mute); text-transform: uppercase; letter-spacing: .5px; }
.cs-td-name { display: inline-flex; align-items: center; gap: 8px; font-weight: 600; }
.cs-dot { width: 6px; height: 6px; border-radius: 50%; background: #4fb783; display: inline-block; }
.cs-tag { font-size: 11px; color: var(--c-text-mute); }
</style>
