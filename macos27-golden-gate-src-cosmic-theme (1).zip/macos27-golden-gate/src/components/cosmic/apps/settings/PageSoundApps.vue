<script setup lang="ts">
/** 设置 · 声音 → 应用程序音量（每种应用的独立音量） */
import { computed } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const sa = sys.soundApps

const audible = computed(() => sa.apps.filter((a) => !a.muted && a.volume > 0).length)

function muteAll() {
  sa.apps.forEach((a) => (a.muted = true))
}
function resetAll() {
  sa.apps.forEach((a) => {
    a.muted = false
    a.volume = 70
  })
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">应用程序音量</h1>
    <p class="set-sub">{{ sa.apps.length }} 个应用正在使用音频 · {{ audible }} 个有声</p>

    <div class="set-card">
      <div class="set-row">
        <div class="set-label"><b>批量操作</b><span>一键静音或恢复默认音量</span></div>
        <div style="display: flex; gap: 8px; margin-left: auto">
          <button class="c-btn" @click="muteAll"><Icon name="ri-volume-mute-line" :size="15" /> 全部静音</button>
          <button class="c-btn" @click="resetAll"><Icon name="ri-refresh-line" :size="15" /> 重置音量</button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">播放中的应用</div>
      <div v-for="a in sa.apps" :key="a.name" class="set-item">
        <span class="set-ico"><Icon :name="a.icon" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ a.name }}</b>
          <span>输出到 {{ a.route }}</span>
        </div>
        <div class="set-item-ctl" style="min-width: 320px">
          <button class="c-iconbtn" @click="a.muted = !a.muted">
            <Icon :name="a.muted || a.volume === 0 ? 'ri-volume-mute-line' : 'ri-volume-up-line'" :size="16" />
          </button>
          <input
            v-model.number="a.volume"
            type="range"
            min="0"
            max="100"
            class="set-slider"
            style="width: 140px"
            :disabled="a.muted"
          />
          <span class="set-badge" style="min-width: 44px; justify-content: center">
            {{ a.muted ? '静音' : a.volume + '%' }}
          </span>
          <select v-model="a.route" class="set-select" style="min-width: 130px">
            <option>内置扬声器</option>
            <option>WH-1000XM5</option>
            <option>DELL U2723QE</option>
          </select>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">设备配置文件</div>
      <div class="set-row">
        <div class="set-label"><b>内置扬声器</b><span>立体声输出 · 当前激活</span></div>
        <div class="set-seg">
          <button class="active">立体声</button>
          <button>环绕</button>
          <button>关闭</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>WH-1000XM5</b><span>蓝牙 · A2DP / 免提</span></div>
        <div class="set-seg">
          <button class="active">高保真 (A2DP)</button>
          <button>免提 (HFP)</button>
        </div>
      </div>
    </div>
  </div>
</template>
