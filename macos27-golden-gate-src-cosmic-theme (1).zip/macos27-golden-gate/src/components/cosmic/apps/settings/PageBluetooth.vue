<script setup lang="ts">
/** 设置 · 蓝牙 —— 开关、已配对设备、扫描发现 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const b = sys.bt

function toggleDevice(mac: string) {
  const d = b.devices.find((x) => x.mac === mac)
  if (!d) return
  d.connected = !d.connected
  d.paired = true
}

function remove(mac: string) {
  b.devices = b.devices.filter((x) => x.mac !== mac)
}

function scan() {
  b.scanning = true
  window.setTimeout(() => (b.scanning = false), 2200)
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">蓝牙</h1>
    <p class="set-sub">{{ b.enabled ? `${b.devices.filter((d) => d.connected).length} 台设备已连接` : '蓝牙已关闭' }}</p>

    <div class="set-card">
      <div class="set-row">
        <span class="set-ico" :style="{ background: b.enabled ? 'var(--c-accent-soft)' : 'var(--c-surface-3)' }">
          <Icon name="ri-bluetooth-line" :size="17" />
        </span>
        <div class="set-label"><b>蓝牙</b><span>{{ b.enabled ? '可被发现 · cosmic-pc' : '已关闭' }}</span></div>
        <button class="set-switch" :class="{ on: b.enabled }" @click="b.enabled = !b.enabled"><i /></button>
      </div>
    </div>

    <template v-if="b.enabled">
      <div class="set-card">
        <div class="set-card-title">我的设备 · {{ b.devices.length }}</div>
        <div v-for="d in b.devices" :key="d.mac" class="set-item">
          <span class="set-ico round" :style="{ background: d.connected ? 'var(--c-accent-soft)' : 'var(--c-surface-3)' }">
            <Icon :name="d.icon" :size="16" />
          </span>
          <div class="set-item-text">
            <b>{{ d.name }}</b>
            <span>{{ d.mac }} · {{ d.connected ? '已连接' : d.paired ? '已配对 · 未连接' : '未配对' }}</span>
          </div>
          <div class="set-item-ctl">
            <button class="c-btn" style="height: 28px; font-size: 12px" @click="toggleDevice(d.mac)">
              {{ d.connected ? '断开' : '连接' }}
            </button>
            <button class="c-iconbtn" title="移除设备" @click="remove(d.mac)">
              <Icon name="ri-delete-bin-6-line" :size="15" />
            </button>
          </div>
        </div>
        <div v-if="!b.devices.length" class="set-item" style="color: var(--c-text-mute)">暂无已配对设备</div>
      </div>

      <div class="set-card">
        <div class="set-card-title">扫描</div>
        <div class="set-row">
          <div class="set-label">
            <b>{{ b.scanning ? '正在扫描附近设备…' : '搜索新设备' }}</b>
            <span>确保目标设备处于配对模式</span>
          </div>
          <button class="c-btn c-btn--primary" :disabled="b.scanning" @click="scan">
            <Icon name="ri-radar-line" :size="15" /> {{ b.scanning ? '扫描中…' : '扫描' }}
          </button>
        </div>
        <div class="set-row">
          <div class="set-label"><b>对附近设备可见</b><span>关闭后仅已配对设备能找到本机</span></div>
          <button class="set-switch on"><i /></button>
        </div>
      </div>
    </template>
  </div>
</template>
