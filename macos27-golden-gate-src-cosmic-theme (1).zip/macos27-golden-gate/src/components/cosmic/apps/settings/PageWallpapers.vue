<script setup lang="ts">
/** 设置 · 壁纸（独立分页，COSMIC 1.0 与「桌面」并列） */
import { computed } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'
import { WALLPAPER_GRADIENTS } from '@/utils/wallpapers'

const store = useCosmicStore()
const sys = useCosmicSystemStore()
const w = sys.wallpapers

const gradients = WALLPAPER_GRADIENTS

const currentBg = computed(() =>
  w.mode === 'solid'
    ? w.solidColor
    : w.mode === 'gradient'
      ? `linear-gradient(140deg, ${w.gradientFrom}, ${w.gradientTo})`
      : gradients[w.current]
)
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">壁纸</h1>
    <p class="set-sub">选择背景、填充方式与显示效果</p>

    <div class="set-card">
      <div class="set-card-title">预览</div>
      <div class="set-row col">
        <div class="wp-preview" :style="{ background: currentBg, filter: `blur(${w.blur}px)` }">
          <div class="wp-preview-bar">COSMIC 面板预览</div>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>背景类型</b><span>图片 / 纯色 / 渐变</span></div>
        <div class="set-seg">
          <button :class="{ active: w.mode === 'image' }" @click="w.mode = 'image'">图片</button>
          <button :class="{ active: w.mode === 'solid' }" @click="w.mode = 'solid'">纯色</button>
          <button :class="{ active: w.mode === 'gradient' }" @click="w.mode = 'gradient'">渐变</button>
        </div>
      </div>
      <div v-if="w.mode === 'solid'" class="set-row">
        <div class="set-label"><b>颜色</b><span>{{ w.solidColor }}</span></div>
        <input v-model="w.solidColor" type="color" class="wp-color" />
      </div>
      <div v-if="w.mode === 'gradient'" class="set-row">
        <div class="set-label"><b>渐变两端</b><span>{{ w.gradientFrom }} → {{ w.gradientTo }}</span></div>
        <div style="display: flex; gap: 8px; margin-left: auto">
          <input v-model="w.gradientFrom" type="color" class="wp-color" />
          <input v-model="w.gradientTo" type="color" class="wp-color" />
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>填充方式</b><span>与「桌面」设置联动</span></div>
        <select v-model="w.fill" class="set-select">
          <option v-for="f in ['填充', '适应', '拉伸', '平铺', '居中', '跨屏']" :key="f">{{ f }}</option>
        </select>
      </div>
      <div class="set-row">
        <div class="set-label"><b>虚化</b><span>{{ w.blur }} px</span></div>
        <input v-model.number="w.blur" type="range" min="0" max="40" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>暗化</b><span>{{ Math.round(w.darken * 100) }}%</span></div>
        <input v-model.number="w.darken" type="range" min="0" max="0.8" step="0.05" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>提取强调色</b><span>从壁纸取主色作为系统强调色</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <span class="set-badge">{{ w.accentColor }}</span>
          <button class="c-btn" @click="store.settings.accent = w.accentColor">
            <Icon name="ri-magic-line" :size="14" /> 应用到系统
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">内置壁纸 · {{ w.items.length }}</div>
      <div class="set-row col">
        <div class="set-thumbs">
          <button
            v-for="it in w.items"
            :key="it.id"
            class="set-thumb"
            :class="{ active: w.mode === 'image' && w.current === it.id }"
            :style="{ background: gradients[it.id] }"
            @click="w.mode = 'image'; w.current = it.id"
          >
            <em>{{ it.name }}</em>
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">显示器</div>
      <div class="set-row">
        <div class="set-label"><b>应用到所有显示器</b><span>关闭后可分别为每块屏设置</span></div>
        <button class="set-switch" :class="{ on: w.onAll }" @click="w.onAll = !w.onAll"><i /></button>
      </div>
      <div v-if="!w.onAll" v-for="(m, i) in sys.display.monitors" :key="m.name" class="set-row">
        <div class="set-label"><b>{{ m.name }}</b><span>{{ m.res }}</span></div>
        <select v-model="w.perMonitor[i]" class="set-select">
          <option v-for="it in w.items" :key="it.id" :value="it.id">{{ it.name }}</option>
        </select>
      </div>
    </div>
  </div>
</template>

<style scoped>
.wp-preview {
  position: relative;
  width: 100%;
  height: 210px;
  border-radius: 12px;
  border: 1px solid var(--c-border);
  overflow: hidden;
  transition: background 0.2s ease, filter 0.2s ease;
}
.wp-preview-bar {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 30px;
  background: rgba(0, 0, 0, 0.42);
  backdrop-filter: blur(12px);
  color: rgba(255, 255, 255, 0.85);
  font-size: 11.5px;
  display: flex;
  align-items: center;
  padding: 0 12px;
}
.wp-color {
  width: 44px;
  height: 32px;
  padding: 2px;
  border-radius: 9px;
  background: var(--c-surface-3);
  border: 1px solid var(--c-border);
  cursor: pointer;
}
</style>
