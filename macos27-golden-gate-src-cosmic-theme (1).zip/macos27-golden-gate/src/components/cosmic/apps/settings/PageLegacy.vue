<script setup lang="ts">
/** 设置 · 旧版应用程序（X11 / XWayland 兼容） */
import { ref } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const l = sys.legacy

const scales = ['自动', '1.0x', '1.25x', '1.5x', '2.0x']
const draft = ref('')

function add() {
  const name = draft.value.trim()
  if (!name) return
  l.items.push({ name, cmd: name.toLowerCase().replace(/\s+/g, '-'), scale: l.defaultScale, enabled: true })
  draft.value = ''
}

function setScale(s: string) {
  l.defaultScale = s as typeof l.defaultScale
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">旧版应用程序</h1>
    <p class="set-sub">X11 应用通过 XWayland 运行 · {{ l.items.length }} 个已配置</p>

    <div class="set-card">
      <div class="set-row">
        <span class="set-ico" :style="{ background: l.xwaylandEnabled ? 'var(--c-accent-soft)' : 'var(--c-surface-3)' }">
          <Icon name="ri-window-2-line" :size="17" />
        </span>
        <div class="set-label">
          <b>启用 XWayland 兼容层</b>
          <span>关闭后 X11 应用将无法启动（需要重启会话）</span>
        </div>
        <button class="set-switch" :class="{ on: l.xwaylandEnabled }" @click="l.xwaylandEnabled = !l.xwaylandEnabled"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>默认缩放</b><span>新添加的 X11 应用使用的缩放</span></div>
        <div class="set-seg">
          <button v-for="s in scales" :key="s" :class="{ active: l.defaultScale === s }" @click="setScale(s)">
            {{ s }}
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">已配置的 X11 应用</div>
      <div v-for="it in l.items" :key="it.cmd" class="set-item">
        <span class="set-ico"><Icon name="ri-apps-2-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ it.name }}</b>
          <span style="font-family: monospace">{{ it.cmd }}</span>
        </div>
        <div class="set-item-ctl">
          <select v-model="it.scale" class="set-select" style="min-width: 110px">
            <option v-for="s in scales" :key="s">{{ s }}</option>
          </select>
          <button class="set-switch" :class="{ on: it.enabled }" @click="it.enabled = !it.enabled"><i /></button>
          <button class="c-iconbtn" title="移除" @click="l.items = l.items.filter((x) => x.cmd !== it.cmd)">
            <Icon name="ri-delete-bin-6-line" :size="15" />
          </button>
        </div>
      </div>
      <div v-if="!l.items.length" class="set-item" style="color: var(--c-text-mute)">暂无配置项</div>
      <div class="set-row">
        <div class="set-label"><b>添加应用</b><span>输入可执行文件名或 .desktop 名称</span></div>
        <div style="display: flex; gap: 8px; margin-left: auto">
          <input v-model="draft" class="c-input" placeholder="例如 code" style="width: 180px" @keydown.enter="add" />
          <button class="c-btn c-btn--primary" :disabled="!draft.trim()" @click="add">
            <Icon name="ri-add-line" :size="15" /> 添加
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">兼容层状态</div>
      <div class="set-kv"><span>XWayland 版本</span><b>24.1.4</b></div>
      <div class="set-kv"><span>运行中的 X11 客户端</span><b>{{ l.xwaylandEnabled ? 6 : 0 }} 个</b></div>
      <div class="set-kv"><span>剪贴板同步</span><b>双向同步已启用</b></div>
      <div class="set-kv"><span>缩放方式</span><b>分数缩放（fracrel）</b></div>
    </div>

    <div class="set-note">
      <Icon name="ri-alert-line" :size="15" style="margin-top: 1px; flex: none" />
      <span>部分 X11 应用在高分屏下会模糊，建议按应用单独设置缩放比例。</span>
    </div>
  </div>
</template>
