<script setup lang="ts">
/** 设置 · 启动应用程序 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const s = sys.startup
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">启动应用程序</h1>
    <p class="set-sub">登录桌面时自动运行的程序（已启用 {{ s.items.filter((i) => i.on).length }} / {{ s.items.length }}）</p>

    <div class="set-card">
      <div v-for="it in s.items" :key="it.name" class="set-item">
        <span class="set-ico"><Icon name="ri-play-circle-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ it.name }}</b>
          <span>{{ it.cmd }}{{ it.system ? ' · 系统组件' : '' }}</span>
        </div>
        <div class="set-item-ctl">
          <span v-if="it.system" class="set-badge">系统</span>
          <button class="set-switch" :class="{ on: it.on }" @click="it.on = !it.on"><i /></button>
        </div>
      </div>
      <div class="set-actions">
        <button class="c-btn c-btn--primary" @click="s.items.push({ name: '新启动项', cmd: 'custom-app', on: true, system: false })">
          <Icon name="ri-add-line" :size="15" /> 添加启动项
        </button>
        <button class="c-btn"><Icon name="ri-folder-open-line" :size="15" /> 浏览…</button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">选项</div>
      <div class="set-row">
        <div class="set-label"><b>延迟启动</b><span>登录后等待 3 秒再运行启动项</span></div>
        <button class="set-switch on"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>在启动器中显示</b><span>把启动项也作为应用条目展示</span></div>
        <button class="set-switch"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">桌面环境组件</div>
      <div class="set-kv"><span>cosmic-session</span><b>会话管理</b></div>
      <div class="set-kv"><span>cosmic-comp</span><b>Wayland 合成器</b></div>
      <div class="set-kv"><span>cosmic-panel</span><b>顶栏 / Dock</b></div>
      <div class="set-kv"><span>cosmic-applets</span><b>面板插件</b></div>
      <div class="set-kv"><span>cosmic-notifications</span><b>通知守护</b></div>
      <div class="set-kv"><span>cosmic-osd</span><b>音量 / 亮度提示</b></div>
      <div class="set-kv"><span>cosmic-bg</span><b>壁纸与主题</b></div>
      <div class="set-kv"><span>cosmic-idle</span><b>空闲管理</b></div>
    </div>
  </div>
</template>
