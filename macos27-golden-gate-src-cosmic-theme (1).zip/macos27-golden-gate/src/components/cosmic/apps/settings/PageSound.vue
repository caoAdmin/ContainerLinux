<script setup lang="ts">
/** 设置 · 声音 —— 输出/输入设备、音量、电平、提示音 */
import { onMounted, onUnmounted } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const s = sys.sound

const outputs = [
  { name: '内置扬声器 (Radeon HD Audio)', icon: 'ri-volume-up-line', active: true },
  { name: 'WH-1000XM5 (蓝牙)', icon: 'ri-headphone-line', active: false },
  { name: 'DELL U2723QE (HDMI)', icon: 'ri-tv-line', active: false }
]
const inputs = [
  { name: '内置麦克风', icon: 'ri-mic-line', active: true },
  { name: 'WH-1000XM5 (蓝牙)', icon: 'ri-mic-2-line', active: false }
]

let timer = 0
onMounted(() => {
  timer = window.setInterval(() => {
    s.outputLevel = Math.max(0.05, Math.min(1, s.outputLevel + (Math.random() - 0.5) * 0.28))
    s.inputLevel = Math.max(0.03, Math.min(1, s.inputLevel + (Math.random() - 0.5) * 0.2))
  }, 140)
})
onUnmounted(() => window.clearInterval(timer))
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">声音</h1>
    <p class="set-sub">输出与输入设备、音量与提示音</p>

    <div class="set-card">
      <div class="set-card-title">输出</div>
      <div class="set-row">
        <div class="set-label"><b>主音量</b><span>作用于当前输出设备</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <button class="c-iconbtn" @click="s.muted = !s.muted">
            <Icon :name="s.muted || s.outputVolume === 0 ? 'ri-volume-mute-line' : 'ri-volume-up-line'" :size="16" />
          </button>
          <input v-model.number="s.outputVolume" type="range" min="0" max="100" class="set-slider" />
          <span class="set-badge" style="min-width: 44px; justify-content: center">{{ s.outputVolume }}%</span>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>输出电平</b><span>实时音量指示</span></div>
        <div class="meter"><i :style="{ width: s.outputLevel * 100 + '%' }" /></div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>允许超过 100%</b><span>可能出现削波失真</span></div>
        <button class="set-switch" :class="{ on: s.overamplify }" @click="s.overamplify = !s.overamplify"><i /></button>
      </div>
      <div v-for="o in outputs" :key="o.name" class="set-item">
        <span class="set-ico round"><Icon :name="o.icon" :size="15" /></span>
        <div class="set-item-text">
          <b>{{ o.name }}</b>
          <span>{{ o.active ? '当前使用中' : '可用' }}</span>
        </div>
        <div class="set-item-ctl">
          <span class="set-badge" :class="{ on: o.active }">{{ o.active ? '已选择' : '切换' }}</span>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">输入</div>
      <div class="set-row">
        <div class="set-label"><b>输入音量</b><span>麦克风增益</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <Icon name="ri-mic-line" :size="16" color="var(--c-text-mute)" />
          <input v-model.number="s.inputVolume" type="range" min="0" max="100" class="set-slider" />
          <span class="set-badge" style="min-width: 44px; justify-content: center">{{ s.inputVolume }}%</span>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>输入电平</b><span>说话时会跳动</span></div>
        <div class="meter"><i :style="{ width: s.inputLevel * 100 + '%' }" /></div>
      </div>
      <div v-for="o in inputs" :key="o.name" class="set-item">
        <span class="set-ico round"><Icon :name="o.icon" :size="15" /></span>
        <div class="set-item-text">
          <b>{{ o.name }}</b>
          <span>{{ o.active ? '当前使用中' : '可用' }}</span>
        </div>
        <div class="set-item-ctl">
          <span class="set-badge" :class="{ on: o.active }">{{ o.active ? '已选择' : '切换' }}</span>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">提示音</div>
      <div class="set-row">
        <div class="set-label"><b>系统提示音音量</b><span>{{ s.alertVolume }}%</span></div>
        <input v-model.number="s.alertVolume" type="range" min="0" max="100" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>播放测试音</b><span>确认当前输出是否正常</span></div>
        <button class="c-btn"><Icon name="ri-play-fill" :size="14" /> 播放</button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.meter {
  margin-left: auto;
  width: 190px;
  height: 8px;
  border-radius: 4px;
  background: var(--c-surface-3);
  overflow: hidden;
}
.meter i {
  display: block;
  height: 100%;
  background: linear-gradient(90deg, var(--c-accent), color-mix(in srgb, var(--c-accent) 45%, #fff));
  transition: width 0.12s linear;
}
</style>
