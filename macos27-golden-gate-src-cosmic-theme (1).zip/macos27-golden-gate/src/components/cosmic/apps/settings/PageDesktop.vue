<script setup lang="ts">
/** 设置 · 桌面 —— 壁纸、图标、工作区 */
import { useCosmicStore } from '@/stores/cosmic'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'

const store = useCosmicStore()
const sys = useCosmicSystemStore()
const d = sys.desktop

const wallpapers = [
  { id: 'nebula', name: '星云', bg: 'linear-gradient(140deg, #2b1b4d, #6b3fa0 55%, #c76bd1)' },
  { id: 'ubuntu', name: 'Ubuntu 橙', bg: 'linear-gradient(140deg, #2b1020, #7a2547 55%, #e95420)' },
  { id: 'ocean', name: '深海', bg: 'linear-gradient(140deg, #08213d, #1c5c8a 55%, #4fb8c9)' },
  { id: 'forest', name: '森林', bg: 'linear-gradient(140deg, #0f2418, #2c6b45 55%, #8fd18c)' },
  { id: 'sunset', name: '落日', bg: 'linear-gradient(140deg, #3b1030, #a83a56 55%, #f2a65a)' },
  { id: 'mono', name: '石墨', bg: 'linear-gradient(140deg, #141416, #33333a 55%, #6b6b78)' }
]
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">桌面</h1>
    <p class="set-sub">壁纸、桌面图标与工作区</p>

    <div class="set-card">
      <div class="set-card-title">壁纸</div>
      <div class="set-row col">
        <div class="set-thumbs">
          <button
            v-for="w in wallpapers"
            :key="w.id"
            class="set-thumb"
            :class="{ active: d.wallpaper === w.id }"
            :style="{ background: w.bg }"
            @click="d.wallpaper = w.id"
          >
            <em>{{ w.name }}</em>
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>填充模式</b><span>壁纸如何适配屏幕比例</span></div>
        <div class="set-seg">
          <button v-for="f in ['填充', '适应', '拉伸', '平铺', '居中']" :key="f" :class="{ active: d.fill === f }" @click="d.fill = f">
            {{ f }}
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>壁纸暗化</b><span>{{ Math.round(store.settings.wallpaperDim * 100) }}%</span></div>
        <input v-model.number="store.settings.wallpaperDim" type="range" min="0" max="0.6" step="0.02" class="set-slider" />
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">桌面图标</div>
      <div class="set-row">
        <div class="set-label"><b>显示桌面图标</b><span>在主目录桌面上显示文件</span></div>
        <button class="set-switch" :class="{ on: d.showIcons }" @click="d.showIcons = !d.showIcons"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>图标大小</b><span>{{ d.iconSize }} px</span></div>
        <input v-model.number="d.iconSize" type="range" min="32" max="96" step="8" class="set-slider" />
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">工作区</div>
      <div class="set-row">
        <div class="set-label"><b>工作区数量</b><span>{{ d.workspaces }} 个</span></div>
        <div class="set-seg">
          <button v-for="n in [1, 2, 3, 4, 6, 8]" :key="n" :class="{ active: d.workspaces === n }" @click="d.workspaces = n">
            {{ n }}
          </button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>排列方向</b><span>COSMIC 默认垂直排列</span></div>
        <div class="set-seg">
          <button :class="{ active: d.workspaceLayout === 'vertical' }" @click="d.workspaceLayout = 'vertical'">垂直</button>
          <button :class="{ active: d.workspaceLayout === 'horizontal' }" @click="d.workspaceLayout = 'horizontal'">水平</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>热区触发</b><span>鼠标移到屏幕角落切换工作区</span></div>
        <button class="set-switch" :class="{ on: d.hotCorners }" @click="d.hotCorners = !d.hotCorners"><i /></button>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">时间显示</div>
      <div class="set-row">
        <div class="set-label"><b>时间格式</b><span>顶栏时钟显示方式</span></div>
        <div class="set-seg">
          <button :class="{ active: sys.time.format === '24h' }" @click="sys.time.format = '24h'">24 小时</button>
          <button :class="{ active: sys.time.format === '12h' }" @click="sys.time.format = '12h'">12 小时</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>显示秒数</b><span>时钟中是否包含秒</span></div>
        <button class="set-switch" :class="{ on: sys.time.showSeconds }" @click="sys.time.showSeconds = !sys.time.showSeconds"><i /></button>
      </div>
    </div>
  </div>
</template>
