<script setup lang="ts">
/** 设置 · 固件 */
import { ref } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const f = sys.firmware
const running = ref<string | null>(null)
const pct = ref(0)
let timer = 0

function update(name: string) {
  if (running.value) return
  running.value = name
  pct.value = 0
  window.clearInterval(timer)
  timer = window.setInterval(() => {
    pct.value += 10 + Math.random() * 12
    if (pct.value >= 100) {
      window.clearInterval(timer)
      const d = f.devices.find((x) => x.name === name)
      if (d) {
        d.current = d.latest
        d.update = false
      }
      running.value = null
      pct.value = 0
    }
  }, 120)
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">固件</h1>
    <p class="set-sub">由 fwupd 管理的设备固件更新</p>

    <div class="set-card">
      <div class="set-item" style="padding: 16px 0">
        <span class="set-ico" style="width: 52px; height: 52px; border-radius: 16px; background: var(--c-accent-soft)">
          <Icon name="ri-cpu-line" :size="26" />
        </span>
        <div class="set-item-text">
          <b style="font-size: 16px">{{ f.devices.filter((d) => d.update).length }} 个固件可更新</b>
          <span>fwupd 2.0.1 · LVFS 元数据已同步</span>
        </div>
        <div class="set-item-ctl">
          <button class="c-btn"><Icon name="ri-refresh-line" :size="15" /> 刷新元数据</button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">设备</div>
      <div v-for="d in f.devices" :key="d.name" class="set-item">
        <span class="set-ico"><Icon name="ri-hard-drive-3-line" :size="16" /></span>
        <div class="set-item-text">
          <b>{{ d.name }}</b>
          <span>{{ d.vendor }} · 当前 {{ d.current }}<template v-if="d.update"> → {{ d.latest }}</template></span>
        </div>
        <div class="set-item-ctl">
          <div v-if="running === d.name" style="display: flex; align-items: center; gap: 10px; width: 170px">
            <div class="set-progress" style="flex: 1"><i :style="{ width: pct + '%' }" /></div>
            <span class="set-badge" style="min-width: 44px; justify-content: center">{{ Math.round(pct) }}%</span>
          </div>
          <span v-else-if="d.update" class="set-badge on">可更新</span>
          <span v-else class="set-badge"><Icon name="ri-check-line" :size="12" /> 最新</span>
          <button v-if="d.update && running !== d.name" class="c-btn" style="height: 28px; font-size: 12px" @click="update(d.name)">
            更新
          </button>
        </div>
      </div>
    </div>

    <div class="set-note">
      <Icon name="ri-alert-line" :size="15" style="margin-top: 1px; flex: none" />
      <span>固件更新期间请保持电源接通，切勿断电或合盖。</span>
    </div>

    <div class="set-card">
      <div class="set-card-title">历史</div>
      <div class="set-kv"><span>NVMe SSD</span><b>2026-06-12 · 4B2QJXD7</b></div>
      <div class="set-kv"><span>UEFI 固件</span><b>2026-03-04 · 1.62</b></div>
      <div class="set-kv"><span>雷电控制器</span><b>2025-11-20 · 42.0</b></div>
    </div>
  </div>
</template>
