<script setup lang="ts">
/** 设置 · 窗口管理 —— 自动平铺、间隙、吸附、聚焦、按钮位置 */
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import Icon from '@/components/common/Icon.vue'

const sys = useCosmicSystemStore()
const w = sys.windows

const tiles: Record<string, { x: number; y: number; w: number; h: number }[]> = {
  grid: [
    { x: 0, y: 0, w: 50, h: 50 },
    { x: 50, y: 0, w: 50, h: 50 },
    { x: 0, y: 50, w: 100, h: 50 }
  ],
  rows: [
    { x: 0, y: 0, w: 100, h: 33 },
    { x: 0, y: 33, w: 100, h: 34 },
    { x: 0, y: 67, w: 100, h: 33 }
  ],
  columns: [
    { x: 0, y: 0, w: 33, h: 100 },
    { x: 33, y: 0, w: 34, h: 100 },
    { x: 67, y: 0, w: 33, h: 100 }
  ]
}
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">窗口管理</h1>
    <p class="set-sub">自动平铺、间隙与聚焦行为</p>

    <div class="set-card">
      <div class="set-card-title">自动平铺</div>
      <div class="set-row">
        <div class="set-label"><b>启用自动平铺</b><span>新窗口自动排入网格，不留空隙</span></div>
        <button class="set-switch" :class="{ on: w.autoTile }" @click="w.autoTile = !w.autoTile"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>平铺模式</b><span>网格 / 行 / 列</span></div>
        <div class="set-seg">
          <button :class="{ active: w.tileMode === 'grid' }" @click="w.tileMode = 'grid'">网格</button>
          <button :class="{ active: w.tileMode === 'rows' }" @click="w.tileMode = 'rows'">行</button>
          <button :class="{ active: w.tileMode === 'columns' }" @click="w.tileMode = 'columns'">列</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>窗口间隙</b><span>平铺窗口之间的留白</span></div>
        <div style="display: flex; align-items: center; gap: 10px; margin-left: auto">
          <input v-model.number="w.gaps" type="range" min="0" max="32" class="set-slider" />
          <span class="set-badge" style="min-width: 42px; justify-content: center">{{ w.gaps }}px</span>
        </div>
      </div>
      <div class="set-row col">
        <div class="set-label"><b>平铺预览</b><span>三种模式下的窗口排布</span></div>
        <div class="tile-preview">
          <span
            v-for="(t, i) in tiles[w.tileMode]"
            :key="i"
            :style="{
              left: t.x + '%',
              top: t.y + '%',
              width: t.w + '%',
              height: t.h + '%',
              padding: w.gaps / 4 + 'px'
            }"
          />
        </div>
      </div>
    </div>

    <div class="set-card">
      <div class="set-card-title">交互</div>
      <div class="set-row">
        <div class="set-label"><b>边缘吸附</b><span>拖到屏幕边缘自动贴合</span></div>
        <button class="set-switch" :class="{ on: w.snapping }" @click="w.snapping = !w.snapping"><i /></button>
      </div>
      <div class="set-row">
        <div class="set-label"><b>边缘阻力</b><span>{{ w.edgeResistance }} px</span></div>
        <input v-model.number="w.edgeResistance" type="range" min="0" max="80" step="5" class="set-slider" />
      </div>
      <div class="set-row">
        <div class="set-label"><b>聚焦方式</b><span>点击聚焦或跟随鼠标</span></div>
        <div class="set-seg">
          <button :class="{ active: !w.focusFollowsMouse }" @click="w.focusFollowsMouse = false">点击聚焦</button>
          <button :class="{ active: w.focusFollowsMouse }" @click="w.focusFollowsMouse = true">跟随鼠标</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>窗口按钮位置</b><span>最小化 / 最大化 / 关闭</span></div>
        <div class="set-seg">
          <button :class="{ active: w.buttonPosition === 'left' }" @click="w.buttonPosition = 'left'">左侧</button>
          <button :class="{ active: w.buttonPosition === 'right' }" @click="w.buttonPosition = 'right'">右侧</button>
        </div>
      </div>
      <div class="set-row">
        <div class="set-label"><b>平铺快捷键</b><span>方向键 + Super 排列窗口</span></div>
        <span class="c-kbd">Super + ← / → / ↑ / ↓</span>
      </div>
    </div>

    <div class="set-note">
      <Icon name="ri-information-line" :size="15" style="margin-top: 1px; flex: none" />
      <span>本演示中窗口为自由浮动模式；自动平铺为 COSMIC 的标志性能力，此处以配置项形式呈现。</span>
    </div>
  </div>
</template>

<style scoped>
.tile-preview {
  position: relative;
  width: 100%;
  height: 150px;
  border-radius: 11px;
  background: var(--c-surface-3);
  border: 1px solid var(--c-border);
  overflow: hidden;
}
.tile-preview span {
  position: absolute;
  box-sizing: border-box;
  background-clip: content-box;
}
.tile-preview span::after {
  content: '';
  display: block;
  width: 100%;
  height: 100%;
  border-radius: 8px;
  background: var(--c-accent-soft);
  border: 1px solid var(--c-accent);
}
</style>
