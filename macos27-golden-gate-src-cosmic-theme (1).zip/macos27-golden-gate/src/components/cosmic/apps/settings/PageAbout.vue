<script setup lang="ts">
/** 设置 · 关于 */
import { computed } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { cosmicApps } from '@/utils/cosmicApps'
import Icon from '@/components/common/Icon.vue'

const store = useCosmicStore()
const sys = useCosmicSystemStore()

const rows = computed(() => [
  { k: '设备名称', v: 'cosmic-pc' },
  { k: '操作系统', v: 'Pop!_OS 24.04 LTS (COSMIC Epoch)' },
  { k: '内核版本', v: '6.12.0-1018-generic' },
  { k: '桌面环境', v: 'COSMIC 1.0.0 (Wayland)' },
  { k: '窗口管理器', v: 'cosmic-comp (Rust / Smithay)' },
  { k: '处理器', v: 'AMD Ryzen 7 7840U · 8 核 16 线程' },
  { k: '图形', v: 'AMD Radeon 780M · Vulkan 1.3 (Mesa 24.2)' },
  { k: '内存', v: '4.8 GB / 16 GB' },
  { k: '磁盘', v: '512 GB NVMe · 已用 42%' },
  { k: '主机型号', v: 'ThinkPad X13 Gen 4' },
  { k: '序列号', v: 'PF3XK9Q2' },
  { k: '已安装应用', v: `${cosmicApps.length + 10} 个` },
  { k: '固件版本', v: 'UEFI 1.62' }
])
</script>

<template>
  <div class="set-wrap">
    <h1 class="set-h1">关于</h1>
    <p class="set-sub">系统与硬件信息</p>

    <div class="set-card">
      <div class="set-item" style="padding: 18px 0">
        <span class="set-ico" style="width: 58px; height: 58px; border-radius: 18px; background: linear-gradient(140deg, #7b5cf0, #a48bf5)">
          <Icon name="ri-planet-line" :size="30" color="#fff" />
        </span>
        <div class="set-item-text">
          <b style="font-size: 17px">COSMIC Web Epoch</b>
          <span>版本 1.0.0 (x86_64) · 基于 Rust / libcosmic 重绘</span>
          <span>运行于 macos27-golden-gate · Vue 3 + Vite + Tailwind v4</span>
        </div>
        <div class="set-item-ctl">
          <button class="c-btn c-btn--primary" @click="store.openApp('store')">
            <Icon name="ri-download-cloud-2-line" :size="15" /> 检查更新
          </button>
        </div>
      </div>
    </div>

    <div class="set-card">
      <div v-for="r in rows" :key="r.k" class="set-kv">
        <span>{{ r.k }}</span><b>{{ r.v }}</b>
      </div>
    </div>

    <div class="set-note">
      <Icon name="ri-information-line" :size="15" style="margin-top: 1px; flex: none" />
      <span>
        本设置面板为 COSMIC 桌面环境的网页复刻，主题色、深浅色、圆角、面板与 Dock 等改动会
        <b>实时作用于当前桌面</b>；其余系统项为交互演示。
      </span>
    </div>

    <div class="set-actions">
      <button class="c-btn" @click="store.openApp('store')">
        <Icon name="ri-refresh-line" :size="15" /> 打开软件商店
      </button>
      <button class="c-btn" @click="store.openApp('terminal')">
        <Icon name="ri-terminal-box-line" :size="15" /> 打开终端
      </button>
      <span class="c-tag" style="height: 34px; padding: 0 12px">
        <Icon name="ri-time-line" :size="13" /> 最近检查：{{ sys.updates.lastCheck }}
      </span>
    </div>
  </div>
</template>
