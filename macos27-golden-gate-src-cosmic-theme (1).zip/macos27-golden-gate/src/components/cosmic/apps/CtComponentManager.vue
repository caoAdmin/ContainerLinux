<script setup lang="ts">
/**
 * CtComponentManager —— 组件管理器（ct-plugins）的交互式实现
 *
 * 五分区合一（内容与规则取自《ContainerLinux 文档合集》）：
 *  · 内核管理 —— ctk-old/ctk-new 双档、更新通道、四格式打包（内核章 / 决策 D10）
 *  · 插件管理 —— .ko 内核态 + .cte 用户态双子分区、加载门禁、市场（第 48 章）
 *  · 原子管理 —— atom-*.so 成本画像、Resources 预算、显式 load/unload（决策 D20）
 *  · 发行版管理 —— 槽位换装、双运行模式、官方换装目录（发行版章）
 *  · 镜像包管理 —— 四类挂载包、冷热三态、evict 策略（Mounts 章）
 *
 * 实际交互逻辑：门禁/预算/策略都是真实开关，直接决定装载、安装、归档是否放行。
 * 复用 CtApp 的 ctToast / ctConfirm；视觉沿用 CtBlock 的 tone 令牌。
 */
import { computed, inject, onUnmounted, reactive, ref, watch } from 'vue'
import { ctApps } from '@/data/ct/ctApps'
import CtBlock from './CtBlock.vue'

type Priv = 'normal' | 'elevated' | 'privileged'
type Kind = 'ko' | 'cte'
type Section = 'overview' | 'kernel' | 'plugin' | 'atom' | 'distro' | 'image'
type Partition = 'system' | 'app'

const toast = inject<(m: string) => void>('ctToast', () => {})
const confirm = inject<(o: { title?: string; text?: string; confirmLabel?: string }) => Promise<boolean>>(
  'ctConfirm',
  async () => true
)

function now() {
  const d = new Date()
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`
}

const props = defineProps<{ /** 当前分区索引（与 CtApp 左侧页面导航联动） */ section?: number }>()

/* ═══════════════ 分区切换 ═══════════════ */
const section = ref<Section>('overview')
const SECTIONS: Array<{ k: Section; label: string; ic: string }> = [
  { k: 'overview', label: '总览', ic: '◎' },
  { k: 'kernel', label: '内核管理', ic: '⚙' },
  { k: 'plugin', label: '插件管理', ic: '▦' },
  { k: 'atom', label: '原子管理', ic: '◈' },
  { k: 'distro', label: '发行版管理', ic: '⇄' },
  { k: 'image', label: '镜像包管理', ic: '▣' }
]
/* 左侧页面导航 → 内部分区（分区切换唯一入口） */
watch(() => props.section, (idx) => {
  if (typeof idx === 'number' && SECTIONS[idx] && SECTIONS[idx].k !== section.value) {
    section.value = SECTIONS[idx].k
  }
}, { immediate: true })

/* ═══════════════ ① 内核管理 ═══════════════ */
const kernel = reactive({
  tier: 'ctk-new' as 'ctk-old' | 'ctk-new',
  channel: 'stable' as 'stable' | 'beta',
  version: '6.17.2-ct1',
  pending: '',
  updating: false,
  progress: 0,
  /* 调频与电源（分散版「调频与电源」页） */
  governor: 'schedutil' as 'performance' | 'schedutil' | 'powersave' | 'conservative' | 'ondemand',
  epp: 'balance_performance' as 'performance' | 'balance_performance' | 'balance_power' | 'power',
  freqMHz: 3120,
  tempC: 52,
  /* CT 专属内核配置块（分散版同名页） */
  kcfg: { ntsync: true, binder: true, relay: true, overdrive: false, saver: false, secureboot: true } as Record<string, boolean>,
  /* ESP 救援副本 */
  espCopy: '' as string
})
/* CPU 频率 / 核心温度：模拟实时监控（governor 越激进频率越高、温度越高） */
const GOV_BASE: Record<string, number> = { performance: 3600, schedutil: 3100, conservative: 2500, ondemand: 2700, powersave: 1800 }
let freqTimer = 0
onUnmounted(() => window.clearInterval(freqTimer))
watch(() => kernel.governor, () => { /* 切 governor 立即体现 */ })
function startFreqTick() {
  if (freqTimer) return
  freqTimer = window.setInterval(() => {
    const base = GOV_BASE[kernel.governor]
    kernel.freqMHz = Math.round(base + (Math.random() * 500 - 250))
    kernel.tempC = Math.round(38 + (base / 3600) * 26 + (Math.random() * 6 - 3))
  }, 1200)
}
startFreqTick()
const GOVS = ['performance', 'schedutil', 'conservative', 'ondemand', 'powersave'] as const
const EPPS = ['performance', 'balance_performance', 'balance_power', 'power'] as const
const KCFG: Array<{ k: string; label: string; desc: string }> = [
  { k: 'ntsync', label: 'NTSync', desc: 'Windows NT 同步原语 · 提升 Wine/Proton 线程同步性能' },
  { k: 'binder', label: 'binder_linux', desc: 'Android binder IPC · Waydroid 等容器必需' },
  { k: 'relay', label: 'ct-ko 中继器', desc: '/dev/containerlinux 中继 · .ko 插件通信底座' },
  { k: 'overdrive', label: 'ct_overdrive', desc: '激进超频档 · 需自担稳定性风险' },
  { k: 'saver', label: 'ct_ultra_saver', desc: '极致省电档 · 限制频率上限换续航' },
  { k: 'secureboot', label: 'Secure Boot 签名', desc: '内核 + 模块双签名 · 关闭后自编模块免签装载' }
]
function toggleKcfg(item: { k: string; label: string }) {
  const was = kernel.kcfg[item.k]
  kernel.kcfg[item.k] = !was
  toast(`${item.label} 已${was ? '停用' : '启用'}${item.k === 'secureboot' ? '，重启后生效' : '（运行时热切换）'}`)
}
async function makeEspCopy() {
  kernel.espCopy = '制作中'
  await new Promise<void>((res) => { setTimeout(res, 1600) })
  kernel.espCopy = `vmlinuz-${kernel.version}.backup`
  toast(`ESP 救援副本已写入：${kernel.espCopy}`)
}
async function switchTier(t: 'ctk-old' | 'ctk-new') {
  if (kernel.tier === t || kernel.updating) return
  const ok = await confirm({
    title: `切换到 ${t}？`,
    text: '双档内核共享 CachyOS base patchset；smart-tune 开机按 CPU 判档自动选择，本次切换重启后生效。',
    confirmLabel: '切换'
  })
  if (!ok) return
  kernel.tier = t
  toast(`内核档已切换为 ${t}，重启后生效`)
}
function checkUpdate() {
  if (kernel.updating) return
  const next = kernel.channel === 'stable' ? '6.17.3-ct1' : '6.18.0-rc1'
  if (next === kernel.version || next === kernel.pending) {
    toast(`已是 ${kernel.channel} 通道最新版本（${kernel.version}）`)
    return
  }
  kernel.pending = next
  toast(`${kernel.channel} 通道发现新内核：${next}`)
}
async function applyUpdate() {
  if (kernel.updating || !kernel.pending) return
  kernel.updating = true
  kernel.progress = 0
  await new Promise<void>((res) => {
    const t = window.setInterval(() => {
      kernel.progress = Math.min(100, kernel.progress + 7 + Math.random() * 14)
      if (kernel.progress >= 100) { window.clearInterval(t); res() }
    }, 85)
  })
  kernel.version = kernel.pending
  kernel.pending = ''
  kernel.updating = false
  toast(`内核原子更新完成：${kernel.version}（L0 层随内核原子更新 · 重启后生效）`)
}
const KERNEL_FORMATS = [
  { name: '.deb', desc: 'Ubuntu / Debian', badge: '一级', tone: 'tone-amber' },
  { name: '.rpm', desc: 'Fedora / openSUSE', badge: '二级', tone: 'tone-blue' },
  { name: 'pacman', desc: 'arch 系 / CachyOS', badge: '一级', tone: 'tone-green' },
  { name: 'tar.xz', desc: '通用分发（+ headers）', badge: 'DKMS', tone: 'tone-violet' }
]

/* ═══════════════ ② 插件管理（第 48 章，保持完整交互） ═══════════════ */
interface Plugin {
  id: string
  name: string
  kind: Kind
  version: string
  desc: string
  privilege: Priv
  signed: boolean
  network: boolean
  fs: 'readonly' | 'none'
  abi: number
  bundled: boolean
  active: boolean
  progress: number
  installing: boolean
  err: string
}

/* 加载门禁（48.10 / 48.11）：真实生效的开关 */
const gates = reactive({ manifest: true, signature: true, sandbox: true, privilege: false })
const gatePass = computed(() => Object.values(gates).filter(Boolean).length)

const systemPlugins = ref<Plugin[]>([
  { id: 'rdbus-relay', name: 'rdbus-relay.ko', kind: 'ko', version: '2.4.1', desc: 'RDBus 总线中继 —— 用户态服务与合成器间的结构化消息通道', privilege: 'privileged', signed: true, network: false, fs: 'none', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'ctf-bind', name: 'ctf-bind.ko', kind: 'ko', version: '1.7.0', desc: 'CTF 命名空间 bind 聚合（ESP + ct-data → 统一 /CTF 视图）', privilege: 'privileged', signed: true, network: false, fs: 'none', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'glass-compositor', name: 'glass-compositor.ko', kind: 'ko', version: '3.1.2', desc: '液态玻璃合成加速 —— 位移折射管线的 GPU 提交路径', privilege: 'elevated', signed: true, network: false, fs: 'none', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'vsync-warp', name: 'vsync-warp.ko', kind: 'ko', version: '1.3.0', desc: '垂直同步补偿 —— 低帧档位下的合成器节拍稳定器', privilege: 'normal', signed: true, network: false, fs: 'none', abi: 1, bundled: true, active: false, progress: 0, installing: false, err: '' },
  { id: 'slot-loader', name: 'slot-loader.ko', kind: 'ko', version: '2.0.0', desc: '发行版槽位探测装载（L0–L2 运行器阶梯解锁）', privilege: 'privileged', signed: true, network: false, fs: 'none', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' }
])
const appPlugins = ref<Plugin[]>([
  { id: 'ai-assistant', name: 'ai-assistant.cte', kind: 'cte', version: '4.2.0', desc: 'AI 助手入口（CTclaw 唤醒链的 .cte 桌面扩展）', privilege: 'normal', signed: true, network: false, fs: 'readonly', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'top-bar', name: 'top-bar.cte', kind: 'cte', version: '4.2.0', desc: '顶部面板 —— AppBar / 信息岛宿主', privilege: 'normal', signed: true, network: false, fs: 'readonly', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'dock', name: 'dock.cte', kind: 'cte', version: '4.2.0', desc: 'Dock 栏 —— 应用网格与唤醒态缩放', privilege: 'normal', signed: true, network: false, fs: 'readonly', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'notification-center', name: 'notification-center.cte', kind: 'cte', version: '3.8.1', desc: '通知中心 —— 通知条 / 信息岛归档', privilege: 'normal', signed: true, network: false, fs: 'readonly', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'quick-settings', name: 'quick-settings.cte', kind: 'cte', version: '3.8.1', desc: '控制中心 —— 快捷开关与玻璃档位面板', privilege: 'normal', signed: true, network: false, fs: 'readonly', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'tuck-pane', name: 'tuck-pane.cte', kind: 'cte', version: '2.1.0', desc: 'D24 中转站 —— 拖拽转移链的暂存面板', privilege: 'normal', signed: true, network: false, fs: 'readonly', abi: 1, bundled: true, active: false, progress: 0, installing: false, err: '' },
  { id: 'weather-widget', name: 'weather-widget.cte', kind: 'cte', version: '1.9.3', desc: '天气挂件（需网络：沙箱 network=true 例外名单）', privilege: 'normal', signed: true, network: true, fs: 'readonly', abi: 1, bundled: true, active: false, progress: 0, installing: false, err: '' },
  { id: 'ct-wallpaper-liquid', name: 'ct-wallpaper-liquid.cte', kind: 'cte', version: '1.2.0', desc: '壁纸与液态玻璃效果（manifest 示例同款）', privilege: 'elevated', signed: true, network: false, fs: 'readonly', abi: 1, bundled: true, active: true, progress: 0, installing: false, err: '' },
  { id: 'software-center', name: 'software-center.cte', kind: 'cte', version: '2.5.0', desc: '软件中心 —— 应用挂载包与魔改技能上架', privilege: 'normal', signed: true, network: true, fs: 'readonly', abi: 1, bundled: false, active: true, progress: 0, installing: false, err: '' },
  { id: 'sysmon', name: 'sysmon.cte', kind: 'cte', version: '1.4.2', desc: '系统监控 —— 原子 / 蜂群 / 内存预算可视化', privilege: 'normal', signed: true, network: false, fs: 'readonly', abi: 1, bundled: false, active: false, progress: 0, installing: false, err: '' }
])

interface MarketItem {
  id: string; name: string; version: string; desc: string
  privilege: Priv; signed: boolean; abi: number; note?: string
}
const market = ref<MarketItem[]>([
  { id: 'python-example', name: 'python-example.cte', version: '0.9.1', desc: 'Python 示例插件 —— Host API 最小调用样例', privilege: 'normal', signed: true, abi: 1 },
  { id: 'net-meter', name: 'net-meter.cte', version: '1.1.0', desc: '网络流量表 —— 需沙箱放行 network', privilege: 'elevated', signed: true, abi: 1 },
  { id: 'dsh-port-skill', name: 'dsh-port-skill.cte', version: '0.3.0', desc: '魔改移植版 DSH 技能（须带原作者 license + 修改声明）', privilege: 'privileged', signed: false, abi: 1, note: '未附 CT 签名链签名' },
  { id: 'legacy-theme', name: 'legacy-theme.cte', version: '0.8.0', desc: '旧版主题包 —— 按 ABI v0 打包', privilege: 'normal', signed: true, abi: 0, note: 'ABI 版本低于冻结版本' }
])

const pTab = ref<Partition>('system')
const pluginList = computed(() => (pTab.value === 'system' ? systemPlugins.value : appPlugins.value))
const rejected = ref<Array<{ name: string; reason: string; time: string }>>([])

function manifestOf(p: Plugin): string {
  const kindLine = p.kind === 'ko'
    ? `[kernel]\nkind = "ko"\ndescriptor = ".ctb.desc"\nrelay = "/dev/containerlinux"`
    : `[plugin]\nkind = "cte"`
  return [
    kindLine,
    `name = "${p.name.replace(/\.(cte|ko)$/, '')}"`,
    `version = "${p.version}"`,
    `privilege = "${p.privilege}"    # normal | elevated | privileged`,
    ``,
    `[sandbox]`,
    `profile = "bwrap-ct-default"`,
    `network = ${p.network}`,
    `filesystem = "${p.fs}"`,
    ``,
    `[abi]`,
    `version = ${p.abi}             # 跨语言 ABI 冻结`,
    ``,
    `[trust]`,
    `signed = ${p.signed}           # CT 签名链 v2`
  ].join('\n')
}
const expanded = ref('')
function toggleDetail(id: string) {
  expanded.value = expanded.value === id ? '' : id
}

const privLabel: Record<Priv, string> = { normal: 'normal', elevated: 'elevated', privileged: 'privileged' }
function privTone(p: Priv): string {
  return p === 'privileged' ? 'tone-red' : p === 'elevated' ? 'tone-amber' : 'tone-green'
}

const granted = ref<Set<string>>(new Set())
async function toggleActive(p: Plugin) {
  if (p.installing) return
  if (p.active) {
    if (p.kind === 'ko') {
      const ok = await confirm({
        title: `卸载 ${p.name}？`,
        text: '内核态插件卸载与原子热更新是两套机制：本次保持驻留，重启后生效。',
        confirmLabel: '卸载'
      })
      if (!ok) return
      p.active = false
      toast(`${p.name} 卸载已调度，重启后生效`)
      return
    }
    p.active = false
    toast(`${p.name} 已停用（进程退出，资源释放）`)
    return
  }
  if (!p.signed && gates.signature) {
    p.err = '签名链校验未通过（未签名插件拒绝装载）'
    rejected.value.unshift({ name: p.name, reason: '未签名 · 48.10', time: now() })
    toast(`${p.name} 被门禁拒绝：未签名`)
    return
  }
  if (p.privilege !== 'normal' && !gates.privilege && !granted.value.has(p.id)) {
    const ok = await confirm({
      title: 'privilege 升级授权',
      text: `${p.name} 需要 ${privLabel[p.privilege]} 权限。按 48.10 规范，elevated / privileged 需用户显式授权。`,
      confirmLabel: '授权并装载'
    })
    if (!ok) {
      rejected.value.unshift({ name: p.name, reason: `privilege ${privLabel[p.privilege]} 未授权`, time: now() })
      toast('已取消：未授予 privilege 升级')
      return
    }
    granted.value.add(p.id)
  }
  p.installing = true
  p.progress = 0
  const timer = window.setInterval(() => {
    p.progress = Math.min(100, p.progress + 8 + Math.random() * 18)
    if (p.progress >= 100) {
      window.clearInterval(timer)
      p.installing = false
      p.active = true
      p.err = ''
      toast(`${p.name} ${p.kind === 'ko' ? '装载完成' : '已启用'}（bwrap 沙箱 · privilege ${privLabel[p.privilege]}）`)
    }
  }, 90)
}

async function uninstall(p: Plugin) {
  if (p.installing || p.active) return
  const ok = await confirm({
    title: `卸载 ${p.name}？`,
    text: `将移除插件目录包并回收沙箱配额（${p.bundled ? '随系统分发，可随时从市场重装' : '第三方插件'}）。`,
    confirmLabel: '卸载'
  })
  if (!ok) return
  if (p.kind === 'ko') systemPlugins.value = systemPlugins.value.filter((x) => x.id !== p.id)
  else appPlugins.value = appPlugins.value.filter((x) => x.id !== p.id)
  toast(`${p.name} 已卸载`)
}

const marketOpen = ref(false)
const installingId = ref('')
const installStep = ref('')
const installPct = ref(0)
async function installItem(m: MarketItem) {
  if (installingId.value) return
  const steps: Array<[string, () => string | null]> = [
    ['manifest 校验', () => {
      if (!gates.manifest) return null
      return m.abi >= 1 ? null : `ABI v${m.abi} 低于冻结版本（48.6 跨语言 ABI 冻结）`
    }],
    ['签名链校验', () => {
      if (!gates.signature) return null
      return m.signed ? null : '未附 CT 签名链签名（48.10：未签名插件拒绝装载）'
    }],
    ['bwrap 沙箱预检', () => (gates.sandbox ? null : null)],
    ['privilege 授权', () => {
      if (m.privilege === 'normal' || gates.privilege) return null
      return `需要 ${privLabel[m.privilege]} 权限，未开启 privilege 升级授权（48.10）`
    }]
  ]
  installingId.value = m.id
  for (const [label, check] of steps) {
    installStep.value = label
    installPct.value = 0
    const ok = check()
    await new Promise<void>((res) => {
      const t = window.setInterval(() => {
        installPct.value = Math.min(100, installPct.value + 16 + Math.random() * 12)
        if (installPct.value >= 100) { window.clearInterval(t); res() }
      }, 55)
    })
    if (ok) {
      rejected.value.unshift({ name: m.name, reason: ok, time: now() })
      toast(`${m.name} 被门禁拒绝：${ok}`)
      installingId.value = ''
      return
    }
  }
  appPlugins.value.push({
    id: m.id, name: m.name, kind: 'cte', version: m.version, desc: m.desc,
    privilege: m.privilege, signed: m.signed, network: false, fs: 'readonly', abi: m.abi,
    bundled: false, active: false, progress: 0, installing: false, err: ''
  })
  installingId.value = ''
  marketOpen.value = false
  toast(`${m.name} 安装完成，待启用`)
  pTab.value = 'app'
}

/* ═══════════════ ③ 原子管理（决策 D20） ═══════════════ */
interface Atom {
  id: string
  name: string
  desc: string
  /** 成本画像：内存 MB / GPU % / fd / 线程 */
  mem: number
  gpu: number
  fd: number
  thr: number
  loaded: boolean
  swapping: boolean
  progress: number
}
const atoms = ref<Atom[]>([
  { id: 'glass-liquid', name: 'atom-glass-liquid.so', desc: '液态玻璃折射管线（位移采样 / 高光通道）', mem: 48, gpu: 12, fd: 8, thr: 4, loaded: true, swapping: false, progress: 0 },
  { id: 'ctf-bind', name: 'atom-ctf-bind.so', desc: 'CTF 命名空间 bind 聚合视图', mem: 12, gpu: 0, fd: 3, thr: 1, loaded: true, swapping: false, progress: 0 },
  { id: 'netd-qos', name: 'atom-netd-qos.so', desc: 'netd 服务质量分级（p2p / vpn 共用底座）', mem: 16, gpu: 0, fd: 6, thr: 2, loaded: true, swapping: false, progress: 0 },
  { id: 'fluent-i18n', name: 'atom-fluent-i18n.so', desc: 'Fluent 国际化资源装载器（48.13）', mem: 22, gpu: 0, fd: 2, thr: 1, loaded: false, swapping: false, progress: 0 },
  { id: 'p2p-mesh', name: 'atom-p2p-mesh.so', desc: 'P2P 组网发现与 NAT 打洞', mem: 30, gpu: 0, fd: 10, thr: 3, loaded: false, swapping: false, progress: 0 },
  { id: 'bench-mark', name: 'atom-bench-mark.so', desc: '基准测试套件（bench → ct-data 归档）', mem: 26, gpu: 4, fd: 4, thr: 2, loaded: false, swapping: false, progress: 0 }
])
/** Resources 管家预算（ct-core：约 150 行 [EST]，HashMap + 预算 + LRU） */
const BUDGET = { mem: 128, fd: 40, thr: 16 }
const usedMem = computed(() => atoms.value.filter((a) => a.loaded).reduce((s, a) => s + a.mem, 0))
const usedFd = computed(() => atoms.value.filter((a) => a.loaded).reduce((s, a) => s + a.fd, 0))
const usedThr = computed(() => atoms.value.filter((a) => a.loaded).reduce((s, a) => s + a.thr, 0))
const memPct = computed(() => Math.min(100, Math.round((usedMem.value / BUDGET.mem) * 100)))
const atomLoaded = computed(() => atoms.value.filter((a) => a.loaded).length)

function toggleAtom(a: Atom) {
  if (a.swapping) return
  if (a.loaded) {
    a.loaded = false
    toast(`${a.name} 已 unload，预算回收（内存 -${a.mem}MB / fd -${a.fd}）`)
    return
  }
  // Resources 管家：装载前做预算校验，超预算拒绝（D20 显式 load）
  if (usedMem.value + a.mem > BUDGET.mem) {
    rejected.value.unshift({ name: a.name, reason: `Resources 拒绝：内存预算不足（需 ${a.mem}MB，余 ${BUDGET.mem - usedMem.value}MB）· D20`, time: now() })
    toast(`${a.name} 被 Resources 拒绝：内存预算不足`)
    return
  }
  if (usedFd.value + a.fd > BUDGET.fd) {
    rejected.value.unshift({ name: a.name, reason: 'Resources 拒绝：fd 预算不足 · D20', time: now() })
    toast(`${a.name} 被 Resources 拒绝：fd 预算不足`)
    return
  }
  a.swapping = true
  a.progress = 0
  const t = window.setInterval(() => {
    a.progress = Math.min(100, a.progress + 12 + Math.random() * 16)
    if (a.progress >= 100) {
      window.clearInterval(t)
      a.swapping = false
      a.loaded = true
      toast(`${a.name} 已 load（成本画像：${a.mem}MB · GPU ${a.gpu}% · fd ${a.fd} · 线程 ${a.thr}）`)
    }
  }, 80)
}
async function hotSwap(a: Atom) {
  if (!a.loaded || a.swapping) return
  const ok = await confirm({
    title: `热更新 ${a.name}？`,
    text: '原子热更新与内核插件卸载是两套机制：AtomRegistry 单例由 rsystemd-pid1 持有，热替换原子性由 48.5 保证。',
    confirmLabel: '热更新'
  })
  if (!ok) return
  a.swapping = true
  a.progress = 0
  const t = window.setInterval(() => {
    a.progress = Math.min(100, a.progress + 14 + Math.random() * 18)
    if (a.progress >= 100) {
      window.clearInterval(t)
      a.swapping = false
      toast(`${a.name} 热更新完成（无断流替换 · 成本画像不变）`)
    }
  }, 80)
}

/* ═══════════════ ④ 发行版管理（槽位换装） ═══════════════ */
interface Slot {
  id: string
  name: string
  ver: string
  state: 'active' | 'ready' | 'empty'
  progress: number
  installing: boolean
}
const slots = ref<Slot[]>([
  { id: 'slot0', name: 'Ubuntu', ver: '26.04 LTS', state: 'active', progress: 0, installing: false },
  { id: 'slot1', name: '（空槽位）', ver: '', state: 'empty', progress: 0, installing: false }
])
const runMode = ref<'distro' | 'zero'>('distro')
const distroBusy = computed(() => slots.value.some((s) => s.installing))
async function switchMode() {
  if (distroBusy.value) return
  const toZero = runMode.value === 'distro'
  const ok = await confirm({
    title: toZero ? '切换到零发行版模式？' : '切换回有发行版模式？',
    text: toZero
      ? '零发行版模式 = 不装发行版用户态，.cte 静态加载路径（ct-run 沙箱通道）成为第三方插件唯一入口。两模式随时可切换。'
      : '恢复发行版用户态承载（需至少一个已安装槽位）。',
    confirmLabel: '切换'
  })
  if (!ok) return
  runMode.value = toZero ? 'zero' : 'distro'
  toast(toZero ? '已切换到零发行版模式（CT 层不动）' : '已切换回有发行版模式')
}
const CATALOG = [
  { name: 'Fedora 43', desc: '官方换装目录 · rpm 系' },
  { name: 'Arch Linux', desc: 'CachyOS 底 · pacman 系' },
  { name: 'Debian 13', desc: '官方换装目录 · deb 系' },
  { name: 'Kali 场景镜像', desc: 'DML 动态挂载 · 非槽位发行版' }
]
const installingCat = ref('')
async function installDistro(c: (typeof CATALOG)[number]) {
  if (installingCat.value || distroBusy.value) return
  const empty = slots.value.find((s) => s.state === 'empty')
  if (!empty) {
    toast('没有空槽位：先卸载一个非活动发行版')
    return
  }
  if (runMode.value === 'zero') {
    toast('零发行版模式下不装载用户态：先切回有发行版模式')
    return
  }
  installingCat.value = c.name
  empty.installing = true
  empty.name = c.name
  empty.ver = c.name.includes('Kali') ? '2026.09' : 'latest'
  await new Promise<void>((res) => {
    const t = window.setInterval(() => {
      empty.progress = Math.min(100, empty.progress + 4 + Math.random() * 8)
      if (empty.progress >= 100) { window.clearInterval(t); res() }
    }, 110)
  })
  empty.installing = false
  empty.state = 'ready'
  installingCat.value = ''
  toast(`${c.name} 装入 ${empty.id}（换租客不搬家：ct-data 与 CT 层不动）`)
}
async function activateSlot(s: Slot) {
  if (s.state !== 'ready' || s.installing || distroBusy.value) return
  const ok = await confirm({
    title: `切换活动发行版到 ${s.name}？`,
    text: 'CT-Kernel 底座与 /CTF 不动，仅换装用户态；slot-loader 探测装载（L0–L2 运行器阶梯解锁）。',
    confirmLabel: '切换'
  })
  if (!ok) return
  s.installing = true
  await new Promise<void>((res) => {
    const t = window.setInterval(() => {
      s.progress = Math.min(100, s.progress + 10 + Math.random() * 14)
      if (s.progress >= 100) { window.clearInterval(t); res() }
    }, 85)
  })
  s.installing = false
  slots.value.forEach((x) => { if (x.state === 'active') x.state = 'ready' })
  s.state = 'active'
  toast(`活动发行版已切换：${s.name} ${s.ver}`)
}
async function removeSlot(s: Slot) {
  if (s.state === 'empty' || s.installing || distroBusy.value) return
  if (s.state === 'active') {
    toast('活动发行版不能卸载：先切换到其他槽位')
    return
  }
  const ok = await confirm({
    title: `卸载 ${s.name}？`,
    text: '卸载耗时 <5 分钟，CT 层改动为 0；槽位恢复为空，可随时重装。',
    confirmLabel: '卸载'
  })
  if (!ok) return
  s.state = 'empty'
  s.name = '（空槽位）'
  s.ver = ''
  s.progress = 0
  toast(`${s.id} 已卸载（<5 分钟 · CT 层改动 0）`)
}

/* ═══════════════ ⑤ 镜像包管理（Mounts） ═══════════════ */
type PackType = 'resource' | 'application' | 'driver' | 'scenario'
interface Pack {
  id: string
  name: string
  type: PackType
  size: string
  mounted: boolean
  archived: boolean
  /** 挂载后空闲秒数（evict_idle 计时） */
  idle: number
  progress: number
  working: boolean
}
const packs = ref<Pack[]>([
  { id: 'icons', name: 'ct-icons-liquid.pack', type: 'resource', size: '412MB', mounted: true, archived: false, idle: 0, progress: 0, working: false },
  { id: 'gimp', name: 'ct-gimp-suite.pack', type: 'application', size: '1.2GB', mounted: false, archived: true, idle: 0, progress: 0, working: false },
  { id: 'gpu', name: 'ct-gpu-driver-617.pack', type: 'driver', size: '286MB', mounted: true, archived: false, idle: 0, progress: 0, working: false },
  { id: 'kali', name: 'ct-kali-scenario.pack', type: 'scenario', size: '3.4GB', mounted: false, archived: false, idle: 0, progress: 0, working: false }
])
const TYPE_LABEL: Record<PackType, string> = { resource: '资源包', application: '应用包', driver: '驱动包', scenario: '场景包' }
const TYPE_TONE: Record<PackType, string> = { resource: 'tone-blue', application: 'tone-green', driver: 'tone-violet', scenario: 'tone-amber' }
/** evict 策略（Mounts 管理器：约 200 行 [EST]，与 Resources 对称） */
const evict = reactive({ idle: true, pressure: true })
const IDLE_TIMEOUT = 20
let evictTimer = 0
function startEvictTimer() {
  window.clearInterval(evictTimer)
  evictTimer = window.setInterval(() => {
    for (const p of packs.value) {
      if (p.mounted && !p.working) {
        p.idle++
        if (evict.idle && p.idle >= IDLE_TIMEOUT) {
          p.mounted = false
          p.archived = true
          p.idle = 0
          toast(`evict_idle：${p.name} 空闲超时已自动归档（演示阈值 ${IDLE_TIMEOUT}s）`)
        }
      }
    }
  }, 1000)
}
startEvictTimer()
onUnmounted(() => window.clearInterval(evictTimer))

async function mountPack(p: Pack) {
  if (p.working) return
  p.working = true
  p.progress = 0
  if (p.archived) toast(`${p.name} 解档中（从 Images/ 冷存储恢复）`)
  await new Promise<void>((res) => {
    const t = window.setInterval(() => {
      p.progress = Math.min(100, p.progress + 10 + Math.random() * 16)
      if (p.progress >= 100) { window.clearInterval(t); res() }
    }, 75)
  })
  p.working = false
  p.archived = false
  p.mounted = true
  p.idle = 0
  toast(`${p.name} 已挂载（只读 EROFS · 签名校验后置 · ${TYPE_LABEL[p.type]}）`)
}
function unmountPack(p: Pack) {
  if (p.working || !p.mounted) return
  p.mounted = false
  p.idle = 0
  toast(`${p.name} 已卸载（umount · 回收挂载点）`)
}
async function archivePack(p: Pack) {
  if (p.working || p.mounted) return
  p.working = true
  p.progress = 0
  await new Promise<void>((res) => {
    const t = window.setInterval(() => {
      p.progress = Math.min(100, p.progress + 14 + Math.random() * 18)
      if (p.progress >= 100) { window.clearInterval(t); res() }
    }, 70)
  })
  p.working = false
  p.archived = true
  toast(`${p.name} 已归档到 /CTF/Images（透明压缩 · 空间释放）`)
}
function packState(p: Pack): { label: string; tone: string } {
  if (p.working) return { label: '处理中', tone: 'tone-cyan' }
  if (p.mounted) return { label: `挂载中 · 空闲 ${p.idle}s`, tone: 'tone-green' }
  if (p.archived) return { label: '已归档（冷）', tone: 'tone-neutral' }
  return { label: '已卸载（温）', tone: 'tone-amber' }
}

/* ═══════════════ 全局 KPI ═══════════════ */
const kpiKo = computed(() => systemPlugins.value.filter((p) => p.active).length)
const kpiCte = computed(() => appPlugins.value.filter((p) => p.active).length)

/* ═══════════════ 深资料（分散版应用 blocks 复用） ═══════════════
   集成版保留全部交互；分散版数据页的概念/矩阵/路线等纯文档内容
   以折叠面板形式跟在每个分区尾部，信息不丢失。 */
function docBlocks(appId: string) {
  const app = ctApps.find((a) => a.id === appId)
  return app ? app.pages.flatMap((p) => p.blocks) : []
}
const docsKernel = computed(() => docBlocks('ct-kernel'))
const docsAtom = computed(() => docBlocks('ct-atoms'))
const docsDistro = computed(() => docBlocks('ct-distro'))
const docsImage = computed(() => docBlocks('ct-mounts'))

/* 镜像包：热 / 温 / 冷三态分布（分散版「当前分布」页） */
const triStats = computed(() => ({
  hot: packs.value.filter((p) => p.mounted && !p.archived).length,
  warm: packs.value.filter((p) => !p.mounted && !p.archived).length,
  cold: packs.value.filter((p) => p.archived).length
}))
</script>

<template>
  <section class="cpm">
    <!-- ═══════ ⓪ 总览 ═══════ -->
    <template v-if="section === 'overview'">
      <div class="sec-hd"><b>组件总览</b><em>内核 / 插件 / 原子 / 发行版 / 镜像包 · 五类组件实时状态一目了然</em></div>
      <div class="cpm-kpis">
        <div class="kpi tone-amber"><span class="kpi-v">{{ kernel.tier }}</span><span class="kpi-l">内核档 · {{ kernel.version }}</span></div>
        <div class="kpi tone-blue"><span class="kpi-v">{{ kpiKo + kpiCte }}</span><span class="kpi-l">插件已激活（.ko {{ kpiKo }} + .cte {{ kpiCte }}）</span></div>
        <div class="kpi tone-violet"><span class="kpi-v">{{ atomLoaded }}/{{ atoms.length }}</span><span class="kpi-l">原子已 load（内存 {{ usedMem }}/{{ BUDGET.mem }}MB）</span></div>
        <div class="kpi tone-teal"><span class="kpi-v">{{ slots.find((s) => s.state === 'active')?.name || '零发行版' }}</span><span class="kpi-l">活动发行版 · {{ runMode === 'distro' ? '有发行版模式' : '零发行版模式' }}</span></div>
        <div class="kpi tone-green"><span class="kpi-v">{{ gatePass }}/4</span><span class="kpi-l">插件加载门禁在岗</span></div>
        <div class="kpi" :class="rejected.length ? 'tone-red' : 'tone-good'"><span class="kpi-v">{{ rejected.length }}</span><span class="kpi-l">拒绝记录</span></div>
      </div>
    </template>

    <!-- 分区切换只走左侧页面导航（与 M3AppShell 联动），不再重复一排 tab -->

    <!-- ═══════ ① 内核管理 ═══════ -->
    <template v-else-if="section === 'kernel'">
      <div class="sec-hd"><b>CT-Kernel 通用内核</b><em>「通用」= 同一份内核托起任意发行版用户态 · 基于 CachyOS</em></div>
      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>运行档与通道</b><em>smart-tune 开机按 CPU 判档自动选择</em></div>
        <div class="krn-rows">
          <div class="krn-row">
            <span class="krn-l">内核档位</span>
            <div class="seg-row seg-mini">
              <button class="seg" :class="{ on: kernel.tier === 'ctk-old' }" @click="switchTier('ctk-old')">ctk-old（x86-64 v1）</button>
              <button class="seg" :class="{ on: kernel.tier === 'ctk-new' }" @click="switchTier('ctk-new')">ctk-new（v3/v4/znver4）</button>
            </div>
          </div>
          <div class="krn-row">
            <span class="krn-l">更新通道</span>
            <div class="seg-row seg-mini">
              <button class="seg" :class="{ on: kernel.channel === 'stable' }" @click="kernel.channel = 'stable'; kernel.pending = ''">stable</button>
              <button class="seg" :class="{ on: kernel.channel === 'beta' }" @click="kernel.channel = 'beta'; kernel.pending = ''">beta</button>
            </div>
          </div>
          <div class="krn-row">
            <span class="krn-l">当前版本</span>
            <b class="krn-v">{{ kernel.version }}</b>
            <template v-if="kernel.pending">
              <span class="plug-badge tone-cyan">可用更新 {{ kernel.pending }}</span>
              <button class="krn-upd" :disabled="kernel.updating" @click="applyUpdate">
                {{ kernel.updating ? '更新中…' : '原子更新' }}
              </button>
            </template>
            <button v-else class="krn-upd" :disabled="kernel.updating" @click="checkUpdate">检查更新</button>
          </div>
          <div v-if="kernel.updating" class="krn-progress">
            <span>L0 层原子更新 · LLVM ThinLTO 构建</span>
            <span class="plug-track"><i :style="{ width: kernel.progress + '%' }" /></span>
            <b>{{ Math.round(kernel.progress) }}%</b>
          </div>
        </div>
      </div>
      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>四格式打包矩阵</b><em>同一内核 · 四种发行格式 · 随 CT Runtime 分发</em></div>
        <div class="krn-formats">
          <div v-for="f in KERNEL_FORMATS" :key="f.name" class="kf" :class="f.tone">
            <b>{{ f.name }}</b>
            <em>{{ f.desc }}</em>
            <span class="plug-badge" :class="f.tone">{{ f.badge }}</span>
          </div>
        </div>
      </div>
      <div class="cpm-note-line">ctk-old = x86-64 v1 基线档（覆盖老硬件）；ctk-new = LLVM ThinLTO · BORE/EEVDF · BBR3 · MGLRU · sched-ext</div>

      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>调频与电源</b><em>governor 运行时切换 · EPP 能量偏好 · 实时频率/温度监控</em></div>
        <div class="krn-rows">
          <div class="krn-row">
            <span class="krn-l">governor</span>
            <div class="seg-row seg-mini">
              <button v-for="g in GOVS" :key="g" class="seg" :class="{ on: kernel.governor === g }" @click="kernel.governor = g">{{ g }}</button>
            </div>
          </div>
          <div class="krn-row">
            <span class="krn-l">EPP hint</span>
            <div class="seg-row seg-mini">
              <button v-for="e in EPPS" :key="e" class="seg" :class="{ on: kernel.epp === e }" @click="kernel.epp = e">{{ e }}</button>
            </div>
          </div>
          <div class="krn-row">
            <span class="krn-l">CPU 频率</span>
            <b class="krn-live">{{ kernel.freqMHz }} MHz <em class="krn-temp" :class="{ hot: kernel.tempC >= 70 }">{{ kernel.tempC }}°C</em></b>
          </div>
        </div>
      </div>

      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>CT 专属内核配置块</b><em>除 governor 外全量编入 · 运行时热切换，Secure Boot 重启生效</em></div>
        <div class="cpm-gates-grid">
          <button v-for="c in KCFG" :key="c.k" class="tog" :class="{ off: !kernel.kcfg[c.k] }" @click="toggleKcfg(c)">
            <span class="tog-txt"><b class="tog-l">{{ c.label }}</b><em class="tog-d">{{ c.desc }}</em></span>
            <span class="tog-sw"><i /></span>
          </button>
        </div>
      </div>

      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>ESP 救援副本</b><em>可启动内核备份写入 EFI 系统分区 · 双档各留一份</em></div>
        <div class="krn-rows">
          <div class="krn-row">
            <span class="krn-l">副本状态</span>
            <b class="krn-live">{{ kernel.espCopy || '未创建' }}</b>
            <button class="kf-btn" :disabled="kernel.espCopy === '制作中'" @click="makeEspCopy">{{ kernel.espCopy === '制作中' ? '写入中…' : '创建救援副本' }}</button>
          </div>
        </div>
      </div>

      <!-- 深资料：内核管理分散版数据页（NTSync / binder / 中继器 / 调频细节 / 双档对照等） -->
      <details class="cpm-docs">
        <summary>深资料 · 内核管理文档页（{{ docsKernel.length }} 节）</summary>
        <div class="cpm-docs-body"><CtBlock v-for="(b, i) in docsKernel" :key="i" :block="b" /></div>
      </details>
    </template>

    <!-- ═══════ ② 插件管理 ═══════ -->
    <template v-else-if="section === 'plugin'">
      <div class="cpm-toolbar">
        <div class="seg-row seg-mini" role="tablist">
          <button class="seg" :class="{ on: pTab === 'system' }" role="tab" @click="pTab = 'system'">
            <span class="seg-ic">⚙</span> 系统插件 · .ko 内核态
          </button>
          <button class="seg" :class="{ on: pTab === 'app' }" role="tab" @click="pTab = 'app'">
            <span class="seg-ic">▦</span> 应用插件 · .cte 用户态
          </button>
        </div>
        <button v-if="pTab === 'app'" class="cpm-install" @click="marketOpen = true">
          <span>+</span> 安装 .cte
        </button>
        <span v-else class="cpm-note">内核插件随内核镜像分发 · 签名链校验后装载（48.4）</span>
      </div>

      <div class="cpm-gates">
        <div class="cpm-gates-hd">
          <b>加载门禁</b>
          <em>第 48 章 · 决定安装与装载是否放行</em>
        </div>
        <div class="cpm-gates-grid">
          <button
            v-for="(g, gi) in [
              { k: 'manifest', l: 'manifest 校验', d: '字段完整性 + 版本 + ABI 兼容性' },
              { k: 'signature', l: '签名链校验', d: 'CT 签名 v2，未签名拒绝' },
              { k: 'sandbox', l: 'bwrap 沙箱', d: '默认 profile 网络关闭、文件系统只读' },
              { k: 'privilege', l: 'privilege 升级授权', d: 'elevated / privileged 需显式授权' }
            ]"
            :key="gi" class="tog" :class="{ off: !gates[g.k as keyof typeof gates] }"
            @click="gates[g.k as keyof typeof gates] = !gates[g.k as keyof typeof gates]"
          >
            <span class="tog-txt"><b class="tog-l">{{ g.l }}</b><em class="tog-d">{{ g.d }}</em></span>
            <span class="tog-sw"><i /></span>
          </button>
        </div>
      </div>

      <div class="cpm-list">
        <article v-for="p in pluginList" :key="p.id" class="plug" :class="{ off: !p.active }">
          <div class="plug-main">
            <span class="plug-ic" :class="p.kind === 'ko' ? 'tone-violet' : 'tone-blue'">
              {{ p.kind === 'ko' ? '⚙' : '▦' }}
            </span>
            <div class="plug-txt" @click="toggleDetail(p.id)">
              <div class="plug-top">
                <b>{{ p.name }}</b>
                <span class="plug-ver">v{{ p.version }}</span>
                <span class="plug-badge" :class="privTone(p.privilege)">{{ privLabel[p.privilege] }}</span>
                <span class="plug-badge" :class="p.signed ? 'tone-green' : 'tone-red'">{{ p.signed ? '已签名' : '未签名' }}</span>
                <span v-if="p.network" class="plug-badge tone-cyan">network</span>
                <span v-if="p.bundled" class="plug-badge tone-neutral">随系统分发</span>
              </div>
              <em class="plug-desc">{{ p.desc }}</em>
              <em v-if="p.err" class="plug-err">⛔ {{ p.err }}</em>
            </div>
            <div class="plug-acts">
              <button class="plug-sw" :class="{ on: p.active }" :title="p.active ? '停用' : '装载 / 启用'" @click="toggleActive(p)">
                <i />
              </button>
              <button v-if="!p.active" class="plug-rm" title="卸载" @click="uninstall(p)">卸载</button>
              <button class="plug-more" :title="expanded === p.id ? '收起详情' : '查看 manifest'" @click="toggleDetail(p.id)">
                {{ expanded === p.id ? '▴' : '▾' }}
              </button>
            </div>
          </div>
          <div v-if="p.installing" class="plug-load">
            <span class="plug-load-l">{{ p.kind === 'ko' ? '装载中' : '启用中' }} · bwrap 沙箱建立</span>
            <span class="plug-track"><i :style="{ width: p.progress + '%' }" /></span>
            <b class="plug-pct">{{ Math.round(p.progress) }}%</b>
          </div>
          <div v-if="expanded === p.id" class="plug-detail">
            <div class="plug-meta">
              <div><span>沙箱 profile</span><b>bwrap-ct-default</b></div>
              <div><span>文件系统</span><b>{{ p.fs === 'none' ? '不挂载' : '只读' }}</b></div>
              <div><span>网络</span><b>{{ p.network ? '放行（例外名单）' : '关闭' }}</b></div>
              <div><span>ABI 版本</span><b>v{{ p.abi }}（冻结）</b></div>
              <div><span>加载通道</span><b>{{ p.kind === 'ko' ? '签名链校验 → 内核装载' : 'ct-run 静态加载' }}</b></div>
            </div>
            <pre class="plug-manifest">{{ manifestOf(p) }}</pre>
          </div>
        </article>
        <div v-if="!pluginList.length" class="cpm-empty">该分区暂无插件</div>
      </div>
    </template>

    <!-- ═══════ ③ 原子管理 ═══════ -->
    <template v-else-if="section === 'atom'">
      <div class="sec-hd"><b>原子进程</b><em>atom-*.so 签名出厂 · 成本画像自报 · 显式 load / unload（决策 D20）· 存放 /CTF/Core/Atoms/</em></div>
      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>Resources 预算</b><em>ct-core 管家 · 按需加载、按预算释放</em></div>
        <div class="atom-budget">
          <div class="ab-row">
            <span>内存</span>
            <span class="plug-track"><i :class="{ warn: memPct >= 85 }" :style="{ width: memPct + '%' }" /></span>
            <b :class="{ warn: memPct >= 85 }">{{ usedMem }}/{{ BUDGET.mem }}MB</b>
          </div>
          <div class="ab-row">
            <span>fd</span>
            <span class="plug-track"><i :style="{ width: Math.min(100, (usedFd / BUDGET.fd) * 100) + '%' }" /></span>
            <b>{{ usedFd }}/{{ BUDGET.fd }}</b>
          </div>
          <div class="ab-row">
            <span>线程</span>
            <span class="plug-track"><i :style="{ width: Math.min(100, (usedThr / BUDGET.thr) * 100) + '%' }" /></span>
            <b>{{ usedThr }}/{{ BUDGET.thr }}</b>
          </div>
        </div>
      </div>
      <div class="cpm-list">
        <article v-for="a in atoms" :key="a.id" class="plug" :class="{ off: !a.loaded }">
          <div class="plug-main">
            <span class="plug-ic tone-violet">◈</span>
            <div class="plug-txt">
              <div class="plug-top">
                <b>{{ a.name }}</b>
                <span class="plug-badge tone-neutral">{{ a.mem }}MB</span>
                <span class="plug-badge tone-neutral">GPU {{ a.gpu }}%</span>
                <span class="plug-badge tone-neutral">fd {{ a.fd }}</span>
                <span class="plug-badge tone-neutral">线程 {{ a.thr }}</span>
              </div>
              <em class="plug-desc">{{ a.desc }}</em>
            </div>
            <div class="plug-acts">
              <button
                v-if="a.loaded" class="plug-rm ok" title="原子热更新（无断流替换）"
                :disabled="a.swapping" @click="hotSwap(a)"
              >热更新</button>
              <button class="plug-sw" :class="{ on: a.loaded }" :title="a.loaded ? 'unload' : 'load'" @click="toggleAtom(a)">
                <i />
              </button>
            </div>
          </div>
          <div v-if="a.swapping" class="plug-load">
            <span class="plug-load-l">{{ a.loaded ? '热更新中 · 原子性保证' : 'load 中 · AtomRegistry 登记' }}</span>
            <span class="plug-track"><i :style="{ width: a.progress + '%' }" /></span>
            <b class="plug-pct">{{ Math.round(a.progress) }}%</b>
          </div>
        </article>
      </div>

      <!-- 深资料：原子管理分散版数据页（四核心概念 / 运行约束 / 五阶段路线 / 规模指标等） -->
      <details class="cpm-docs">
        <summary>深资料 · 原子管理文档页（{{ docsAtom.length }} 节）</summary>
        <div class="cpm-docs-body"><CtBlock v-for="(b, i) in docsAtom" :key="i" :block="b" /></div>
      </details>
    </template>

    <!-- ═══════ ④ 发行版管理 ═══════ -->
    <template v-else-if="section === 'distro'">
      <div class="sec-hd"><b>发行版槽位</b><em>换租客不搬家 —— ct-data 与 CT 层不动 · 装发行版 20–40 分钟 / 卸载 &lt;5 分钟 / CT 层改动 0</em></div>
      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>运行模式</b><em>两模式随时可切换</em></div>
        <div class="krn-rows">
          <div class="krn-row">
            <div class="seg-row seg-mini">
              <button class="seg" :class="{ on: runMode === 'distro' }" @click="runMode !== 'distro' && switchMode()">有发行版模式（默认）</button>
              <button class="seg" :class="{ on: runMode === 'zero' }" @click="runMode !== 'zero' && switchMode()">零发行版模式</button>
            </div>
            <em class="krn-mode-hint">{{ runMode === 'distro' ? '槽位承载发行版用户态' : '.cte 静态加载路径（ct-run）为第三方唯一入口' }}</em>
          </div>
        </div>
      </div>
      <div class="cpm-list">
        <article v-for="s in slots" :key="s.id" class="plug" :class="{ off: s.state === 'empty' }">
          <div class="plug-main">
            <span class="plug-ic" :class="s.state === 'active' ? 'tone-green' : s.state === 'ready' ? 'tone-blue' : 'tone-neutral'">⇄</span>
            <div class="plug-txt">
              <div class="plug-top">
                <b>{{ s.id }} · {{ s.name }}</b>
                <span v-if="s.ver" class="plug-ver">{{ s.ver }}</span>
                <span v-if="s.state === 'active'" class="plug-badge tone-green">活动槽位</span>
                <span v-else-if="s.state === 'ready'" class="plug-badge tone-blue">就绪</span>
                <span v-else class="plug-badge tone-neutral">空槽位</span>
              </div>
              <em class="plug-desc">{{ s.state === 'empty' ? '可从官方换装目录安装发行版' : 'CT-Kernel 底座上承载发行版用户态的可替换位置' }}</em>
            </div>
            <div class="plug-acts">
              <button v-if="s.state === 'ready'" class="plug-rm ok" :disabled="s.installing || distroBusy" @click="activateSlot(s)">切换到此槽</button>
              <button v-if="s.state !== 'empty'" class="plug-rm" :disabled="s.installing || distroBusy" @click="removeSlot(s)">卸载</button>
            </div>
          </div>
          <div v-if="s.installing" class="plug-load">
            <span class="plug-load-l">{{ s.state === 'active' ? '换装中 · slot-loader 探测装载' : '装配中 · 每层独立 EROFS 镜像' }}</span>
            <span class="plug-track"><i :style="{ width: s.progress + '%' }" /></span>
            <b class="plug-pct">{{ Math.round(s.progress) }}%</b>
          </div>
        </article>
      </div>
      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>CT 官方换装目录</b><em>4 个官方可安装发行版 · 装入空槽位</em></div>
        <div class="krn-formats">
          <div v-for="c in CATALOG" :key="c.name" class="kf tone-blue">
            <b>{{ c.name }}</b>
            <em>{{ c.desc }}</em>
            <button class="kf-btn" :disabled="!!installingCat || distroBusy" @click="installDistro(c)">
              {{ installingCat === c.name ? '安装中…' : '安装' }}
            </button>
          </div>
        </div>
      </div>

      <!-- 深资料：发行版管理分散版数据页（能力边界矩阵 / 槽位状态转换 / 双模式能力等） -->
      <details class="cpm-docs">
        <summary>深资料 · 发行版管理文档页（{{ docsDistro.length }} 节）</summary>
        <div class="cpm-docs-body"><CtBlock v-for="(b, i) in docsDistro" :key="i" :block="b" /></div>
      </details>
    </template>

    <!-- ═══════ ⑤ 镜像包管理 ═══════ -->
    <template v-else>
      <div class="sec-hd"><b>挂载包（Mounts）</b><em>按需挂载的「镜像包裹」：只读镜像 + 说明书 + 签名 · 与 Resources 对称的 Mounts 管理器</em></div>
      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>evict 策略</b><em>空闲超时自动归档（演示阈值 {{ IDLE_TIMEOUT }}s）</em></div>
        <div class="cpm-gates-grid">
          <button class="tog" :class="{ off: !evict.idle }" @click="evict.idle = !evict.idle">
            <span class="tog-txt"><b class="tog-l">evict_idle</b><em class="tog-d">空闲超时自动卸载并归档</em></span>
            <span class="tog-sw"><i /></span>
          </button>
          <button class="tog" :class="{ off: !evict.pressure }" @click="evict.pressure = !evict.pressure">
            <span class="tog-txt"><b class="tog-l">evict_under_pressure</b><em class="tog-d">磁盘压力触发立即归档</em></span>
            <span class="tog-sw"><i /></span>
          </button>
        </div>
      </div>
      <div class="cpm-list">
        <article v-for="p in packs" :key="p.id" class="plug" :class="{ off: !p.mounted }">
          <div class="plug-main">
            <span class="plug-ic" :class="TYPE_TONE[p.type]">▣</span>
            <div class="plug-txt">
              <div class="plug-top">
                <b>{{ p.name }}</b>
                <span class="plug-badge" :class="TYPE_TONE[p.type]">{{ TYPE_LABEL[p.type] }}</span>
                <span class="plug-badge tone-neutral">{{ p.size }}</span>
                <span class="plug-badge" :class="packState(p).tone">{{ packState(p).label }}</span>
              </div>
              <em class="plug-desc">
                {{ p.type === 'resource' ? '资源包：字体 / 图标 / 模型 / 词库'
                  : p.type === 'application' ? '应用包：完整应用及其私有依赖（AppRegistry 冷热账本）'
                  : p.type === 'driver' ? '驱动包：EROFS + zstd，按内核版本命名'
                  : '场景包：DML 动态挂载的 Kali 等场景镜像' }}
              </em>
            </div>
            <div class="plug-acts">
              <button v-if="p.mounted" class="plug-rm" :disabled="p.working" @click="unmountPack(p)">卸载</button>
              <button v-else-if="!p.archived" class="plug-rm" :disabled="p.working" @click="archivePack(p)">归档</button>
              <button class="plug-sw" :class="{ on: p.mounted }" :title="p.mounted ? '卸载' : '挂载'" @click="mountPack(p)">
                <i />
              </button>
            </div>
          </div>
          <div v-if="p.working" class="plug-load">
            <span class="plug-load-l">{{ p.archived ? '解档中 · 从 /CTF/Images 冷存储恢复' : '归档中 · 透明压缩' }}</span>
            <span class="plug-track"><i :style="{ width: p.progress + '%' }" /></span>
            <b class="plug-pct">{{ Math.round(p.progress) }}%</b>
          </div>
        </article>
      </div>
      <div class="cpm-note-line">说明书 schema：[lifecycle] policy = persistent | on-demand · idle_timeout_sec · pack_after_idle_days · min_keep_sec</div>

      <div class="cpm-gates">
        <div class="cpm-gates-hd"><b>冷热三态分布</b><em>HotColdScheduler 作息 · 热=挂载运行 / 温=已卸载未归档 / 冷=归档冷存</em></div>
        <div class="krn-formats">
          <div class="kf tone-good"><b>{{ triStats.hot }} 热</b><em>挂载运行 · 零拷贝 EROFS</em></div>
          <div class="kf tone-amber"><b>{{ triStats.warm }} 温</b><em>已卸载 · 磁盘驻留待命</em></div>
          <div class="kf tone-neutral"><b>{{ triStats.cold }} 冷</b><em>已归档 /CTF/Images · 透明压缩</em></div>
        </div>
      </div>

      <!-- 深资料：镜像包管理分散版数据页（四类型 / manifest schema / 三态规则 / 作息表等） -->
      <details class="cpm-docs">
        <summary>深资料 · 镜像包管理文档页（{{ docsImage.length }} 节）</summary>
        <div class="cpm-docs-body"><CtBlock v-for="(b, i) in docsImage" :key="i" :block="b" /></div>
      </details>
    </template>

    <!-- ── 拒绝记录（全局） ── -->
    <div v-if="rejected.length" class="cpm-rejects">
      <div class="cpm-gates-hd"><b>拒绝记录</b><em>门禁 / 预算拦截流水</em></div>
      <div class="cpm-reject" v-for="(r, ri) in rejected" :key="ri">
        <span class="rj-time">{{ r.time }}</span>
        <b>{{ r.name }}</b>
        <em>{{ r.reason }}</em>
      </div>
    </div>

    <div class="cpm-end">内容与规则取自《ContainerLinux 文档合集》· 内核章 / 第 48 章 / 决策 D20 / 发行版章 / Mounts 章</div>

    <!-- ── 安装市场弹层 ── -->
    <transition name="cpm-modal">
      <div v-if="marketOpen" class="cpm-mask" @click.self="!installingId && (marketOpen = false)">
        <div class="cpm-market">
          <header class="cpm-market-hd">
            <div><h3>安装 .cte 插件</h3><em>ct-run 静态加载通道 · 门禁流水线：manifest → 签名 → bwrap → privilege</em></div>
            <button class="cpm-market-x" :disabled="!!installingId" @click="marketOpen = false">✕</button>
          </header>
          <div class="cpm-market-list">
            <div v-for="m in market" :key="m.id" class="mk">
              <div class="mk-txt">
                <div class="plug-top">
                  <b>{{ m.name }}</b>
                  <span class="plug-ver">v{{ m.version }}</span>
                  <span class="plug-badge" :class="privTone(m.privilege)">{{ privLabel[m.privilege] }}</span>
                  <span class="plug-badge" :class="m.signed ? 'tone-green' : 'tone-red'">{{ m.signed ? '已签名' : '未签名' }}</span>
                  <span v-if="m.abi < 1" class="plug-badge tone-amber">ABI v{{ m.abi }}</span>
                </div>
                <em class="plug-desc">{{ m.desc }}{{ m.note ? ' · ' + m.note : '' }}</em>
              </div>
              <button class="mk-btn" :disabled="!!installingId" @click="installItem(m)">
                {{ installingId === m.id ? '安装中…' : '安装' }}
              </button>
            </div>
          </div>
          <div v-if="installingId" class="cpm-installing">
            <span>{{ installStep }}</span>
            <span class="plug-track"><i :style="{ width: installPct + '%' }" /></span>
            <b>{{ Math.round(installPct) }}%</b>
          </div>
        </div>
      </div>
    </transition>
  </section>
</template>

<style scoped>
/* tone 色板（与 CtBlock.vue 同值；scoped 样式跨组件不继承，需自带一份） */
.tone-blue   { --tone: #5b8def; --tone-s: rgba(91, 141, 239, .13); }
.tone-violet { --tone: #9b7ae8; --tone-s: rgba(155, 122, 232, .13); }
.tone-green  { --tone: #5fb488; --tone-s: rgba(95, 180, 136, .13); }
.tone-good   { --tone: #5fb488; --tone-s: rgba(95, 180, 136, .13); }
.tone-teal   { --tone: #45b8a8; --tone-s: rgba(69, 184, 168, .13); }
.tone-amber  { --tone: #d5a04e; --tone-s: rgba(213, 160, 78, .13); }
.tone-cyan   { --tone: #45a9d4; --tone-s: rgba(69, 169, 212, .13); }
.tone-red    { --tone: #d9695f; --tone-s: rgba(217, 105, 95, .13); }

.cpm { display: flex; flex-direction: column; gap: 16px; max-width: 1000px; }

/* KPI */
.cpm-kpis { display: grid; grid-template-columns: repeat(3, 1fr); gap: 9px; }
.kpi {
  padding: 13px 15px; border-radius: 13px; border: 1px solid var(--c-border);
  background: var(--c-surface-2); display: flex; flex-direction: column; gap: 3px;
}
.kpi-v { font-size: 17px; font-weight: 750; color: var(--tone); font-variant-numeric: tabular-nums; }
.kpi-l { font-size: 10.5px; color: var(--c-text-mute); }

/* 工具条 */
.cpm-toolbar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.seg-row {
  display: inline-flex; gap: 3px; padding: 3px; border-radius: 11px;
  background: var(--c-surface-2); border: 1px solid var(--c-border);
}
.seg-row.seg-mini { padding: 2px; }
.seg {
  border: 0; background: transparent; color: var(--c-text-dim); font-size: 11.5px;
  padding: 7px 13px; border-radius: 8px; cursor: pointer; transition: all .15s; white-space: nowrap;
  display: inline-flex; align-items: center; gap: 6px;
}
.seg:hover { color: var(--c-text); }
.seg.on { background: var(--c-accent); color: #fff; font-weight: 600; box-shadow: 0 2px 8px var(--c-shadow); }
.seg-ic { font-size: 12px; }
.cpm-install {
  margin-left: auto; display: inline-flex; align-items: center; gap: 6px;
  border: 0; cursor: pointer; padding: 8px 15px; border-radius: 10px;
  background: var(--c-accent); color: #fff; font-size: 12px; font-weight: 650;
  box-shadow: 0 3px 12px var(--c-shadow); transition: filter .15s;
}
.cpm-install:hover { filter: brightness(1.08); }
.cpm-install span { font-size: 14px; font-weight: 700; }
.cpm-note { margin-left: auto; font-size: 11px; color: var(--c-text-mute); }
.sec-hd { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
.sec-hd b { font-size: 13px; color: var(--c-text); }
.sec-hd em { font-size: 10.5px; font-style: normal; color: var(--c-text-mute); }

/* 门禁 / 策略卡 */
.cpm-gates { border: 1px solid var(--c-border); border-radius: 13px; background: var(--c-surface-2); padding: 13px; }
.cpm-gates-hd { display: flex; align-items: baseline; gap: 9px; margin-bottom: 10px; }
.cpm-gates-hd b { font-size: 12.5px; color: var(--c-text); }
.cpm-gates-hd em { font-size: 10.5px; font-style: normal; color: var(--c-text-mute); }
.cpm-gates-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 7px; }
.tog {
  display: flex; align-items: center; justify-content: space-between; gap: 12px; width: 100%; text-align: left;
  padding: 9px 12px; border-radius: 10px; border: 1px solid var(--c-border);
  background: var(--c-surface); color: var(--c-text); cursor: pointer; transition: background .15s;
}
.tog:hover { background: var(--c-hover); }
.tog.off { opacity: .6; }
.tog-txt { min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.tog-l { font-size: 12px; font-weight: 600; }
.tog-d { font-size: 10.5px; font-style: normal; color: var(--c-text-mute); line-height: 1.4; }
.tog-sw {
  flex: none; width: 34px; height: 20px; border-radius: 20px; background: var(--c-accent);
  position: relative; transition: background .18s;
}
.tog.off .tog-sw { background: var(--c-border-strong, #6b7280); }
.tog-sw i {
  position: absolute; top: 2px; left: 16px; width: 16px; height: 16px; border-radius: 50%;
  background: #fff; transition: left .18s; box-shadow: 0 1px 3px rgba(0,0,0,.3);
}
.tog.off .tog-sw i { left: 2px; }

/* 卡片列表（插件 / 原子 / 槽位 / 挂载包共用） */
.cpm-list { display: flex; flex-direction: column; gap: 7px; }
.plug {
  border: 1px solid var(--c-border); border-radius: 13px; background: var(--c-surface-2);
  padding: 10px 13px; transition: opacity .18s, border-color .18s;
}
.plug.off { opacity: .68; }
.plug-main { display: flex; align-items: center; gap: 11px; }
.plug-ic {
  flex: none; width: 34px; height: 34px; border-radius: 10px; display: grid; place-items: center;
  background: var(--tone-s); color: var(--tone); font-size: 15px;
}
.plug-txt { flex: 1; min-width: 0; cursor: pointer; }
.plug-top { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.plug-top b { font-size: 12.5px; color: var(--c-text); }
.plug-ver { font-size: 10.5px; color: var(--c-text-mute); font-variant-numeric: tabular-nums; }
.plug-badge { font-size: 9.5px; font-weight: 600; padding: 1px 7px; border-radius: 20px; background: var(--tone-s); color: var(--tone); }
.plug-badge.tone-neutral { --tone: var(--c-text-mute); --tone-s: var(--c-surface-3); background: var(--c-surface-3); color: var(--c-text-mute); }
.plug-desc { display: block; font-size: 11px; font-style: normal; color: var(--c-text-dim); line-height: 1.5; margin-top: 3px; }
.plug-err { display: block; font-size: 11px; font-style: normal; color: #d9695f; margin-top: 3px; font-weight: 600; }
.plug-acts { flex: none; display: flex; align-items: center; gap: 8px; }
.plug-sw {
  flex: none; width: 38px; height: 22px; border-radius: 22px; border: 0; cursor: pointer;
  background: var(--c-accent); position: relative; transition: background .18s;
}
.plug-sw:not(.on) { background: var(--c-border-strong, #6b7280); }
.plug-sw i {
  position: absolute; top: 2px; left: 18px; width: 18px; height: 18px; border-radius: 50%;
  background: #fff; transition: left .18s; box-shadow: 0 1px 3px rgba(0,0,0,.3);
}
.plug-sw:not(.on) i { left: 2px; }
.plug-rm {
  flex: none; border: 1px solid var(--c-border); background: transparent; cursor: pointer;
  color: var(--c-text-dim); font-size: 11px; font-weight: 600; padding: 5px 11px; border-radius: 8px; transition: .15s;
}
.plug-rm:hover { color: #d9695f; border-color: color-mix(in srgb, #d9695f 45%, var(--c-border)); }
.plug-rm.ok:hover { color: var(--c-accent); border-color: color-mix(in srgb, var(--c-accent) 45%, var(--c-border)); }
.plug-rm:disabled { opacity: .45; cursor: default; }
.plug-more {
  flex: none; width: 26px; height: 26px; border-radius: 8px; border: 1px solid var(--c-border);
  background: transparent; color: var(--c-text-mute); cursor: pointer; font-size: 11px; transition: .15s;
}
.plug-more:hover { color: var(--c-text); background: var(--c-hover); }

/* 进度 */
.plug-load { display: flex; align-items: center; gap: 10px; margin-top: 9px; }
.plug-load-l { flex: none; font-size: 10.5px; color: var(--c-text-mute); }
.plug-track { flex: 1; height: 6px; border-radius: 6px; background: var(--c-surface-3); overflow: hidden; }
.plug-track i { display: block; height: 100%; border-radius: 6px; background: var(--c-accent); transition: width .12s ease; }
.plug-track i.warn { background: #d9695f; }
.plug-pct { flex: none; font-size: 11px; color: var(--c-accent); font-variant-numeric: tabular-nums; }

/* 详情 */
.plug-detail { margin-top: 10px; border-top: 1px dashed var(--c-border); padding-top: 10px; }
.plug-meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 6px 14px; margin-bottom: 9px; }
.plug-meta div { display: flex; justify-content: space-between; font-size: 11px; gap: 8px; }
.plug-meta span { color: var(--c-text-mute); }
.plug-meta b { color: var(--c-text-dim); font-weight: 600; text-align: right; }
.plug-manifest {
  margin: 0; padding: 11px 13px; border-radius: 10px; background: var(--c-surface);
  border: 1px solid var(--c-border); font-family: ui-monospace, monospace; font-size: 10.5px;
  line-height: 1.55; color: var(--c-text-dim); overflow-x: auto; white-space: pre;
}

/* 内核分区 */
.krn-rows { display: flex; flex-direction: column; gap: 10px; }
.krn-row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.krn-l { flex: none; width: 64px; font-size: 11.5px; color: var(--c-text-mute); }
.krn-v { font-size: 12px; color: var(--c-text); font-variant-numeric: tabular-nums; }
.krn-upd {
  border: 0; cursor: pointer; padding: 7px 14px; border-radius: 9px;
  background: var(--c-accent); color: #fff; font-size: 11.5px; font-weight: 650; transition: filter .15s;
}
.krn-upd:hover { filter: brightness(1.08); }
.krn-upd:disabled { opacity: .5; cursor: default; }
.krn-mode-hint { flex-basis: 100%; font-size: 10.5px; font-style: normal; color: var(--c-text-mute); }
.krn-progress { display: flex; align-items: center; gap: 10px; font-size: 10.5px; color: var(--c-text-mute); }
.krn-progress b { color: var(--c-accent); font-variant-numeric: tabular-nums; }
.krn-formats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 9px; }
.kf {
  position: relative; padding: 12px 13px; border-radius: 11px; border: 1px solid var(--c-border);
  background: var(--c-surface); display: flex; flex-direction: column; gap: 4px;
}
.kf b { font-size: 13px; color: var(--tone); font-family: ui-monospace, monospace; }
.kf em { font-size: 10.5px; font-style: normal; color: var(--c-text-dim); line-height: 1.45; }
.kf .plug-badge { align-self: flex-start; margin-top: 3px; }
.kf-btn {
  align-self: flex-start; margin-top: 6px; border: 0; cursor: pointer; padding: 6px 13px; border-radius: 8px;
  background: var(--c-accent); color: #fff; font-size: 11px; font-weight: 650;
}
.kf-btn:disabled { opacity: .5; cursor: default; }
.cpm-note-line { font-size: 10.5px; color: var(--c-text-mute); line-height: 1.5; padding: 0 2px; }

/* 调频与电源：实时读数 */
.krn-live { font-size: 12px; font-weight: 650; color: var(--c-text-dim); font-variant-numeric: tabular-nums; }
.krn-temp { font-style: normal; margin-left: 8px; color: var(--c-text-mute); font-weight: 600; }
.krn-temp.hot { color: #d9695f; }

/* 深资料折叠面板（分散版 blocks 复用） */
.cpm-docs {
  border: 1px solid var(--c-border); border-radius: 13px; background: var(--c-surface-2);
  overflow: hidden;
}
.cpm-docs summary {
  cursor: pointer; padding: 11px 15px; font-size: 12px; font-weight: 650; color: var(--c-text-dim);
  list-style: none; user-select: none; transition: .14s;
}
.cpm-docs summary::-webkit-details-marker { display: none; }
.cpm-docs summary::before { content: '▸'; margin-right: 7px; display: inline-block; transition: transform .18s; }
.cpm-docs[open] summary::before { transform: rotate(90deg); }
.cpm-docs summary:hover { color: var(--c-text); background: var(--c-hover, transparent); }
.cpm-docs-body { padding: 4px 14px 14px; border-top: 1px dashed var(--c-border); display: flex; flex-direction: column; gap: 12px; }

/* 原子预算 */
.atom-budget { display: flex; flex-direction: column; gap: 9px; }
.ab-row { display: flex; align-items: center; gap: 12px; font-size: 11.5px; }
.ab-row > span:first-child { flex: none; width: 36px; color: var(--c-text-mute); }
.ab-row b { flex: none; min-width: 84px; text-align: right; font-variant-numeric: tabular-nums; color: var(--c-text-dim); font-weight: 600; }
.ab-row b.warn { color: #d9695f; }

/* 拒绝记录 */
.cpm-rejects { border: 1px solid color-mix(in srgb, #d9695f 30%, var(--c-border)); border-radius: 13px; background: var(--c-surface-2); padding: 13px; }
.cpm-reject { display: flex; align-items: baseline; gap: 10px; padding: 5px 0; border-bottom: 1px dashed var(--c-border); }
.cpm-reject:last-child { border-bottom: 0; }
.rj-time { flex: none; font-size: 10.5px; color: var(--c-text-mute); font-variant-numeric: tabular-nums; }
.cpm-reject b { font-size: 11.5px; color: var(--c-text); }
.cpm-reject em { flex: 1; font-size: 11px; font-style: normal; color: #d9695f; }

.cpm-empty {
  padding: 26px; text-align: center; font-size: 12px; color: var(--c-text-mute);
  border: 1px dashed var(--c-border); border-radius: 13px;
}
.cpm-end {
  display: flex; align-items: center; gap: 7px; font-size: 10.5px; color: var(--c-text-mute);
  border-top: 1px dashed var(--c-border); padding-top: 12px;
}

/* 市场弹层 */
.cpm-mask {
  position: absolute; inset: 0; z-index: 30; display: grid; place-items: center;
  background: rgba(0,0,0,.34); backdrop-filter: blur(2px);
}
.cpm-market {
  width: min(560px, 92%); max-height: 78%; display: flex; flex-direction: column;
  border-radius: 16px; background: var(--c-surface, #1c1c1e);
  border: 1px solid var(--c-border, rgba(255,255,255,.12)); box-shadow: 0 24px 60px var(--c-shadow);
  overflow: hidden;
}
.cpm-market-hd { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; padding: 16px 18px 12px; border-bottom: 1px solid var(--c-border); }
.cpm-market-hd h3 { margin: 0 0 4px; font-size: 14.5px; color: var(--c-text); }
.cpm-market-hd em { font-size: 10.5px; font-style: normal; color: var(--c-text-mute); }
.cpm-market-x {
  flex: none; width: 26px; height: 26px; border-radius: 8px; border: 1px solid var(--c-border);
  background: transparent; color: var(--c-text-dim); cursor: pointer; font-size: 12px;
}
.cpm-market-x:disabled { opacity: .4; cursor: default; }
.cpm-market-list { overflow-y: auto; padding: 10px 14px; display: flex; flex-direction: column; gap: 8px; }
.mk {
  display: flex; align-items: center; gap: 12px; padding: 10px 12px;
  border: 1px solid var(--c-border); border-radius: 11px; background: var(--c-surface-2);
}
.mk-txt { flex: 1; min-width: 0; }
.mk-btn {
  flex: none; border: 0; cursor: pointer; padding: 7px 14px; border-radius: 9px;
  background: var(--c-accent); color: #fff; font-size: 11.5px; font-weight: 650;
}
.mk-btn:disabled { opacity: .45; cursor: default; }
.cpm-installing { display: flex; align-items: center; gap: 10px; padding: 10px 18px 14px; font-size: 11px; color: var(--c-text-dim); }
.cpm-installing b { color: var(--c-accent); font-variant-numeric: tabular-nums; }
.cpm-modal-enter-active, .cpm-modal-leave-active { transition: opacity .18s; }
.cpm-modal-enter-from, .cpm-modal-leave-to { opacity: 0; }

@media (max-width: 900px) {
  .cpm-kpis { grid-template-columns: repeat(2, 1fr); }
  .cpm-gates-grid { grid-template-columns: 1fr; }
  .krn-formats { grid-template-columns: repeat(2, 1fr); }
}
</style>
