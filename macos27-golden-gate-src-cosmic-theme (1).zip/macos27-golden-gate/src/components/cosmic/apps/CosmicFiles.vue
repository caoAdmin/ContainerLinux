<script setup lang="ts">
/**
 * COSMIC Files —— 文件管理器
 * 侧边栏书签 / 面包屑导航 / 前进后退 / 列表与网格视图 / 新建 / 重命名 / 删除 / 搜索
 */
import { computed, inject, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { placeIconUrl, type PlaceId } from '@/utils/iconThemes'
import {
  HOME,
  baseName,
  createDir,
  createFile,
  formatSize,
  getNode,
  listDir,
  normalizePath,
  prettyPath,
  removeNode,
  renameNode,
  type VNode
} from '@/utils/cosmicVfs'
import Icon from '@/components/common/Icon.vue'
import CosmicFileIcon from '../CosmicFileIcon.vue'
import M3AppShell from '../M3AppShell.vue'

const store = useCosmicStore()
const sys = useCosmicSystemStore()
const winId = inject<string>('cosmicWinId', '')

/** 磁盘占用（与 Dock 上的 Disk 状态卡同一份数据） */
const disk = computed(() => sys.storage.disk1)
const diskPct = computed(() => Math.round((disk.value.usedGB / disk.value.totalGB) * 100))
const diskFree = computed(() => disk.value.totalGB - disk.value.usedGB)

const places: { label: string; path: string; icon: string; place: PlaceId }[] = [
  { label: '主目录', path: HOME, icon: 'ri-home-5-line', place: 'home' },
  { label: '桌面', path: HOME + '/Desktop', icon: 'ri-computer-line', place: 'desktop' },
  { label: '文档', path: HOME + '/Documents', icon: 'ri-file-text-line', place: 'documents' },
  { label: '下载', path: HOME + '/Downloads', icon: 'ri-download-2-line', place: 'downloads' },
  { label: '音乐', path: HOME + '/Music', icon: 'ri-music-2-line', place: 'music' },
  { label: '图片', path: HOME + '/Pictures', icon: 'ri-image-2-line', place: 'pictures' },
  { label: '视频', path: HOME + '/Videos', icon: 'ri-movie-2-line', place: 'videos' }
]

/** 侧边栏位置图标：当前主题有就用图，没有就回落到 Remix 字形 */
function placeIcon(place: PlaceId) {
  return placeIconUrl(place, sys.appearance.iconTheme)
}

const history = ref<string[]>([HOME])
const histIndex = ref(0)
const cwd = computed(() => history.value[histIndex.value])

const selectedPath = ref<string | null>(null)
const view = ref<'list' | 'grid'>('list')
const query = ref('')
const editing = ref<{ path: string; value: string; isNew: boolean } | null>(null)

function focusRename() {
  nextTick(() => {
    const el = document.querySelector<HTMLInputElement>('.cf-rename')
    el?.focus()
    el?.select()
  })
}

const entries = computed<VNode[]>(() => {
  const list = listDir(cwd.value)
  const k = query.value.trim().toLowerCase()
  return k ? list.filter((n) => n.name.toLowerCase().includes(k)) : list
})

const selectedNode = computed<VNode | null>(() => (selectedPath.value ? getNode(selectedPath.value) : null))

const crumbs = computed(() => {
  const out = [{ name: '文件系统', path: '/' }]
  if (cwd.value === '/') return out
  let acc = ''
  for (const s of cwd.value.slice(1).split('/')) {
    acc += '/' + s
    out.push({ name: s, path: acc })
  }
  return out
})

const counts = computed(() => {
  const list = listDir(cwd.value)
  return {
    dirs: list.filter((n) => n.type === 'dir').length,
    files: list.filter((n) => n.type === 'file').length
  }
})

/* 标题跟随目录 */
watch(
  cwd,
  (p) => store.setTitle(winId, `COSMIC Files — ${prettyPath(p)}`),
  { immediate: true }
)

/* 接收其它应用发来的「在文件管理器中定位」请求 */
watch(
  () => store.pending['files'],
  (v) => {
    if (v && store.activeId === winId) {
      store.takePending('files')
      go(v as string)
    }
  },
  { immediate: true }
)

function go(path: string) {
  const p = normalizePath(path, cwd.value)
  if (!getNode(p)) return
  history.value = history.value.slice(0, histIndex.value + 1)
  history.value.push(p)
  histIndex.value = history.value.length - 1
  selectedPath.value = null
  query.value = ''
}
function back() {
  if (histIndex.value > 0) {
    histIndex.value -= 1
    selectedPath.value = null
  }
}
function forward() {
  if (histIndex.value < history.value.length - 1) {
    histIndex.value += 1
    selectedPath.value = null
  }
}
function up() {
  if (cwd.value === '/') return
  go(cwd.value.slice(0, cwd.value.lastIndexOf('/')) || '/')
}

function openNode(node: VNode) {
  const path = `${cwd.value === '/' ? '' : cwd.value}/${node.name}`
  if (node.type === 'dir') {
    go(path)
    return
  }
  const kind = node.kind ?? 'text'
  if (kind === 'audio' || kind === 'video') store.openWithPayload('player', path)
  else if (kind === 'image') store.openWithPayload('viewer', path)
  else store.openWithPayload('edit', path)
}

function uniqueName(base: string): string {
  const list = listDir(cwd.value)
  if (!list.some((n) => n.name === base)) return base
  let i = 2
  while (list.some((n) => n.name === `${base} (${i})`)) i += 1
  return `${base} (${i})`
}

async function newFolder() {
  const name = uniqueName('新建文件夹')
  if (!createDir(cwd.value, name)) return
  const p = `${cwd.value === '/' ? '' : cwd.value}/${name}`
  editing.value = { path: p, value: name, isNew: true }
  focusRename()
}

async function newFile() {
  const name = uniqueName('新建文本.txt')
  if (!createFile(cwd.value, name, '')) return
  const p = `${cwd.value === '/' ? '' : cwd.value}/${name}`
  editing.value = { path: p, value: name, isNew: true }
  focusRename()
}

function startRename(node: VNode) {
  const p = `${cwd.value === '/' ? '' : cwd.value}/${node.name}`
  editing.value = { path: p, value: node.name, isNew: false }
  focusRename()
}

function commitRename() {
  const e = editing.value
  if (!e) return
  const name = e.value.trim()
  if (name && name !== baseName(e.path)) renameNode(e.path, name)
  const dir = e.path.slice(0, e.path.lastIndexOf('/')) || '/'
  editing.value = null
  store.setTitle(winId, `COSMIC Files — ${prettyPath(dir)}`)
}

function cancelRename() {
  const e = editing.value
  if (e?.isNew) removeNode(e.path)
  editing.value = null
}

function doDelete() {
  if (!selectedPath.value) return
  removeNode(selectedPath.value)
  selectedPath.value = null
}

function isEditing(path: string): boolean {
  return editing.value?.path === path
}

function rowPath(node: VNode): string {
  return `${cwd.value === '/' ? '' : cwd.value}/${node.name}`
}

function onBodyClick(e: MouseEvent) {
  if (e.target === e.currentTarget) selectedPath.value = null
}

function onKey(e: KeyboardEvent) {
  if (winId && store.activeId !== winId) return
  if (editing.value) return
  if (e.key === 'F2' && selectedNode.value) startRename(selectedNode.value)
  else if (e.key === 'Delete' && selectedPath.value) doDelete()
  else if (e.key === 'Enter' && selectedNode.value) openNode(selectedNode.value)
}

onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <M3AppShell fabIcon="ri-folder-add-line">
  <template #rail>
    <aside class="c-sidebar">
      <div class="c-side-title">位置</div>
      <button
        v-for="p in places"
        :key="p.path"
        class="c-side-item"
        :class="{ active: cwd === p.path }"
        @click="go(p.path)"
      >
        <img v-if="placeIcon(p.place)" class="cf-place-img" :src="placeIcon(p.place)" alt="" draggable="false" />
        <Icon v-else :name="p.icon" :size="16" />
        <span>{{ p.label }}</span>
      </button>
      <div class="c-side-title">设备</div>
      <button class="c-side-item" :class="{ active: cwd === '/' }" @click="go('/')">
        <img v-if="placeIcon('system')" class="cf-place-img" :src="placeIcon('system')" alt="" draggable="false" />
        <Icon v-else name="ri-hard-drive-3-line" :size="16" />
        <span>文件系统</span>
      </button>
      <button class="c-side-item" @click="go(HOME + '/Downloads')">
        <img v-if="placeIcon('usb')" class="cf-place-img" :src="placeIcon('usb')" alt="" draggable="false" />
        <Icon v-else name="ri-usb-line" :size="16" />
        <span>U 盘 (未挂载)</span>
      </button>
      <div class="cf-spacer" />
      <div class="cf-usage">
        <div class="cf-usage-bar"><i :style="{ width: diskPct + '%' }" /></div>
        <span>已用 {{ diskPct }}% · 共 {{ disk.totalGB }} GB</span>
      </div>
    </aside>
  </template>
  <div class="cx-root cf">
    <!-- 侧边栏 -->
    <!-- 主区 -->
    <section class="c-main">
      <div class="c-toolbar">
        <button class="c-iconbtn" :disabled="histIndex === 0" title="后退" @click="back">
          <Icon name="ri-arrow-left-s-line" :size="18" />
        </button>
        <button class="c-iconbtn" :disabled="histIndex >= history.length - 1" title="前进" @click="forward">
          <Icon name="ri-arrow-right-s-line" :size="18" />
        </button>
        <button class="c-iconbtn" :disabled="cwd === '/'" title="上一级" @click="up">
          <Icon name="ri-arrow-up-line" :size="17" />
        </button>

        <nav class="cf-crumbs">
          <template v-for="(c, i) in crumbs" :key="c.path">
            <button class="cf-crumb" :class="{ last: i === crumbs.length - 1 }" @click="go(c.path)">
              {{ c.name }}
            </button>
            <Icon v-if="i < crumbs.length - 1" name="ri-arrow-right-s-line" :size="13" color="var(--c-text-mute)" />
          </template>
        </nav>

        <div class="cf-search">
          <Icon name="ri-search-line" :size="15" color="var(--c-text-mute)" />
          <input v-model="query" class="c-input" placeholder="搜索当前文件夹…" spellcheck="false" />
        </div>

        <button class="c-iconbtn" title="新建文件夹" @click="newFolder">
          <Icon name="ri-folder-add-line" :size="17" />
        </button>
        <button class="c-iconbtn" title="新建文件" @click="newFile">
          <Icon name="ri-file-add-line" :size="17" />
        </button>
        <button class="c-iconbtn" title="重命名" :disabled="!selectedNode" @click="selectedNode && startRename(selectedNode)">
          <Icon name="ri-edit-line" :size="17" />
        </button>
        <button class="c-iconbtn" title="删除" :disabled="!selectedPath" @click="doDelete">
          <Icon name="ri-delete-bin-6-line" :size="17" />
        </button>

        <div class="c-seg">
          <button :class="{ active: view === 'list' }" @click="view = 'list'">
            <Icon name="ri-list-check" :size="14" />
          </button>
          <button :class="{ active: view === 'grid' }" @click="view = 'grid'">
            <Icon name="ri-grid-fill" :size="14" />
          </button>
        </div>
      </div>

      <!-- 列表视图 -->
      <div v-if="view === 'list'" class="cf-list c-scroll" @click="onBodyClick">
        <div class="cf-head">
          <span>名称</span><span>大小</span><span>类型</span><span>修改时间</span>
        </div>
        <div
          v-for="n in entries"
          :key="n.name"
          class="cf-row"
          :class="{ selected: selectedPath === rowPath(n) }"
          @click="selectedPath = rowPath(n)"
          @dblclick="openNode(n)"
        >
          <span class="cf-name">
            <CosmicFileIcon :node="n" :size="17" />
            <input
              v-if="isEditing(rowPath(n))"
              v-model="editing!.value"
              class="cf-rename"
              spellcheck="false"
              @keydown.enter.prevent="commitRename"
              @keydown.esc.prevent="cancelRename"
              @blur="commitRename"
              @click.stop
            />
            <template v-else>{{ n.name }}</template>
          </span>
          <span class="cf-dim">{{ n.type === 'dir' ? '—' : formatSize(n.size) }}</span>
          <span class="cf-dim">{{ n.type === 'dir' ? '文件夹' : (n.kind ?? '文件') }}</span>
          <span class="cf-dim">{{ n.mtime }}</span>
        </div>
        <div v-if="!entries.length" class="c-empty">
          <Icon name="ri-folder-open-line" :size="34" color="var(--c-text-mute)" />
          <span>{{ query ? '没有匹配项' : '这个文件夹是空的' }}</span>
        </div>
      </div>

      <!-- 网格视图 -->
      <div v-else class="cf-grid-wrap c-scroll" @click="onBodyClick">
        <div class="cf-grid">
          <div
            v-for="n in entries"
            :key="n.name"
            class="cf-tile"
            :class="{ selected: selectedPath === rowPath(n) }"
            @click="selectedPath = rowPath(n)"
            @dblclick="openNode(n)"
          >
            <CosmicFileIcon :node="n" :size="42" />
            <input
              v-if="isEditing(rowPath(n))"
              v-model="editing!.value"
              class="cf-rename cf-rename--tile"
              spellcheck="false"
              @keydown.enter.prevent="commitRename"
              @keydown.esc.prevent="cancelRename"
              @blur="commitRename"
              @click.stop
            />
            <span v-else class="cf-tile-name">{{ n.name }}</span>
          </div>
        </div>
        <div v-if="!entries.length" class="c-empty">
          <Icon name="ri-folder-open-line" :size="34" color="var(--c-text-mute)" />
          <span>{{ query ? '没有匹配项' : '这个文件夹是空的' }}</span>
        </div>
      </div>

      <div class="c-status">
        <span><b>{{ counts.dirs }}</b> 个文件夹</span>
        <span><b>{{ counts.files }}</b> 个文件</span>
        <span v-if="selectedNode" class="cf-status-sel">
          已选：<b>{{ selectedNode.name }}</b>
        </span>
        <span class="cf-status-right">
          <Icon name="ri-hard-drive-3-line" :size="12" /> {{ diskFree }} GB 可用
        </span>
      </div>
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.cf {
  position: relative;
}
/* 侧边栏的位置 / 设备图标（图标主题提供时用图，否则是 Remix 字形） */
.cf-place-img {
  width: 16px;
  height: 16px;
  flex: none;
  object-fit: contain;
}
.cf-spacer {
  flex: 1;
}
.cf-usage {
  padding: 8px 10px 4px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  color: var(--c-text-mute);
  font-size: 11px;
}
.cf-usage-bar {
  height: 5px;
  border-radius: 3px;
  background: var(--c-surface-3);
  overflow: hidden;
}
.cf-usage-bar i {
  display: block;
  height: 100%;
  background: var(--c-accent);
}

.cf-crumbs {
  display: flex;
  align-items: center;
  gap: 1px;
  flex: 1;
  min-width: 0;
  overflow: hidden;
}
.cf-crumb {
  border: none;
  background: transparent;
  color: var(--c-text-dim);
  font: inherit;
  font-size: 13px;
  padding: 5px 9px;
  border-radius: 8px;
  cursor: pointer;
  white-space: nowrap;
}
.cf-crumb:hover {
  background: var(--c-hover);
  color: var(--c-text);
}
.cf-crumb.last {
  color: var(--c-text);
  font-weight: 600;
}
.cf-search {
  display: flex;
  align-items: center;
  gap: 7px;
  width: 190px;
  flex: none;
}
.cf-search .c-input {
  flex: 1;
  width: 100%;
  height: 30px;
}

.cf-list {
  flex: 1;
  min-height: 0;
  padding: 6px 8px 12px;
}
.cf-head,
.cf-row {
  display: grid;
  grid-template-columns: minmax(0, 2.2fr) 96px 110px 130px;
  align-items: center;
  gap: 10px;
  padding: 0 12px;
  height: 38px;
  border-radius: 9px;
}
.cf-head {
  height: 30px;
  color: var(--c-text-mute);
  font-size: 11.5px;
  font-weight: 600;
  position: sticky;
  top: 0;
  background: var(--c-surface);
  z-index: 2;
}
.cf-row:hover {
  background: var(--c-hover);
}
.cf-row.selected {
  background: var(--c-accent-soft);
}
.cf-name {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.cf-dim {
  color: var(--c-text-mute);
  font-size: 12px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.cf-rename {
  flex: 1;
  min-width: 0;
  height: 26px;
  border-radius: 7px;
  border: 1px solid var(--c-accent);
  background: var(--c-surface);
  color: var(--c-text);
  font: inherit;
  font-size: 13px;
  padding: 0 8px;
  outline: none;
}
.cf-rename--tile {
  width: 100%;
  font-size: 12px;
  text-align: center;
}

.cf-grid-wrap {
  flex: 1;
  min-height: 0;
  padding: 14px;
}
.cf-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(112px, 1fr));
  gap: 8px;
}
.cf-tile {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 14px 8px 12px;
  border-radius: 12px;
  cursor: default;
  border: 1px solid transparent;
}
.cf-tile:hover {
  background: var(--c-hover);
}
.cf-tile.selected {
  background: var(--c-accent-soft);
  border-color: var(--c-accent);
}
.cf-tile-name {
  font-size: 12px;
  text-align: center;
  line-height: 1.3;
  word-break: break-all;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.cf-status-sel {
  color: var(--c-text-dim);
}
.cf-status-right {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
</style>
