<script setup lang="ts">
/**
 * COSMIC Player —— 媒体播放器
 * 播放列表取自 /home/cosmic/Music，进度/音量/可视化均为实时交互。
 */
import { computed, inject, onMounted, onUnmounted, ref, watch, type Ref } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import { HOME, baseName, listDir, prettyPath, type VNode } from '@/utils/cosmicVfs'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const store = useCosmicStore()
const winId = inject<string>('cosmicWinId', '')
/** 窗口是否真的在画（最小化 / 被完全盖住时为 false）——频谱就不用白算了 */
const winVisible = inject<Ref<boolean>>('cosmicWinVisible', ref(true))

const playlist = ref<VNode[]>(listDir(HOME + '/Music'))
const index = ref(0)
const playing = ref(true)
const position = ref(38)
const volume = ref(72)
const shuffle = ref(false)
const repeat = ref<'off' | 'all' | 'one'>('all')
/** 频谱：只留每根柱子的「峰值 + 节奏」，跳动本身交给 CSS 动画。
 *  以前每 110ms 重算一次数组、重排 28 个高度，开着就一直在烧主线程；
 *  现在一帧 JS 都不用跑，还能在窗口被盖住时直接暂停（见模板的 is-paused）。 */
const bars = Array.from({ length: 28 }, (__, i) => ({
  peak: 0.55 + Math.random() * 0.45 - Math.abs(i - 14) / 14 * 0.25,
  dur: 0.62 + ((i * 7) % 9) * 0.09,
  delay: -((i * 0.37) % 1.7)
}))

const track = computed(() => playlist.value[index.value])
const duration = 268 // Departures 时长（秒）

function fmt(sec: number): string {
  const s = Math.max(0, Math.floor(sec))
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

const elapsed = computed(() => (position.value / 100) * duration)
const remain = computed(() => duration - elapsed.value)

const albumFrom = computed(() => ['#7d4fd1', '#3f8fd0', '#e05a5a', '#2ec27e', '#d1762f'][index.value % 5])
const albumTo = computed(() => ['#a97ef0', '#6fb6ea', '#f08b8b', '#63d9a4', '#eba75e'][index.value % 5])

/* ── 与顶部灵动岛共享播放状态 ── */
const cvTrackName = computed(() => {
  const t = track.value
  return t ? baseName(t.name).replace(/\.(mp3|flac|wav|ogg|m4a)$/i, '') : '未播放'
})
watch(
  [cvTrackName, playing, albumFrom, albumTo],
  () => {
    store.nowPlaying.title = cvTrackName.value
    store.nowPlaying.artist = 'EGOIST'
    store.nowPlaying.from = albumFrom.value
    store.nowPlaying.to = albumTo.value
    store.nowPlaying.playing = playing.value
  },
  { immediate: true }
)
// 灵动岛点击播放/暂停 → 同步回播放器
watch(
  () => store.nowPlaying.playing,
  (v) => {
    if (v !== playing.value) playing.value = v
  }
)

let timer = 0

function tick() {
  if (!playing.value) return
  position.value = (position.value + 0.35) % 100
}

function next() {
  index.value = shuffle.value
    ? Math.floor(Math.random() * playlist.value.length)
    : (index.value + 1) % playlist.value.length
  position.value = 0
}

function prev() {
  if (position.value > 4) {
    position.value = 0
    return
  }
  index.value = (index.value - 1 + playlist.value.length) % playlist.value.length
  position.value = 0
}

function pick(i: number) {
  index.value = i
  position.value = 0
  playing.value = true
}

function cycleRepeat() {
  repeat.value = repeat.value === 'off' ? 'all' : repeat.value === 'all' ? 'one' : 'off'
}

function onSeek(e: MouseEvent) {
  const el = e.currentTarget as HTMLElement
  const rect = el.getBoundingClientRect()
  position.value = Math.min(100, Math.max(0, ((e.clientX - rect.left) / rect.width) * 100))
}

watch(track, (t) => store.setTitle(winId, `COSMIC Player — ${t ? baseName(t.name) : '空闲'}`), {
  immediate: true
})

/* 从 Files / 终端打开某个音频 */
watch(
  () => store.pending['player'],
  (v) => {
    if (!v) return
    store.takePending('player')
    const p = v as string
    const list = listDir(HOME + '/Music')
    playlist.value = list
    const i = list.findIndex((n) => `${HOME}/Music/${n.name}` === p)
    if (i >= 0) {
      index.value = i
      position.value = 0
      playing.value = true
    }
  },
  { immediate: true }
)

onMounted(() => {
  timer = window.setInterval(tick, 1000)
  // 把播放控制交给灵动岛
  store.playerControls = {
    next,
    prev,
    toggle: () => (playing.value = !playing.value)
  }
})
onUnmounted(() => {
  window.clearInterval(timer)
  if (store.playerControls.toggle) store.playerControls = {}
})

/** 左侧导航当前选中项（正在播放 / 播放列表） */
const nav = ref<'now' | 'list'>('now')
function openLibrary() {
  store.openWithPayload('files', HOME + '/Music')
}
</script>

<template>
  <M3AppShell fabIcon="ri-skip-forward-fill" @fab="next">
    <template #rail>
      <aside class="c-sidebar">
        <div class="c-side-title">音乐</div>
        <button class="c-side-item" :class="{ active: nav === 'now' }" @click="nav = 'now'; playing = true">
          <Icon name="ri-disc-line" :size="17" />
          <span>正在播放</span>
        </button>
        <button class="c-side-item" :class="{ active: nav === 'list' }" @click="nav = 'list'">
          <Icon name="ri-play-list-2-line" :size="17" />
          <span>播放列表</span>
        </button>
        <button class="c-side-item" @click="openLibrary">
          <Icon name="ri-folder-music-line" :size="17" />
          <span>资料库</span>
        </button>
      </aside>
    </template>

    <div class="cx-root cp">
    <!-- 正在播放 -->
    <section class="cp-now">
      <div class="cp-art" :style="{ background: `linear-gradient(140deg, ${albumFrom}, ${albumTo})` }">
        <Icon name="ri-music-2-fill" :size="70" color="rgba(255,255,255,0.9)" />
        <span v-if="playing" class="cp-art-ring" />
      </div>

      <div class="cp-info">
        <b>{{ track ? baseName(track.name).replace(/\.(mp3|flac|wav|ogg|m4a)$/i, '') : '未选择曲目' }}</b>
        <span>EGOIST · Departures ～ありがとう～</span>
      </div>

      <!-- 可视化 -->
      <div class="cp-viz">
        <i
          v-for="(b, i) in bars"
          :key="i"
          :class="{ 'is-paused': !playing || !winVisible }"
          :style="{ '--peak': b.peak, '--dur': b.dur + 's', '--delay': b.delay + 's' }"
        />
      </div>

      <!-- 进度 -->
      <div class="cp-seek">
        <span>{{ fmt(elapsed) }}</span>
        <div class="cp-bar" @click="onSeek">
          <div class="cp-bar-fill" :style="{ width: position + '%' }">
            <i class="cp-knob" />
          </div>
        </div>
        <span>-{{ fmt(remain) }}</span>
      </div>

      <!-- 控制 -->
      <div class="cp-controls">
        <button class="c-iconbtn" :class="{ active: shuffle }" title="随机播放" @click="shuffle = !shuffle">
          <Icon name="ri-shuffle-line" :size="17" />
        </button>
        <button class="c-iconbtn" title="上一首" @click="prev">
          <Icon name="ri-skip-back-fill" :size="20" />
        </button>
        <button class="cp-play" @click="playing = !playing">
          <Icon :name="playing ? 'ri-pause-fill' : 'ri-play-fill'" :size="26" color="#fff" />
        </button>
        <button class="c-iconbtn" title="下一首" @click="next">
          <Icon name="ri-skip-forward-fill" :size="20" />
        </button>
        <button class="c-iconbtn" :class="{ active: repeat !== 'off' }" :title="`循环：${repeat}`" @click="cycleRepeat">
          <Icon :name="repeat === 'one' ? 'ri-repeat-one-line' : 'ri-repeat-line'" :size="17" />
        </button>
      </div>

      <!-- 音量 -->
      <div class="cp-volume">
        <Icon name="ri-volume-down-line" :size="16" color="var(--c-text-mute)" />
        <input v-model.number="volume" type="range" min="0" max="100" class="cp-range" />
        <Icon name="ri-volume-up-line" :size="16" color="var(--c-text-mute)" />
        <span>{{ volume }}%</span>
      </div>
    </section>

    <!-- 播放列表 -->
    <aside class="cp-list">
      <div class="cp-list-head">
        <Icon name="ri-play-list-2-line" :size="15" />
        <span>播放列表</span>
        <em>{{ playlist.length }} 首</em>
      </div>
      <div class="cp-list-body c-scroll">
        <button
          v-for="(t, i) in playlist"
          :key="t.name"
          class="cp-item"
          :class="{ active: i === index }"
          @click="pick(i)"
        >
          <span class="cp-item-idx">
            <Icon v-if="i === index && playing" name="ri-volume-up-fill" :size="13" :color="'var(--c-accent)'" />
            <template v-else>{{ i + 1 }}</template>
          </span>
          <span class="cp-item-text">
            <b>{{ baseName(t.name).replace(/\.(mp3|flac|wav|ogg|m4a)$/i, '') }}</b>
            <i>{{ prettyPath(HOME + '/Music') }}</i>
          </span>
          <span class="cp-item-time">{{ fmt(200 + i * 17) }}</span>
        </button>
      </div>
    </aside>
  </div>
  </M3AppShell>
</template>

<style scoped>
.cp {
  display: flex;
}
.cp-now {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 30px 30px 26px;
  gap: 16px;
  background: linear-gradient(180deg, var(--c-surface) 0%, var(--c-surface-2) 100%);
}
.cp-art {
  position: relative;
  width: 196px;
  height: 196px;
  border-radius: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 18px 46px rgba(0, 0, 0, 0.45);
  overflow: hidden;
}
.cp-art-ring {
  position: absolute;
  inset: 0;
  border-radius: 24px;
  border: 2px solid rgba(255, 255, 255, 0.22);
  animation: cp-pulse 2.6s ease-in-out infinite;
}
@keyframes cp-pulse {
  0%, 100% { transform: scale(1); opacity: 0.5; }
  50% { transform: scale(1.04); opacity: 0.15; }
}
.cp-info {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
  text-align: center;
}
.cp-info b {
  font-size: 17px;
}
.cp-info span {
  font-size: 12.5px;
  color: var(--c-text-mute);
}
.cp-viz {
  display: flex;
  align-items: flex-end;
  gap: 3px;
  height: 66px;
  width: 100%;
  max-width: 420px;
  justify-content: center;
}
.cp-viz i {
  width: 4px;
  /* 固定满高、只缩放：跳动是纯 CSS 动画，主线程零开销 */
  height: 62px;
  border-radius: 2px;
  transform-origin: 50% 100%;
  background: linear-gradient(180deg, var(--c-accent), color-mix(in srgb, var(--c-accent) 35%, transparent));
  animation: vizPulse var(--dur, 0.9s) ease-in-out infinite alternate;
  animation-delay: var(--delay, 0s);
}
.cp-viz i.is-paused {
  animation-play-state: paused;
}
@keyframes vizPulse {
  from {
    transform: scaleY(0.14);
  }
  to {
    transform: scaleY(var(--peak, 0.8));
  }
}
.cp-seek {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  max-width: 460px;
  font-size: 11.5px;
  color: var(--c-text-mute);
  font-variant-numeric: tabular-nums;
}
.cp-bar {
  flex: 1;
  height: 6px;
  border-radius: 3px;
  background: var(--c-surface-3);
  cursor: pointer;
  position: relative;
}
.cp-bar-fill {
  height: 100%;
  border-radius: 3px;
  background: var(--c-accent);
  position: relative;
}
.cp-knob {
  position: absolute;
  right: -6px;
  top: 50%;
  transform: translateY(-50%);
  width: 13px;
  height: 13px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
}
.cp-controls {
  display: flex;
  align-items: center;
  gap: 14px;
}
.cp-play {
  width: 58px;
  height: 58px;
  border-radius: 50%;
  border: none;
  background: var(--c-accent);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 8px 22px color-mix(in srgb, var(--c-accent) 45%, transparent);
  transition: transform 0.14s ease;
}
.cp-play:hover {
  transform: scale(1.06);
}
.cp-volume {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  max-width: 300px;
}
.cp-range {
  flex: 1;
  accent-color: var(--c-accent);
}
.cp-volume span {
  font-size: 11.5px;
  color: var(--c-text-mute);
  width: 34px;
  text-align: right;
}

.cp-list {
  width: 288px;
  flex: none;
  border-left: 1px solid var(--c-border);
  background: var(--c-sidebar);
  display: flex;
  flex-direction: column;
}
.cp-list-head {
  flex: none;
  height: 44px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 14px;
  border-bottom: 1px solid var(--c-border);
  font-size: 13px;
  font-weight: 600;
  color: var(--c-text-dim);
}
.cp-list-head em {
  margin-left: auto;
  font-style: normal;
  font-size: 11.5px;
  color: var(--c-text-mute);
}
.cp-list-body {
  flex: 1;
  min-height: 0;
  padding: 8px;
}
.cp-item {
  display: flex;
  align-items: center;
  gap: 11px;
  width: 100%;
  height: 46px;
  padding: 0 10px;
  border-radius: 10px;
  border: none;
  background: transparent;
  color: var(--c-text);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.cp-item:hover {
  background: var(--c-hover);
}
.cp-item.active {
  background: var(--c-accent-soft);
}
.cp-item-idx {
  width: 18px;
  flex: none;
  text-align: center;
  font-size: 12px;
  color: var(--c-text-mute);
}
.cp-item-text {
  min-width: 0;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.cp-item-text b {
  font-size: 13px;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.cp-item-text i {
  font-style: normal;
  font-size: 11px;
  color: var(--c-text-mute);
}
.cp-item-time {
  font-size: 11.5px;
  color: var(--c-text-mute);
  flex: none;
}
</style>
