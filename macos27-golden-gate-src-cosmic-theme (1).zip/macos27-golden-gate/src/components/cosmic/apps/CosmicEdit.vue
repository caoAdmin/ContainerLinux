<script setup lang="ts">
/**
 * COSMIC Edit —— 文本编辑器
 * 多标签页 / 行号栏 / 项目文件夹 / 保存回虚拟文件系统 / Git 状态栏
 */
import { computed, inject, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import {
  HOME,
  baseName,
  iconForNode,
  colorForNode,
  listDir,
  prettyPath,
  readFile,
  writeFile,
  type VNode
} from '@/utils/cosmicVfs'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const store = useCosmicStore()
const winId = inject<string>('cosmicWinId', '')

interface Tab {
  path: string
  content: string
  saved: string
}

const tabs = ref<Tab[]>([])
const activeIdx = ref(0)
const treeRoot = ref(HOME + '/Documents')
const cursorLine = ref(1)
const cursorCol = ref(1)
const textarea = ref<HTMLTextAreaElement | null>(null)
const gutter = ref<HTMLElement | null>(null)

const activeTab = computed<Tab | null>(() => tabs.value[activeIdx.value] ?? null)
const dirty = computed(() => (activeTab.value ? activeTab.value.content !== activeTab.value.saved : false))
const lineCount = computed(() => (activeTab.value ? activeTab.value.content.split('\n').length : 1))
const changedLines = computed(() => {
  const t = activeTab.value
  if (!t) return 0
  const a = t.saved.split('\n')
  const b = t.content.split('\n')
  let n = 0
  for (let i = 0; i < Math.max(a.length, b.length); i++) if (a[i] !== b[i]) n++
  return n
})

const lang = computed(() => {
  const p = activeTab.value?.path ?? ''
  const ext = p.slice(p.lastIndexOf('.') + 1).toLowerCase()
  const map: Record<string, string> = {
    rs: 'Rust', ts: 'TypeScript', js: 'JavaScript', vue: 'Vue', py: 'Python',
    json: 'JSON', toml: 'TOML', md: 'Markdown', txt: 'Plain Text',
    sh: 'Shell Script', css: 'CSS', html: 'HTML'
  }
  return map[ext] ?? 'Plain Text'
})

function openPath(path: string) {
  const existing = tabs.value.findIndex((t) => t.path === path)
  if (existing >= 0) {
    activeIdx.value = existing
  } else {
    const content = readFile(path)
    if (content == null) return
    tabs.value.push({ path, content, saved: content })
    activeIdx.value = tabs.value.length - 1
  }
  updateTitle()
  nextTick(() => textarea.value?.focus())
}

function updateTitle() {
  const t = activeTab.value
  const name = t ? baseName(t.path) + (dirty.value ? ' •' : '') : '未命名'
  store.setTitle(winId, `COSMIC Edit — ${name}`)
}

watch(dirty, updateTitle)

function save() {
  const t = activeTab.value
  if (!t) return
  writeFile(t.path, t.content)
  t.saved = t.content
  updateTitle()
}

function closeTab(i: number) {
  tabs.value.splice(i, 1)
  activeIdx.value = Math.max(0, Math.min(activeIdx.value, tabs.value.length - 1))
  updateTitle()
}

function newTab() {
  tabs.value.push({ path: '', content: '', saved: '' })
  activeIdx.value = tabs.value.length - 1
  nextTick(() => textarea.value?.focus())
}

function onInput() {
  updateTitle()
  updateCursor()
}

function updateCursor() {
  const el = textarea.value
  if (!el) return
  const upto = el.value.slice(0, el.selectionStart)
  const lines = upto.split('\n')
  cursorLine.value = lines.length
  cursorCol.value = lines[lines.length - 1].length + 1
}

function syncScroll() {
  if (gutter.value && textarea.value) gutter.value.scrollTop = textarea.value.scrollTop
}

function onKey(e: KeyboardEvent) {
  if (winId && store.activeId !== winId) return
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
    e.preventDefault()
    save()
  } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') {
    e.preventDefault()
    newTab()
  } else if (e.key === 'Tab' && e.target === textarea.value) {
    e.preventDefault()
    const el = textarea.value!
    const s = el.selectionStart
    const t = activeTab.value!
    t.content = t.content.slice(0, s) + '  ' + t.content.slice(el.selectionEnd)
    nextTick(() => {
      el.selectionStart = el.selectionEnd = s + 2
      updateCursor()
    })
  }
}

/* 项目文件树 */
interface TreeItem {
  name: string
  path: string
  depth: number
  node: VNode
}
const treeItems = computed<TreeItem[]>(() => {
  const out: TreeItem[] = []
  const walk = (p: string, depth: number) => {
    for (const n of listDir(p)) {
      const path = `${p === '/' ? '' : p}/${n.name}`
      out.push({ name: n.name, path, depth, node: n })
      if (n.type === 'dir' && depth < 2) walk(path, depth + 1)
    }
  }
  walk(treeRoot.value, 0)
  return out
})

function pickTree(item: TreeItem) {
  if (item.node.type === 'file') openPath(item.path)
  else treeRoot.value = item.path
}

/* 响应 Files / 终端发来的打开请求 */
watch(
  () => store.pending['edit'],
  (v) => {
    if (v && store.activeId === winId) {
      store.takePending('edit')
      openPath(v as string)
    }
  },
  { immediate: true }
)

onMounted(() => {
  window.addEventListener('keydown', onKey)
  updateTitle()
})
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <M3AppShell fabIcon="ri-file-add-line">
  <template #rail>
    <aside class="c-sidebar ce-side">
      <div class="ce-side-head">
        <Icon name="ri-folder-open-line" :size="14" />
        <span>{{ prettyPath(treeRoot) }}</span>
      </div>
      <div class="ce-tree c-scroll">
        <button
          v-for="it in treeItems"
          :key="it.path"
          class="ce-tree-item"
          :class="{ active: it.path === activeTab?.path }"
          :style="{ paddingLeft: 10 + it.depth * 14 + 'px' }"
          @click="pickTree(it)"
        >
          <Icon :name="iconForNode(it.node)" :size="14" :color="colorForNode(it.node)" />
          <span>{{ it.name }}</span>
        </button>
      </div>
      <div class="ce-git">
        <Icon name="ri-git-branch-line" :size="13" />
        <span>main</span>
        <span class="ce-git-badge">{{ changedLines }} ±</span>
      </div>
    </aside>
  </template>
  <div class="cx-root ce">
    <!-- 项目侧边栏 -->
    <!-- 编辑区 -->
    <section class="c-main">
      <!-- 标签栏 -->
      <div class="ce-tabs">
        <div
          v-for="(t, i) in tabs"
          :key="t.path + i"
          class="ce-tab"
          :class="{ active: i === activeIdx }"
          @click="activeIdx = i"
        >
          <Icon name="ri-file-text-line" :size="13" />
          <span>{{ t.path ? baseName(t.path) : '未命名' }}</span>
          <i v-if="t.content !== t.saved" class="ce-dot" />
          <button class="ce-tab-x" @click.stop="closeTab(i)">
            <Icon name="ri-close-line" :size="13" />
          </button>
        </div>
        <button class="ce-tab-add" title="新建标签 (Ctrl+N)" @click="newTab">
          <Icon name="ri-add-line" :size="15" />
        </button>
        <button class="ce-save" :class="{ dirty }" title="保存 (Ctrl+S)" @click="save">
          <Icon name="ri-save-3-line" :size="15" />
          <span>{{ dirty ? '保存' : '已保存' }}</span>
        </button>
      </div>

      <!-- 编辑器 -->
      <div v-if="activeTab" class="ce-editor">
        <div ref="gutter" class="ce-gutter">
          <div v-for="n in lineCount" :key="n" class="ce-ln" :class="{ cur: n === cursorLine }">{{ n }}</div>
        </div>
        <textarea
          ref="textarea"
          v-model="activeTab.content"
          class="ce-textarea"
          spellcheck="false"
          @input="onInput"
          @keyup="updateCursor"
          @click="updateCursor"
          @scroll="syncScroll"
        />
      </div>
      <div v-else class="ce-welcome">
        <Icon name="ri-file-edit-line" :size="42" color="var(--c-text-mute)" />
        <b>COSMIC Edit</b>
        <p>从左侧项目树打开一个文件，或按 Ctrl+N 新建标签页。</p>
      </div>

      <div class="c-status">
        <span v-if="activeTab">
          <b>Ln {{ cursorLine }}, Col {{ cursorCol }}</b>
        </span>
        <span>{{ lang }}</span>
        <span>UTF-8</span>
        <span class="ce-status-right">
          <Icon name="ri-git-branch-line" :size="12" />
          main
          <template v-if="activeTab"> · {{ prettyPath(activeTab.path) || '未命名' }}</template>
        </span>
      </div>
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.ce {
  position: relative;
}
.ce-side {
  width: 226px;
  padding: 0;
  display: flex;
  flex-direction: column;
}
.ce-side-head {
  flex: none;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 12px 10px;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--c-text-dim);
  border-bottom: 1px solid var(--c-border);
}
.ce-tree {
  flex: 1;
  min-height: 0;
  padding: 6px 6px 10px;
}
.ce-tree-item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 28px;
  border: none;
  background: transparent;
  border-radius: 7px;
  color: var(--c-text-dim);
  font: inherit;
  font-size: 12.5px;
  cursor: pointer;
  text-align: left;
}
.ce-tree-item span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ce-tree-item:hover {
  background: var(--c-hover);
  color: var(--c-text);
}
.ce-tree-item.active {
  background: var(--c-accent-soft);
  color: var(--c-text);
}
.ce-git {
  flex: none;
  height: 30px;
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 0 12px;
  border-top: 1px solid var(--c-border);
  color: var(--c-text-mute);
  font-size: 11.5px;
}
.ce-git-badge {
  margin-left: auto;
  padding: 1px 7px;
  border-radius: 9px;
  background: var(--c-accent-soft);
  color: var(--c-text);
}

.ce-tabs {
  flex: none;
  display: flex;
  align-items: center;
  gap: 4px;
  height: 38px;
  padding: 0 8px;
  background: var(--c-surface-2);
  border-bottom: 1px solid var(--c-border);
  overflow-x: auto;
}
.ce-tab {
  display: flex;
  align-items: center;
  gap: 7px;
  height: 28px;
  padding: 0 8px 0 10px;
  border-radius: 8px;
  color: var(--c-text-dim);
  font-size: 12.5px;
  cursor: pointer;
  white-space: nowrap;
  border: 1px solid transparent;
}
.ce-tab.active {
  background: var(--c-surface);
  border-color: var(--c-border);
  color: var(--c-text);
}
.ce-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--c-accent);
}
.ce-tab-x {
  border: none;
  background: transparent;
  color: inherit;
  opacity: 0.6;
  cursor: pointer;
  display: inline-flex;
  padding: 0;
}
.ce-tab-x:hover {
  opacity: 1;
}
.ce-tab-add {
  width: 28px;
  height: 28px;
  border: none;
  background: transparent;
  color: var(--c-text-dim);
  border-radius: 8px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
.ce-tab-add:hover {
  background: var(--c-hover);
  color: var(--c-text);
}
.ce-save {
  margin-left: auto;
  flex: none;
  height: 28px;
  padding: 0 12px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border-radius: 9px;
  border: 1px solid var(--c-border);
  background: var(--c-surface-3);
  color: var(--c-text-dim);
  font: inherit;
  font-size: 12.5px;
  cursor: pointer;
}
.ce-save.dirty {
  background: var(--c-accent);
  border-color: transparent;
  color: #fff;
}

.ce-editor {
  flex: 1;
  min-height: 0;
  display: flex;
  background: var(--c-surface);
  font-family: 'JetBrains Mono', 'Fira Code', Consolas, monospace;
  font-size: 13px;
  line-height: 1.62;
}
.ce-gutter {
  flex: none;
  width: 52px;
  padding: 12px 0;
  overflow: hidden;
  text-align: right;
  background: var(--c-sidebar);
  border-right: 1px solid var(--c-border);
  color: var(--c-text-mute);
  user-select: none;
}
.ce-ln {
  padding-right: 12px;
  font-size: 12.5px;
}
.ce-ln.cur {
  color: var(--c-text);
  font-weight: 700;
}
.ce-textarea {
  flex: 1;
  min-width: 0;
  padding: 12px 16px;
  border: none;
  outline: none;
  resize: none;
  background: transparent;
  color: var(--c-text);
  font: inherit;
  line-height: inherit;
  tab-size: 2;
  white-space: pre;
  overflow: auto;
  caret-color: var(--c-accent);
}
.ce-welcome {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: var(--c-text-mute);
}
.ce-welcome b {
  font-size: 16px;
  color: var(--c-text-dim);
}
.ce-welcome p {
  margin: 0;
  font-size: 13px;
}
.ce-status-right {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
</style>
