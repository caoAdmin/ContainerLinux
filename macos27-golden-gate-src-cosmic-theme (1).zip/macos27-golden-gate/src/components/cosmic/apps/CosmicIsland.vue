<script setup lang="ts">
/**
 * CosmicIsland —— 「信息岛」应用窗口
 * 与桌面胶囊堆叠共用同一份工作台与数据，Dock / 启动台可直接打开完整版。
 * 音乐播放不在本应用内，仍由桌面原生灵动岛承担。
 */
import IslandWorkbench from '../island/IslandWorkbench.vue'
</script>

<template>
  <div class="ih-win">
    <IslandWorkbench windowed />
  </div>
</template>

<style scoped>
.ih-win {
  flex: 1;
  min-width: 0;
  min-height: 0;
  display: flex;
  overflow: hidden;
}
</style>
