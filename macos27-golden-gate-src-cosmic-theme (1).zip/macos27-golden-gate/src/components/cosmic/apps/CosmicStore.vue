<script setup lang="ts">
/**
 * COSMIC Store —— 应用商店
 * 分类 / 搜索 / 安装进度动画 / 已安装与更新管理
 */
import { computed, inject, onMounted, ref } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import { cosmicApps } from '@/utils/cosmicApps'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'
import CosmicAppIcon from '../CosmicAppIcon.vue'

const store = useCosmicStore()
const winId = inject<string>('cosmicWinId', '')

interface CatalogItem {
  id: string
  name: string
  icon: string
  from: string
  to: string
  desc: string
  category: string
  size: string
  rating: number
  core?: boolean
  update?: string
}

const catalog: CatalogItem[] = [
  ...cosmicApps.map((a) => ({
    id: a.id,
    name: a.name.replace('COSMIC ', ''),
    icon: a.icon,
    from: a.from,
    to: a.to,
    desc: a.description,
    category: a.category,
    size: '24.6 MB',
    rating: 4.8,
    core: true
  })),
  { id: 'calculator', name: 'Calculator', icon: 'ri-calculator-fill', from: '#e05a5a', to: '#f08b8b', desc: '快速计算与单位换算', category: '生产力', size: '8.2 MB', rating: 4.6 },
  { id: 'weather', name: 'Weather', icon: 'ri-sun-cloudy-fill', from: '#3f8fd0', to: '#6fb6ea', desc: '未来 7 天天气预报', category: '精选', size: '12.4 MB', rating: 4.7, update: 'v1.2.0' },
  { id: 'camera', name: 'Camera', icon: 'ri-camera-3-fill', from: '#7a5cf0', to: '#a48bf5', desc: '拍照与录像', category: '图形', size: '31.8 MB', rating: 4.4 },
  { id: 'screenshot', name: 'Screenshot', icon: 'ri-screenshot-2-fill', from: '#25c2a0', to: '#5fd9be', desc: '全屏、区域、窗口截图', category: '系统', size: '6.1 MB', rating: 4.9, update: 'v1.4.2' },
  { id: 'clock', name: 'Clock', icon: 'ri-timer-fill', from: '#e5a50a', to: '#f2c65c', desc: '时钟、闹钟、计时器与秒表', category: '精选', size: '9.7 MB', rating: 4.8 },
  { id: 'tasks', name: 'Tasks', icon: 'ri-checkbox-multiple-line', from: '#2ec27e', to: '#63d9a4', desc: '待办事项与提醒', category: '生产力', size: '14.3 MB', rating: 4.5 },
  { id: 'docs', name: 'Docs', icon: 'ri-file-paper-2-fill', from: '#b5813a', to: '#d8ab68', desc: '轻量文档阅读器', category: '生产力', size: '18.9 MB', rating: 4.3, update: 'v0.9.6' },
  { id: 'paint', name: 'Paint', icon: 'ri-brush-2-fill', from: '#e45b9c', to: '#f08fbc', desc: '简单绘图与标注', category: '图形', size: '22.5 MB', rating: 4.2 },
  { id: 'archive', name: 'Archive', icon: 'ri-archive-2-fill', from: '#d1762f', to: '#eba75e', desc: '压缩与解压归档文件', category: '系统', size: '11.2 MB', rating: 4.6 },
  { id: 'games', name: 'Games', icon: 'ri-gamepad-fill', from: '#5b6472', to: '#8b94a5', desc: '小游戏合集（扫雷、数独…）', category: '游戏', size: '48.4 MB', rating: 4.1 }
]

const categories = ['精选', '全部', '核心', '生产力', '图形', '系统', '游戏']
const category = ref('精选')
const query = ref('')
const progress = ref<Record<string, number>>({})
const tab = ref<'discover' | 'installed' | 'updates'>('discover')

const updates = computed(() => catalog.filter((c) => c.update))

const shown = computed(() => {
  if (tab.value === 'updates') return updates.value
  let list = catalog
  if (tab.value === 'installed') list = catalog.filter((c) => store.installed.includes(c.id))
  else if (category.value !== '全部') list = list.filter((c) => c.category === category.value)
  const k = query.value.trim().toLowerCase()
  if (k) list = list.filter((c) => c.name.toLowerCase().includes(k) || c.desc.toLowerCase().includes(k))
  return list
})

function isInstalled(id: string) {
  return store.installed.includes(id)
}

function installing(id: string) {
  return progress.value[id] != null
}

function install(item: CatalogItem) {
  if (isInstalled(item.id) || installing(item.id)) return
  progress.value[item.id] = 0
  const tick = window.setInterval(() => {
    const cur = progress.value[item.id] ?? 0
    const next = cur + 6 + Math.random() * 12
    if (next >= 100) {
      progress.value[item.id] = 100
      window.clearInterval(tick)
      window.setTimeout(() => {
        delete progress.value[item.id]
        store.install(item.id)
      }, 260)
    } else {
      progress.value[item.id] = next
    }
  }, 60)
}

function primary(item: CatalogItem) {
  if (item.core && isInstalled(item.id)) store.openApp(item.id)
  else install(item)
}

function updateAll() {
  updates.value.forEach((u) => {
    progress.value[u.id] = 0
    const tick = window.setInterval(() => {
      const cur = progress.value[u.id] ?? 0
      if (cur + 20 >= 100) {
        window.clearInterval(tick)
        delete progress.value[u.id]
      } else progress.value[u.id] = cur + 20
    }, 70)
  })
}

onMounted(() => store.setTitle(winId, 'COSMIC Store'))
</script>

<template>
  <M3AppShell fabIcon="ri-download-cloud-2-line">
  <template #rail>
    <aside class="c-sidebar">
      <div class="c-side-title">商店</div>
      <button class="c-side-item" :class="{ active: tab === 'discover' }" @click="tab = 'discover'">
        <Icon name="ri-compass-3-line" :size="16" /><span>发现</span>
      </button>
      <button class="c-side-item" :class="{ active: tab === 'installed' }" @click="tab = 'installed'">
        <Icon name="ri-checkbox-circle-line" :size="16" /><span>已安装</span>
        <em class="cs-count">{{ store.installed.length }}</em>
      </button>
      <button class="c-side-item" :class="{ active: tab === 'updates' }" @click="tab = 'updates'">
        <Icon name="ri-refresh-line" :size="16" /><span>更新</span>
        <em class="cs-count cs-count--hot">{{ updates.length }}</em>
      </button>

      <template v-if="tab === 'discover'">
        <div class="c-side-title">分类</div>
        <button
          v-for="c in categories"
          :key="c"
          class="c-side-item"
          :class="{ active: category === c }"
          @click="category = c"
        >
          <Icon name="ri-price-tag-3-line" :size="15" /><span>{{ c }}</span>
        </button>
      </template>

      <div class="cs-side-foot">
        <Icon name="ri-shield-check-line" :size="14" />
        <span>Flathub 源已连接</span>
      </div>
    </aside>
  </template>
  <div class="cx-root cs">
    <section class="c-main">
      <div class="c-toolbar">
        <div class="cs-search">
          <Icon name="ri-search-line" :size="16" color="var(--c-text-mute)" />
          <input v-model="query" class="c-input" placeholder="搜索应用商店…" spellcheck="false" />
        </div>
        <button v-if="tab === 'updates'" class="c-btn c-btn--primary" @click="updateAll">
          <Icon name="ri-download-cloud-2-line" :size="15" /> 全部更新
        </button>
        <span class="cs-toolbar-hint">{{ shown.length }} 个应用</span>
      </div>

      <div class="cs-grid c-scroll">
        <article v-for="item in shown" :key="item.id" class="cs-card">
          <header class="cs-card-head">
            <CosmicAppIcon class="cs-icon" :app="item" :size="44" :glyph="0.55" />
            <div class="cs-meta">
              <b>{{ item.name }}</b>
              <span class="cs-rating">
                <Icon name="ri-star-fill" :size="11" color="#f2c65c" />
                {{ item.rating }} · {{ item.size }}
              </span>
            </div>
            <span v-if="item.update && isInstalled(item.id)" class="c-tag cs-upd">{{ item.update }}</span>
          </header>

          <p class="cs-desc">{{ item.desc }}</p>

          <footer class="cs-card-foot">
            <template v-if="installing(item.id)">
              <div class="cs-progress"><i :style="{ width: (progress[item.id] ?? 0) + '%' }" /></div>
              <span class="cs-pct">{{ Math.round(progress[item.id] ?? 0) }}%</span>
            </template>
            <template v-else-if="isInstalled(item.id)">
              <button class="c-btn" @click="item.core ? store.openApp(item.id) : store.uninstall(item.id)">
                <Icon :name="item.core ? 'ri-external-link-line' : 'ri-delete-bin-6-line'" :size="14" />
                {{ item.core ? '打开' : '卸载' }}
              </button>
              <span class="cs-installed"><Icon name="ri-check-line" :size="13" /> 已安装</span>
            </template>
            <template v-else>
              <button class="c-btn c-btn--primary" @click="primary(item)">
                <Icon name="ri-download-2-line" :size="14" /> 安装
              </button>
            </template>
          </footer>
        </article>

        <div v-if="!shown.length" class="c-empty cs-empty">
          <Icon name="ri-store-3-line" :size="34" color="var(--c-text-mute)" />
          <span>没有符合条件的应用</span>
        </div>
      </div>

      <div class="c-status">
        <span><b>{{ store.installed.length }}</b> 个已安装</span>
        <span><b>{{ updates.length }}</b> 个可更新</span>
        <span class="cs-status-right"><Icon name="ri-hard-drive-3-line" :size="12" /> 218 GB 可用</span>
      </div>
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.cs {
  position: relative;
}
.cs-count {
  margin-left: auto;
  font-style: normal;
  font-size: 11px;
  padding: 1px 7px;
  border-radius: 9px;
  background: var(--c-surface-3);
  color: var(--c-text-dim);
}
.cs-count--hot {
  background: var(--c-accent);
  color: #fff;
}
.cs-side-foot {
  margin-top: auto;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px;
  color: var(--c-text-mute);
  font-size: 11.5px;
}
.cs-search {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  max-width: 360px;
}
.cs-search .c-input {
  flex: 1;
  height: 34px;
}
.cs-toolbar-hint {
  margin-left: auto;
  color: var(--c-text-mute);
  font-size: 12px;
}
.cs-grid {
  flex: 1;
  min-height: 0;
  padding: 14px;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(268px, 1fr));
  gap: 12px;
  align-content: start;
}
.cs-card {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 14px;
  border-radius: 14px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border);
  transition: border-color 0.15s ease, transform 0.15s ease;
}
.cs-card:hover {
  border-color: var(--c-border-strong);
  transform: translateY(-2px);
}
.cs-card-head {
  display: flex;
  align-items: center;
  gap: 11px;
}
.cs-icon {
  width: 44px;
  height: 44px;
  flex: none;
  border-radius: 13px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}
.cs-meta {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 3px;
}
.cs-meta b {
  font-size: 14px;
}
.cs-rating {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11.5px;
  color: var(--c-text-mute);
}
.cs-upd {
  margin-left: auto;
  color: var(--c-text);
  border-color: var(--c-accent);
  background: var(--c-accent-soft);
}
.cs-desc {
  margin: 0;
  font-size: 12.5px;
  line-height: 1.5;
  color: var(--c-text-dim);
  min-height: 38px;
}
.cs-card-foot {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 34px;
}
.cs-progress {
  flex: 1;
  height: 6px;
  border-radius: 3px;
  background: var(--c-surface-3);
  overflow: hidden;
}
.cs-progress i {
  display: block;
  height: 100%;
  background: var(--c-accent);
  transition: width 0.12s linear;
}
.cs-pct {
  font-size: 12px;
  color: var(--c-text-dim);
  font-variant-numeric: tabular-nums;
}
.cs-installed {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  color: var(--c-text-mute);
  font-size: 11.5px;
}
.cs-empty {
  grid-column: 1 / -1;
}
.cs-status-right {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
</style>
