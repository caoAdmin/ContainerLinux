<script setup lang="ts">
/**
 * COSMIC Fonts —— 字体查看器
 * 字体列表 + 自定义预览文本 + 字号/字重调节 + 字符集预览。
 */
import { computed, ref } from 'vue'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const fonts = [
  { name: 'Fira Sans', family: '"Fira Sans", "Noto Sans SC", sans-serif', kind: '无衬线' },
  { name: 'Noto Sans SC', family: '"Noto Sans SC", system-ui, sans-serif', kind: '无衬线' },
  { name: 'JetBrains Mono', family: '"JetBrains Mono", ui-monospace, monospace', kind: '等宽' },
  { name: 'Source Serif', family: '"Source Serif Pro", Georgia, serif', kind: '衬线' },
  { name: 'Inter', family: 'Inter, "Helvetica Neue", Arial, sans-serif', kind: '无衬线' },
  { name: 'Noto Serif SC', family: '"Noto Serif SC", "Songti SC", serif', kind: '衬线' },
  { name: 'Comic Neue', family: '"Comic Neue", "Comic Sans MS", cursive', kind: '手写' },
  { name: '系统默认', family: 'system-ui, -apple-system, sans-serif', kind: '无衬线' }
]

const query = ref('')
const preview = ref('The quick brown fox jumps over the lazy dog')
const size = ref(26)
const weight = ref(500)
const selected = ref(fonts[0].name)

const filtered = computed(() => {
  const q = query.value.trim().toLowerCase()
  if (!q) return fonts
  return fonts.filter((f) => f.name.toLowerCase().includes(q) || f.kind.includes(q))
})
const cur = computed(() => fonts.find((f) => f.name === selected.value) ?? fonts[0])

const glyphs = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz 0123456789'
const cjk = '永和九年，岁在癸丑，暮春之初，会于会稽山阴之兰亭。'
</script>

<template>
  <M3AppShell fabIcon="ri-download-line">
  <template #rail>
    <aside class="c-sidebar fonts-side">
      <div class="fonts-search">
        <Icon name="ri-search-line" :size="13" color="var(--c-text-dim)" />
        <input v-model="query" placeholder="搜索字体…" spellcheck="false" />
      </div>
      <button
        v-for="f in filtered"
        :key="f.name"
        class="c-side-item fonts-item"
        :class="{ on: selected === f.name }"
        @click="selected = f.name"
      >
        <span class="fonts-item-name" :style="{ fontFamily: f.family }">{{ f.name }}</span>
        <span class="fonts-kind">{{ f.kind }}</span>
      </button>
      <div v-if="!filtered.length" class="fonts-none">没有匹配的字体</div>
    </aside>
  </template>
  <div class="fonts">
    <section class="fonts-main">
      <div class="c-toolbar fonts-bar">
        <b>{{ cur.name }}</b>
        <span class="fonts-tag">{{ cur.kind }}</span>
        <div style="flex: 1" />
        <label class="fonts-ctl">
          字号
          <input v-model.number="size" type="range" min="12" max="72" />
          <b>{{ size }}</b>
        </label>
        <label class="fonts-ctl">
          字重
          <input v-model.number="weight" type="range" min="100" max="900" step="100" />
          <b>{{ weight }}</b>
        </label>
      </div>

      <div class="fonts-body c-scroll">
        <input v-model="preview" class="fonts-input" placeholder="输入预览文本…" spellcheck="false" />

        <div
          class="fonts-preview"
          :style="{ fontFamily: cur.family, fontSize: size + 'px', fontWeight: weight }"
        >
          {{ preview || 'Aa' }}
        </div>

        <div class="fonts-section">字符集</div>
        <div
          class="fonts-glyphs"
          :style="{ fontFamily: cur.family, fontWeight: weight }"
        >
          {{ glyphs }}
        </div>
        <div class="fonts-glyphs cjk" :style="{ fontFamily: cur.family }">{{ cjk }}</div>

        <div class="fonts-section">分级</div>
        <div class="fonts-scale" :style="{ fontFamily: cur.family }">
          <div v-for="s in [12, 14, 16, 20, 24, 32, 40, 56]" :key="s" class="fonts-scale-row">
            <span class="fonts-scale-num">{{ s }}</span>
            <span :style="{ fontSize: s + 'px', fontWeight: weight }">COSMIC 桌面 · {{ s }}px</span>
          </div>
        </div>
      </div>
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.fonts { height: 100%; display: flex; min-height: 0; }
.fonts-side { width: 216px; }
.fonts-search {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0 8px;
  height: 28px;
  border-radius: 8px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border);
  margin-bottom: 8px;
}
.fonts-search input {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  color: var(--c-text);
  font-size: 12px;
  min-width: 0;
}
.fonts-item { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.fonts-item.on { background: color-mix(in srgb, var(--c-accent) 22%, transparent); }
.fonts-item-name { font-size: 13px; }
.fonts-kind { font-size: 9.5px; color: var(--c-text-mute); }
.fonts-none { font-size: 12px; color: var(--c-text-mute); padding: 10px; }
.fonts-main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.fonts-bar { gap: 10px; }
.fonts-tag {
  font-size: 10px;
  padding: 1px 7px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--c-accent) 20%, transparent);
  color: var(--c-text);
}
.fonts-ctl { display: flex; align-items: center; gap: 6px; font-size: 11px; color: var(--c-text-dim); }
.fonts-ctl input { width: 92px; accent-color: var(--c-accent); }
.fonts-ctl b { width: 26px; text-align: right; color: var(--c-text); font-size: 11.5px; }
.fonts-body { flex: 1; min-height: 0; overflow-y: auto; padding: 16px 20px 26px; }
.fonts-input {
  width: 100%;
  height: 34px;
  border-radius: 9px;
  border: 1px solid var(--c-border);
  background: var(--c-surface-2);
  color: var(--c-text);
  padding: 0 12px;
  font-size: 12.5px;
  outline: none;
  margin-bottom: 14px;
}
.fonts-preview {
  min-height: 96px;
  display: flex;
  align-items: center;
  padding: 10px 2px 18px;
  border-bottom: 1px solid var(--c-border);
  line-height: 1.25;
  word-break: break-word;
}
.fonts-section { font-size: 10.5px; letter-spacing: 0.09em; text-transform: uppercase; color: var(--c-text-mute); margin: 18px 0 8px; }
.fonts-glyphs { font-size: 20px; line-height: 1.9; color: var(--c-text); word-break: break-all; }
.fonts-glyphs.cjk { font-size: 17px; color: var(--c-text-dim); }
.fonts-scale { display: grid; gap: 6px; }
.fonts-scale-row { display: flex; align-items: baseline; gap: 14px; }
.fonts-scale-num { width: 24px; text-align: right; font-size: 10.5px; color: var(--c-text-mute); font-family: ui-monospace, monospace; }
</style>
