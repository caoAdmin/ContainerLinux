<script setup lang="ts">
/**
 * COSMIC Monitor —— 系统监视器
 * 概览（环形占用） / 进程（可排序、可结束） / 资源（实时折线）
 * 数据为程序化模拟，每秒刷新。
 */
import { computed, inject, onMounted, onUnmounted, ref } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const store = useCosmicStore()
const winId = inject<string>('cosmicWinId', '')

/* ── 导航 ── */
const tabs = [
  { id: 'overview', label: '概览', icon: 'ri-dashboard-3-line' },
  { id: 'processes', label: '进程', icon: 'ri-list-check-2' },
  { id: 'resources', label: '资源', icon: 'ri-line-chart-line' },
  { id: 'system', label: '系统', icon: 'ri-information-line' }
]
const tab = ref('overview')

/* ── 实时指标 ── */
const cpu = ref(23)
const mem = ref(48)
const disk = ref(42)
const gpu = ref(12)
const netUp = ref(9.8)
const netDown = ref(839)
const temp = ref(52)

const cpuHist = ref<number[]>(Array.from({ length: 60 }, () => 15 + Math.random() * 20))
const memHist = ref<number[]>(Array.from({ length: 60 }, () => 44 + Math.random() * 6))
const netHist = ref<number[]>(Array.from({ length: 60 }, () => 200 + Math.random() * 500))
const diskHist = ref<number[]>(Array.from({ length: 60 }, () => Math.random() * 40))

/* ── 进程表 ── */
interface Proc {
  pid: number
  name: string
  user: string
  cpu: number
  mem: number
  state: string
  icon: string
}

const seed: Array<[string, string, string]> = [
  ['cosmic-comp', 'cosmic', 'ri-layout-line'],
  ['cosmic-panel', 'cosmic', 'ri-layout-top-line'],
  ['cosmic-settings', 'cosmic', 'ri-settings-3-line'],
  ['cosmic-files', 'cosmic', 'ri-folders-line'],
  ['cosmic-term', 'cosmic', 'ri-terminal-box-line'],
  ['cosmic-store', 'cosmic', 'ri-store-3-line'],
  ['cosmic-player', 'cosmic', 'ri-play-circle-line'],
  ['cosmic-notifications', 'cosmic', 'ri-notification-3-line'],
  ['cosmic-osd', 'cosmic', 'ri-volume-up-line'],
  ['xdg-desktop-portal-cosmic', 'cosmic', 'ri-door-open-line'],
  ['firefox', 'cosmic', 'ri-firefox-line'],
  ['Xwayland', 'cosmic', 'ri-window-2-line'],
  ['pipewire', 'cosmic', 'ri-sound-module-line'],
  ['wireplumber', 'cosmic', 'ri-equalizer-line'],
  ['systemd', 'root', 'ri-server-line'],
  ['dbus-daemon', 'messagebus', 'ri-share-line'],
  ['NetworkManager', 'root', 'ri-wifi-line'],
  ['bluetoothd', 'root', 'ri-bluetooth-line'],
  ['gnome-keyring-daemon', 'cosmic', 'ri-key-2-line'],
  ['kworker/u16:3', 'root', 'ri-cpu-line'],
  ['ksoftirqd/0', 'root', 'ri-cpu-line'],
  ['nvme0n1', 'root', 'ri-hard-drive-3-line']
]

const procs = ref<Proc[]>(
  seed.map(([name, user, icon], i) => ({
    pid: 1000 + i * 37,
    name,
    user,
    cpu: name.startsWith('k') ? 0 : Math.random() * 12,
    mem: name.startsWith('k') ? 0 : 20 + Math.random() * 420,
    state: Math.random() < 0.3 ? '运行' : Math.random() < 0.7 ? '睡眠' : '空闲',
    icon
  }))
)

const procQuery = ref('')
const sortKey = ref<'cpu' | 'mem' | 'name' | 'pid'>('cpu')
const sortAsc = ref(false)
const killed = ref<string | null>(null)

const shownProcs = computed(() => {
  const k = procQuery.value.trim().toLowerCase()
  const list = procs.value.filter((p) => !k || p.name.toLowerCase().includes(k) || String(p.pid).includes(k))
  const dir = sortAsc.value ? 1 : -1
  return [...list].sort((a, b) => {
    if (sortKey.value === 'name') return a.name.localeCompare(b.name) * dir
    return ((a[sortKey.value] as number) - (b[sortKey.value] as number)) * dir
  })
})

function sortBy(key: typeof sortKey.value) {
  if (sortKey.value === key) sortAsc.value = !sortAsc.value
  else {
    sortKey.value = key
    sortAsc.value = key === 'name'
  }
}

function kill(p: Proc) {
  killed.value = `已结束进程 ${p.name} (${p.pid})`
  procs.value = procs.value.filter((x) => x.pid !== p.pid)
  window.setTimeout(() => (killed.value = null), 2400)
}

/* ── 刷新 ── */
let timer = 0
function tick() {
  const load = cpuHist.value.reduce((a, b) => a + b, 0) / cpuHist.value.length
  cpu.value = Math.max(4, Math.min(96, cpu.value + (Math.random() - 0.5) * 16 + (Math.random() - 0.5) * 6))
  mem.value = Math.max(30, Math.min(88, mem.value + (Math.random() - 0.5) * 3))
  disk.value = Math.max(2, Math.min(90, disk.value + (Math.random() - 0.5) * 12))
  gpu.value = Math.max(1, Math.min(80, gpu.value + (Math.random() - 0.5) * 20))
  netUp.value = Math.max(0.4, Math.min(90, netUp.value + (Math.random() - 0.5) * 6))
  netDown.value = Math.max(40, Math.min(1800, netDown.value + (Math.random() - 0.5) * 260))
  temp.value = Math.max(38, Math.min(82, 48 + load * 0.5 + Math.random() * 6))

  cpuHist.value = [...cpuHist.value.slice(1), cpu.value]
  memHist.value = [...memHist.value.slice(1), mem.value]
  netHist.value = [...netHist.value.slice(1), netDown.value / 20]
  diskHist.value = [...diskHist.value.slice(1), disk.value]

  procs.value.forEach((p) => {
    if (p.name.startsWith('k')) return
    p.cpu = Math.max(0, Math.min(85, p.cpu + (Math.random() - 0.5) * 4))
    p.mem = Math.max(8, p.mem + (Math.random() - 0.5) * 14)
    if (Math.random() < 0.08) p.state = p.state === '运行' ? '睡眠' : '运行'
  })
}

/* ── 图表 ── */
function pathOf(arr: number[], w: number, h: number, max: number): string {
  if (!arr.length) return ''
  const step = w / (arr.length - 1)
  return arr
    .map((v, i) => `${i === 0 ? 'M' : 'L'}${(i * step).toFixed(1)},${(h - (Math.min(v, max) / max) * h).toFixed(1)}`)
    .join(' ')
}

const cpuPath = computed(() => pathOf(cpuHist.value, 300, 70, 100))
const memPath = computed(() => pathOf(memHist.value, 300, 70, 100))
const diskPath = computed(() => pathOf(diskHist.value, 300, 70, 100))
const netPath = computed(() => pathOf(netHist.value, 300, 70, 140))

const chord = (r: number) => 2 * Math.PI * r
function dash(pct: number, r: number): string {
  const c = chord(r)
  return `${(c * pct) / 100} ${c}`
}

const uptime = ref('3 小时 42 分')
const sysRows = [
  { k: '设备名称', v: 'cosmic-pc' },
  { k: '处理器', v: 'AMD Ryzen 7 7840U · 8 核 / 16 线程 @ 5.10 GHz' },
  { k: '架构', v: 'x86_64' },
  { k: '内核', v: '6.12.0-1018-generic' },
  { k: '图形', v: 'AMD Radeon 780M (RADV PHOENIX) · Vulkan 1.3' },
  { k: '内存', v: '16 GB LPDDR5-6400' },
  { k: '交换分区', v: '4.0 GB · 已用 218 MB' },
  { k: '根分区', v: '512 GB NVMe · 已用 218 GB' },
  { k: '温度', v: 'CPU 52°C · GPU 46°C' },
  { k: '风扇', v: '2 440 RPM' }
]

onMounted(() => {
  store.setTitle(winId, 'COSMIC Monitor')
  timer = window.setInterval(tick, 1000)
})
onUnmounted(() => window.clearInterval(timer))
</script>

<template>
  <M3AppShell fabIcon="ri-refresh-line">
  <template #rail>
    <aside class="c-sidebar">
      <div class="c-side-title">系统监视器</div>
      <button
        v-for="t in tabs"
        :key="t.id"
        class="c-side-item"
        :class="{ active: tab === t.id }"
        @click="tab = t.id"
      >
        <Icon :name="t.icon" :size="16" /><span>{{ t.label }}</span>
      </button>
      <div class="cm-side-foot">
        <div class="set-progress"><i :style="{ width: cpu + '%' }" /></div>
        <span>CPU {{ Math.round(cpu) }}%</span>
      </div>
    </aside>
  </template>
  <div class="cx-root cm">
    <section class="c-main">
      <div class="c-toolbar">
        <span class="cm-title">
          <Icon name="ri-pulse-line" :size="15" color="var(--c-accent)" />
          <b>{{ tabs.find((t) => t.id === tab)?.label }}</b>
        </span>
        <span class="cm-up">运行时间 {{ uptime }}</span>
        <div class="cm-live"><i /> 实时刷新中</div>
      </div>

      <!-- 概览 -->
      <div v-if="tab === 'overview'" class="cm-body c-scroll">
        <div class="cm-rings">
          <div v-for="r in [
            { label: '处理器', val: cpu, sub: 'AMD Ryzen 7 7840U', color: 'var(--c-accent)' },
            { label: '内存', val: mem, sub: '7.7 GB / 16 GB', color: '#25c2a0' },
            { label: '磁盘', val: disk, sub: '218 GB / 512 GB', color: '#e5a50a' },
            { label: '图形', val: gpu, sub: 'Radeon 780M', color: '#e45b9c' }
          ]" :key="r.label" class="cm-ring-card">
            <svg viewBox="0 0 120 120" class="cm-ring">
              <circle cx="60" cy="60" r="48" fill="none" stroke="var(--c-surface-3)" stroke-width="11" />
              <circle
                cx="60" cy="60" r="48" fill="none"
                :stroke="r.color" stroke-width="11" stroke-linecap="round"
                :stroke-dasharray="dash(r.val, 48)"
                transform="rotate(-90 60 60)"
              />
            </svg>
            <b>{{ Math.round(r.val) }}%</b>
            <span class="cm-ring-label">{{ r.label }}</span>
            <i>{{ r.sub }}</i>
          </div>
        </div>

        <div class="cm-cards">
          <div class="cm-card">
            <div class="set-card-title">网络</div>
            <div class="cm-net">
              <span><Icon name="ri-arrow-up-line" :size="13" /> 上传</span>
              <b>{{ netUp.toFixed(1) }} KB/s</b>
            </div>
            <div class="cm-net">
              <span><Icon name="ri-arrow-down-line" :size="13" /> 下载</span>
              <b>{{ Math.round(netDown) }} KB/s</b>
            </div>
            <div class="cm-net">
              <span><Icon name="ri-wifi-line" :size="13" /> 接口</span>
              <b>wlan0 · 866 Mb/s</b>
            </div>
          </div>
          <div class="cm-card">
            <div class="set-card-title">系统负载</div>
            <div class="cm-net"><span>1 分钟</span><b>{{ (cpu / 12).toFixed(2) }}</b></div>
            <div class="cm-net"><span>5 分钟</span><b>{{ (cpu / 14).toFixed(2) }}</b></div>
            <div class="cm-net"><span>15 分钟</span><b>{{ (cpu / 16).toFixed(2) }}</b></div>
            <div class="cm-net"><span>进程数</span><b>{{ procs.length }}</b></div>
          </div>
        </div>
      </div>

      <!-- 进程 -->
      <div v-else-if="tab === 'processes'" class="cm-procs">
        <div class="cm-proc-head">
          <Icon name="ri-search-line" :size="15" color="var(--c-text-mute)" />
          <input v-model="procQuery" class="c-input" placeholder="搜索进程名或 PID…" />
          <span class="cm-count">{{ shownProcs.length }} 个进程</span>
        </div>
        <div class="cm-table c-scroll">
          <div class="cm-tr cm-th">
            <span class="cm-td-sort" @click="sortBy('pid')">PID</span>
            <span class="cm-td-sort" @click="sortBy('name')">名称</span>
            <span>用户</span>
            <span class="cm-td-sort" @click="sortBy('cpu')">CPU</span>
            <span class="cm-td-sort" @click="sortBy('mem')">内存</span>
            <span>状态</span>
            <span />
          </div>
          <div v-for="p in shownProcs" :key="p.pid" class="cm-tr">
            <span class="cm-mono">{{ p.pid }}</span>
            <span class="cm-name"><Icon :name="p.icon" :size="14" :color="'var(--c-text-dim)'" />{{ p.name }}</span>
            <span class="cm-dim">{{ p.user }}</span>
            <span class="cm-mono">
              <i class="cm-spark" :style="{ width: Math.min(100, p.cpu * 3) + '%' }" />
              {{ p.cpu.toFixed(1) }}%
            </span>
            <span class="cm-mono">{{ p.mem.toFixed(1) }} MB</span>
            <span class="cm-dim">{{ p.state }}</span>
            <span class="cm-act">
              <button class="c-iconbtn" title="结束进程" @click="kill(p)">
                <Icon name="ri-close-circle-line" :size="15" />
              </button>
            </span>
          </div>
        </div>
      </div>

      <!-- 资源 -->
      <div v-else-if="tab === 'resources'" class="cm-body c-scroll">
        <div class="cm-chart">
          <div class="cm-chart-head"><b>CPU 使用率</b><span>{{ Math.round(cpu) }}%</span></div>
          <svg viewBox="0 0 300 70" preserveAspectRatio="none" class="cm-svg">
            <path :d="cpuPath" fill="none" stroke="var(--c-accent)" stroke-width="2" />
          </svg>
        </div>
        <div class="cm-chart">
          <div class="cm-chart-head"><b>内存占用</b><span>{{ Math.round(mem) }}%</span></div>
          <svg viewBox="0 0 300 70" preserveAspectRatio="none" class="cm-svg">
            <path :d="memPath" fill="none" stroke="#25c2a0" stroke-width="2" />
          </svg>
        </div>
        <div class="cm-chart">
          <div class="cm-chart-head"><b>磁盘 I/O</b><span>{{ Math.round(disk) }}%</span></div>
          <svg viewBox="0 0 300 70" preserveAspectRatio="none" class="cm-svg">
            <path :d="diskPath" fill="none" stroke="#e5a50a" stroke-width="2" />
          </svg>
        </div>
        <div class="cm-chart">
          <div class="cm-chart-head"><b>网络下载</b><span>{{ Math.round(netDown) }} KB/s</span></div>
          <svg viewBox="0 0 300 70" preserveAspectRatio="none" class="cm-svg">
            <path :d="netPath" fill="none" stroke="#e45b9c" stroke-width="2" />
          </svg>
        </div>
      </div>

      <!-- 系统信息 -->
      <div v-else class="cm-body c-scroll">
        <div class="set-card">
          <div v-for="r in sysRows" :key="r.k" class="set-kv"><span>{{ r.k }}</span><b>{{ r.v }}</b></div>
        </div>
      </div>

      <Transition name="cm-toast">
        <div v-if="killed" class="cm-toast">
          <Icon name="ri-checkbox-circle-fill" :size="15" /> {{ killed }}
        </div>
      </Transition>
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.cm {
  position: relative;
}
.cm-side-foot {
  margin-top: auto;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 7px;
  font-size: 11px;
  color: var(--c-text-mute);
}
.cm-title {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 13.5px;
}
.cm-up {
  font-size: 11.5px;
  color: var(--c-text-mute);
  margin-left: 12px;
}
.cm-live {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 11.5px;
  color: var(--c-text-mute);
}
.cm-live i {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #2ec27e;
  animation: cm-blink 1.4s ease-in-out infinite;
}
@keyframes cm-blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.28; }
}

.cm-body {
  flex: 1;
  min-height: 0;
  padding: 16px;
}
.cm-rings {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 12px;
}
.cm-ring-card {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 16px 12px 14px;
  border-radius: 14px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border);
}
.cm-ring {
  width: 116px;
  height: 116px;
}
.cm-ring-card b {
  position: absolute;
  top: 68px;
  font-size: 22px;
  font-variant-numeric: tabular-nums;
}
.cm-ring-card .cm-ring-label {
  font-size: 13px;
  font-weight: 600;
  margin-top: 4px;
}
.cm-ring-card i {
  font-style: normal;
  font-size: 11px;
  color: var(--c-text-mute);
}
.cm-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 12px;
  margin-top: 12px;
}
.cm-card {
  border-radius: 14px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border);
  padding: 4px 16px 10px;
}
.cm-net {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 9px 0;
  border-bottom: 1px solid var(--c-border);
  font-size: 13px;
}
.cm-net:last-child {
  border-bottom: none;
}
.cm-net span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--c-text-mute);
  font-size: 12px;
}

.cm-procs {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
}
.cm-proc-head {
  flex: none;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 9px 14px;
  border-bottom: 1px solid var(--c-border);
}
.cm-proc-head .c-input {
  flex: 1;
  max-width: 300px;
  height: 30px;
}
.cm-count {
  margin-left: auto;
  font-size: 11.5px;
  color: var(--c-text-mute);
}
.cm-table {
  flex: 1;
  min-height: 0;
  padding: 4px 8px 12px;
}
.cm-tr {
  display: grid;
  grid-template-columns: 74px minmax(0, 2fr) 96px 136px 108px 66px 40px;
  align-items: center;
  gap: 10px;
  height: 34px;
  padding: 0 10px;
  border-radius: 8px;
  font-size: 12.5px;
}
.cm-tr:hover {
  background: var(--c-hover);
}
.cm-th {
  height: 28px;
  color: var(--c-text-mute);
  font-size: 11px;
  font-weight: 600;
  position: sticky;
  top: 0;
  background: var(--c-surface);
  z-index: 2;
}
.cm-td-sort {
  cursor: pointer;
}
.cm-td-sort:hover {
  color: var(--c-text);
}
.cm-mono {
  font-variant-numeric: tabular-nums;
  font-family: 'JetBrains Mono', Consolas, monospace;
  font-size: 12px;
  display: inline-flex;
  align-items: center;
  gap: 7px;
}
.cm-name {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.cm-dim {
  color: var(--c-text-mute);
  font-size: 11.5px;
}
.cm-spark {
  height: 5px;
  border-radius: 3px;
  background: var(--c-accent);
  max-width: 40px;
  min-width: 2px;
}
.cm-act {
  display: flex;
  justify-content: flex-end;
}

.cm-chart {
  border-radius: 14px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border);
  padding: 12px 16px 8px;
  margin-bottom: 12px;
}
.cm-chart-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  margin-bottom: 6px;
}
.cm-chart-head span {
  color: var(--c-text-dim);
  font-variant-numeric: tabular-nums;
}
.cm-svg {
  width: 100%;
  height: 74px;
  background: var(--c-surface-3);
  border-radius: 9px;
}

.cm-toast {
  position: absolute;
  left: 50%;
  bottom: 18px;
  transform: translateX(-50%);
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 36px;
  padding: 0 16px;
  border-radius: 18px;
  background: var(--c-surface-3);
  border: 1px solid var(--c-border-strong);
  box-shadow: 0 10px 30px var(--c-shadow);
  font-size: 12.5px;
  color: var(--c-text);
}
.cm-toast-enter-active,
.cm-toast-leave-active {
  transition: opacity 0.18s ease, transform 0.18s ease;
}
.cm-toast-enter-from,
.cm-toast-leave-to {
  opacity: 0;
  transform: translate(-50%, 10px);
}
</style>
