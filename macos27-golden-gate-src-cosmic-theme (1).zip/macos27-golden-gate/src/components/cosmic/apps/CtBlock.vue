<script setup lang="ts">
/**
 * CtBlock —— ContainerLinux 系统应用的通用小部件渲染器
 * 静态小部件：hero / kpis / cards / toggles / segments / progress / timeline / table /
 *           bars / nodes / logs / code / chips / steps / callout / rings / spark
 * 交互型小部件：review（时间轴回滚） / swarm（蜂群管理） / chat（对话助手）
 * CT AI 契约演示（§12）：lifecycle / tiers / importer / wake / agent
 * 全部走 --c-* 设计令牌，随桌面主题实时联动。
 */
import { computed, inject, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import Icon from '@/components/common/Icon.vue'
import type { CtBlock as CtBlockT } from '@/data/ct/ctTypes'
import { useCtAIStore, type CtPhase, type CtTier } from '@/stores/ctai'
import { useCosmicStore } from '@/stores/cosmic'

const props = defineProps<{ block: CtBlockT }>()
const ctConfirm = inject<(o: any) => Promise<boolean>>('ctConfirm')
const ctToast = inject<(m: string) => void>('ctToast')
const ctai = useCtAIStore()
const cosmic = useCosmicStore()

const TONES = ['blue', 'teal', 'violet', 'amber', 'orange', 'green', 'pink', 'cyan', 'red', 'accent', 'good', 'warn', 'bad', 'info']
function toneClass(t?: string): string {
  return `tone-${TONES.includes(t || '') ? t : 'blue'}`
}

/* ── 静态交互状态 ── */
const toggles = ref<Record<number, boolean>>({})
const segment = ref('')
watch(
  () => props.block,
  (b) => {
    const next: Record<number, boolean> = {}
    ;(b.items || []).forEach((it: any, i: number) => {
      if (typeof it?.on === 'boolean') next[i] = it.on
    })
    toggles.value = next
    segment.value = b.value || (b.options || [])[0] || ''
  },
  { immediate: true }
)

/* ── spark 折线 ── */
const sparkPoints = computed(() => {
  const pts: number[] = props.block.points || [12, 26, 19, 34, 28, 44, 38, 52, 47, 61]
  const max = Math.max(...pts, 1)
  const min = Math.min(...pts, 0)
  const span = max - min || 1
  return pts.map((v, i) => `${(i / (pts.length - 1)) * 100},${40 - ((v - min) / span) * 34}`).join(' ')
})

/* ── 环形进度 ── */
function ringDash(pct: number): string {
  const c = 2 * Math.PI * 26
  return `${(Math.max(0, Math.min(100, pct)) / 100) * c} ${c}`
}

/* ══════════════════ 交互型：时间轴回滚 ════════════════ */
const rvCurrent = ref('live')
const rvBusy = ref(false)
const rvProgress = ref(0)
const rvLogs = ref<Array<{ t: string; text: string }>>([])
watch(
  () => props.block,
  (b) => {
    if (b.t === 'review') {
      rvCurrent.value = b.current || (b.snapshots?.[0]?.id) || 'live'
      rvBusy.value = false
      rvProgress.value = 0
      rvLogs.value = []
    }
  },
  { immediate: true }
)
async function rollbackTo(s: any) {
  if (rvBusy.value || s.id === rvCurrent.value) return
  const ok = await (ctConfirm?.({ title: '回滚到该状态', text: `将把系统回滚到「${s.label}」(${s.date})。回滚后当前增量层会被替换，确认继续？`, confirmLabel: '回滚', cancelLabel: '取消' }) ?? Promise.resolve(false))
  if (!ok) return
  rvBusy.value = true
  rvProgress.value = 0
  const timer = window.setInterval(() => {
    rvProgress.value = Math.min(100, rvProgress.value + 12)
    if (rvProgress.value >= 100) {
      window.clearInterval(timer)
      rvBusy.value = false
      rvCurrent.value = s.id
      const now = new Date()
      rvLogs.value.unshift({ t: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`, text: `回滚 → ${s.label} (${s.date})` })
      ctToast?.('已回滚到 ' + s.label)
    }
  }, 90)
}

/* ══════════════════ 交互型：蜂群管理 ════════════════ */
const swNodes = ref<any[]>([])
const swTasks = ref<any[]>([])
const swNewTask = ref('')
const swNewNode = ref('')
watch(
  () => props.block,
  (b) => {
    if (b.t === 'swarm') {
      swNodes.value = (b.nodes || []).map((n: any) => ({ ...n }))
      swTasks.value = (b.tasks || []).map((t: any) => ({ ...t }))
    }
  },
  { immediate: true }
)
let swTimer = 0
onMounted(() => {
  swTimer = window.setInterval(() => {
    swTasks.value.forEach((t) => {
      if (t.status === 'running' && t.progress < 100) {
        t.progress = Math.min(100, t.progress + Math.floor(Math.random() * 7) + 2)
        if (t.progress >= 100) t.status = 'done'
      }
    })
  }, 900)
})
onBeforeUnmount(() => window.clearInterval(swTimer))

function setQueen(node: any) {
  swNodes.value.forEach((n) => (n.isQueen = n === node))
  ctToast?.(`已将「${node.name}」设为蜂后（协调节点）`)
}
function toggleNode(node: any) {
  if (node.status === 'offline') node.status = 'online'
  else if (node.status === 'online') node.status = 'idle'
  else node.status = 'offline'
}
function addTask() {
  const name = swNewTask.value.trim()
  if (!name) return
  const online = swNodes.value.filter((n) => n.status === 'online' && !n.isQueen)
  swTasks.value.unshift({ name, node: online[0]?.name || '本机', progress: 0, status: 'running' })
  swNewTask.value = ''
  ctToast?.('已提交蜂群任务：' + name)
}
function cancelTask(t: any) {
  swTasks.value = swTasks.value.filter((x) => x !== t)
}
function addNode() {
  const ip = swNewNode.value.trim()
  if (!ip) return
  swNodes.value.push({ name: '新节点 ' + ip, role: '算力', status: 'online', ip })
  swNewNode.value = ''
  ctToast?.('已加入节点 ' + ip)
}

/* ══════════════════ 交互型：对话助手 ════════════════ */
const chatMsgs = ref<Array<{ role: 'user' | 'bot'; text: string }>>([])
const chatInput = ref('')
const chatBusy = ref(false)
const chatBox = ref<HTMLElement | null>(null)
watch(
  () => props.block,
  (b) => {
    if (b.t === 'chat') {
      chatMsgs.value = [{ role: 'bot', text: '你好，我是 CTclaw —— ContainerLinux 的零常驻系统智慧助手。问我系统状态、蜂群、回滚、网络都可以，也能帮你执行一些模拟操作。' }]
      chatInput.value = ''
    }
  },
  { immediate: true }
)
function scrollChat() {
  nextTick(() => chatBox.value?.scrollTo({ top: chatBox.value.scrollHeight, behavior: 'smooth' }))
}
function reply(text: string): string {
  const q = text.toLowerCase()
  if (/(你好|hi|hello|在吗)/.test(q)) return '在的。需要我帮你查看系统状态、调度蜂群任务，还是解释某个 ContainerLinux 子系统？'
  if (/(模式|性能|省电|过载|专注)/.test(q)) return '系统当前为「标准模式」。十种模式通过 Ctrl+Alt+ 组合键切换：O 过载（全核锁频）、S 超级省电（单核 400MHz）、F 专注（屏蔽通知）。我可以帮你切换到某个模式（这是模拟操作）。'
  if (/(内存|优化|oom|swap|回收)/.test(q)) return '已模拟执行内存优化：触发 MGLRU 回收 + zswap 压缩，预计释放约 1.4GB。当前内存预算使用率从 62% 降到 48%。（演示）'
  if (/(蜂群|节点|设备|互联|协同)/.test(q)) {
    const on = swNodes.value.filter((n) => n.status === 'online').length
    const qn = swNodes.value.find((n) => n.isQueen)
    return `蜂群当前有 ${on} 个在线节点，蜂后为「${qn?.name || '本机'}」。可以连接/断开节点、设为蜂后或提交分布式任务。`
  }
  if (/(回滚|快照|回溯|出厂|时间线)/.test(q)) return '时间回溯基于 Btrfs 快照链：快照是引用而非复制，创建几乎零成本。打开「时间回溯」应用，点击任意快照节点即可回滚到该状态（演示）。'
  if (/(网络|下载|wifi|dns|vpn|p2p)/.test(q)) return '网络由 ct-netd 接管：wlan0 已连接（−42dBm），ct-resolved 启用 DoT 防旁路，下载引擎支持多线程分片与蜂群加速。'
  if (/(内核|ct-kernel|档位|ctk)/.test(q)) return 'CT-Kernel 为通用内核双档：ctk-old（v1 基线）、ctk-new（v3/v4/znver4 优化）。开机由 smart-tune 按 CPU 判档自动选择。'
  if (/(能做什么|帮助|功能|你会)/.test(q)) return '我能：①解答 ContainerLinux 各子系统；②报告实时系统状态；③模拟执行模式切换 / 内存优化 / 快照回滚 / 蜂群调度；④帮你打开对应应用。'
  if (/(谢谢|感谢|thanks)/.test(q)) return '不客气，随时叫我。'
  return '我已经记下这个问题。作为本地零常驻助手，我基于 ContainerLinux 文档知识作答；涉及具体执行的操作我会以模拟方式演示。你还可以试试问我「当前系统模式」「有哪些蜂群节点在线」或「如何回滚到出厂基线」。'
}
async function sendChat() {
  const text = chatInput.value.trim()
  if (!text || chatBusy.value) return
  chatMsgs.value.push({ role: 'user', text })
  chatInput.value = ''
  chatBusy.value = true
  scrollChat()
  await new Promise((r) => setTimeout(r, 480))
  chatMsgs.value.push({ role: 'bot', text: reply(text) })
  chatBusy.value = false
  scrollChat()
}
function sendHint(h: string) {
  chatInput.value = h
  sendChat()
}

/* ══════════════════ CT AI 契约演示（§12） ════════════════ */

/** toggles 可选二次确认：给 skills 页高风险项用 */
async function onToggle(it: any, i: number) {
  if (!toggles.value[i] && it.confirm) {
    const ok = await (ctConfirm?.({ title: '启用高风险技能？', text: it.confirm, confirmLabel: '仍要启用', cancelLabel: '取消' }) ?? Promise.resolve(false))
    if (!ok) return
  }
  toggles.value[i] = !toggles.value[i]
}

/* ── lifecycle：零常驻状态机 ── */
const lcPhase = computed(() => ctai.phase)
const lcMem = computed(() => ctai.memMB)
function lcPick(p: CtPhase) { ctai.setPhase(p) }

/* ── tiers：五层路由 ── */
const trTier = computed(() => ctai.tier)
const trPrivacy = computed(() => ctai.privacyText)
const trLocal = computed(() => ctai.isLocalTier)
function trPick(t: CtTier, canDefault: boolean) {
  if (!canDefault) {
    ctToast?.('free-web 默认关闭 · 永不抢默认位（演示）')
    return
  }
  ctai.setTier(t)
}

/* ── importer：一键填入 ── */
const imState = computed(() => ctai.importState)
function imApply() {
  ctai.applyImport(props.block.sample || {})
}
function imKey(e: Event) {
  ctai.setKey((e.target as HTMLInputElement).value)
}

/* ── wake：长按空格演示 ── */
const wkActive = computed(() => ctai.wake.active)
const wkProgress = computed(() => ctai.wake.progress)
const wkDone = computed(() => ctai.phase === 'ready' || ctai.phase === 'deep')
let wkTimer = 0
function wkDown() {
  if (wkDone.value) return
  ctai.startWake()
  window.clearInterval(wkTimer)
  wkTimer = window.setInterval(() => {
    if (ctai.wake.progress >= 100) {
      window.clearInterval(wkTimer)
      wkFire()
    }
  }, 120)
}
function wkUp() {
  window.clearInterval(wkTimer)
  if (!wkDone.value) ctai.cancelWake()
}
function wkFire() {
  window.clearInterval(wkTimer)
  ctai.wakeUp()
  cosmic.openApp('ct-claw') // 单例 → 已开则聚焦
  ctToast?.('已唤醒 CTclaw · 本地模型 400MB（演示）')
}

/* ── agent：大馒头 → 小馒头 ── */
const agTasks = computed(() => ctai.tasks)
const agRunning = computed(() => ctai.runningCount)
const agHas = computed(() => ctai.tasks.length > 0)
function agStart() {
  const subs = (props.block.subtasks || []).map((s: any) => ({ name: s.name, weight: s.weight }))
  ctai.startAgent(props.block.parent || '大馒头', subs)
  ctToast?.('大馒头已派出 ' + subs.length + ' 个小馒头（演示）')
}
function agCancel() { ctai.cancelAgent() }

onBeforeUnmount(() => window.clearInterval(wkTimer))

// 这些事件处理器仅由模板引用。vue-tsc 在 build 模式下对模板引用的识别存在偶发漏判，
// 这里显式暴露，确保 noUnusedLocals 不会误报，同时不影响运行期行为。
defineExpose({
  rollbackTo,
  setQueen,
  toggleNode,
  addTask,
  cancelTask,
  addNode,
  sendHint,
  sendChat,
  onToggle,
  lcPick,
  trPick,
  imApply,
  imKey,
  wkDown,
  wkUp,
  agStart,
  agCancel,
})
</script>

<template>
  <section class="ctb" :class="[`ctb--${block.t}`, toneClass(block.tone)]">
    <!-- 标题栏 -->
    <header v-if="block.title && !['hero', 'review', 'swarm', 'chat', 'lifecycle', 'tiers', 'importer', 'wake', 'agent'].includes(block.t)" class="ctb-head">
      <div class="ctb-title">{{ block.title }}</div>
      <div v-if="block.sub" class="ctb-sub">{{ block.sub }}</div>
    </header>

    <!-- hero -->
    <div v-if="block.t === 'hero'" class="hero">
      <div class="hero-icon"><Icon :name="block.icon || 'ri-planet-line'" :size="30" /></div>
      <div class="hero-main">
        <div v-if="block.badge" class="hero-badge">{{ block.badge }}</div>
        <h2 class="hero-title">{{ block.title }}</h2>
        <p class="hero-desc">{{ block.desc }}</p>
      </div>
      <div class="hero-glow" />
    </div>

    <!-- kpis -->
    <div v-else-if="block.t === 'kpis'" class="kpis">
      <div v-for="(it, i) in block.items || []" :key="i" class="kpi" :class="toneClass(it.tone)">
        <div class="kpi-v">{{ it.v }}<span v-if="it.unit" class="kpi-u">{{ it.unit }}</span></div>
        <div class="kpi-l">{{ it.label }}</div>
      </div>
    </div>

    <!-- cards -->
    <div v-else-if="block.t === 'cards'" class="cards">
      <article v-for="(it, i) in block.items || []" :key="i" class="card" :class="toneClass(it.tone)">
        <div class="card-top">
          <span class="card-ic"><Icon :name="it.icon || 'ri-box-3-line'" :size="18" /></span>
          <span v-if="it.badge" class="card-badge">{{ it.badge }}</span>
        </div>
        <h3 class="card-title">{{ it.title }}</h3>
        <p class="card-desc">{{ it.desc }}</p>
        <div v-if="it.tags?.length" class="card-tags">
          <span v-for="(tg, k) in it.tags" :key="k" class="tag">{{ tg }}</span>
        </div>
      </article>
    </div>

    <!-- toggles -->
    <div v-else-if="block.t === 'toggles'" class="toggles">
      <button
        v-for="(it, i) in block.items || []"
        :key="i"
        class="tog"
        :class="[toneClass(it.tone), { off: !toggles[i] }]"
        type="button"
        @click="onToggle(it, i)"
      >
        <span class="tog-txt">
          <span class="tog-l">{{ it.label }}</span>
          <span v-if="it.desc" class="tog-d">{{ it.desc }}</span>
        </span>
        <span class="tog-sw"><i /></span>
      </button>
    </div>

    <!-- segments -->
    <div v-else-if="block.t === 'segments'" class="segments">
      <div class="seg-row">
        <button
          v-for="(op, i) in block.options || []"
          :key="i"
          class="seg"
          :class="{ on: segment === op }"
          type="button"
          @click="segment = op"
        >{{ op }}</button>
      </div>
      <div v-if="block.hint" class="seg-hint">{{ block.hint }}</div>
    </div>

    <!-- progress -->
    <div v-else-if="block.t === 'progress'" class="progress">
      <div v-for="(it, i) in block.items || []" :key="i" class="pr" :class="toneClass(it.tone)">
        <div class="pr-top">
          <span class="pr-l">{{ it.label }}</span>
          <span class="pr-p">{{ it.pct }}%</span>
        </div>
        <div class="pr-track"><div class="pr-fill" :style="{ width: `${it.pct}%` }" /></div>
        <div class="pr-meta"><span>{{ it.sub }}</span><span>{{ it.meta }}</span></div>
      </div>
    </div>

    <!-- timeline（静态） -->
    <div v-else-if="block.t === 'timeline'" class="timeline">
      <div v-for="(it, i) in block.items || []" :key="i" class="tl" :class="toneClass(it.tone)">
        <div class="tl-rail"><span class="tl-dot" /></div>
        <div class="tl-body">
          <div class="tl-time">{{ it.time }}</div>
          <div class="tl-title">{{ it.title }}</div>
          <div v-if="it.desc" class="tl-desc">{{ it.desc }}</div>
        </div>
      </div>
    </div>

    <!-- table -->
    <div v-else-if="block.t === 'table'" class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th v-for="(c, i) in block.cols || []" :key="i">{{ c }}</th></tr></thead>
        <tbody>
          <tr v-for="(r, i) in block.rows || []" :key="i">
            <td v-for="(cell, k) in r" :key="k" :class="{ first: k === 0 }">{{ cell }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- bars -->
    <div v-else-if="block.t === 'bars'" class="bars">
      <div v-for="(it, i) in block.items || []" :key="i" class="bar" :class="toneClass(it.tone)">
        <span class="bar-l">{{ it.label }}</span>
        <span class="bar-track"><span class="bar-fill" :style="{ width: `${it.pct}%` }" /></span>
        <span class="bar-p">{{ it.pct }}</span>
      </div>
    </div>

    <!-- nodes（静态） -->
    <div v-else-if="block.t === 'nodes'" class="nodes">
      <div v-if="block.center" class="node-center">{{ block.center }}</div>
      <div class="node-grid">
        <div v-for="(it, i) in block.items || []" :key="i" class="node" :class="toneClass(it.tone)">
          <span class="node-l">{{ it.label }}</span>
          <span v-if="it.sub" class="node-s">{{ it.sub }}</span>
        </div>
      </div>
    </div>

    <!-- logs（静态） -->
    <div v-else-if="block.t === 'logs'" class="logs">
      <div v-for="(l, i) in block.lines || []" :key="i" class="lg" :class="toneClass(l.tone)">
        <span class="lg-t">{{ l.t }}</span><span class="lg-x">{{ l.text }}</span>
      </div>
    </div>

    <!-- code -->
    <div v-else-if="block.t === 'code'" class="code">
      <div class="code-bar"><span class="code-dots"><i /><i /><i /></span><span class="code-lang">{{ block.lang || 'text' }}</span></div>
      <pre><code>{{ block.code }}</code></pre>
    </div>

    <!-- chips -->
    <div v-else-if="block.t === 'chips'" class="chips">
      <span v-for="(c, i) in block.items || []" :key="i" class="chip">{{ c }}</span>
    </div>

    <!-- steps -->
    <div v-else-if="block.t === 'steps'" class="steps">
      <div v-for="(it, i) in block.items || []" :key="i" class="stp" :class="toneClass(it.tone)">
        <div class="stp-n">{{ it.n }}</div>
        <div class="stp-body">
          <div class="stp-t">{{ it.title }}</div>
          <div v-if="it.desc" class="stp-d">{{ it.desc }}</div>
        </div>
      </div>
    </div>

    <!-- callout -->
    <div v-else-if="block.t === 'callout'" class="callout" :class="toneClass(block.tone)">
      <span class="co-ic"><Icon :name="block.tone === 'bad' || block.tone === 'warn' ? 'ri-error-warning-line' : 'ri-information-line'" :size="17" /></span>
      <div class="co-body">
        <div v-if="block.title" class="co-t">{{ block.title }}</div>
        <div class="co-x">{{ block.text }}</div>
      </div>
    </div>

    <!-- rings -->
    <div v-else-if="block.t === 'rings'" class="rings">
      <div v-for="(it, i) in block.items || []" :key="i" class="rg" :class="toneClass(it.tone)">
        <svg viewBox="0 0 64 64" class="rg-svg">
          <circle cx="32" cy="32" r="26" class="rg-bg" />
          <circle cx="32" cy="32" r="26" class="rg-fg" :stroke-dasharray="ringDash(it.pct)" />
        </svg>
        <div class="rg-num">{{ it.pct }}<small>%</small></div>
        <div class="rg-l">{{ it.label }}</div>
      </div>
    </div>

    <!-- spark -->
    <div v-else-if="block.t === 'spark'" class="spark">
      <svg viewBox="0 0 100 44" preserveAspectRatio="none" class="sp-svg">
        <polyline :points="sparkPoints" class="sp-line" />
      </svg>
      <div v-if="block.center" class="sp-c">{{ block.center }} <small>{{ block.unit }}</small></div>
    </div>

    <!-- ════════ 交互型：时间轴回滚 ════════ -->
    <div v-else-if="block.t === 'review'" class="review">
      <div class="ctb-head">
        <div class="ctb-title">{{ block.title }}</div>
        <div v-if="block.sub" class="ctb-sub">{{ block.sub }}</div>
      </div>
      <div class="rv-now">
        <div class="rv-now-l">
          <span class="rv-now-k">当前状态</span>
          <span class="rv-now-v">{{ (block.snapshots || []).find((s: any) => s.id === rvCurrent)?.label || '当前增量层' }}</span>
        </div>
        <span class="rv-now-badge"><i />运行中</span>
      </div>

      <ol class="rv-list">
        <li v-for="s in block.snapshots || []" :key="s.id" class="rv-i" :class="[s.id === rvCurrent ? 'on' : '', toneClass(s.tone)]">
          <div class="rv-dot" />
          <div class="rv-info">
            <div class="rv-d">{{ s.date }}</div>
            <div class="rv-l">{{ s.label }}</div>
            <div class="rv-meta"><span class="rv-tag">{{ s.type }}</span><span v-if="s.size">{{ s.size }}</span></div>
          </div>
          <button
            v-if="s.id !== rvCurrent && !rvBusy"
            class="rv-rollback"
            type="button"
            @click="rollbackTo(s)"
          >回滚到此</button>
          <span v-else-if="s.id === rvCurrent" class="rv-cur"><i />当前</span>
          <span v-else class="rv-cur rv-wait">回滚中…</span>
        </li>
      </ol>

      <div v-if="rvBusy" class="rv-prog"><div class="rv-prog-f" :style="{ width: rvProgress + '%' }" /></div>

      <div v-if="rvLogs.length" class="rv-logs">
        <div class="rv-logs-h">回滚记录</div>
        <div v-for="(l, i) in rvLogs" :key="i" class="rv-log"><span class="rv-log-t">{{ l.t }}</span><span>{{ l.text }}</span></div>
      </div>
    </div>

    <!-- ════════ 交互型：蜂群管理 ════════ -->
    <div v-else-if="block.t === 'swarm'" class="swarm">
      <div class="ctb-head">
        <div class="ctb-title">{{ block.title }}</div>
        <div v-if="block.sub" class="ctb-sub">{{ block.sub }}</div>
      </div>

      <div class="sw-sec-h"><Icon name="ri-team-line" :size="14" /> 节点（{{ swNodes.filter((n) => n.status === 'online').length }} 在线 / {{ swNodes.length }}）</div>
      <div class="sw-nodes">
        <div v-for="(n, i) in swNodes" :key="i" class="sw-node" :class="{ offline: n.status === 'offline', queen: n.isQueen }">
          <div class="sw-node-top">
            <span class="sw-node-name"><Icon :name="n.isQueen ? 'ri-crown-line' : 'ri-server-line'" :size="15" />{{ n.name }}</span>
            <span class="sw-node-st" :class="n.status"><i />{{ n.status === 'online' ? '在线' : n.status === 'idle' ? '空闲' : '离线' }}</span>
          </div>
          <div class="sw-node-meta">{{ n.role }} · {{ n.ip }}</div>
          <div class="sw-node-btns">
            <button v-if="n.status !== 'offline'" class="sw-btn" type="button" @click="toggleNode(n)">{{ n.status === 'online' ? '断开' : '唤醒' }}</button>
            <button v-else class="sw-btn" type="button" @click="toggleNode(n)">连接</button>
            <button v-if="!n.isQueen" class="sw-btn sw-btn-ok" type="button" @click="setQueen(n)">设为蜂后</button>
            <span v-else class="sw-btn sw-queen-tag"><i />蜂后</span>
          </div>
        </div>
      </div>

      <div class="sw-sec-h"><Icon name="ri-task-line" :size="14" /> 任务队列（{{ swTasks.filter((t) => t.status === 'running').length }} 进行中）</div>
      <div class="sw-tasks">
        <div v-for="(t, i) in swTasks" :key="i" class="sw-task" :class="{ done: t.status === 'done' }">
          <div class="sw-task-top">
            <span class="sw-task-name">{{ t.name }}</span>
            <span class="sw-task-node">{{ t.node }}</span>
            <button v-if="t.status === 'running'" class="sw-btn sw-btn-x" type="button" @click="cancelTask(t)">取消</button>
            <span v-else class="sw-task-done"><i />完成</span>
          </div>
          <div class="sw-task-track"><div class="sw-task-f" :style="{ width: (t.status === 'done' ? 100 : t.progress) + '%' }" /></div>
        </div>
        <div v-if="!swTasks.length" class="sw-empty">暂无任务</div>
      </div>

      <div class="sw-add">
        <input v-model="swNewTask" class="sw-input" placeholder="提交分布式任务，如：渲染分发 4K 视频" @keyup.enter="addTask" />
        <button class="sw-btn sw-btn-ok" type="button" @click="addTask">提交</button>
      </div>
      <div class="sw-add">
        <input v-model="swNewNode" class="sw-input" placeholder="加入节点 IP，如：192.168.1.99" @keyup.enter="addNode" />
        <button class="sw-btn sw-btn-ok" type="button" @click="addNode">加入</button>
      </div>
    </div>

    <!-- ════════ 交互型：对话助手 ════════ -->
    <div v-else-if="block.t === 'chat'" class="chat">
      <div class="ctb-head">
        <div class="ctb-title">{{ block.title }}</div>
        <div v-if="block.sub" class="ctb-sub">{{ block.sub }}</div>
      </div>
      <div ref="chatBox" class="chat-box">
        <div v-for="(m, i) in chatMsgs" :key="i" class="chat-msg" :class="m.role">
          <div class="chat-av"><Icon :name="m.role === 'bot' ? 'ri-robot-line' : 'ri-user-line'" :size="14" /></div>
          <div class="chat-bubble">{{ m.text }}</div>
        </div>
        <div v-if="chatBusy" class="chat-msg bot"><div class="chat-av"><Icon name="ri-robot-line" :size="14" /></div><div class="chat-bubble chat-typing"><i /><i /><i /></div></div>
      </div>
      <div v-if="block.hints?.length" class="chat-hints">
        <button v-for="(h, i) in block.hints" :key="i" class="chat-hint" type="button" @click="sendHint(h)">{{ h }}</button>
      </div>
      <div class="chat-input">
        <input v-model="chatInput" class="chat-field" placeholder="问点什么，或点上方提示…" @keyup.enter="sendChat" />
        <button class="chat-send" type="button" :disabled="!chatInput.trim() || chatBusy" @click="sendChat"><Icon name="ri-send-plane-2-line" :size="16" /></button>
      </div>
    </div>

    <!-- ════════ CT AI：零常驻状态机 lifecycle ════════ -->
    <div v-else-if="block.t === 'lifecycle'" class="ct-ai lifecycle">
      <div class="ai-head">
        <div>
          <div class="ai-title">{{ block.title }}</div>
          <div class="ai-sub">{{ block.sub }}</div>
        </div>
        <div class="ai-shell"><i />~{{ block.shellMB || 10 }}MB 调度外壳常驻</div>
      </div>
      <div class="lc-mem">
        <span class="lc-mem-num">{{ lcMem }}</span><span class="lc-mem-u">MB 模型进程</span>
        <span v-if="lcPhase === 'loading'" class="lc-mem-tag">加载中…</span>
      </div>
      <div class="lc-track">
        <button
          v-for="p in block.phases || []"
          :key="p.id"
          type="button"
          class="lc-node"
          :class="[`tone-${['blue','teal','violet','amber','green'].includes(p.tone) ? p.tone : 'blue'}`, { on: lcPhase === p.id }]"
          @click="lcPick(p.id)"
        >
          <span class="lc-dot"><i /></span>
          <span class="lc-l">{{ p.label }}</span>
          <span class="lc-mem-s">{{ p.mem }}</span>
          <span class="lc-d">{{ p.desc }}</span>
        </button>
      </div>
      <div v-if="block.note" class="ai-note"><Icon name="ri-information-line" :size="14" />{{ block.note }}</div>
    </div>

    <!-- ════════ CT AI：五层路由 tiers ════════ -->
    <div v-else-if="block.t === 'tiers'" class="ct-ai tiers">
      <div class="ai-head">
        <div>
          <div class="ai-title">{{ block.title }}</div>
          <div class="ai-sub">{{ block.sub }}</div>
        </div>
        <div class="ai-cur">当前：<b>{{ ctai.tierLabel }}</b></div>
      </div>
      <div class="tr-list">
        <button
          v-for="t in block.tiers || []"
          :key="t.id"
          type="button"
          class="tr-row"
          :class="[`tone-${['good','blue','teal','violet','warn'].includes(t.tone) ? t.tone : 'blue'}`, { on: trTier === t.id }]"
          @click="trPick(t.id, t.canDefault)"
        >
          <span class="tr-radio"><i /></span>
          <span class="tr-body">
            <span class="tr-t">{{ t.label }} <em v-if="t.defaultOn" class="tr-def">默认</em></span>
            <span class="tr-d">{{ t.desc }}</span>
          </span>
          <span class="tr-priv" :class="t.privacy === 'local' ? 'priv-local' : 'priv-cloud'">
            <Icon :name="t.privacy === 'local' ? 'ri-shield-check-line' : 'ri-upload-cloud-2-line'" :size="13" />
            {{ t.dest }}
          </span>
        </button>
      </div>
      <div class="tr-banner" :class="trLocal ? 'priv-local' : 'priv-cloud'">
        <Icon :name="trLocal ? 'ri-shield-check-line' : 'ri-error-warning-line'" :size="16" />
        <span>{{ ctai.tierLabel }} · {{ trPrivacy }}</span>
      </div>
    </div>

    <!-- ════════ CT AI：CT优选导入 importer ════════ -->
    <div v-else-if="block.t === 'importer'" class="ct-ai importer">
      <div class="ai-head">
        <div>
          <div class="ai-title">{{ block.title }}</div>
          <div class="ai-sub">{{ block.sub }} · {{ block.spec }}</div>
        </div>
      </div>
      <div class="im-card">
        <div class="im-prov"><Icon name="ri-links-line" :size="16" />{{ block.sample?.label || block.sample?.provider }}</div>
        <div class="im-hint">CT优选已验证该接入点可用，但你的 API key 仅你自己持有，CT优选与 CTclaw 都不会上传或查看它。</div>
        <label class="im-field">
          <span>endpoint</span>
          <input :value="imState.endpoint" readonly placeholder="点「一键填入」后出现" />
        </label>
        <label class="im-field">
          <span>你的 API key</span>
          <input :value="imState.key" type="password" placeholder="sk-...（仅你可见，不随分享包落地）" @input="imKey" />
        </label>
        <div class="im-actions">
          <button type="button" class="im-btn primary" @click="imApply"><Icon name="ri-magic-line" :size="15" />一键填入 CTClaw</button>
          <button type="button" class="im-btn" @click="ctai.copyShare()"><Icon name="ri-file-copy-line" :size="15" />复制分享包</button>
        </div>
        <div v-if="imState.status === 'no_key'" class="im-err">
          <span class="im-err-code">NO_KEY</span>
          <span>字段 key 为空 —— 请在上方填入你自己的 key（结构化错误演示）</span>
        </div>
        <div v-else-if="imState.status === 'ok'" class="im-ok"><Icon name="ri-check-line" :size="14" />已激活该 provider，可在对话中选择它（演示）</div>
      </div>
      <div v-if="block.note" class="ai-note"><Icon name="ri-information-line" :size="14" />{{ block.note }}</div>
    </div>

    <!-- ════════ CT AI：长按空格唤醒 wake ════════ -->
    <div v-else-if="block.t === 'wake'" class="ct-ai wake">
      <div class="ai-head">
        <div>
          <div class="ai-title">{{ block.title }}</div>
          <div class="ai-sub">{{ block.sub }}</div>
        </div>
      </div>
      <div class="wk-stage">
        <button
          type="button"
          class="wk-key"
          :class="{ holding: wkActive, done: wkDone }"
          @pointerdown="wkDown"
          @pointerup="wkUp"
          @pointerleave="wkUp"
        >
          <svg viewBox="0 0 64 64" class="wk-ring">
            <circle cx="32" cy="32" r="26" class="wk-bg" />
            <circle cx="32" cy="32" r="26" class="wk-fg" :stroke-dasharray="ringDash(wkProgress)" />
          </svg>
          <span class="wk-key-label">{{ wkDone ? '已唤醒' : wkActive ? Math.round(wkProgress) + '%' : '空格' }}</span>
        </button>
        <div class="wk-info">
          <div class="wk-state">{{ wkDone ? '就绪 · 模型进程 400MB' : wkActive ? '保持按住…' : '按住屏幕键 1s，或真实长按空格' }}</div>
          <div class="wk-avoid"><Icon name="ri-error-warning-line" :size="13" />{{ block.avoid }}</div>
        </div>
      </div>
      <div class="wk-steps">
        <div v-for="(s, i) in block.steps || []" :key="i" class="wk-step"><span>{{ Number(i) + 1 }}</span>{{ s }}</div>
      </div>
    </div>

    <!-- ════════ CT AI：Agent 执行 agent ════════ -->
    <div v-else-if="block.t === 'agent'" class="ct-ai agent">
      <div class="ai-head">
        <div>
          <div class="ai-title">{{ block.title }}</div>
          <div class="ai-sub">{{ block.sub }}</div>
        </div>
        <div class="ag-badge" :class="{ live: agRunning > 0 }">
          <i /> {{ agRunning > 0 ? `运行中 ${agRunning}` : agHas ? '已完成' : '待执行' }}
        </div>
      </div>
      <div v-if="!agHas" class="ag-empty">
        <Icon name="ri-robot-2-line" :size="28" />
        <span>{{ block.parent }} 待命 —— 派出小馒头并行处理子任务</span>
      </div>
      <div v-else class="ag-list">
        <div v-for="t in agTasks" :key="t.id" class="ag-task" :class="t.state">
          <div class="ag-task-hd">
            <span class="ag-ico"><Icon name="ri-robot-line" :size="14" /></span>
            <span class="ag-name">小馒头#{{ t.id }} · {{ t.name }}</span>
            <span class="ag-pct">{{ t.progress }}%</span>
          </div>
          <div class="ag-bar"><div class="ag-fill" :style="{ width: t.progress + '%' }" /></div>
          <div class="ag-origin">{{ t.origin }}</div>
        </div>
      </div>
      <div class="ag-actions">
        <button type="button" class="im-btn primary" :disabled="agRunning > 0" @click="agStart"><Icon name="ri-play-line" :size="15" />开始执行</button>
        <button type="button" class="im-btn" :disabled="agRunning === 0" @click="agCancel"><Icon name="ri-stop-circle-line" :size="15" />取消</button>
        <span class="ag-origin"><Icon name="ri-node-tree" :size="12" />{{ block.origin }}</span>
      </div>
      <div v-if="block.note" class="ai-note"><Icon name="ri-information-line" :size="14" />{{ block.note }}</div>
    </div>

    <!-- 兜底 -->
    <div v-else class="ctb-fallback">{{ block.title || block.t }}</div>
  </section>
</template>

<style scoped>
/* ── tone 色板 ── */
.tone-blue   { --tone: #5b8def; --tone-s: rgba(91,141,239,.13); }
.tone-teal   { --tone: #3fb59a; --tone-s: rgba(63,181,154,.13); }
.tone-violet { --tone: #9b7ae8; --tone-s: rgba(155,122,232,.13); }
.tone-amber  { --tone: #d5a04e; --tone-s: rgba(213,160,78,.13); }
.tone-orange { --tone: #e08a5b; --tone-s: rgba(224,138,91,.13); }
.tone-green  { --tone: #5fb488; --tone-s: rgba(95,180,136,.13); }
.tone-pink   { --tone: #dc7fa6; --tone-s: rgba(220,127,166,.13); }
.tone-cyan   { --tone: #45a9d4; --tone-s: rgba(69,169,212,.13); }
.tone-red    { --tone: #d9695f; --tone-s: rgba(217,105,95,.13); }
.tone-accent { --tone: var(--c-accent, #5b8def); --tone-s: color-mix(in srgb, var(--c-accent, #5b8def) 14%, transparent); }
.tone-good   { --tone: #4fb783; --tone-s: rgba(79,183,131,.13); }
.tone-warn   { --tone: #d9a54b; --tone-s: rgba(217,165,75,.14); }
.tone-bad    { --tone: #d9695f; --tone-s: rgba(217,105,95,.14); }
.tone-info   { --tone: #5b9ad4; --tone-s: rgba(91,154,212,.13); }

.ctb { margin-bottom: 14px; }
.ctb-head { display: flex; align-items: baseline; gap: 10px; margin: 0 0 10px; }
.ctb-title { font-size: 13.5px; font-weight: 650; color: var(--c-text); letter-spacing: .2px; }
.ctb-sub { font-size: 11.5px; color: var(--c-text-mute); }

/* hero */
.hero {
  position: relative; overflow: hidden; display: flex; gap: 16px; align-items: flex-start;
  padding: 20px 22px; border-radius: 16px;
  border: 1px solid color-mix(in srgb, var(--tone) 28%, var(--c-border));
  background: linear-gradient(135deg, var(--tone-s), transparent 62%), var(--c-surface-2);
}
.hero-icon {
  flex: none; width: 52px; height: 52px; border-radius: 15px; display: grid; place-items: center;
  color: var(--tone); background: var(--tone-s);
  border: 1px solid color-mix(in srgb, var(--tone) 30%, transparent);
}
.hero-main { min-width: 0; position: relative; z-index: 1; }
.hero-badge {
  display: inline-block; font-size: 10.5px; font-weight: 600; letter-spacing: .3px;
  color: var(--tone); background: var(--tone-s); padding: 3px 9px; border-radius: 20px; margin-bottom: 8px;
}
.hero-title { margin: 0 0 6px; font-size: 21px; font-weight: 700; color: var(--c-text); letter-spacing: -.3px; }
.hero-desc { margin: 0; font-size: 12.5px; line-height: 1.65; color: var(--c-text-dim); }
.hero-glow {
  position: absolute; right: -50px; top: -70px; width: 220px; height: 220px; border-radius: 50%;
  background: var(--tone); opacity: .07; filter: blur(30px); pointer-events: none;
}

/* kpis */
.kpis { display: grid; grid-template-columns: repeat(auto-fit, minmax(112px, 1fr)); gap: 10px; }
.kpi {
  padding: 13px 14px; border-radius: 13px; border: 1px solid var(--c-border);
  background: var(--c-surface-2); border-top: 2px solid var(--tone);
}
.kpi-v { font-size: 22px; font-weight: 700; color: var(--tone); line-height: 1.15; letter-spacing: -.5px; }
.kpi-u { font-size: 11px; font-weight: 500; margin-left: 3px; opacity: .8; }
.kpi-l { font-size: 11px; color: var(--c-text-mute); margin-top: 5px; }

/* cards */
.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(218px, 1fr)); gap: 10px; }
.card {
  padding: 14px; border-radius: 13px; border: 1px solid var(--c-border);
  background: var(--c-surface-2); transition: border-color .16s, transform .16s, background .16s;
}
.card:hover { border-color: color-mix(in srgb, var(--tone) 45%, var(--c-border)); transform: translateY(-1px); background: var(--c-hover); }
.card-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 9px; }
.card-ic {
  width: 32px; height: 32px; border-radius: 10px; display: grid; place-items: center;
  color: var(--tone); background: var(--tone-s);
}
.card-badge { font-size: 10px; color: var(--tone); background: var(--tone-s); padding: 2px 8px; border-radius: 20px; }
.card-title { margin: 0 0 5px; font-size: 13px; font-weight: 650; color: var(--c-text); }
.card-desc { margin: 0; font-size: 11.5px; line-height: 1.6; color: var(--c-text-dim); }
.card-tags { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 9px; }
.tag { font-size: 10px; color: var(--c-text-mute); border: 1px solid var(--c-border); padding: 2px 7px; border-radius: 6px; }

/* toggles */
.toggles { display: flex; flex-direction: column; gap: 7px; }
.tog {
  display: flex; align-items: center; justify-content: space-between; gap: 12px; width: 100%; text-align: left;
  padding: 10px 13px; border-radius: 11px; border: 1px solid var(--c-border);
  background: var(--c-surface-2); color: var(--c-text); cursor: pointer; transition: background .15s, border-color .15s;
}
.tog:hover { background: var(--c-hover); }
.tog.off { opacity: .62; }
.tog-txt { min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.tog-l { font-size: 12.5px; font-weight: 600; }
.tog-d { font-size: 11px; color: var(--c-text-mute); line-height: 1.45; }
.tog-sw {
  flex: none; width: 34px; height: 20px; border-radius: 20px; background: var(--tone);
  position: relative; transition: background .18s;
}
.tog.off .tog-sw { background: var(--c-border-strong, #6b7280); }
.tog-sw i {
  position: absolute; top: 2px; left: 16px; width: 16px; height: 16px; border-radius: 50%;
  background: #fff; transition: left .18s; box-shadow: 0 1px 3px rgba(0,0,0,.3);
}
.tog.off .tog-sw i { left: 2px; }

/* segments */
.seg-row {
  display: inline-flex; flex-wrap: wrap; gap: 3px; padding: 3px; border-radius: 11px;
  background: var(--c-surface-2); border: 1px solid var(--c-border);
}
.seg {
  border: 0; background: transparent; color: var(--c-text-dim); font-size: 11.5px;
  padding: 7px 13px; border-radius: 8px; cursor: pointer; transition: all .15s; white-space: nowrap;
}
.seg:hover { color: var(--c-text); }
.seg.on { background: var(--c-accent); color: #fff; font-weight: 600; box-shadow: 0 2px 8px var(--c-shadow); }
.seg-hint { font-size: 11px; color: var(--c-text-mute); margin-top: 8px; line-height: 1.5; }

/* progress */
.progress { display: flex; flex-direction: column; gap: 12px; }
.pr-top { display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 5px; }
.pr-l { color: var(--c-text); font-weight: 600; }
.pr-p { color: var(--tone); font-weight: 700; font-variant-numeric: tabular-nums; }
.pr-track { height: 7px; border-radius: 8px; background: var(--c-surface-3); overflow: hidden; }
.pr-fill { height: 100%; border-radius: 8px; background: var(--tone); transition: width .5s ease; }
.pr-meta { display: flex; justify-content: space-between; font-size: 10.5px; color: var(--c-text-mute); margin-top: 4px; }

/* timeline */
.timeline { display: flex; flex-direction: column; }
.tl { display: flex; gap: 12px; }
.tl-rail { flex: none; width: 14px; display: flex; justify-content: center; position: relative; }
.tl-rail::before { content: ''; position: absolute; top: 14px; bottom: -4px; width: 1px; background: var(--c-border); }
.tl:last-child .tl-rail::before { display: none; }
.tl-dot { width: 9px; height: 9px; border-radius: 50%; background: var(--tone); margin-top: 5px; z-index: 1; box-shadow: 0 0 0 3px var(--tone-s); }
.tl-body { padding-bottom: 14px; min-width: 0; }
.tl-time { font-size: 10.5px; color: var(--tone); font-weight: 600; }
.tl-title { font-size: 12.5px; font-weight: 650; color: var(--c-text); margin-top: 2px; }
.tl-desc { font-size: 11px; color: var(--c-text-dim); line-height: 1.55; margin-top: 2px; }

/* table */
.tbl-wrap { overflow-x: auto; border: 1px solid var(--c-border); border-radius: 12px; }
.tbl { width: 100%; border-collapse: collapse; font-size: 11.5px; }
.tbl th {
  text-align: left; padding: 9px 12px; font-weight: 650; color: var(--c-text-dim);
  background: var(--c-surface-2); border-bottom: 1px solid var(--c-border); white-space: nowrap;
}
.tbl td { padding: 8px 12px; color: var(--c-text-dim); border-bottom: 1px solid var(--c-border); line-height: 1.5; }
.tbl tr:last-child td { border-bottom: 0; }
.tbl tbody tr:hover td { background: var(--c-hover); }
.tbl td.first { color: var(--c-text); font-weight: 600; white-space: nowrap; }

/* bars */
.bars { display: flex; flex-direction: column; gap: 9px; }
.bar { display: flex; align-items: center; gap: 10px; font-size: 11.5px; }
.bar-l { flex: 0 0 118px; color: var(--c-text-dim); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bar-track { flex: 1; height: 8px; border-radius: 8px; background: var(--c-surface-3); overflow: hidden; }
.bar-fill { display: block; height: 100%; border-radius: 8px; background: var(--tone); }
.bar-p { flex: none; width: 28px; text-align: right; color: var(--c-text-mute); font-variant-numeric: tabular-nums; }

/* nodes */
.nodes { display: flex; flex-direction: column; align-items: center; gap: 12px; }
.node-center {
  padding: 8px 18px; border-radius: 12px; font-size: 12.5px; font-weight: 650; color: var(--c-accent);
  background: color-mix(in srgb, var(--c-accent) 13%, transparent);
  border: 1px solid color-mix(in srgb, var(--c-accent) 35%, transparent);
}
.node-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 8px; width: 100%; }
.node {
  padding: 10px 12px; border-radius: 11px; border: 1px solid color-mix(in srgb, var(--tone) 30%, var(--c-border));
  background: var(--tone-s); display: flex; flex-direction: column; gap: 3px;
}
.node-l { font-size: 12px; font-weight: 650; color: var(--c-text); }
.node-s { font-size: 10.5px; color: var(--tone); }

/* logs */
.logs {
  border: 1px solid var(--c-border); border-radius: 12px; overflow: hidden;
  background: var(--c-surface-2); font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.lg { display: flex; gap: 12px; padding: 6px 12px; font-size: 11px; border-bottom: 1px solid var(--c-border); }
.lg:last-child { border-bottom: 0; }
.lg-t { flex: none; width: 58px; color: var(--tone); font-weight: 700; }
.lg-x { color: var(--c-text-dim); word-break: break-all; line-height: 1.5; }

/* code */
.code { border: 1px solid var(--c-border); border-radius: 12px; overflow: hidden; background: var(--c-surface-2); }
.code-bar {
  display: flex; align-items: center; gap: 10px; padding: 7px 12px;
  border-bottom: 1px solid var(--c-border); background: var(--c-surface-3);
}
.code-dots { display: flex; gap: 5px; }
.code-dots i { width: 8px; height: 8px; border-radius: 50%; background: var(--c-border-strong, #6b7280); }
.code-dots i:first-child { background: #e06c62; } .code-dots i:nth-child(2) { background: #d9a54b; } .code-dots i:nth-child(3) { background: #5fb488; }
.code-lang { font-size: 10.5px; color: var(--c-text-mute); font-family: ui-monospace, monospace; }
.code pre { margin: 0; padding: 12px 14px; overflow-x: auto; font-size: 11px; line-height: 1.65; color: var(--c-text-dim); font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }

/* chips */
.chips { display: flex; flex-wrap: wrap; gap: 7px; }
.chip {
  font-size: 11px; color: var(--c-text-dim); padding: 5px 11px; border-radius: 20px;
  border: 1px solid var(--c-border); background: var(--c-surface-2);
}
.chip:hover { border-color: var(--c-accent); color: var(--c-accent); }

/* steps */
.steps { display: flex; flex-direction: column; gap: 4px; }
.stp { display: flex; gap: 12px; padding: 8px 0; }
.stp-n {
  flex: none; width: 26px; height: 26px; border-radius: 9px; display: grid; place-items: center;
  font-size: 11.5px; font-weight: 700; color: var(--tone); background: var(--tone-s);
  border: 1px solid color-mix(in srgb, var(--tone) 28%, transparent);
}
.stp-body { min-width: 0; padding-top: 2px; }
.stp-t { font-size: 12.5px; font-weight: 650; color: var(--c-text); }
.stp-d { font-size: 11px; color: var(--c-text-dim); line-height: 1.55; margin-top: 2px; }

/* callout */
.callout {
  display: flex; gap: 11px; padding: 12px 14px; border-radius: 12px;
  background: var(--tone-s); border: 1px solid color-mix(in srgb, var(--tone) 28%, var(--c-border));
}
.co-ic { flex: none; color: var(--tone); margin-top: 1px; }
.co-t { font-size: 12.5px; font-weight: 650; color: var(--c-text); margin-bottom: 3px; }
.co-x { font-size: 11.5px; color: var(--c-text-dim); line-height: 1.65; }

/* rings */
.rings { display: flex; gap: 16px; flex-wrap: wrap; justify-content: space-around; }
.rg { display: flex; flex-direction: column; align-items: center; gap: 4px; position: relative; width: 76px; }
.rg-svg { width: 66px; height: 66px; transform: rotate(-90deg); }
.rg-bg { fill: none; stroke: var(--c-surface-3); stroke-width: 6; }
.rg-fg { fill: none; stroke: var(--tone); stroke-width: 6; stroke-linecap: round; transition: stroke-dasharray .5s; }
.rg-num { position: absolute; top: 24px; font-size: 14px; font-weight: 700; color: var(--c-text); }
.rg-num small { font-size: 9px; }
.rg-l { font-size: 10.5px; color: var(--c-text-mute); text-align: center; }

/* spark */
.spark { border: 1px solid var(--c-border); border-radius: 12px; padding: 10px 12px; background: var(--c-surface-2); }
.sp-svg { width: 100%; height: 56px; }
.sp-line { fill: none; stroke: var(--tone); stroke-width: 2; vector-effect: non-scaling-stroke; }
.sp-c { font-size: 17px; font-weight: 700; color: var(--tone); text-align: right; }
.sp-c small { font-size: 10px; }
.ctb-fallback { font-size: 12px; color: var(--c-text-mute); }

/* ── 交互型：review ── */
.review { }
.rv-now {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 12px 14px; border-radius: 13px; border: 1px solid color-mix(in srgb, var(--c-accent) 30%, var(--c-border));
  background: color-mix(in srgb, var(--c-accent) 10%, var(--c-surface-2)); margin-bottom: 12px;
}
.rv-now-l { min-width: 0; }
.rv-now-k { font-size: 10.5px; color: var(--c-text-mute); }
.rv-now-v { display: block; font-size: 14px; font-weight: 700; color: var(--c-text); margin-top: 2px; }
.rv-now-badge { display: inline-flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 600; color: #4fb783; background: rgba(79,183,131,.14); padding: 4px 10px; border-radius: 20px; flex: none; }
.rv-now-badge i { width: 6px; height: 6px; border-radius: 50%; background: #4fb783; }
.rv-list { list-style: none; margin: 0; padding: 0; }
.rv-i { display: flex; align-items: center; gap: 12px; padding: 11px 12px; border-radius: 11px; border: 1px solid transparent; transition: background .15s; }
.rv-i:hover { background: var(--c-hover); }
.rv-i.on { background: var(--tone-s); border-color: color-mix(in srgb, var(--tone) 40%, transparent); }
.rv-dot { flex: none; width: 12px; height: 12px; border-radius: 50%; border: 3px solid var(--tone); background: var(--c-surface); }
.rv-i.on .rv-dot { background: var(--tone); box-shadow: 0 0 0 3px var(--tone-s); }
.rv-info { flex: 1; min-width: 0; }
.rv-d { font-size: 10.5px; color: var(--tone); font-weight: 600; }
.rv-l { font-size: 13px; font-weight: 650; color: var(--c-text); margin-top: 1px; }
.rv-meta { display: flex; gap: 8px; margin-top: 3px; font-size: 10.5px; color: var(--c-text-mute); }
.rv-tag { padding: 1px 7px; border-radius: 6px; background: var(--c-surface-3); color: var(--c-text-dim); }
.rv-rollback { flex: none; border: 1px solid var(--tone); background: transparent; color: var(--tone); font-size: 11.5px; font-weight: 600; padding: 6px 12px; border-radius: 9px; cursor: pointer; transition: all .15s; }
.rv-rollback:hover { background: var(--tone); color: #fff; }
.rv-cur { flex: none; display: inline-flex; align-items: center; gap: 5px; font-size: 11.5px; font-weight: 600; color: var(--tone); }
.rv-cur i { width: 7px; height: 7px; border-radius: 50%; background: var(--tone); }
.rv-wait { color: var(--c-text-mute); }
.rv-prog { height: 6px; border-radius: 6px; background: var(--c-surface-3); overflow: hidden; margin-top: 10px; }
.rv-prog-f { height: 100%; background: var(--c-accent); border-radius: 6px; transition: width .1s linear; }
.rv-logs { margin-top: 14px; border-top: 1px dashed var(--c-border); padding-top: 10px; }
.rv-logs-h { font-size: 11px; font-weight: 650; color: var(--c-text-dim); margin-bottom: 6px; }
.rv-log { display: flex; gap: 10px; font-size: 11px; padding: 3px 0; font-family: ui-monospace, monospace; }
.rv-log-t { flex: none; width: 64px; color: #4fb783; font-weight: 700; }
.rv-log span:last-child { color: var(--c-text-dim); }

/* ── 交互型：swarm ── */
.swarm { }
.sw-sec-h { display: flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 650; color: var(--c-text-dim); margin: 4px 0 9px; }
.sw-nodes { display: grid; grid-template-columns: repeat(auto-fit, minmax(178px, 1fr)); gap: 9px; margin-bottom: 12px; }
.sw-node { padding: 11px 12px; border-radius: 12px; border: 1px solid var(--c-border); background: var(--c-surface-2); transition: border-color .15s; }
.sw-node.queen { border-color: color-mix(in srgb, var(--c-accent) 45%, var(--c-border)); background: color-mix(in srgb, var(--c-accent) 8%, var(--c-surface-2)); }
.sw-node.offline { opacity: .6; }
.sw-node-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.sw-node-name { display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px; font-weight: 650; color: var(--c-text); min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sw-node-st { flex: none; display: inline-flex; align-items: center; gap: 4px; font-size: 10.5px; font-weight: 600; }
.sw-node-st i { width: 6px; height: 6px; border-radius: 50%; }
.sw-node-st.online i { background: #4fb783; } .sw-node-st.idle i { background: #d9a54b; } .sw-node-st.offline i { background: #8b93a3; }
.sw-node-st.online { color: #4fb783; } .sw-node-st.idle { color: #d9a54b; } .sw-node-st.offline { color: #8b93a3; }
.sw-node-meta { font-size: 10.5px; color: var(--c-text-mute); margin: 5px 0 9px; }
.sw-node-btns { display: flex; gap: 6px; }
.sw-btn { border: 1px solid var(--c-border); background: var(--c-surface-3); color: var(--c-text-dim); font-size: 11px; font-weight: 600; padding: 5px 10px; border-radius: 8px; cursor: pointer; transition: all .15s; white-space: nowrap; }
.sw-btn:hover { background: var(--c-hover); color: var(--c-text); }
.sw-btn-ok { border-color: color-mix(in srgb, var(--c-accent) 40%, transparent); color: var(--c-accent); }
.sw-btn-ok:hover { background: var(--c-accent); color: #fff; }
.sw-btn-x { border-color: rgba(217,105,95,.4); color: #d9695f; }
.sw-btn-x:hover { background: #d9695f; color: #fff; }
.sw-queen-tag { display: inline-flex; align-items: center; gap: 4px; border: none; background: transparent; color: var(--c-accent); cursor: default; }
.sw-queen-tag i { width: 6px; height: 6px; border-radius: 50%; background: var(--c-accent); }
.sw-tasks { display: flex; flex-direction: column; gap: 8px; margin-bottom: 12px; }
.sw-task { padding: 10px 12px; border-radius: 11px; border: 1px solid var(--c-border); background: var(--c-surface-2); }
.sw-task.done { opacity: .78; }
.sw-task-top { display: flex; align-items: center; gap: 9px; margin-bottom: 7px; }
.sw-task-name { flex: 1; min-width: 0; font-size: 12.5px; font-weight: 600; color: var(--c-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sw-task-node { font-size: 10.5px; color: var(--c-text-mute); }
.sw-task-done { display: inline-flex; align-items: center; gap: 4px; font-size: 10.5px; color: #4fb783; }
.sw-task-done i { width: 6px; height: 6px; border-radius: 50%; background: #4fb783; }
.sw-task-track { height: 6px; border-radius: 6px; background: var(--c-surface-3); overflow: hidden; }
.sw-task-f { height: 100%; background: linear-gradient(90deg, var(--c-accent), color-mix(in srgb, var(--c-accent) 60%, #4fb783)); border-radius: 6px; transition: width .8s ease; }
.sw-empty { font-size: 11.5px; color: var(--c-text-mute); text-align: center; padding: 14px; }
.sw-add { display: flex; gap: 8px; margin-top: 8px; }
.sw-input { flex: 1; min-width: 0; height: 32px; padding: 0 12px; border-radius: 9px; border: 1px solid var(--c-border); background: var(--c-surface-2); color: var(--c-text); font-size: 12px; }
.sw-input:focus { outline: none; border-color: var(--c-accent); }

/* ── 交互型：chat ── */
.chat { display: flex; flex-direction: column; min-height: 320px; }
.chat-box { flex: 1; min-height: 220px; max-height: 420px; overflow-y: auto; padding: 6px 2px 10px; display: flex; flex-direction: column; gap: 10px; }
.chat-msg { display: flex; gap: 9px; align-items: flex-start; }
.chat-msg.user { flex-direction: row-reverse; }
.chat-av { flex: none; width: 26px; height: 26px; border-radius: 9px; display: grid; place-items: center; background: var(--c-surface-3); color: var(--c-text-dim); }
.chat-msg.bot .chat-av { background: color-mix(in srgb, var(--c-accent) 18%, transparent); color: var(--c-accent); }
.chat-bubble { max-width: 78%; padding: 9px 13px; border-radius: 14px; font-size: 12.5px; line-height: 1.6; color: var(--c-text); background: var(--c-surface-2); border: 1px solid var(--c-border); }
.chat-msg.user .chat-bubble { background: var(--c-accent); color: #fff; border-color: transparent; }
.chat-typing { display: inline-flex; gap: 4px; align-items: center; }
.chat-typing i { width: 5px; height: 5px; border-radius: 50%; background: var(--c-text-mute); animation: ctblink 1.2s infinite; }
.chat-typing i:nth-child(2) { animation-delay: .2s; } .chat-typing i:nth-child(3) { animation-delay: .4s; }
@keyframes ctblink { 0%, 60%, 100% { opacity: .3; } 30% { opacity: 1; } }
.chat-hints { display: flex; flex-wrap: wrap; gap: 6px; padding: 8px 0 10px; }
.chat-hint { border: 1px solid var(--c-border); background: var(--c-surface-2); color: var(--c-text-dim); font-size: 11px; padding: 5px 10px; border-radius: 20px; cursor: pointer; transition: all .15s; }
.chat-hint:hover { border-color: var(--c-accent); color: var(--c-accent); }
.chat-input { display: flex; gap: 8px; margin-top: auto; }
.chat-field { flex: 1; min-width: 0; height: 38px; padding: 0 14px; border-radius: 12px; border: 1px solid var(--c-border); background: var(--c-surface-2); color: var(--c-text); font-size: 12.5px; }
.chat-field:focus { outline: none; border-color: var(--c-accent); }
.chat-send { flex: none; width: 40px; height: 38px; border: 0; border-radius: 12px; background: var(--c-accent); color: #fff; cursor: pointer; display: grid; place-items: center; box-shadow: 0 4px 14px var(--c-shadow); transition: filter .15s; }
.chat-send:hover { filter: brightness(1.06); }
.chat-send:disabled { opacity: .45; cursor: not-allowed; }

/* ══════════ CT AI 契约演示（§12）══════════ */
.ct-ai { display: flex; flex-direction: column; gap: 12px; }
.ct-ai .ai-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; }
.ai-title { font-size: 14px; font-weight: 700; color: var(--c-text); }
.ai-sub { font-size: 11px; color: var(--c-text-mute); margin-top: 3px; }
.ai-shell { flex: none; display: inline-flex; align-items: center; gap: 6px; font-size: 10.5px; font-weight: 600; color: var(--c-text-dim); background: var(--c-surface-3); padding: 5px 10px; border-radius: 8px; }
.ai-shell i { width: 6px; height: 6px; border-radius: 50%; background: #4fb783; }
.ai-cur { flex: none; font-size: 11px; color: var(--c-text-mute); }
.ai-cur b { color: var(--c-accent); }
.ai-note { display: flex; align-items: flex-start; gap: 7px; font-size: 11px; line-height: 1.6; color: var(--c-text-mute); background: var(--c-surface-2); border: 1px solid var(--c-border); border-radius: 10px; padding: 9px 12px; }
.ai-note svg { flex: none; margin-top: 1px; color: var(--c-accent); }

/* lifecycle */
.lc-mem { display: flex; align-items: baseline; gap: 8px; padding: 14px 16px; border-radius: 12px; background: linear-gradient(135deg, color-mix(in srgb, var(--c-accent) 14%, var(--c-surface-2)), var(--c-surface-2)); border: 1px solid var(--c-border); }
.lc-mem-num { font-size: 34px; font-weight: 750; color: var(--c-accent); font-variant-numeric: tabular-nums; line-height: 1; }
.lc-mem-u { font-size: 12px; color: var(--c-text-dim); }
.lc-mem-tag { margin-left: auto; font-size: 11px; color: #d5a04e; }
.lc-track { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; }
.lc-node { --tone: #5b8def; display: flex; flex-direction: column; align-items: center; gap: 5px; padding: 12px 6px 10px; border: 1px solid var(--c-border); border-radius: 12px; background: var(--c-surface-2); cursor: pointer; transition: all .15s; text-align: center; }
.lc-node:hover { border-color: var(--tone); transform: translateY(-2px); }
.lc-node.on { border-color: var(--tone); background: color-mix(in srgb, var(--tone) 12%, var(--c-surface-2)); box-shadow: 0 0 0 1px var(--tone) inset; }
.lc-dot { width: 20px; height: 20px; border-radius: 50%; display: grid; place-items: center; border: 2px solid var(--tone); }
.lc-dot i { width: 8px; height: 8px; border-radius: 50%; background: transparent; }
.lc-node.on .lc-dot i { background: var(--tone); box-shadow: 0 0 8px var(--tone); }
.lc-l { font-size: 12px; font-weight: 650; color: var(--c-text); }
.lc-mem-s { font-size: 11px; color: var(--tone); font-weight: 600; }
.lc-d { font-size: 10px; color: var(--c-text-mute); line-height: 1.4; }

/* tiers */
.tr-list { display: flex; flex-direction: column; gap: 6px; }
.tr-row { --tone: #5b8def; display: flex; align-items: center; gap: 11px; padding: 11px 13px; border: 1px solid var(--c-border); border-radius: 12px; background: var(--c-surface-2); cursor: pointer; text-align: left; transition: all .15s; }
.tr-row:hover { border-color: var(--tone); }
.tr-row.on { border-color: var(--tone); background: color-mix(in srgb, var(--tone) 10%, var(--c-surface-2)); }
.tr-radio { flex: none; width: 16px; height: 16px; border-radius: 50%; border: 2px solid var(--c-border-strong); display: grid; place-items: center; }
.tr-row.on .tr-radio { border-color: var(--tone); }
.tr-row.on .tr-radio i { width: 8px; height: 8px; border-radius: 50%; background: var(--tone); }
.tr-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.tr-t { font-size: 12.5px; font-weight: 650; color: var(--c-text); }
.tr-def { font-style: normal; font-size: 9.5px; color: #4fb783; background: rgba(79,183,131,.13); padding: 1px 6px; border-radius: 6px; margin-left: 4px; }
.tr-d { font-size: 10.5px; color: var(--c-text-mute); }
.tr-priv { flex: none; display: inline-flex; align-items: center; gap: 5px; font-size: 10.5px; padding: 4px 9px; border-radius: 8px; }
.priv-local { color: #4fb783; background: rgba(79,183,131,.12); }
.priv-cloud { color: #d9a54b; background: rgba(217,165,75,.12); }
.tr-banner { display: flex; align-items: center; gap: 9px; font-size: 12px; font-weight: 600; padding: 11px 14px; border-radius: 11px; }
.tr-banner.priv-local { border: 1px solid rgba(79,183,131,.3); }
.tr-banner.priv-cloud { border: 1px solid rgba(217,165,75,.3); }

/* importer */
.im-card { display: flex; flex-direction: column; gap: 10px; padding: 14px; border: 1px solid var(--c-border); border-radius: 12px; background: var(--c-surface-2); }
.im-prov { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 650; color: var(--c-text); }
.im-prov svg { color: var(--c-accent); }
.im-hint { font-size: 11px; line-height: 1.6; color: var(--c-text-dim); padding: 9px 11px; background: var(--c-surface-3); border-radius: 9px; }
.im-field { display: flex; flex-direction: column; gap: 5px; }
.im-field span { font-size: 10.5px; color: var(--c-text-mute); }
.im-field input { height: 36px; padding: 0 12px; border-radius: 9px; border: 1px solid var(--c-border); background: var(--c-bg); color: var(--c-text); font-size: 12px; font-family: initial; }
.im-field input:read-only { opacity: .75; }
.im-field input:focus { outline: none; border-color: var(--c-accent); }
.im-actions { display: flex; gap: 8px; flex-wrap: wrap; }
.im-btn { display: inline-flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 600; color: var(--c-text-dim); background: var(--c-surface-3); border: 1px solid var(--c-border); padding: 8px 13px; border-radius: 10px; cursor: pointer; transition: all .15s; }
.im-btn:hover:not(:disabled) { border-color: var(--c-accent); color: var(--c-accent); }
.im-btn.primary { background: var(--c-accent); color: #fff; border-color: transparent; }
.im-btn.primary:hover:not(:disabled) { filter: brightness(1.06); color: #fff; }
.im-btn:disabled { opacity: .45; cursor: not-allowed; }
.im-err { display: flex; align-items: center; gap: 9px; font-size: 11px; color: #d9695f; background: rgba(217,105,95,.1); border: 1px solid rgba(217,105,95,.25); border-radius: 9px; padding: 9px 11px; }
.im-err-code { font-family: monospace; font-weight: 700; background: rgba(217,105,95,.18); padding: 2px 7px; border-radius: 6px; }
.im-ok { display: flex; align-items: center; gap: 6px; font-size: 11px; color: #4fb783; }

/* wake */
.wk-stage { display: flex; align-items: center; gap: 20px; padding: 16px; border: 1px solid var(--c-border); border-radius: 12px; background: var(--c-surface-2); }
.wk-key { --tone: var(--c-accent); flex: none; position: relative; width: 92px; height: 92px; border: 0; background: none; cursor: pointer; display: grid; place-items: center; color: var(--c-text); }
.wk-ring { position: absolute; inset: 0; width: 100%; height: 100%; transform: rotate(-90deg); }
.wk-bg { fill: var(--c-surface-3); stroke: var(--c-border); stroke-width: 4; }
.wk-fg { fill: none; stroke: var(--c-accent); stroke-width: 4; stroke-linecap: round; transition: stroke-dasharray .15s; }
.wk-key.holding .wk-fg { stroke: #d5a04e; }
.wk-key.done .wk-fg { stroke: #4fb783; }
.wk-key-label { position: relative; font-size: 14px; font-weight: 650; }
.wk-info { display: flex; flex-direction: column; gap: 8px; }
.wk-state { font-size: 13px; font-weight: 600; color: var(--c-text); }
.wk-avoid { display: inline-flex; align-items: center; gap: 6px; font-size: 10.5px; color: #d9a54b; }
.wk-steps { display: flex; flex-direction: column; gap: 6px; }
.wk-step { display: flex; align-items: center; gap: 9px; font-size: 11px; color: var(--c-text-dim); }
.wk-step span { flex: none; width: 18px; height: 18px; border-radius: 50%; display: grid; place-items: center; font-size: 10px; font-weight: 700; color: var(--c-accent); background: color-mix(in srgb, var(--c-accent) 14%, transparent); }

/* agent */
.ag-badge { flex: none; display: inline-flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 600; color: var(--c-text-mute); background: var(--c-surface-3); padding: 5px 10px; border-radius: 8px; }
.ag-badge i { width: 6px; height: 6px; border-radius: 50%; background: var(--c-text-mute); }
.ag-badge.live { color: #4fb783; }
.ag-badge.live i { background: #4fb783; box-shadow: 0 0 8px #4fb783; animation: ctblink 1.1s infinite; }
.ag-empty { display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 22px; color: var(--c-text-mute); font-size: 12px; border: 1px dashed var(--c-border); border-radius: 12px; }
.ag-empty svg { color: var(--c-accent); }
.ag-list { display: flex; flex-direction: column; gap: 8px; }
.ag-task { padding: 10px 12px; border: 1px solid var(--c-border); border-radius: 10px; background: var(--c-surface-2); }
.ag-task.done { border-color: rgba(79,183,131,.35); }
.ag-task.canceled { opacity: .6; }
.ag-task-hd { display: flex; align-items: center; gap: 8px; margin-bottom: 7px; }
.ag-ico { color: var(--c-accent); display: inline-flex; }
.ag-name { flex: 1; min-width: 0; font-size: 11.5px; color: var(--c-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.ag-pct { font-size: 11px; color: var(--c-text-dim); font-variant-numeric: tabular-nums; }
.ag-bar { height: 6px; border-radius: 6px; background: var(--c-surface-3); overflow: hidden; }
.ag-fill { height: 100%; border-radius: 6px; background: linear-gradient(90deg, var(--c-accent), #9b7ae8); transition: width .3s; }
.ag-task.done .ag-fill { background: #4fb783; }
.ag-origin { font-family: monospace; font-size: 9.5px; color: var(--c-text-mute); margin-top: 6px; display: inline-flex; align-items: center; gap: 5px; }
.ag-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.ag-actions .ag-origin { margin: 0 0 0 auto; }
@media (max-width: 720px) {
  .lc-track { grid-template-columns: repeat(2, 1fr); }
  .wk-stage { flex-direction: column; align-items: flex-start; }
}
</style>
