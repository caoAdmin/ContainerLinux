<script setup lang="ts">
/**
 * COSMIC Viewer —— 文档 / 图片查看器
 * 文本与 Markdown 直接渲染；图片用程序化渐变占位（工程内无真实位图）。
 */
import { computed, inject, onMounted, ref, watch } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import {
  HOME,
  formatSize,
  getNode,
  iconForNode,
  colorForNode,
  listDir,
  prettyPath,
  readFile,
  type VNode
} from '@/utils/cosmicVfs'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const store = useCosmicStore()
const winId = inject<string>('cosmicWinId', '')

const path = ref<string | null>(null)
const zoom = ref(100)

const recentDirs = [HOME + '/Pictures', HOME + '/Documents', HOME + '/Downloads']

const recent = computed<VNode[]>(() => {
  const out: VNode[] = []
  for (const d of recentDirs) {
    for (const n of listDir(d)) {
      if (n.type === 'file') out.push({ ...n, name: n.name })
    }
  }
  return out
})

function fullPath(node: VNode): string {
  for (const d of recentDirs) {
    if (getNode(`${d}/${node.name}`)) return `${d}/${node.name}`
  }
  return node.name
}

const node = computed<VNode | null>(() => (path.value ? getNode(path.value) : null))
const kind = computed(() => node.value?.kind ?? 'text')
const isImage = computed(() => kind.value === 'image')

/* 程序化「图片」配色：按文件名哈希取色 */
function hashOf(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return h
}
const artStyle = computed(() => {
  const h = hashOf(node.value?.name ?? 'x')
  const a = h % 360
  const b = (a + 58) % 360
  return {
    background: `radial-gradient(circle at 34% 28%, hsl(${b} 62% 52%), hsl(${a} 58% 22%) 68%)`
  }
})

/* 极简 Markdown 渲染 */
function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}
function inline(s: string): string {
  return esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/`(.+?)`/g, '<code>$1</code>')
    .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank" rel="noreferrer">$1</a>')
}
function mdToHtml(md: string): string {
  const lines = md.split('\n')
  const out: string[] = []
  let inCode = false
  let inList = false
  for (const raw of lines) {
    if (raw.trim().startsWith('```')) {
      if (inCode) {
        out.push('</code></pre>')
        inCode = false
      } else {
        out.push('<pre><code>')
        inCode = true
      }
      continue
    }
    if (inCode) {
      out.push(esc(raw))
      continue
    }
    const line = raw.trimEnd()
    if (/^#{1,6}\s/.test(line)) {
      const lvl = line.match(/^#+/)![0].length
      out.push(`<h${lvl}>${inline(line.replace(/^#+\s*/, ''))}</h${lvl}>`)
      continue
    }
    if (/^[-*]\s/.test(line)) {
      if (!inList) {
        out.push('<ul>')
        inList = true
      }
      out.push(`<li>${inline(line.replace(/^[-*]\s*/, ''))}</li>`)
      continue
    }
    if (inList) {
      out.push('</ul>')
      inList = false
    }
    if (!line) {
      out.push('')
      continue
    }
    out.push(`<p>${inline(line)}</p>`)
  }
  if (inList) out.push('</ul>')
  if (inCode) out.push('</code></pre>')
  return out.join('\n')
}

const textHtml = computed(() => {
  if (!node.value || isImage.value) return ''
  const c = readFile(path.value!) ?? ''
  if (kind.value === 'markdown') return mdToHtml(c)
  return `<pre class="cr-plain">${esc(c)}</pre>`
})

watch(
  node,
  (n) => store.setTitle(winId, `COSMIC Viewer — ${n ? n.name : '空闲'}`),
  { immediate: true }
)

function openPath(p: string) {
  path.value = p
  zoom.value = 100
}

watch(
  () => store.pending['viewer'],
  (v) => {
    if (v && store.activeId === winId) {
      store.takePending('viewer')
      openPath(v as string)
    }
  },
  { immediate: true }
)

onMounted(() => {
  const first = recent.value.find((n) => n.kind === 'image') ?? recent.value[0]
  if (first && !path.value) openPath(fullPath(first))
})
</script>

<template>
  <M3AppShell fabIcon="ri-folder-open-line">
  <template #rail>
    <aside class="c-sidebar">
      <div class="c-side-title">最近文件</div>
      <button
        v-for="f in recent"
        :key="f.name"
        class="c-side-item"
        :class="{ active: path === fullPath(f) }"
        @click="openPath(fullPath(f))"
      >
        <Icon :name="iconForNode(f)" :size="15" :color="colorForNode(f)" />
        <span>{{ f.name }}</span>
      </button>
    </aside>
  </template>
  <div class="cx-root cr">
    <section class="c-main">
      <div class="c-toolbar">
        <span class="cr-title">
          <Icon :name="node ? iconForNode(node) : 'ri-book-2-line'" :size="15" :color="node ? colorForNode(node) : 'var(--c-text-dim)'" />
          <b>{{ node?.name ?? '未打开文件' }}</b>
        </span>
        <span class="cr-path">{{ path ? prettyPath(path) : '—' }}</span>
        <div class="cr-zoom">
          <button class="c-iconbtn" @click="zoom = Math.max(40, zoom - 10)">
            <Icon name="ri-zoom-out-line" :size="16" />
          </button>
          <span>{{ zoom }}%</span>
          <button class="c-iconbtn" @click="zoom = Math.min(220, zoom + 10)">
            <Icon name="ri-zoom-in-line" :size="16" />
          </button>
          <button class="c-iconbtn" title="适应窗口" @click="zoom = 100">
            <Icon name="ri-fullscreen-line" :size="16" />
          </button>
        </div>
      </div>

      <div class="cr-view c-scroll">
        <template v-if="node">
          <div v-if="isImage" class="cr-image" :style="artStyle">
            <div class="cr-image-inner" :style="{ transform: `scale(${zoom / 100})` }">
              <Icon name="ri-image-2-fill" :size="64" color="rgba(255,255,255,0.85)" />
              <b>{{ node.name }}</b>
              <span>{{ formatSize(node.size) }} · 1600 × 900</span>
            </div>
          </div>
          <div v-else class="cr-doc" :style="{ fontSize: (14 * zoom) / 100 + 'px' }" v-html="textHtml" />
        </template>
        <div v-else class="c-empty">
          <Icon name="ri-book-open-line" :size="36" color="var(--c-text-mute)" />
          <span>从左侧选择一个文件</span>
        </div>
      </div>

      <div class="c-status">
        <span v-if="node"><b>{{ node.kind ?? 'text' }}</b></span>
        <span v-if="node">{{ formatSize(node.size) }}</span>
        <span>UTF-8</span>
        <span class="cr-status-right"><Icon name="ri-pages-line" :size="12" /> {{ isImage ? '图片视图' : '文档视图' }}</span>
      </div>
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.cr {
  position: relative;
}
.cr-title {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  min-width: 0;
}
.cr-title b {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.cr-path {
  font-size: 11.5px;
  color: var(--c-text-mute);
  margin-left: 6px;
}
.cr-zoom {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--c-text-dim);
}
.cr-view {
  flex: 1;
  min-height: 0;
  display: flex;
  justify-content: center;
  padding: 22px;
  background: var(--c-surface-2);
}
.cr-image {
  width: min(100%, 720px);
  aspect-ratio: 16 / 9;
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.45);
}
.cr-image-inner {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  color: #fff;
  transition: transform 0.16s ease;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
}
.cr-image-inner b {
  font-size: 16px;
}
.cr-image-inner span {
  font-size: 12px;
  opacity: 0.85;
}
.cr-doc {
  width: min(100%, 720px);
  padding: 32px 38px;
  border-radius: 14px;
  background: var(--c-surface);
  border: 1px solid var(--c-border);
  color: var(--c-text);
  line-height: 1.75;
}
.cr-doc :deep(h1) {
  font-size: 1.9em;
  margin: 0 0 0.6em;
}
.cr-doc :deep(h2) {
  font-size: 1.45em;
  margin: 1.3em 0 0.5em;
}
.cr-doc :deep(h3) {
  font-size: 1.18em;
  margin: 1.1em 0 0.4em;
}
.cr-doc :deep(p) {
  margin: 0.7em 0;
}
.cr-doc :deep(ul) {
  padding-left: 1.3em;
  margin: 0.6em 0;
}
.cr-doc :deep(li) {
  margin: 0.28em 0;
}
.cr-doc :deep(code) {
  background: var(--c-surface-3);
  padding: 0.15em 0.42em;
  border-radius: 5px;
  font-size: 0.9em;
  font-family: 'JetBrains Mono', Consolas, monospace;
}
.cr-doc :deep(pre) {
  background: var(--c-surface-3);
  padding: 14px 16px;
  border-radius: 10px;
  overflow-x: auto;
}
.cr-doc :deep(pre code) {
  background: transparent;
  padding: 0;
}
.cr-doc :deep(a) {
  color: var(--c-accent);
}
.cr-doc :deep(.cr-plain) {
  margin: 0;
  white-space: pre-wrap;
  font-family: 'JetBrains Mono', Consolas, monospace;
  font-size: 0.92em;
}
.cr-status-right {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
</style>
