<script setup lang="ts">
/**
 * COSMIC Terminal —— 可真实交互的终端
 * 支持 ls / cd / pwd / cat / echo / mkdir / touch / rm / tree / grep /
 * find / head / wc / open / clear / history / neofetch / uname / whoami / date / help
 * 全部作用于共享虚拟文件系统（与 Files / Edit 实时联动）。
 */
import { computed, inject, nextTick, onMounted, ref, watch } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import {
  HOME,
  baseName,
  createDir,
  createFile,
  getNode,
  listDir,
  normalizePath,
  prettyPath,
  readFile,
  removeNode,
  treeOf,
  writeFile
} from '@/utils/cosmicVfs'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const store = useCosmicStore()
const winId = inject<string>('cosmicWinId', '')

interface Line {
  id: number
  text: string
  cls?: string
}

let lineId = 0
const lines = ref<Line[]>([])
const cwd = ref(HOME)
const input = ref('')
const cmdHistory = ref<string[]>([])
const histIdx = ref(-1)
const scroller = ref<HTMLElement | null>(null)
const inputEl = ref<HTMLInputElement | null>(null)

function focusInput() {
  inputEl.value?.focus()
}

const prompt = computed(() => {
  const name = baseName(cwd.value) || '/'
  return `cosmic@cosmic-pc:${cwd.value === HOME ? '~' : name}$`
})

watch(
  () => cwd.value,
  (p) => store.setTitle(winId, `cosmic@cosmic-pc: ${prettyPath(p)}`),
  { immediate: true }
)

function print(text: string, cls?: string) {
  lines.value.push({ id: ++lineId, text, cls })
}

function printLines(arr: string[], cls?: string) {
  arr.forEach((t) => print(t, cls))
}

async function scrollBottom() {
  await nextTick()
  if (scroller.value) scroller.value.scrollTop = scroller.value.scrollHeight
}

/* ─────────── 命令实现 ─────────── */

const MOTD = [
  'COSMIC Terminal  ·  alacritty_terminal + 自定义渲染器',
  '输入 "help" 查看可用命令，输入 "neofetch" 看看系统信息。',
  ''
]

function ls(args: string[]): string[] {
  const long = args.includes('-l') || args.includes('-la') || args.includes('-al')
  const target = args.find((a) => !a.startsWith('-'))
  const path = target ? normalizePath(target, cwd.value) : cwd.value
  const nodes = listDir(path)
  if (!nodes.length) return []
  if (!long) {
    return [
      nodes
        .map((n) => (n.type === 'dir' ? `${n.name}/` : n.name))
        .join('   ')
    ]
  }
  return nodes.map((n) => {
    const perm = n.type === 'dir' ? 'drwxr-xr-x' : '-rw-r--r--'
    const size = n.type === 'dir' ? '4096' : String(n.size ?? 0).padStart(8)
    return `${perm}  cosmic cosmic ${size}  ${n.mtime}  ${n.type === 'dir' ? n.name + '/' : n.name}`
  })
}

function cd(args: string[]): string[] {
  const target = args[0] ?? '~'
  const path = normalizePath(target, cwd.value)
  const node = getNode(path)
  if (!node) return [`cd: 没有那个文件或目录: ${target}`]
  if (node.type !== 'dir') return [`cd: 不是目录: ${target}`]
  cwd.value = path
  return []
}

function cat(args: string[]): string[] {
  if (!args[0]) return ['用法: cat <文件>']
  const path = normalizePath(args[0], cwd.value)
  const node = getNode(path)
  if (!node) return [`cat: ${args[0]}: 没有那个文件或目录`]
  if (node.type === 'dir') return [`cat: ${args[0]}: 是一个目录`]
  const kind = node.kind ?? 'text'
  if (['image', 'audio', 'video', 'archive', 'binary'].includes(kind))
    return [`cat: ${args[0]}: 二进制文件（${kind}），已跳过`]
  return (readFile(path) ?? '').replace(/\n$/, '').split('\n')
}

function mkdir(args: string[]): string[] {
  if (!args[0]) return ['用法: mkdir <目录名>']
  const path = normalizePath(args[0], cwd.value)
  const dir = path.slice(0, path.lastIndexOf('/')) || '/'
  if (createDir(dir, baseName(path))) return []
  return [`mkdir: 无法创建目录 "${args[0]}": 已存在`]
}

function touch(args: string[]): string[] {
  if (!args[0]) return ['用法: touch <文件名>']
  const path = normalizePath(args[0], cwd.value)
  const dir = path.slice(0, path.lastIndexOf('/')) || '/'
  if (getNode(path)) {
    writeFile(path, readFile(path) ?? '')
    return []
  }
  if (createFile(dir, baseName(path), '')) return []
  return [`touch: 无法创建 "${args[0]}"`]
}

function rm(args: string[]): string[] {
  const target = args.find((a) => !a.startsWith('-'))
  if (!target) return ['用法: rm [-r] <文件|目录>']
  const path = normalizePath(target, cwd.value)
  const node = getNode(path)
  if (!node) return [`rm: 无法删除 "${target}": 没有那个文件或目录`]
  if (node.type === 'dir' && !args.some((a) => a.startsWith('-')))
    return [`rm: 无法删除 "${target}": 是一个目录（试试 rm -r）`]
  removeNode(path)
  return []
}

function grep(args: string[]): string[] {
  const [kw, file] = args
  if (!kw || !file) return ['用法: grep <关键词> <文件>']
  const path = normalizePath(file, cwd.value)
  if (!getNode(path)) return [`grep: ${file}: 没有那个文件或目录`]
  const content = readFile(path) ?? ''
  return content
    .split('\n')
    .filter((l) => l.includes(kw))
    .map((l) => l)
}

function find(args: string[]): string[] {
  const kw = args[0]
  if (!kw) return ['用法: find <关键词>']
  const out: string[] = []
  const walk = (p: string) => {
    for (const n of listDir(p)) {
      const child = `${p === '/' ? '' : p}/${n.name}`
      if (n.name.includes(kw)) out.push(child)
      if (n.type === 'dir') walk(child)
    }
  }
  walk(cwd.value)
  return out.length ? out : ['（未找到）']
}

function head(args: string[]): string[] {
  if (!args[0]) return ['用法: head <文件>']
  return cat([args[0]]).slice(0, 8)
}

function wc(args: string[]): string[] {
  if (!args[0]) return ['用法: wc <文件>']
  const path = normalizePath(args[0], cwd.value)
  const c = readFile(path)
  if (c == null) return [`wc: ${args[0]}: 没有那个文件或目录`]
  return [`${c.split('\n').length} 行  ${c.length} 字符  ${args[0]}`]
}

function open(args: string[]): string[] {
  if (!args[0]) return ['用法: open <文件>']
  const path = normalizePath(args[0], cwd.value)
  const node = getNode(path)
  if (!node) return [`open: ${args[0]}: 没有那个文件或目录`]
  const kind = node.kind ?? 'text'
  if (kind === 'audio' || kind === 'video') store.openWithPayload('player', path)
  else if (kind === 'image') store.openWithPayload('viewer', path)
  else store.openWithPayload('edit', path)
  return [`已用默认应用打开 ${node.name}`]
}

function neofetch(): string[] {
  const a = store.settings.accent
  return [
    '        ▄▄▄▄▄▄        cosmic@cosmic-pc',
    '      ▄████████▄      ─────────────────',
    '     ███▀    ▀███     OS      COSMIC Web Epoch 1.0 (x86_64)',
    '    ███  ▄▄▄▄  ███    Host    macos27-golden-gate',
    '    ███  ████  ███    Kernel  6.12.0-cosmic',
    '     ███▄    ▄███     Uptime  2 小时 14 分',
    '      ▀████████▀      Shell   cosmic-term',
    '        ▀▀▀▀▀▀        DE      COSMIC (Rust / libcosmic)',
    '                      WM      cosmic-comp (Wayland)',
    `                      Theme   ${store.settings.mode === 'dark' ? 'Dark' : 'Light'} · ${a}`,
    '                      CPU     Ryzen 7 7840U @ 5.1GHz',
    '                      GPU     Radeon 780M (Vulkan 1.3)',
    '                      Memory  4821MiB / 16384MiB',
    ''
  ]
}

const COMMANDS = [
  'help', 'ls', 'cd', 'pwd', 'cat', 'echo', 'mkdir', 'touch', 'rm', 'tree',
  'grep', 'find', 'head', 'wc', 'open', 'clear', 'history', 'neofetch',
  'uname', 'whoami', 'date', 'hostname', 'exit'
]

function run(raw: string) {
  const line = raw.trim()
  print(`${prompt.value} ${line}`, 'cmd')
  if (!line) return
  const [cmd, ...args] = line.split(/\s+/)
  let out: string[] = []

  switch (cmd) {
    case 'help':
      out = [
        '可用命令：',
        '  ls [-l] [目录]   列出目录内容      cd <目录>      切换目录',
        '  pwd              显示当前路径      cat <文件>     查看文件内容',
        '  mkdir <目录>      新建目录          touch <文件>   新建文件',
        '  rm [-r] <目标>    删除              tree [目录]    目录树',
        '  grep <词> <文件>  文本搜索          find <关键词>   递归查找',
        '  head <文件>       前 8 行           wc <文件>      统计',
        '  open <文件>       用默认应用打开    echo <文本>    输出文本',
        '  neofetch          系统信息          date/uname/whoami/hostname',
        '  history           命令历史          clear          清屏',
        ''
      ]
      break
    case 'ls':
      out = ls(args)
      break
    case 'cd':
      out = cd(args)
      break
    case 'pwd':
      out = [cwd.value]
      break
    case 'cat':
      out = cat(args)
      break
    case 'echo':
      out = [args.join(' ')]
      break
    case 'mkdir':
      out = mkdir(args)
      break
    case 'touch':
      out = touch(args)
      break
    case 'rm':
      out = rm(args)
      break
    case 'tree':
      out = [prettyPath(normalizePath(args[0] ?? '.', cwd.value)), ...treeOf(normalizePath(args[0] ?? '.', cwd.value))]
      break
    case 'grep':
      out = grep(args)
      break
    case 'find':
      out = find(args)
      break
    case 'head':
      out = head(args)
      break
    case 'wc':
      out = wc(args)
      break
    case 'open':
      out = open(args)
      break
    case 'neofetch':
      out = neofetch()
      break
    case 'uname':
      out = ['Linux cosmic-pc 6.12.0-cosmic #1 SMP PREEMPT_DYNAMIC x86_64 GNU/Linux']
      break
    case 'whoami':
      out = ['cosmic']
      break
    case 'hostname':
      out = ['cosmic-pc']
      break
    case 'date':
      out = [new Date().toString()]
      break
    case 'history':
      out = cmdHistory.value.map((c, i) => `${String(i + 1).padStart(4)}  ${c}`)
      break
    case 'clear':
      lines.value = []
      return
    case 'exit':
      store.close(winId)
      return
    default:
      out = [`cosmic-term: 未找到命令 "${cmd}"，输入 "help" 查看帮助`]
  }
  printLines(out)
}

function submit() {
  const raw = input.value
  if (raw.trim()) {
    cmdHistory.value.push(raw.trim())
    histIdx.value = cmdHistory.value.length
  }
  run(raw)
  input.value = ''
  scrollBottom()
}

function onKeydown(e: KeyboardEvent) {
  if (e.key === 'Enter') {
    e.preventDefault()
    submit()
  } else if (e.key === 'ArrowUp') {
    e.preventDefault()
    if (histIdx.value > 0) {
      histIdx.value -= 1
      input.value = cmdHistory.value[histIdx.value] ?? ''
    }
  } else if (e.key === 'ArrowDown') {
    e.preventDefault()
    if (histIdx.value < cmdHistory.value.length - 1) {
      histIdx.value += 1
      input.value = cmdHistory.value[histIdx.value] ?? ''
    } else {
      histIdx.value = cmdHistory.value.length
      input.value = ''
    }
  } else if (e.key === 'Tab') {
    e.preventDefault()
    const parts = input.value.split(/\s+/)
    const last = parts[parts.length - 1] ?? ''
    if (parts.length === 1) {
      const hit = COMMANDS.filter((c) => c.startsWith(last))
      if (hit.length === 1) input.value = hit[0] + ' '
      else if (hit.length > 1) print(hit.join('   '))
    } else {
      const hit = listDir(cwd.value).filter((n) => n.name.startsWith(last))
      if (hit.length === 1) {
        parts[parts.length - 1] = hit[0].name
        input.value = parts.join(' ')
      } else if (hit.length > 1) print(hit.map((n) => n.name).join('   '))
    }
    scrollBottom()
  } else if (e.key === 'l' && e.ctrlKey) {
    e.preventDefault()
    lines.value = []
  }
}

onMounted(() => {
  printLines(MOTD)
  nextTick(() => inputEl.value?.focus())
})

/** 左侧导航里的快捷命令：直接把命令塞进终端并执行 */
function quick(cmd: string) {
  input.value = ''
  run(cmd)
  scrollBottom()
}
</script>

<template>
  <M3AppShell fabIcon="ri-eraser-line" @fab="quick('clear')">
    <template #rail>
      <aside class="c-sidebar">
        <div class="c-side-title">快捷命令</div>
        <button class="c-side-item" @click="quick('help')">
          <Icon name="ri-question-line" :size="17" />
          <span>帮助</span>
        </button>
        <button class="c-side-item" @click="quick('neofetch')">
          <Icon name="ri-information-line" :size="17" />
          <span>系统信息</span>
        </button>
        <button class="c-side-item" @click="quick('ls -l')">
          <Icon name="ri-list-check-2" :size="17" />
          <span>列出目录</span>
        </button>
        <button class="c-side-item" @click="quick('tree')">
          <Icon name="ri-node-tree" :size="17" />
          <span>目录树</span>
        </button>
        <button class="c-side-item" @click="quick('history')">
          <Icon name="ri-history-line" :size="17" />
          <span>命令历史</span>
        </button>
        <div class="c-side-title">操作</div>
        <button class="c-side-item" @click="quick('clear')">
          <Icon name="ri-eraser-line" :size="17" />
          <span>清屏</span>
        </button>
      </aside>
    </template>

    <div class="ct" @click="focusInput">
      <div ref="scroller" class="ct-scroll c-scroll">
        <div
          v-for="l in lines"
          :key="l.id"
          class="ct-line"
          :class="{ 'ct-line--cmd': l.cls === 'cmd' }"
        >
          {{ l.text || ' ' }}
        </div>

        <div class="ct-prompt">
          <span class="ct-ps1">{{ prompt }}</span>
          <input
            ref="inputEl"
            v-model="input"
            class="ct-input"
            spellcheck="false"
            autocomplete="off"
            @keydown="onKeydown"
          />
        </div>
      </div>

      <div class="ct-status">
        <Icon name="ri-terminal-box-line" :size="13" />
        <span>cosmic-term</span>
        <span class="ct-sep">·</span>
        <span>{{ prettyPath(cwd) }}</span>
        <span class="ct-right">UTF-8 · zsh · 80×24</span>
      </div>
    </div>
  </M3AppShell>
</template>

<style scoped>
.ct {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  background: #101013;
  font-family: 'JetBrains Mono', 'Fira Code', 'SFMono-Regular', Consolas, monospace;
  font-size: 12.5px;
  line-height: 1.55;
}
.ct-scroll {
  flex: 1;
  min-height: 0;
  padding: 12px 14px 4px;
  color: #d6d6db;
  white-space: pre-wrap;
  word-break: break-word;
}
.ct-line {
  color: #c9c9d1;
}
.ct-line--cmd {
  color: #f0f0f4;
  font-weight: 600;
}
.ct-prompt {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-top: 2px;
}
.ct-ps1 {
  color: #6fdc9c;
  font-weight: 700;
  white-space: nowrap;
  flex: none;
}
.ct-input {
  flex: 1;
  min-width: 0;
  background: transparent;
  border: none;
  outline: none;
  color: #f0f0f4;
  font: inherit;
  caret-color: #6fdc9c;
  padding: 0;
}
.ct-status {
  flex: none;
  height: 28px;
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 0 12px;
  background: #17171c;
  border-top: 1px solid rgba(255, 255, 255, 0.07);
  color: #8b8b96;
  font-size: 11.5px;
}
.ct-sep {
  opacity: 0.5;
}
.ct-right {
  margin-left: auto;
}
</style>
