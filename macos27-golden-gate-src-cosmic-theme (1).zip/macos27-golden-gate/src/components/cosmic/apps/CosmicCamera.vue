<script setup lang="ts">
/**
 * COSMIC Camera —— 摄像头
 * 尝试调用 getUserMedia 显示真实画面；无权限/无设备时退化为模拟取景器
 * （网格、准星、时间码、录制指示），保留完整的拍摄交互。
 */
import { computed, onMounted, onUnmounted, ref } from 'vue'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const video = ref<HTMLVideoElement | null>(null)
const stream = ref<MediaStream | null>(null)
const live = ref(false)
const denied = ref(false)
const recording = ref(false)
const shots = ref<Array<{ id: number; url: string; at: string }>>([])
const flash = ref(false)
const elapsed = ref(0)
const now = ref(new Date())
let timer = 0
let clock = 0
let shotId = 1

const timecode = computed(() => {
  const s = elapsed.value
  const mm = String(Math.floor(s / 60)).padStart(2, '0')
  const ss = String(s % 60).padStart(2, '0')
  return `${mm}:${ss}`
})
const stamp = computed(() =>
  now.value.toLocaleTimeString('zh-CN', { hour12: false })
)

async function start() {
  try {
    const media = await navigator.mediaDevices.getUserMedia({ video: true, audio: false })
    stream.value = media
    live.value = true
    if (video.value) {
      video.value.srcObject = media
      await video.value.play().catch(() => {})
    }
  } catch {
    denied.value = true
    live.value = false
  }
}

function stop() {
  stream.value?.getTracks().forEach((t) => t.stop())
  stream.value = null
  live.value = false
}

function snapshot() {
  flash.value = true
  setTimeout(() => (flash.value = false), 160)
  const at = new Date().toLocaleTimeString('zh-CN', { hour12: false })
  if (live.value && video.value) {
    const c = document.createElement('canvas')
    c.width = video.value.videoWidth || 640
    c.height = video.value.videoHeight || 360
    c.getContext('2d')?.drawImage(video.value, 0, 0, c.width, c.height)
    shots.value.unshift({ id: shotId++, url: c.toDataURL('image/jpeg', 0.85), at })
  } else {
    // 模拟拍摄：用当前取景器的渐变作为缩略图
    shots.value.unshift({ id: shotId++, url: '', at })
  }
  shots.value = shots.value.slice(0, 8)
}

function toggleRecord() {
  recording.value = !recording.value
  if (recording.value) {
    elapsed.value = 0
    timer = window.setInterval(() => elapsed.value++, 1000)
  } else {
    clearInterval(timer)
    timer = 0
  }
}

onMounted(() => {
  start()
  clock = window.setInterval(() => (now.value = new Date()), 1000)
})
onUnmounted(() => {
  stop()
  clearInterval(timer)
  clearInterval(clock)
})
</script>

<template>
  <M3AppShell fabIcon="ri-camera-lens-line" @fab="snapshot">
    <template #rail>
      <aside class="c-sidebar">
        <div class="c-side-title">取景</div>
        <button class="c-side-item" @click="snapshot">
          <Icon name="ri-camera-lens-line" :size="17" />
          <span>拍照</span>
        </button>
        <button class="c-side-item" :class="{ active: recording }" @click="toggleRecord">
          <Icon :name="recording ? 'ri-stop-circle-line' : 'ri-record-circle-line'" :size="17" />
          <span>{{ recording ? '停止录制' : '开始录制' }}</span>
        </button>
        <button class="c-side-item" :class="{ active: live }" @click="live ? stop() : start()">
          <Icon :name="live ? 'ri-camera-off-line' : 'ri-camera-line'" :size="17" />
          <span>{{ live ? '断开连接' : '连接摄像头' }}</span>
        </button>
      </aside>
    </template>

    <div class="cam">
    <div class="cam-stage">
      <video v-show="live" ref="video" class="cam-video" muted playsinline />
      <div v-if="!live" class="cam-fallback">
        <div class="cam-orb" />
        <div class="cam-noise" />
        <div class="cam-hint">
          <Icon name="ri-camera-off-line" :size="22" />
          <span>{{ denied ? '未获得摄像头权限 · 模拟取景器' : '正在连接摄像头…' }}</span>
        </div>
      </div>

      <div class="cam-grid" />
      <div class="cam-reticle" />
      <div class="cam-hud">
        <span class="cam-badge" :class="{ 'is-rec': recording }">
          <i />{{ recording ? 'REC ' + timecode : 'CAM' }}
        </span>
        <span class="cam-clock">{{ stamp }}</span>
      </div>
      <div v-if="flash" class="cam-flash" />
    </div>

    <div class="cam-bar">
      <div class="cam-thumbs">
        <div v-for="s in shots" :key="s.id" class="cam-thumb" :title="s.at">
          <img v-if="s.url" :src="s.url" alt="" />
          <div v-else class="cam-thumb-mock" />
        </div>
        <span v-if="!shots.length" class="cam-empty">还没有照片</span>
      </div>

      <div class="cam-actions">
        <button class="cam-btn" :class="{ on: recording }" @click="toggleRecord">
          <Icon :name="recording ? 'ri-stop-circle-line' : 'ri-record-circle-line'" :size="18" />
        </button>
        <button class="cam-shutter" title="拍照" @click="snapshot"><i /></button>
        <button class="cam-btn" :class="{ on: live }" @click="live ? stop() : start()">
          <Icon :name="live ? 'ri-camera-off-line' : 'ri-camera-line'" :size="18" />
        </button>
      </div>
    </div>
  </div>
  </M3AppShell>
</template>

<style scoped>
.cam {
  height: 100%;
  display: flex;
  flex-direction: column;
  min-height: 0;
}
.cam-stage {
  position: relative;
  flex: 1;
  min-height: 0;
  overflow: hidden;
  background: #08090c;
}
.cam-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transform: scaleX(-1);
}
.cam-fallback {
  position: absolute;
  inset: 0;
  background:
    radial-gradient(120% 90% at 30% 20%, #1d2a3a 0%, #0b1018 55%, #06070a 100%);
  display: grid;
  place-items: center;
}
.cam-orb {
  width: 46%;
  aspect-ratio: 1;
  border-radius: 50%;
  background: radial-gradient(circle at 38% 32%, rgba(120, 190, 255, 0.30), rgba(40, 90, 160, 0.06) 62%, transparent 72%);
  filter: blur(6px);
  animation: cam-drift 9s ease-in-out infinite alternate;
}
@keyframes cam-drift {
  to { transform: translate3d(4%, -3%, 0) scale(1.06); }
}
.cam-noise {
  position: absolute;
  inset: -50%;
  opacity: 0.05;
  background-image: repeating-conic-gradient(#fff 0% 0.0004%, #000 0% 0.0008%);
  animation: cam-grain 0.7s steps(2) infinite;
}
@keyframes cam-grain {
  50% { transform: translate3d(-1%, 1%, 0); }
}
.cam-hint {
  position: absolute;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.55);
  background: rgba(0, 0, 0, 0.35);
  padding: 7px 12px;
  border-radius: 999px;
  border: 1px solid rgba(255, 255, 255, 0.08);
}
.cam-grid {
  position: absolute;
  inset: 0;
  pointer-events: none;
  background-image:
    linear-gradient(rgba(255, 255, 255, 0.07) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.07) 1px, transparent 1px);
  background-size: 33.334% 33.334%;
}
.cam-reticle {
  position: absolute;
  left: 50%;
  top: 50%;
  width: 54px;
  height: 54px;
  margin: -27px 0 0 -27px;
  border: 1.5px solid rgba(255, 255, 255, 0.5);
  border-radius: 50%;
  pointer-events: none;
}
.cam-reticle::before,
.cam-reticle::after {
  content: '';
  position: absolute;
  background: rgba(255, 255, 255, 0.5);
}
.cam-reticle::before { left: 50%; top: -8px; width: 1.5px; height: 8px; margin-left: -0.75px; }
.cam-reticle::after { top: 50%; left: -8px; height: 1.5px; width: 8px; margin-top: -0.75px; }
.cam-hud {
  position: absolute;
  left: 12px;
  right: 12px;
  top: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  letter-spacing: 0.06em;
  color: rgba(255, 255, 255, 0.72);
  pointer-events: none;
}
.cam-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 9px;
  border-radius: 999px;
  background: rgba(0, 0, 0, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.1);
}
.cam-badge i {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #48d6a0;
}
.cam-badge.is-rec i { background: #ff4b55; animation: cam-blink 1s steps(2) infinite; }
@keyframes cam-blink { 50% { opacity: 0.2; } }
.cam-flash {
  position: absolute;
  inset: 0;
  background: #fff;
  animation: cam-flash 0.16s ease-out;
}
@keyframes cam-flash { from { opacity: 0.85; } to { opacity: 0; } }
.cam-bar {
  flex: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 10px 14px;
  border-top: 1px solid var(--c-border);
}
.cam-thumbs {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
}
.cam-thumb {
  width: 44px;
  height: 30px;
  border-radius: 6px;
  overflow: hidden;
  border: 1px solid var(--c-border);
  flex: none;
}
.cam-thumb img { width: 100%; height: 100%; object-fit: cover; }
.cam-thumb-mock {
  width: 100%;
  height: 100%;
  background: radial-gradient(circle at 35% 30%, #2a4a6a, #0a0f16);
}
.cam-empty { font-size: 11.5px; color: var(--c-text-mute); }
.cam-actions { display: flex; align-items: center; gap: 10px; }
.cam-btn {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  border: 1px solid var(--c-border);
  background: var(--c-surface-2);
  color: var(--c-text);
  display: grid;
  place-items: center;
  cursor: pointer;
}
.cam-btn.on { color: #ff6b73; border-color: rgba(255, 107, 115, 0.5); }
.cam-shutter {
  width: 52px;
  height: 52px;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.35);
  background: transparent;
  display: grid;
  place-items: center;
  cursor: pointer;
}
.cam-shutter i {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: #fff;
  transition: transform 0.1s;
}
.cam-shutter:active i { transform: scale(0.9); }
</style>
