<script setup lang="ts">
/**
 * COSMIC Settings —— 完整设置中心
 * 22 个分页，侧边栏分组 + 搜索；外观/Dock 等改动实时作用于桌面。
 */
import { computed, inject, onMounted, ref, watch, type Component } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

import PageAbout from './settings/PageAbout.vue'
import PageAppearance from './settings/PageAppearance.vue'
import PageDesktop from './settings/PageDesktop.vue'
import PagePanel from './settings/PagePanel.vue'
import PageDock from './settings/PageDock.vue'
import PageWindows from './settings/PageWindows.vue'
import PageDisplays from './settings/PageDisplays.vue'
import PageSound from './settings/PageSound.vue'
import PageNetwork from './settings/PageNetwork.vue'
import PageBluetooth from './settings/PageBluetooth.vue'
import PagePower from './settings/PagePower.vue'
import PageInput from './settings/PageInput.vue'
import PageNotifications from './settings/PageNotifications.vue'
import PageApplications from './settings/PageApplications.vue'
import PageStartup from './settings/PageStartup.vue'
import PageUsers from './settings/PageUsers.vue'
import PageRegion from './settings/PageRegion.vue'
import PageTime from './settings/PageTime.vue'
import PagePrivacy from './settings/PagePrivacy.vue'
import PageAccessibility from './settings/PageAccessibility.vue'
import PageUpdates from './settings/PageUpdates.vue'
import PageFirmware from './settings/PageFirmware.vue'
import PageWallpapers from './settings/PageWallpapers.vue'
import PagePrinters from './settings/PagePrinters.vue'
import PageShortcuts from './settings/PageShortcuts.vue'
import PageKeyboard from './settings/PageKeyboard.vue'
import PageMouse from './settings/PageMouse.vue'
import PageTablet from './settings/PageTablet.vue'
import PageSoundApps from './settings/PageSoundApps.vue'
import PageWorkspaces from './settings/PageWorkspaces.vue'
import PageLegacy from './settings/PageLegacy.vue'
import PageCtlSettings from './settings/PageCtlSettings.vue'

interface PageItem {
  id: string
  label: string
  icon: string
  comp: Component
  kw?: string
}

const groups: { title: string; items: PageItem[] }[] = [
  {
    title: '系统',
    items: [
      { id: 'about', label: '关于', icon: 'ri-information-line', comp: PageAbout },
      { id: 'updates', label: '系统更新', icon: 'ri-download-cloud-2-line', comp: PageUpdates },
      { id: 'firmware', label: '固件', icon: 'ri-cpu-line', comp: PageFirmware },
      { id: 'users', label: '用户', icon: 'ri-user-3-line', comp: PageUsers, kw: '账户 密码 登录' }
    ]
  },
  {
    title: '设备',
    items: [
      { id: 'network', label: '网络与无线', icon: 'ri-wifi-line', comp: PageNetwork, kw: 'Wi-Fi 有线 VPN 代理' },
      { id: 'bluetooth', label: '蓝牙', icon: 'ri-bluetooth-line', comp: PageBluetooth, kw: '配对 设备' },
      { id: 'displays', label: '显示', icon: 'ri-tv-2-line', comp: PageDisplays, kw: '分辨率 亮度 夜间 显示器' },
      { id: 'sound', label: '声音', icon: 'ri-volume-up-line', comp: PageSound, kw: '音量 麦克风 扬声器' },
      { id: 'sound-apps', label: '应用音量', icon: 'ri-equalizer-line', comp: PageSoundApps, kw: '每个应用 混音 路由' },
      { id: 'power', label: '电源', icon: 'ri-battery-charge-line', comp: PagePower, kw: '电池 省电 挂起' },
      { id: 'input', label: '输入设备', icon: 'ri-mouse-line', comp: PageInput, kw: '触控板 手势' },
      { id: 'keyboard', label: '键盘', icon: 'ri-keyboard-line', comp: PageKeyboard, kw: '重复速率 布局 背光 屏幕键盘' },
      { id: 'mouse', label: '鼠标', icon: 'ri-mouse-fill', comp: PageMouse, kw: '指针 滚动 按键映射' },
      { id: 'tablet', label: '绘图板', icon: 'ri-pen-nib-line', comp: PageTablet, kw: '数位板 笔 压感' },
      { id: 'shortcuts', label: '键盘快捷键', icon: 'ri-command-line', comp: PageShortcuts, kw: '快捷键 组合键 录制' }
    ]
  },
  {
    title: '桌面',
    items: [
      { id: 'appearance', label: '外观', icon: 'ri-palette-line', comp: PageAppearance, kw: '主题 强调色 深色 浅色 圆角 字体' },
      { id: 'desktop', label: '桌面', icon: 'ri-computer-line', comp: PageDesktop, kw: '桌面图标 填充 时间' },
      { id: 'wallpapers', label: '壁纸', icon: 'ri-image-2-line', comp: PageWallpapers, kw: '背景 纯色 渐变 提取颜色' },
      { id: 'panel', label: '面板', icon: 'ri-layout-top-line', comp: PagePanel, kw: '顶栏 插件' },
      { id: 'dock', label: 'Dock', icon: 'ri-layout-bottom-line', comp: PageDock, kw: '停靠栏' },
      { id: 'workspaces', label: '工作区', icon: 'ri-layout-grid-line', comp: PageWorkspaces, kw: '动态工作区 排列' },
      { id: 'windows', label: '窗口管理', icon: 'ri-window-2-line', comp: PageWindows, kw: '平铺 吸附 聚焦' }
    ]
  },
  {
    title: '个性化',
    items: [
      { id: 'notifications', label: '通知', icon: 'ri-notification-3-line', comp: PageNotifications, kw: '勿扰 横幅' },
      { id: 'applications', label: '应用程序', icon: 'ri-apps-2-line', comp: PageApplications, kw: '默认应用 启动器' },
      { id: 'legacy', label: '旧版应用程序', icon: 'ri-window-2-fill', comp: PageLegacy, kw: 'X11 XWayland 兼容' },
      { id: 'startup', label: '启动应用程序', icon: 'ri-rocket-line', comp: PageStartup, kw: '自启动' },
      { id: 'region', label: '区域与语言', icon: 'ri-translate-2', comp: PageRegion, kw: '语言 时区 输入法' },
      { id: 'time', label: '时间与日期', icon: 'ri-time-line', comp: PageTime, kw: '时钟 NTP' },
      { id: 'privacy', label: '隐私', icon: 'ri-shield-check-line', comp: PagePrivacy, kw: '权限 摄像头' },
      { id: 'accessibility', label: '辅助功能', icon: 'ri-user-heart-line', comp: PageAccessibility, kw: '无障碍 大字体 放大镜 屏幕键盘' },
      { id: 'printers', label: '打印机', icon: 'ri-printer-line', comp: PagePrinters, kw: 'CUPS 打印队列' }
    ]
  },
  {
    title: 'ContainerLinux',
    items: [
      { id: 'ctl', label: '容器系统', icon: 'ri-stack-line', comp: PageCtlSettings, kw: 'ContainerLinux 守护 功能 系统' }
    ]
  }
]

const store = useCosmicStore()
const winId = inject<string>('cosmicWinId', '')

const page = ref('appearance')
const q = ref('')

const allItems = computed(() => groups.flatMap((g) => g.items))
const shownGroups = computed(() => {
  const k = q.value.trim().toLowerCase()
  if (!k) return groups
  return groups
    .map((g) => ({
      title: g.title,
      items: g.items.filter(
        (i) =>
          i.label.toLowerCase().includes(k) ||
          i.id.includes(k) ||
          (i.kw ?? '').toLowerCase().includes(k)
      )
    }))
    .filter((g) => g.items.length)
})
const current = computed<Component | undefined>(() => allItems.value.find((i) => i.id === page.value)?.comp)

/* 外部（如通知条「通知管理」）要求直接跳到某一分页：
   用 store.pending 传 page id，这里消费后切过去。 */
watch(
  () => store.pending['settings'],
  (v) => {
    const id = (v as { page?: string } | undefined)?.page
    if (!id) return
    store.takePending('settings')
    if (allItems.value.some((i) => i.id === id)) page.value = id
  },
  { immediate: true }
)

onMounted(() => store.setTitle(winId, 'COSMIC Settings'))
</script>

<template>
  <M3AppShell fabIcon="ri-refresh-line">
  <template #rail>
    <aside class="c-sidebar cst-side">
      <div class="cst-search">
        <Icon name="ri-search-line" :size="15" color="var(--c-text-mute)" />
        <input v-model="q" placeholder="搜索设置…" spellcheck="false" />
      </div>
      <div class="cst-nav c-scroll">
        <template v-for="g in shownGroups" :key="g.title">
          <div class="c-side-title">{{ g.title }}</div>
          <button
            v-for="it in g.items"
            :key="it.id"
            class="c-side-item"
            :data-page="it.id"
            :class="{ active: page === it.id }"
            @click="page = it.id"
          >
            <Icon :name="it.icon" :size="16" />
            <span>{{ it.label }}</span>
          </button>
        </template>
        <div v-if="!shownGroups.length" class="cst-noresult">没有匹配的设置项</div>
      </div>
    </aside>
  </template>
  <div class="cx-root cst">
    <section class="c-main">
      <component :is="current" />
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.cst {
  position: relative;
}
.cst-side {
  padding: 0;
  width: 224px;
}
.cst-search {
  flex: none;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  border-bottom: 1px solid var(--c-border);
}
.cst-search input {
  flex: 1;
  min-width: 0;
  border: none;
  outline: none;
  background: transparent;
  color: var(--c-text);
  font: inherit;
  font-size: 13px;
}
.cst-search input::placeholder {
  color: var(--c-text-mute);
}
.cst-nav {
  flex: 1;
  min-height: 0;
  padding: 4px 8px 14px;
}
.cst-noresult {
  padding: 16px 10px;
  color: var(--c-text-mute);
  font-size: 12.5px;
}
</style>
