<script setup lang="ts">
/**
 * COSMIC Calculator —— 计算器
 * 支持键盘输入、表达式历史与百分比；四则运算 + 退格 + 清除。
 */
import { computed, onMounted, onUnmounted, ref } from 'vue'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const MODE_ICON: Record<string, string> = {
  标准: 'ri-calculator-line',
  科学: 'ri-function-line',
  转换: 'ri-exchange-line',
  进制: 'ri-hashtag'
}
function modeIcon(m: string): string {
  return MODE_ICON[m] ?? 'ri-calculator-line'
}

const expr = ref('')
const result = ref('0')
const history = ref<Array<{ e: string; r: string }>>([])
const mode = ref('标准')
const showHistory = ref(true)
const modes = ['标准', '科学', '转换', '进制']

const keys = [
  ['C', '±', '%', '÷'],
  ['7', '8', '9', '×'],
  ['4', '5', '6', '−'],
  ['1', '2', '3', '+'],
  ['0', '.', '⌫', '=']
] as const

function normalize(e: string): string {
  return e.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/%/g, '/100')
}

function evalExpr(e: string): string {
  if (!e.trim()) return '0'
  // 只允许数字与四则运算字符，避免 eval 任意代码
  if (!/^[\d+\-*/().\s]+$/.test(normalize(e))) return 'Error'
  try {
    // eslint-disable-next-line no-new-func
    const v = Function(`"use strict"; return (${normalize(e)})`)()
    if (typeof v !== 'number' || !isFinite(v)) return 'Error'
    return String(Math.round(v * 1e10) / 1e10)
  } catch {
    return 'Error'
  }
}

function preview() {
  const v = evalExpr(expr.value)
  result.value = v === 'Error' ? v : v
}

function press(k: string) {
  if (k === 'C') {
    expr.value = ''
    result.value = '0'
    return
  }
  if (k === '⌫') {
    expr.value = expr.value.slice(0, -1)
    preview()
    return
  }
  if (k === '=') {
    const r = evalExpr(expr.value)
    if (r !== 'Error' && expr.value.trim()) {
      history.value.unshift({ e: expr.value, r })
      history.value = history.value.slice(0, 24)
    }
    result.value = r
    expr.value = r === 'Error' ? '' : r
    return
  }
  if (k === '±') {
    if (!expr.value) return
    expr.value = expr.value.startsWith('-') ? expr.value.slice(1) : '-' + expr.value
    preview()
    return
  }
  expr.value += k
  preview()
}

function onKey(ev: KeyboardEvent) {
  const k = ev.key
  if (/^[0-9.]$/.test(k)) return press(k)
  if (k === '+' ) return press('+')
  if (k === '-') return press('−')
  if (k === '*') return press('×')
  if (k === '/') return press('÷')
  if (k === '%') return press('%')
  if (k === 'Enter' || k === '=') return press('=')
  if (k === 'Backspace') return press('⌫')
  if (k === 'Escape') return press('C')
}

onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))

const display = computed(() => (expr.value || '0'))
</script>

<template>
  <M3AppShell fabIcon="ri-delete-back-2-line" @fab="press('C')">
    <template #rail>
      <aside class="c-sidebar">
        <div class="c-side-title">模式</div>
        <button
          v-for="m in modes"
          :key="m"
          class="c-side-item"
          :class="{ active: mode === m }"
          @click="mode = m"
        >
          <Icon :name="modeIcon(m)" :size="17" />
          <span>{{ m }}</span>
        </button>

        <div class="c-side-title">面板</div>
        <button class="c-side-item" :class="{ active: showHistory }" @click="showHistory = !showHistory">
          <Icon name="ri-history-line" :size="17" />
          <span>历史记录</span>
        </button>
      </aside>
    </template>

    <div class="calc">
      <div class="calc-screen">
        <div class="calc-mode">{{ mode }}</div>
        <div class="calc-expr">{{ display }}</div>
        <div class="calc-result">{{ result }}</div>
      </div>

      <div class="calc-body">
        <div class="calc-pad">
          <button
            v-for="k in keys.flat()"
            :key="k"
            class="calc-key"
            :class="{
              'calc-key--op': ['÷', '×', '−', '+', '='].includes(k),
              'calc-key--fn': ['C', '±', '%', '⌫'].includes(k)
            }"
            @click="press(k)"
          >
            {{ k }}
          </button>
        </div>

        <aside v-if="showHistory" class="calc-history c-scroll">
          <div class="calc-history-title">历史</div>
          <div v-if="!history.length" class="calc-history-empty">还没有计算记录</div>
          <button
            v-for="(h, i) in history"
            :key="i"
            class="calc-history-item"
            @click="expr = h.r; preview()"
          >
            <span class="calc-h-e">{{ h.e }}</span>
            <span class="calc-h-r">= {{ h.r }}</span>
          </button>
        </aside>
      </div>
    </div>
  </M3AppShell>
</template>

<style scoped>
.calc {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: transparent;
  min-height: 0;
}
.calc-screen {
  flex: none;
  padding: 20px 22px 14px;
  text-align: right;
  border-bottom: 1px solid var(--c-border);
}
.calc-mode {
  display: inline-block;
  font-size: 11px;
  letter-spacing: 0.06em;
  color: var(--c-accent);
  background: var(--c-accent-soft);
  padding: 2px 9px;
  border-radius: 999px;
  margin-bottom: 8px;
}
.calc-expr {
  font-size: 13px;
  color: var(--c-text-dim);
  min-height: 18px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.calc-result {
  font-size: 40px;
  font-weight: 700;
  letter-spacing: -0.02em;
  line-height: 1.2;
  margin-top: 6px;
  font-variant-numeric: tabular-nums;
}
.calc-body {
  flex: 1;
  min-height: 0;
  display: flex;
}
.calc-pad {
  flex: 1.4;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
  padding: 12px;
}
.calc-key {
  border: 1px solid var(--c-border);
  border-radius: 14px;
  background: color-mix(in srgb, var(--c-surface-2) 74%, transparent);
  color: var(--c-text);
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.12s, transform 0.08s;
}
.calc-key:hover {
  background: color-mix(in srgb, var(--c-surface-3) 86%, transparent);
}
.calc-key:active {
  transform: scale(0.96);
}
.calc-key--op {
  background: color-mix(in srgb, var(--c-accent) 26%, transparent);
  border-color: color-mix(in srgb, var(--c-accent) 42%, transparent);
}
.calc-key--fn {
  background: color-mix(in srgb, var(--c-surface-3) 62%, transparent);
  font-size: 15px;
}
.calc-history {
  flex: 1;
  border-left: 1px solid var(--c-border);
  padding: 12px 10px;
  overflow-y: auto;
}
.calc-history-title {
  font-size: 10.5px;
  letter-spacing: 0.09em;
  text-transform: uppercase;
  color: var(--c-text-mute);
  padding: 2px 6px 8px;
}
.calc-history-empty {
  font-size: 12px;
  color: var(--c-text-mute);
  padding: 6px;
}
.calc-history-item {
  width: 100%;
  text-align: left;
  border: none;
  background: transparent;
  color: var(--c-text);
  padding: 7px 6px;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.calc-history-item:hover {
  background: var(--c-surface-2);
}
.calc-h-e {
  font-size: 11.5px;
  color: var(--c-text-dim);
}
.calc-h-r {
  font-size: 14px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}
</style>
