<script setup lang="ts">
/**
 * COSMIC Disks —— 磁盘管理
 * 卷列表 + 容量条 + 挂载/卸载（模拟）+ 详情面板。
 */
import { computed, ref } from 'vue'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

interface Volume {
  id: string
  name: string
  mount: string
  fs: string
  total: number
  used: number
  kind: 'ssd' | 'hdd' | 'usb' | 'net'
  mounted: boolean
}

const GB = 1024 ** 3
const volumes = ref<Volume[]>([
  { id: 'v1', name: 'System', mount: '/', fs: 'btrfs', total: 512 * GB, used: 186 * GB, kind: 'ssd', mounted: true },
  { id: 'v2', name: 'Home', mount: '/home', fs: 'btrfs', total: 1.5 * 1024 * GB, used: 604 * GB, kind: 'ssd', mounted: true },
  { id: 'v3', name: 'Backup', mount: '/mnt/backup', fs: 'ext4', total: 2 * 1024 * GB, used: 1.42 * 1024 * GB, kind: 'hdd', mounted: true },
  { id: 'v4', name: 'COSMIC-USB', mount: '', fs: 'exfat', total: 64 * GB, used: 12 * GB, kind: 'usb', mounted: false },
  { id: 'v5', name: 'NAS', mount: '/mnt/nas', fs: 'nfs', total: 4 * 1024 * GB, used: 2.1 * 1024 * GB, kind: 'net', mounted: true }
])

const selected = ref<string>('v1')

const icons: Record<Volume['kind'], string> = {
  ssd: 'ri-hard-drive-3-line',
  hdd: 'ri-hard-drive-2-line',
  usb: 'ri-usb-line',
  net: 'ri-cloud-line'
}

function fmt(n: number) {
  if (n >= 1024 * GB) return (n / (1024 * GB)).toFixed(1) + ' TB'
  return Math.round(n / GB) + ' GB'
}
function pct(v: Volume) {
  return Math.min(100, Math.round((v.used / v.total) * 100))
}
function barColor(p: number) {
  if (p >= 90) return '#ff5b63'
  if (p >= 75) return '#f0b64a'
  return 'var(--c-accent)'
}
function toggleMount(v: Volume) {
  v.mounted = !v.mounted
  v.mount = v.mounted ? (v.mount || '/media/' + v.name.toLowerCase()) : ''
}

const cur = computed(() => volumes.value.find((v) => v.id === selected.value) ?? volumes.value[0])
const totalUsed = computed(() => volumes.value.filter((v) => v.mounted).reduce((a, v) => a + v.used, 0))
const totalCap = computed(() => volumes.value.filter((v) => v.mounted).reduce((a, v) => a + v.total, 0))
</script>

<template>
  <M3AppShell fabIcon="ri-hard-drive-2-line">
  <template #rail>
    <aside class="c-sidebar disks-side">
      <div class="c-side-title">存储卷</div>
      <button
        v-for="v in volumes"
        :key="v.id"
        class="disks-item"
        :class="{ on: selected === v.id }"
        @click="selected = v.id"
      >
        <Icon :name="icons[v.kind]" :size="15" />
        <span class="disks-name">{{ v.name }}</span>
        <span class="disks-badge" :class="{ off: !v.mounted }">{{ v.mounted ? '已挂载' : '未挂载' }}</span>
      </button>

      <div class="disks-summary">
        <div class="disks-summary-bar">
          <i :style="{ width: (totalUsed / totalCap) * 100 + '%' }" />
        </div>
        <div class="disks-summary-text">
          已用 {{ fmt(totalUsed) }} / {{ fmt(totalCap) }}
        </div>
      </div>
    </aside>
  </template>
  <div class="disks">
    <section class="disks-main">
      <div class="c-toolbar">
        <b class="disks-title">{{ cur.name }}</b>
        <span class="disks-mount">{{ cur.mounted ? cur.mount : '未挂载' }}</span>
        <div style="flex: 1" />
        <button class="c-btn" @click="toggleMount(cur)">
          <Icon :name="cur.mounted ? 'ri-eject-line' : 'ri-link'" :size="14" />
          {{ cur.mounted ? '卸载' : '挂载' }}
        </button>
      </div>

      <div class="disks-body c-scroll">
        <div class="disks-hero">
          <div class="disks-donut" :style="{ '--p': pct(cur) + '%', '--c': barColor(pct(cur)) }">
            <div class="disks-donut-inner">
              <b>{{ pct(cur) }}%</b>
              <span>已使用</span>
            </div>
          </div>
          <div class="disks-hero-info">
            <div class="disks-kv"><span>容量</span><b>{{ fmt(cur.total) }}</b></div>
            <div class="disks-kv"><span>已用</span><b>{{ fmt(cur.used) }}</b></div>
            <div class="disks-kv"><span>可用</span><b>{{ fmt(cur.total - cur.used) }}</b></div>
            <div class="disks-kv"><span>文件系统</span><b>{{ cur.fs }}</b></div>
          </div>
        </div>

        <div class="disks-section">卷列表</div>
        <div class="disks-table">
          <div class="disks-th">
            <span>名称</span><span>挂载点</span><span>文件系统</span><span>使用量</span><span class="r">占用</span>
          </div>
          <div v-for="v in volumes" :key="v.id" class="disks-tr" :class="{ dim: !v.mounted }">
            <span class="disks-td-name"><Icon :name="icons[v.kind]" :size="13" /> {{ v.name }}</span>
            <span class="mono">{{ v.mount || '—' }}</span>
            <span class="mono">{{ v.fs }}</span>
            <span class="disks-usage">
              <i :style="{ width: pct(v) + '%', background: barColor(pct(v)) }" />
            </span>
            <span class="r mono">{{ pct(v) }}%</span>
          </div>
        </div>
      </div>
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.disks { height: 100%; display: flex; min-height: 0; }
.disks-side { width: 236px; }
.disks-item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 7px 9px;
  border-radius: 8px;
  border: none;
  background: transparent;
  color: var(--c-text);
  font-size: 12.5px;
  cursor: pointer;
  text-align: left;
}
.disks-item:hover { background: var(--c-surface-2); }
.disks-item.on { background: color-mix(in srgb, var(--c-accent) 22%, transparent); }
.disks-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.disks-badge {
  font-size: 9.5px;
  color: #5ec89a;
  background: rgba(94, 200, 154, 0.12);
  padding: 1px 6px;
  border-radius: 999px;
}
.disks-badge.off { color: var(--c-text-mute); background: var(--c-surface-3); }
.disks-summary { margin-top: auto; padding: 10px 9px 2px; }
.disks-summary-bar {
  height: 6px;
  border-radius: 999px;
  background: var(--c-surface-3);
  overflow: hidden;
}
.disks-summary-bar i { display: block; height: 100%; background: var(--c-accent); }
.disks-summary-text { font-size: 10.5px; color: var(--c-text-mute); margin-top: 6px; }
.disks-main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.disks-title { font-size: 13px; }
.disks-mount { font-size: 11.5px; color: var(--c-text-dim); font-family: ui-monospace, monospace; }
.disks-body { flex: 1; min-height: 0; overflow-y: auto; padding: 16px 18px 24px; }
.disks-hero { display: flex; align-items: center; gap: 28px; padding: 8px 4px 20px; }
.disks-donut {
  width: 132px;
  height: 132px;
  border-radius: 50%;
  flex: none;
  background: conic-gradient(var(--c) var(--p), var(--c-surface-3) 0);
  display: grid;
  place-items: center;
}
.disks-donut-inner {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  background: var(--c-surface);
  display: grid;
  place-content: center;
  text-align: center;
  gap: 2px;
}
.disks-donut-inner b { font-size: 24px; }
.disks-donut-inner span { font-size: 10px; color: var(--c-text-mute); }
.disks-hero-info { display: grid; gap: 8px; min-width: 220px; }
.disks-kv { display: flex; justify-content: space-between; gap: 24px; font-size: 12.5px; }
.disks-kv span { color: var(--c-text-dim); }
.disks-section { font-size: 10.5px; letter-spacing: 0.09em; text-transform: uppercase; color: var(--c-text-mute); margin: 6px 2px 8px; }
.disks-table { border: 1px solid var(--c-border); border-radius: 10px; overflow: hidden; }
.disks-th, .disks-tr {
  display: grid;
  grid-template-columns: 1.2fr 1.1fr 0.7fr 1fr 56px;
  gap: 10px;
  align-items: center;
  padding: 8px 12px;
  font-size: 12px;
}
.disks-th { color: var(--c-text-mute); font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.06em; background: var(--c-surface-2); }
.disks-tr + .disks-tr { border-top: 1px solid var(--c-border); }
.disks-tr.dim { opacity: 0.5; }
.disks-td-name { display: flex; align-items: center; gap: 6px; }
.disks-usage { height: 6px; border-radius: 999px; background: var(--c-surface-3); overflow: hidden; }
.disks-usage i { display: block; height: 100%; }
.mono { font-family: ui-monospace, monospace; font-size: 11.5px; color: var(--c-text-dim); }
.r { text-align: right; }
</style>
