<script setup lang="ts">
/**
 * COSMIC Screenshot —— 截图工具
 * 全屏 / 区域 / 窗口三种模式，支持延迟拍摄；拍完真的会把文件写进
 * 虚拟文件系统的 ~/Pictures，Files 与 Viewer 能立刻看到并打开。
 */
import { computed, inject, onMounted, onUnmounted, ref } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import { HOME, createFile, formatSize, listDir, removeNode, type VNode } from '@/utils/cosmicVfs'
import Icon from '@/components/common/Icon.vue'
import M3AppShell from '../M3AppShell.vue'

const store = useCosmicStore()
const winId = inject<string>('cosmicWinId', '')

const PICS = HOME + '/Pictures'

const modes = [
  { id: 'full', label: '全屏', icon: 'ri-fullscreen-line', desc: '捕获整块屏幕' },
  { id: 'area', label: '区域', icon: 'ri-crop-2-line', desc: '拖拽选择矩形区域' },
  { id: 'window', label: '窗口', icon: 'ri-window-2-line', desc: '捕获当前聚焦窗口' }
] as const

const mode = ref<'full' | 'area' | 'window'>('full')
const delay = ref(0)
const toClipboard = ref(true)
const includeCursor = ref(false)
const format = ref<'PNG' | 'JPG'>('PNG')
const playSound = ref(true)

const counting = ref(0)
const flashing = ref(false)
const toast = ref('')
let timer = 0

const history = computed<VNode[]>(() =>
  listDir(PICS)
    .filter((n) => n.kind === 'image')
    .reverse()
)

const currentMode = computed(() => modes.find((m) => m.id === mode.value)!)

function nextName(): string {
  const existing = listDir(PICS).map((n) => n.name)
  let i = 1
  while (existing.includes(`screenshot-${String(i).padStart(2, '0')}.${format.value.toLowerCase()}`)) i += 1
  return `screenshot-${String(i).padStart(2, '0')}.${format.value.toLowerCase()}`
}

function capture() {
  if (counting.value > 0) return
  if (delay.value > 0) {
    counting.value = delay.value
    timer = window.setInterval(() => {
      counting.value -= 1
      if (counting.value <= 0) {
        window.clearInterval(timer)
        finish()
      }
    }, 1000)
  } else {
    finish()
  }
}

function finish() {
  flashing.value = true
  window.setTimeout(() => (flashing.value = false), 220)

  const name = nextName()
  const node = createFile(PICS, name, 'BINARY')
  if (node) {
    node.kind = 'image'
    node.size = 1_800_000 + Math.floor(Math.random() * 900_000)
  }
  if (playSound.value) {
    toast.value = `${name} 已保存到 ~/Pictures${toClipboard.value ? ' · 已复制到剪贴板' : ''}`
  } else {
    toast.value = `${name} 已保存到 ~/Pictures`
  }
  window.setTimeout(() => (toast.value = ''), 2600)
}

function openInViewer(n: VNode) {
  store.openWithPayload('viewer', `${PICS}/${n.name}`)
}
function showInFiles(n: VNode) {
  store.openWithPayload('files', PICS)
  toast.value = `已在文件管理器中定位到 ${n.name}`
  window.setTimeout(() => (toast.value = ''), 1800)
}
function del(n: VNode) {
  removeNode(`${PICS}/${n.name}`)
  toast.value = `已删除 ${n.name}`
  window.setTimeout(() => (toast.value = ''), 1800)
}

onMounted(() => store.setTitle(winId, 'COSMIC Screenshot'))
onUnmounted(() => window.clearInterval(timer))
</script>

<template>
  <M3AppShell fabIcon="ri-camera-lens-line">
  <template #rail>
    <aside class="c-sidebar csh-side">
      <div class="c-side-title">截图模式</div>
      <button
        v-for="m in modes"
        :key="m.id"
        class="c-side-item"
        :class="{ active: mode === m.id }"
        @click="mode = m.id"
      >
        <Icon :name="m.icon" :size="16" /><span>{{ m.label }}</span>
      </button>
      <div class="c-side-title">选项</div>
      <div class="csh-opt">
        <span>延迟</span>
        <select v-model.number="delay" class="set-select" style="min-width: 92px">
          <option :value="0">无</option>
          <option :value="3">3 秒</option>
          <option :value="5">5 秒</option>
          <option :value="10">10 秒</option>
        </select>
      </div>
      <div class="csh-opt">
        <span>格式</span>
        <select v-model="format" class="set-select" style="min-width: 92px">
          <option>PNG</option>
          <option>JPG</option>
        </select>
      </div>
      <div class="csh-switch">
        <span>复制到剪贴板</span>
        <button class="set-switch" :class="{ on: toClipboard }" @click="toClipboard = !toClipboard"><i /></button>
      </div>
      <div class="csh-switch">
        <span>包含光标</span>
        <button class="set-switch" :class="{ on: includeCursor }" @click="includeCursor = !includeCursor"><i /></button>
      </div>
      <div class="csh-switch">
        <span>播放快门音</span>
        <button class="set-switch" :class="{ on: playSound }" @click="playSound = !playSound"><i /></button>
      </div>
    </aside>
  </template>
  <div class="cx-root csh">
    <!-- 左：选项 -->
    <!-- 右：主区 -->
    <section class="c-main">
      <div class="c-toolbar">
        <span class="csh-title">
          <Icon name="ri-screenshot-2-line" :size="15" color="var(--c-accent)" />
          <b>{{ currentMode.label }}截图</b>
        </span>
        <span class="csh-desc">{{ currentMode.desc }}</span>
        <span class="csh-count">{{ history.length }} 张历史</span>
      </div>

      <div class="csh-main c-scroll">
        <div class="csh-stage">
          <div class="csh-mock" :class="{ 'csh-mock--area': mode === 'area', 'csh-mock--window': mode === 'window' }">
            <div class="csh-mock-bar" />
            <div class="csh-mock-body">
              <span class="csh-dots" />
              <b>{{ mode === 'window' ? '聚焦窗口' : mode === 'area' ? '拖拽选择区域' : '整个屏幕' }}</b>
            </div>
            <div v-if="mode === 'area'" class="csh-crop" />
          </div>

          <button class="csh-shoot" @click="capture">
            <Icon name="ri-camera-3-fill" :size="20" color="#fff" />
            <span>{{ delay ? `延迟 ${delay} 秒拍摄` : '立即拍摄' }}</span>
          </button>

          <Transition name="csh-fade">
            <div v-if="counting > 0" class="csh-countdown">
              <b>{{ counting }}</b>
              <span>准备拍摄…</span>
            </div>
          </Transition>
          <div v-if="flashing" class="csh-flash" />
        </div>

        <div class="set-card">
          <div class="set-card-title">历史截图 · 保存在 ~/Pictures</div>
          <div v-for="n in history" :key="n.name" class="set-item">
            <span class="csh-thumb"><Icon name="ri-image-2-fill" :size="16" color="#5bc8a8" /></span>
            <div class="set-item-text">
              <b>{{ n.name }}</b>
              <span>{{ formatSize(n.size) }} · {{ n.mtime }}</span>
            </div>
            <div class="set-item-ctl">
              <button class="c-btn" style="height: 28px; font-size: 12px" @click="openInViewer(n)">
                <Icon name="ri-eye-line" :size="13" /> 查看
              </button>
              <button class="c-btn" style="height: 28px; font-size: 12px" @click="showInFiles(n)">
                <Icon name="ri-folder-open-line" :size="13" /> 定位
              </button>
              <button class="c-iconbtn" title="删除" @click="del(n)">
                <Icon name="ri-delete-bin-6-line" :size="15" />
              </button>
            </div>
          </div>
          <div v-if="!history.length" class="set-item" style="color: var(--c-text-mute)">
            还没有截图，点上面的「立即拍摄」试试
          </div>
        </div>
      </div>

      <Transition name="csh-fade">
        <div v-if="toast" class="csh-toast">
          <Icon name="ri-checkbox-circle-fill" :size="15" /> {{ toast }}
        </div>
      </Transition>
    </section>
  </div>
  </M3AppShell>
</template>

<style scoped>
.csh {
  position: relative;
}
.csh-side {
  width: 214px;
}
.csh-opt,
.csh-switch {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 7px 10px;
  font-size: 12.5px;
  color: var(--c-text-dim);
}
.csh-title {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 13.5px;
}
.csh-desc {
  font-size: 11.5px;
  color: var(--c-text-mute);
  margin-left: 12px;
}
.csh-count {
  margin-left: auto;
  font-size: 11.5px;
  color: var(--c-text-mute);
}
.csh-main {
  flex: 1;
  min-height: 0;
  padding: 16px;
}
.csh-stage {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  margin-bottom: 16px;
}
.csh-mock {
  position: relative;
  width: 100%;
  height: 220px;
  border-radius: 12px;
  overflow: hidden;
  background: linear-gradient(140deg, #2b1b4d, #6b3fa0 55%, #c76bd1);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
}
.csh-mock--area {
  filter: brightness(0.78);
}
.csh-mock--window {
  width: 78%;
  height: 190px;
  margin-top: 14px;
  filter: brightness(0.9);
}
.csh-mock-bar {
  height: 26px;
  background: rgba(0, 0, 0, 0.42);
  backdrop-filter: blur(10px);
}
.csh-mock-body {
  position: absolute;
  inset: 26px 0 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: rgba(255, 255, 255, 0.92);
  font-size: 13px;
  text-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
}
.csh-dots {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  border: 2px dashed rgba(255, 255, 255, 0.7);
}
.csh-crop {
  position: absolute;
  left: 18%;
  right: 24%;
  top: 38%;
  bottom: 20%;
  border: 2px solid var(--c-accent);
  background: rgba(255, 255, 255, 0.1);
  border-radius: 6px;
}
.csh-shoot {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  height: 44px;
  padding: 0 22px;
  border-radius: 22px;
  border: none;
  background: var(--c-accent);
  color: #fff;
  font: inherit;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 8px 22px color-mix(in srgb, var(--c-accent) 45%, transparent);
  transition: transform 0.14s ease;
}
.csh-shoot:hover {
  transform: scale(1.03);
}
.csh-countdown {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background: rgba(0, 0, 0, 0.5);
  border-radius: 12px;
  color: #fff;
}
.csh-countdown b {
  font-size: 62px;
  line-height: 1;
  font-variant-numeric: tabular-nums;
}
.csh-countdown span {
  font-size: 13px;
  opacity: 0.85;
}
.csh-flash {
  position: absolute;
  inset: 0;
  border-radius: 12px;
  background: #fff;
  animation: csh-flash 0.22s ease-out;
  pointer-events: none;
}
@keyframes csh-flash {
  from { opacity: 0.9; }
  to { opacity: 0; }
}
.csh-thumb {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  flex: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: var(--c-surface-3);
}
.csh-toast {
  position: absolute;
  left: 50%;
  bottom: 16px;
  transform: translateX(-50%);
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 36px;
  padding: 0 16px;
  border-radius: 18px;
  background: var(--c-surface-3);
  border: 1px solid var(--c-border-strong);
  box-shadow: 0 10px 30px var(--c-shadow);
  font-size: 12.5px;
  white-space: nowrap;
}
.csh-fade-enter-active,
.csh-fade-leave-active {
  transition: opacity 0.16s ease;
}
.csh-fade-enter-from,
.csh-fade-leave-to {
  opacity: 0;
}
</style>
