<script setup lang="ts">
/**
 * M3AppShell —— 应用窗口的统一外壳（macOS 设置式布局）
 *
 *   ┌─ 窗口 .cw-clip（唯一边框，四角大圆角）─────────────────┐
 *   │ ┌─ 左导航：独立圆角面板 ─┐                            │
 *   │ │  与窗口框留小间距       │  主内容：平铺在框内        │
 *   │ │  （苹果式 inset）       │  （无自己的边框/圆角/底色） │
 *   │ └────────────────────────┘                            │
 *   │ [FAB 左下]                                            │
 *   └────────────────────────────────────────────────────────┘
 *
 * · 只有左侧栏是独立圆角面板；右侧内容直接铺满窗口剩余区域，靠窗口圆角裁切四角
 * · #rail 槽：每个应用自己的导航；默认槽：应用主内容
 * · FAB：左下角 56px 圆形悬浮按钮，fabIcon 指定图标、点击 emit('fab')
 * · 配色全部走 CosmicDesktop 注入的 --c-* 令牌，随主题实时联动
 */
import Icon from '@/components/common/Icon.vue'

defineProps<{ fabIcon?: string }>()
defineEmits<{ (e: 'fab'): void }>()
</script>

<template>
  <div class="m3-root">
    <slot name="rail" />
    <div class="m3-content"><slot /></div>

    <div class="m3-fab" v-if="$slots.fab || fabIcon">
      <slot name="fab">
        <button v-if="fabIcon" class="m3-fab-btn" type="button" :aria-label="fabIcon" @click="$emit('fab')">
          <Icon :name="fabIcon" :size="24" />
        </button>
      </slot>
    </div>
  </div>
</template>

<style scoped>
.m3-root {
  /* 苹果式：侧栏与窗口框之间只留很小的间距；四角做得更圆润 */
  --m3-inset: 8px;
  --m3-gap: 10px;
  --m3-radius: 22px;

  position: relative;
  flex: 1 1 0;
  min-width: 0;
  min-height: 0;
  display: flex;
  gap: 0;
  padding: 0; /* 右侧内容平铺到窗口边框，不留内缩 */
  background: transparent;
  color: var(--c-text);
  font-size: 13.5px;
}

/* ═══ 左导航：唯一一块独立圆角面板 ═══
   覆盖 cosmic.css 里贴边的窄条样式，以及各应用 xxx-side 的固定宽度。
   :deep 命中 #rail 槽内容（slot 内容 DOM 上仍是 .m3-root 的后代）。
   玻璃材质交给内部的 <LgSheet/>（liquid-glass-vue），宿主只管布局。 */
.m3-root :deep(.c-sidebar),
.m3-root :deep(.ct-sidebar) {
  flex: 0 0 29%;
  width: auto;
  min-width: 176px;
  max-width: 300px;
  align-self: stretch;
  position: relative; /* LgSheet 玻璃层的定位基准 */
  /* 与窗口框的间距由 margin 提供，右侧多留一点作为与主区的缝 */
  margin: var(--m3-inset) var(--m3-gap) var(--m3-inset) var(--m3-inset);
  padding: 14px 10px 78px; /* 底部给左下角 FAB 留位 */
  border-radius: var(--m3-radius);
  background: transparent;
  border: none;
  overflow: visible;
}
/* 内容提到玻璃层之上（玻璃层只折射身后的窗口底色/壁纸） */
.m3-root :deep(.c-sidebar > *),
.m3-root :deep(.ct-sidebar > *) {
  position: relative;
  z-index: 1;
}

/* ═══ 主内容：平铺在窗口框内 ═══
   没有自己的圆角 / 边框 / 底色，四角由窗口 .cw-clip 的圆角统一裁切。 */
.m3-content {
  flex: 1 1 0;
  min-width: 0;
  min-height: 0;
  display: flex;
  flex-direction: column;
  border: 0;
  border-radius: 0;
  background: transparent;
  box-shadow: none;
  overflow: hidden;
}
.m3-content > :slotted(*) {
  flex: 1 1 0;
  min-width: 0;
  min-height: 0;
  background: transparent;
}

/* ═══ FAB：左下角 ═══ */
.m3-fab {
  position: absolute;
  left: calc(var(--m3-inset) + 16px);
  bottom: calc(var(--m3-inset) + 16px);
  z-index: 6;
}
.m3-fab-btn {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  border: none;
  background: var(--c-accent);
  color: #fff;
  display: grid;
  place-items: center;
  cursor: pointer;
  box-shadow: 0 8px 22px var(--c-shadow);
  transition: filter 0.14s ease, transform 0.1s ease;
}
.m3-fab-btn:hover {
  filter: brightness(1.08);
}
.m3-fab-btn:active {
  transform: scale(0.95);
}
</style>
