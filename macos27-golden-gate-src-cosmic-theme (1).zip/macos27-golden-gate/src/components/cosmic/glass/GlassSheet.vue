<script setup lang="ts">
/**
 * GlassSheet —— WebGL 液态玻璃材质层
 *
 * 在片元着色器里直接对**壁纸纹理**做折射：
 *   - 圆角矩形 SDF → 倒角带 → 位移量按 squircle 斜率衰减（视觉上等价 Snell 收敛）
 *   - 位移方向 = SDF 梯度反向（严格垂直边缘、拐角平滑）
 *   - R/G/B 三次不同强度采样 → 边缘棱镜色散
 *   - 单侧 rim light + 顶部 sheen → 玻璃高光
 * 全程 GPU，一次全屏级 quad，无 CPU 滤镜、无每帧重采样成本。
 *
 * 用法：放在一个 position:relative 的容器里，容器背景设成透明/低不透明度，
 * 内容元素 z-index ≥ 1。canvas 自身 pointer-events:none。
 */
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { getWallpaperCanvas, wallpaperKey } from '@/utils/wallpapers'

const props = withDefaults(
  defineProps<{
    /** 圆角（CSS px） */
    radius?: number
    /** 最大位移（CSS px），越大弯折越夸张 */
    strength?: number
    /** 倒角带宽占短边比例 */
    bezel?: number
    /** 色调（rgb 0-255） */
    tint?: [number, number, number]
    /** 色调混合比例 0-1 */
    tintMix?: number
    /** 整体不透明度（决定透出多少背后的内容） */
    opacity?: number
    /** 亮度（配合外层遮罩，避免面板比周围亮太多） */
    brightness?: number
    /** 采样模糊半径（CSS px，0 = 清晰） */
    blur?: number
    /** 霜化程度 0-1（玻璃比背景更亮更灰的程度） */
    frost?: number
    /** 边缘膨胀倍率（仅边缘带生效，1 = 不放大） */
    zoom?: number
    /** 浮动阴影强度 0-1（玻璃片浮在表面上的立体感） */
    shadow?: number
    /** 是否启用（例如非激活窗口关掉省 GPU） */
    active?: boolean
    /** 只画边缘折射带：中心 alpha=0，露出下层的 backdrop-filter 磨砂。
        用于「磨砂玻璃 + 液态边缘」的双层构图（苹果液态玻璃的中心清晰/边缘弯折）。 */
    edgeOnly?: boolean
  }>(),
  {
    radius: 18,
    strength: 22,
    bezel: 0.24,
    tint: () => [0, 0, 0],
    tintMix: 0,
    opacity: 0.9,
    brightness: 1,
    /** 默认带一点磨砂（卡片）；按钮类传 0 = 高透玻璃 */
    blur: 4,
    frost: 0,
    zoom: 1.16,
    /** 默认轻投影（按钮级）；大卡片显式传 0.4+ */
    shadow: 0.24,
    active: true,
    /** 默认整片玻璃；由 LgSheet 接入时显式打开边缘模式 */
    edgeOnly: false
  }
)

const cv = ref<HTMLCanvasElement | null>(null)
let gl: WebGLRenderingContext | null = null
let program: WebGLProgram | null = null
let tex: WebGLTexture | null = null
let raf = 0
let ro: ResizeObserver | null = null

const VERT = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = aPos * 0.5 + 0.5;
  gl_Position = vec4(aPos, 0.0, 1.0);
}`

const FRAG = `
precision highp float;
varying vec2 vUv;
uniform vec2 uRes;       // canvas CSS 尺寸
uniform vec2 uOrigin;    // canvas 左上角在舞台逻辑坐标中的位置
uniform vec4 uWallRect;  // 壁纸 cover 后的 offset.xy + size.zw（舞台逻辑像素）
uniform float uRadius;
uniform float uStrength;
uniform float uBezel;
uniform float uTime;
uniform vec2 uLight;     // 光源方向（归一化，舞台坐标 y 向下）
uniform vec3 uTint;
uniform float uTintMix;
uniform float uOpacity;
uniform float uBrightness;
uniform float uBlur;
uniform float uFrost;
uniform float uSpeed;
uniform float uZoom;
uniform float uEdgeOnly;
uniform sampler2D uTex;

float sdRoundRect(vec2 p, vec2 b, float r) {
  vec2 q = abs(p) - b + r;
  return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}

void main() {
  // ── 坐标：canvas 的 clientWidth/clientHeight 已经是**逻辑 px**（舞台缩放只是 transform，
  //    不改变布局尺寸）。所以这里绝不能再除 scale —— 之前除了，手机端 p 被放大 1/0.3 ≈ 3.3 倍，
  //    整块玻璃的 SDF 尺寸、圆角、折射带全部错位到画面之外，肉眼看就是「玻璃形状和容器对不上」。
  vec2 p = vec2(vUv.x, 1.0 - vUv.y) * uRes;
  vec2 hs = uRes * 0.5;
  vec2 c = p - hs;                    // canvas 中心为原点
  // 圆角半径必须 ≤ 半短边：否则 sdRoundRect 里 q = |p| - hs + r 恒为正，
  // 整块玻璃被判到形状外 → 整块 discard（Dock 收起按钮 28×48 配 radius 16 就是这样消失的）。
  float r = min(uRadius, min(hs.x, hs.y));
  float d = sdRoundRect(c, hs, r);
  if (d > 0.0) discard;                 // 圆角外
  float dist = -d;

  // SDF 梯度（数值微分）
  float e = 0.75;
  float gx = sdRoundRect(c + vec2(e, 0.0), hs, r) - sdRoundRect(c - vec2(e, 0.0), hs, r);
  float gy = sdRoundRect(c + vec2(0.0, e), hs, r) - sdRoundRect(c - vec2(0.0, e), hs, r);
  vec2 grad = normalize(vec2(gx, gy) + vec2(1e-5));

  // 倒角带：从边缘往内的一圈**薄透镜**。
  // 苹果效果图里这条带大约只占短边的 6~10%（图1 圆按钮 / 图2 药丸 / 图4 滑块都是）。
  // 之前写成 *2 且上限 120px，在 878×664 的启动台上变成 120px 宽的厚边，
  // 整块就成了「玻璃相框」—— 这是最核心的一处错。
  float bezel = clamp(min(hs.x, hs.y) * uBezel, 4.5, 42.0);
  float t = clamp(dist / bezel, 0.0, 1.0);
  // squircle 斜率 → 位移强度：边缘最强，倒角末端归零（内部零失真）
  float m = pow(1.0 - t, 2.0);

  // 该像素在舞台逻辑坐标中的位置 → 壁纸 UV
  vec2 scr = uOrigin + p;
  vec2 uv = (scr - uWallRect.xy) / uWallRect.zw;
  // 「膨胀」：只在边缘带内把采样朝面心收（边缘内容被放大 → 像吹起来的液面），
  // m 在倒角带末端归零，所以**中间严格不缩放、不变形** —— 这是苹果规格里最硬的一条。
  vec2 surfCenterUv = (uOrigin + hs - uWallRect.xy) / uWallRect.zw;
  float zoomAmt = (1.0 - 1.0 / max(1.0, uZoom)) * m;
  uv += (surfCenterUv - uv) * zoomAmt;
  vec2 dir = -grad;                    // 指向内部（内容向中心挤压）

  // 弹性：划动越快折射越深（liquid-glass-vue 的 elasticity 思路）
  // 位移上限绑定带宽（小控件带宽只有 4.5px，位移过大会撕出折痕）。
  // 但折射带现在是「先模糊后弯折」，位移必须显著大于模糊半径才看得见：
  // 模糊 20px 时 22px 的位移会被完全抹平 → 玻璃退化成纯磨砂。放宽到带宽 2 倍。
  float effStrength = min(uStrength * (1.0 + uSpeed * 0.85), bezel * 2.0);
  vec2 base = dir * m * effStrength / uWallRect.zw;

  // ── 边缘色散：R/G/B 三次微偏采样，只发生在倒角带。
  // 图4 的 Month 文字边缘能看到红/紫边，就是这个。±8% 足够，再大就成了三色重影。
  vec3 col;
  col.r = texture2D(uTex, clamp(uv + base * 1.08, 0.002, 0.998)).r;
  col.g = texture2D(uTex, clamp(uv + base,        0.002, 0.998)).g;
  col.b = texture2D(uTex, clamp(uv + base * 0.92, 0.002, 0.998)).b;

  // ── 高斯模糊：真·磨砂（12 tap 黄金螺旋，近似各向同性高斯）──
  // uBlur = 0 时整段跳过 → 切换态 / 按钮是**高透玻璃**，不是磨砂。
  if (uBlur > 0.35) {
    vec2 bv = vec2(uBlur) / uWallRect.zw;
    vec2 center = uv + base * 0.5;
    vec3 acc = col * 0.14;
    float wsum = 0.14;
    for (int i = 0; i < 12; i++) {
      float fi = float(i) + 0.5;
      float rr = sqrt(fi / 12.0);
      float th = fi * 2.39996323;          // 黄金角：点分布均匀，无方向性伪影
      vec2 off = vec2(cos(th), sin(th)) * rr * bv;
      float w = exp(-1.8 * rr * rr);
      acc += texture2D(uTex, clamp(center + off, 0.002, 0.998)).rgb * w;
      wsum += w;
    }
    // 折射带内的景物必须与中心磨砂**同清晰度**：只在形状上弯折/放大/色散。
    // 早期版本这里让边缘少混一半模糊 (1-0.5*m)，结果边缘一圈清晰壁纸、
    // 中心一片雾面 —— 视觉上就是「玻璃相框 + 内部磨砂」。现在只留 12% 差异。
    col = mix(col, acc / wsum, smoothstep(0.35, 3.5, uBlur) * (1.0 - 0.12 * m));
  }
  // 对齐 CSS 的 saturate(140%)：折射带的颜色饱和度和下层磨砂保持一致，
  // 否则边缘会偏灰/偏艳，又形成一道色差框。
  float satLum = dot(col, vec3(0.299, 0.587, 0.114));
  col = mix(vec3(satLum), col, 1.4);
  // 背景亮度（在上色前测，代表真实背景）
  float bgLum = dot(col, vec3(0.299, 0.587, 0.114));
  float lightBg = smoothstep(0.42, 0.78, bgLum);
  // 色调 / 霜化 / 亮度（默认全关：纯玻璃 = 背后内容 + 边缘弯折）
  col = mix(col, uTint / 255.0, uTintMix);
  col = mix(col, vec3(lightBg * 0.9 + 0.12), uFrost * 0.55);
  col *= uBrightness;
  // 极淡的冷色偏移：模拟玻璃对光的微弱吸收，几乎不可见
  col *= vec3(0.995, 1.0, 1.005);
  // 抖动：消除暗部渐变条带
  float dither = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
  col += dither / 255.0;

  // ── 边缘只留一条极细的方向性亮线 ──
  // 图 1/2/4 的立体感来自「折射本身把背景弯出明暗」，不是外加白边。
  // 之前又叠内侧白弧、又叠暗线，窄带里会糊成一圈粗白框 —— 相框感的第二个来源。
  float facing = max(0.0, dot(grad, uLight));
  float rim = exp(-dist / 0.75) * (0.045 + 0.28 * pow(facing, 1.4));

  // ── 透镜曲面明暗 ──
  // 倒角带是一条凸起的液面：迎光侧在带内形成一条柔和亮弧，背光侧压暗。
  // 这是「有厚度、会反光」的液态感，且不含任何清晰纹理 —— 不会重新变成相框。
  float spec = pow(1.0 - t, 2.2) * pow(facing, 2.0) * m;
  col *= 1.0 + spec * 0.42 - m * (1.0 - facing) * 0.16;
  col += vec3(spec * 0.055);

  col += vec3(rim);

  float a = uOpacity;
  // 边缘模式：只有倒角折射带着色，中心完全透明 —— 露出下层的磨砂玻璃。
  // m 从边缘 1 平滑衰减到倒角末端 0，所以过渡不会出现硬接缝。
  if (uEdgeOnly > 0.5) a = uOpacity * smoothstep(0.0, 0.9, m);
  gl_FragColor = vec4(col * a, a);
}`

function compile(type: number, src: string): WebGLShader | null {
  if (!gl) return null
  const sh = gl.createShader(type)!
  gl.shaderSource(sh, src)
  gl.compileShader(sh)
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    console.warn('[GlassSheet] shader error:', gl.getShaderInfoLog(sh))
    return null
  }
  return sh
}

const sys = useCosmicSystemStore()
/** 当前壁纸纹理的签名（设置里换壁纸/改虚化时重新上传） */
let texKey = ''

/** 壁纸 cover 映射：返回舞台逻辑坐标下的 offset + size
 *  —— 必须与 CSS `background-size` 的取值**逐模式一致**，否则玻璃采样到的图案
 *     和桌面实际显示的壁纸会错开（原来只实现了 cover，改「适应/拉伸」就整体偏移）。 */
function wallpaperRect(stageW: number, stageH: number, w: typeof sys.wallpapers) {
  const iw = 1920
  const ih = 1080
  let W: number
  let H: number
  if (w.mode === 'solid') {
    return { ox: 0, oy: 0, w: stageW, h: stageH }
  }
  if (w.mode === 'gradient') {
    // CSS 渐变铺满整个元素
    return { ox: 0, oy: 0, w: stageW, h: stageH }
  }
  if (w.fill === '拉伸') {
    W = stageW
    H = stageH
  } else if (w.fill === '适应') {
    const s = Math.min(stageW / iw, stageH / ih)
    W = iw * s
    H = ih * s
  } else if (w.fill === '平铺' || w.fill === '居中') {
    // background-size:auto → 原始像素尺寸
    W = iw
    H = ih
  } else {
    // 填充 / 跨屏：cover
    const s = Math.max(stageW / iw, stageH / ih)
    W = iw * s
    H = ih * s
  }
  // 壁纸层虚化时 CSS 会给它 transform: scale(1.06) 盖住模糊露出的边缘，
  // 纹理映射必须同步放大，否则整张背景会相对玻璃缩进 6%（看着像玻璃"游移"）。
  if (w.blur > 0) {
    W *= 1.06
    H *= 1.06
  }
  return { ox: (stageW - W) / 2, oy: (stageH - H) / 2, w: W, h: H }
}

function resize() {
  const el = cv.value
  if (!el || !gl) return
  const dpr = Math.min(window.devicePixelRatio || 1, 2)
  const w = Math.max(1, Math.round(el.clientWidth * dpr))
  const h = Math.max(1, Math.round(el.clientHeight * dpr))
  if (el.width !== w || el.height !== h) {
    el.width = w
    el.height = h
    gl.viewport(0, 0, w, h)
    // 尺寸变了：圆角可能也跟着变（最大化 / 展开），重测一次并让下一帧重绘
    hostRadius = syncHost()
    lastKey = ''
  } else if (hostRadius < 0) {
    hostRadius = syncHost()
    lastKey = ''
  }
}

/** 玻璃圆角 = 宿主容器的 border-radius，画布扩到 border-box 外缘。
 *  之前 canvas 是 inset:0（铺在 padding box），比容器小 2px、圆角又手写成常量，
 *  一旦和 CSS 对不上，胶囊两端就缺口、面板角上就多一块圆 —— 这就是「玻璃和容器错位」。
 *  现在直接读容器的 computed 样式：圆角、边框、内缩全部对齐，改 CSS 也不会再跑偏。 */
let hostRadius = -1
function syncHost(): number {
  const el = cv.value
  const host = el?.parentElement
  if (!el || !host) return props.radius
  const cs = getComputedStyle(host)
  const bw = parseFloat(cs.borderTopWidth) || 0
  // 负 inset：画布盖住容器的 1px 边框，与外轮廓严格重合（父级 overflow:hidden 会自然裁圆角）
  el.style.inset = `${-bw}px`
  const raw = cs.borderTopLeftRadius.split(/[\s/]+/)[0] || ''
  let r = parseFloat(raw)
  if (!Number.isFinite(r)) return props.radius
  if (raw.includes('%')) r = (r / 100) * host.clientWidth
  return Math.max(0, r)
}

function uniforms() {
  if (!gl || !program) return null
  const U = (n: string) => gl!.getUniformLocation(program!, n)
  return {
    uRes: U('uRes'),
    uOrigin: U('uOrigin'),
    uWallRect: U('uWallRect'),
    uRadius: U('uRadius'),
    uStrength: U('uStrength'),
    uBezel: U('uBezel'),
    uTime: U('uTime'),
    uLight: U('uLight'),
    uTint: U('uTint'),
    uTintMix: U('uTintMix'),
    uOpacity: U('uOpacity'),
    uBrightness: U('uBrightness'),
    uBlur: U('uBlur'),
    uFrost: U('uFrost'),
    uSpeed: U('uSpeed'),
    uZoom: U('uZoom'),
    uEdgeOnly: U('uEdgeOnly'),
    uTex: U('uTex')
  }
}

let uploading = false
async function ensureTexture() {
  if (!gl || !tex) return
  const key = wallpaperKey(sys.wallpapers)
  if (key === texKey || uploading) return
  uploading = true
  texKey = key
  try {
    const canvas = await getWallpaperCanvas(sys.wallpapers)
    if (gl && tex) {
      gl.bindTexture(gl.TEXTURE_2D, tex)
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false)
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, canvas)
      lastKey = ''
    }
  } finally {
    uploading = false
  }
}

let lastKey = ''
function render(ts: number) {
  if (gl && tex && wallpaperKey(sys.wallpapers) !== texKey) void ensureTexture()
  raf = requestAnimationFrame(render)
  const el = cv.value
  if (!el || !gl || !program || !props.active) return
  if (el.clientWidth === 0 || el.clientHeight === 0) return
  resize()

  const stage = document.querySelector('.stage-canvas') as HTMLElement | null
  if (!stage) return
  const sr = stage.getBoundingClientRect()
  const scale = sr.width > 0 ? sr.width / stage.offsetWidth || 1 : 1
  const cr = el.getBoundingClientRect()
  // canvas 左上角在舞台逻辑坐标中的位置（rect 是视觉坐标，除舞台缩放得到逻辑坐标）
  const ox = (cr.left - sr.left) / scale
  const oy = (cr.top - sr.top) / scale
  const stageW = stage.offsetWidth
  const stageH = stage.offsetHeight
  const wr = wallpaperRect(stageW, stageH, sys.wallpapers)

  // 光照方向跟随指针。
  // 指针居中（css 变量还是 50/50）时给一个固定的**上方环境光** ——
  // 否则 facing 恒为 0，边缘亮线会整圈消失，玻璃立刻退化成塑料片。
  // 一次 getComputedStyle 读三个变量：每帧调 3 次会触发多余的样式重算。
  const rootStyle = getComputedStyle(document.documentElement)
  let lx = (parseFloat(rootStyle.getPropertyValue('--lg-hx')) || 50) / 100 - 0.5
  let ly = (parseFloat(rootStyle.getPropertyValue('--lg-hy')) || 50) / 100 - 0.5
  if (Math.hypot(lx, ly) < 0.03) {
    lx = -0.28
    ly = -0.9
  }
  const ll = Math.hypot(lx, ly) || 1

  // 按需渲染：位置、尺寸、光照都没变就不重绘（静止时不烧 GPU / 电量）
  const spd = parseFloat(rootStyle.getPropertyValue('--lg-speed')) || 0
  const key = `${cr.left}|${cr.top}|${el.clientWidth}x${el.clientHeight}|${lx.toFixed(3)}|${ly.toFixed(3)}|${spd.toFixed(2)}|${texKey}`
  if (key === lastKey) return
  lastKey = key

  gl.useProgram(program)
  const u = uniforms()!
  gl.uniform2f(u.uRes, el.clientWidth, el.clientHeight)
  gl.uniform2f(u.uOrigin, ox, oy)
  gl.uniform4f(u.uWallRect, wr.ox, wr.oy, wr.w, wr.h)
  gl.uniform1f(u.uRadius, hostRadius >= 0 ? hostRadius : props.radius)
  gl.uniform1f(u.uStrength, props.strength)
  gl.uniform1f(u.uBezel, props.bezel)
  gl.uniform1f(u.uTime, ts / 1000)
  // uLight = 从表面指向光源（p / grad 都是 y 向下，这里同坐标系）
  gl.uniform2f(u.uLight, lx / ll, ly / ll)
  gl.uniform3f(u.uTint, props.tint[0], props.tint[1], props.tint[2])
  gl.uniform1f(u.uTintMix, props.tintMix)
  gl.uniform1f(u.uOpacity, props.opacity)
  gl.uniform1f(u.uBrightness, props.brightness)
  gl.uniform1f(u.uBlur, props.blur)
  gl.uniform1f(u.uFrost, props.frost)
  gl.uniform1f(u.uZoom, props.zoom)
  gl.uniform1f(u.uSpeed, spd)
  gl.uniform1f(u.uEdgeOnly, props.edgeOnly ? 1 : 0)
  gl.uniform1i(u.uTex, 0)

  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
  if (el.dataset.ready !== '1') el.dataset.ready = '1'
}

onMounted(async () => {
  const el = cv.value
  if (!el) return
  gl = el.getContext('webgl', {
    alpha: true,
    premultipliedAlpha: true,
    antialias: false,
    powerPreference: 'high-performance'
  })
  if (!gl) {
    // 没有 WebGL 时静默降级：LgSheet 的 backdrop-filter 磨砂仍然完整，
    // 只是少了边缘折射。绝不写 data-glass='off'（会连带关掉全站玻璃材质）。
    return
  }
  // data-glass='webgl' 由 LgSheet 统一设置（每个玻璃实例挂载时都会写一次）。
  gl.clearColor(0, 0, 0, 0)

  const vs = compile(gl.VERTEX_SHADER, VERT)
  const fs = compile(gl.FRAGMENT_SHADER, FRAG)
  if (!vs || !fs) return
  program = gl.createProgram()!
  gl.attachShader(program, vs)
  gl.attachShader(program, fs)
  gl.linkProgram(program)
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.warn('[GlassSheet] link error:', gl.getProgramInfoLog(program))
    return
  }

  // 全屏 quad
  const buf = gl.createBuffer()
  gl.bindBuffer(gl.ARRAY_BUFFER, buf)
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW)
  const aPos = gl.getAttribLocation(program, 'aPos')
  gl.enableVertexAttribArray(aPos)
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0)

  // 壁纸纹理（跟随「设置 → 壁纸」变化）
  tex = gl.createTexture()
  gl.bindTexture(gl.TEXTURE_2D, tex)
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false)
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
  gl.activeTexture(gl.TEXTURE0)
  await ensureTexture()
  lastKey = ''

  el.addEventListener('webglcontextlost', (e) => {
    e.preventDefault()
  })
  ro = new ResizeObserver(() => resize())
  ro.observe(el)
  resize()
  raf = requestAnimationFrame(render)
})

watch(
  () => props.active,
  (v) => {
    if (v && !raf) raf = requestAnimationFrame(render)
  }
)

onBeforeUnmount(() => {
  cancelAnimationFrame(raf)
  raf = 0
  ro?.disconnect()
  ro = null
  // 主动释放上下文，避免窗口多开时超出浏览器上限
  gl?.getExtension('WEBGL_lose_context')?.loseContext()
  gl = null
  program = null
  tex = null
})
</script>

<template>
  <canvas
    ref="cv"
    class="glass-sheet"
    aria-hidden="true"
    :data-blur="blur"
    :data-strength="strength"
    :style="{ '--gs-shadow': String(shadow) }"
  />
</template>

<style scoped>
.glass-sheet {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  border-radius: inherit;
  pointer-events: none;
  z-index: 0;
  display: block;
  /* 浮动阴影：玻璃片投在壁纸上的影子 —— 没有它，再好的折射也像贴纸。
     强度由组件 prop 控制（小按钮弱、大卡片强）。 */
  box-shadow: 0 10px 26px -8px rgba(0, 0, 0, var(--gs-shadow, 0.3));
  /* 首帧画完前保持透明，画完淡入 —— 避免窗口切换激活态时闪一下空白 */
  opacity: 0;
  transition: opacity 0.18s ease;
}
.glass-sheet[data-ready='1'] {
  opacity: 1;
}
</style>
