<script setup lang="ts">
/**
 * CtWakePanel —— 长按空格 1s 唤醒的「CTclaw 系统对话框」
 *
 * 形态对标 DeepSeek 那种极简输入框：浅色大圆角框，占位「问点什么，一起探索」，
 * 左下两个功能开关（深度思考 / 智能搜索），右下角【折叠式模型切换】+ 圆形发送钮。
 * 模型切换平时只显示当前一个，点开只有两个本地模型（无独立「Agent 模型」）：
 *   · 轻量对话 Qwen3-0.6B —— 普通问答
 *   · 深度思考 Qwen3-1.5B —— 带推理步骤展开
 * 「对话 / Agent」是工作模式开关，与模型正交 —— 打开 Agent 后沿用当前选中的
 * 同一个模型，只是把回答改成大馒头拆小馒头的派活流程（后台不阻塞、进度推信息岛）。
 *
 * 配色走系统 --c-* 令牌：深色主题深底浅字、浅色主题浅底深字，强调色随 accent。
 * 玻璃复用 <LgSheet liquid />，与 Dock / 控制中心同一套三态材质：
 *   液态=壁纸折射、磨砂=雾面、无玻璃=不透明实底。
 * 三条红线（§12.3）：区分外壳/模型进程；云端不说离线；演示非落地。
 */
import { computed, nextTick, onUnmounted, ref, watch } from 'vue'
import { useCtAIStore, type CtPanelMode } from '@/stores/ctai'
import Icon from '@/components/common/Icon.vue'
import LgSheet from './LgSheet.vue'

const ctai = useCtAIStore()

const MODELS: Array<{ id: CtPanelMode; label: string; sub: string; icon: string }> = [
  { id: 'chat', label: 'Qwen3-0.6B', sub: '轻量对话 · 400MB', icon: 'ri-chat-4-line' },
  { id: 'deep', label: 'Qwen3-1.5B', sub: '深度思考 · 1.5GB', icon: 'ri-brain-line' }
]
const current = computed(() => MODELS.find((m) => m.id === ctai.panelMode)!)

const modelOpen = ref(false)
const inputRef = ref<HTMLInputElement | null>(null)
const streamRef = ref<HTMLElement | null>(null)

/** Agent 工作台提示条：叉号弹出的「本次/永久关闭」二选一菜单 */
const hintMenuOpen = ref(false)
const hintRef = ref<HTMLElement | null>(null)
watch(hintMenuOpen, (open) => {
  if (open) document.addEventListener('pointerdown', onHintDocDown, true)
  else document.removeEventListener('pointerdown', onHintDocDown, true)
})
function onHintDocDown(e: PointerEvent) {
  if (hintRef.value && !hintRef.value.contains(e.target as Node)) hintMenuOpen.value = false
}
function chooseHint(kind: 'session' | 'forever') {
  if (kind === 'session') ctai.dismissHintThisSession()
  else ctai.dismissHintForever()
  hintMenuOpen.value = false
}
/** 切模式 / 关闭面板时收起二选一菜单 */
watch(() => [ctai.panelOpen, ctai.panelAgent], () => { hintMenuOpen.value = false })
onUnmounted(() => document.removeEventListener('pointerdown', onHintDocDown, true))
/** 只有一条欢迎语时保持截图的干净输入框；发出消息后才向上展开消息流 */
const showStream = computed(() => ctai.panelMsgs.length > 1 || ctai.tasks.length > 0)

function scrollBottom() {
  nextTick(() => { if (streamRef.value) streamRef.value.scrollTop = streamRef.value.scrollHeight })
}
watch(() => [ctai.panelMsgs.length, ctai.tasks.length], scrollBottom)
watch(() => ctai.panelOpen, (v) => {
  if (v) nextTick(() => inputRef.value?.focus())
  else modelOpen.value = false
})

function pickModel(id: CtPanelMode) {
  modelOpen.value = false
  const firstChat = ctai.panelMsgs.length <= 1
  ctai.setPanelMode(id)
  // 还没开始对话时，让欢迎语跟随当前模式，避免"深度模式却说轻量对话"
  if (firstChat) ctai.resetPanelChat()
}
/** 对话 / Agent 二选一：工作模式，与模型正交（Agent 沿用当前选中的模型） */
const isAgent = computed(() => ctai.panelAgent)
function setFamily(family: 'chat' | 'agent') {
  ctai.setPanelAgent(family === 'agent')
  const firstChat = ctai.panelMsgs.length <= 1
  if (firstChat) ctai.resetPanelChat()
}
function toggleDeep() {
  pickModel(ctai.panelMode === 'deep' ? 'chat' : 'deep')
}
function toggleSearch() {
  const next = !ctai.panelSearch
  ctai.panelSearch = next
  ctai.setTier(next ? 'glm-flash' : 'local')
}
function send() {
  modelOpen.value = false
  ctai.sendPanel()
}
function close() {
  ctai.closePanel()
}
</script>

<template>
  <Transition name="cwp">
    <!-- 对话框与 Agent 工作台严格互斥：进工作台时 panelOpen 已真正置 false，
         这里再挡一道 sidebarOpen 作为双保险。关闭工作台不会自动弹回本对话框。 -->
    <div v-if="ctai.panelOpen && !ctai.panelAgentSidebarOpen" class="cwp-root">
      <!-- 点击面板外空白关闭 -->
      <div class="cwp-backdrop" @click="close" />

      <div class="cwp-panel lg-host" role="dialog" aria-label="CTclaw 唤醒对话框">
        <!-- 与 Dock / 控制中心同一套官方玻璃：液态=壁纸折射、磨砂=雾面、无玻璃=实心底 -->
        <LgSheet liquid />
        <!-- 可读性衬底：浅色主题薄白雾、深色主题薄黑雾，压住壁纸保证文字可读
             （与控制中心 .hc-tint 同思路）；flat 档已有实心底，这层自动隐去。 -->
        <div class="cwp-tint" aria-hidden="true" />
        <!-- ── 消息流：有对话才向上展开 ── -->
        <div v-if="showStream" ref="streamRef" class="cwp-stream">
          <div v-for="(m, i) in ctai.panelMsgs" :key="i" class="cwp-msg" :class="m.role">
            <div v-if="m.role === 'bot'" class="cwp-av"><Icon name="ri-sparkling-2-line" :size="13" /></div>
            <div class="cwp-bubble">
              <div class="cwp-txt">{{ m.text }}</div>
              <div v-if="m.steps" class="cwp-steps">
                <div v-for="(s, si) in m.steps" :key="si" class="cwp-step">
                  <Icon name="ri-check-line" :size="10" />{{ s }}
                </div>
              </div>
            </div>
          </div>
          <div v-if="ctai.panelBusy" class="cwp-msg bot">
            <div class="cwp-av"><Icon name="ri-sparkling-2-line" :size="13" /></div>
            <div class="cwp-bubble cwp-typing"><i /><i /><i /></div>
          </div>
          <!-- 任务 Agent：大馒头 → 小馒头子任务卡 -->
          <div v-if="ctai.panelAgent && ctai.tasks.length" class="cwp-tasks">
            <div v-for="(t, i) in ctai.tasks" :key="t.id" class="cwp-task" :class="{ done: t.state === 'done', canceled: t.state === 'canceled' }">
              <div class="cwp-task-top">
                <span class="cwp-task-ico"><Icon :name="t.state === 'done' ? 'ri-check-line' : 'ri-loader-4-line'" :size="11" /></span>
                <b>{{ t.name }}</b><em>{{ t.progress }}%</em>
              </div>
              <div class="cwp-bar"><i :style="{ width: t.progress + '%' }" /></div>
              <div class="cwp-task-foot">小馒头 #{{ i + 1 }} · {{ t.origin }}</div>
            </div>
          </div>
        </div>

        <!-- ── 输入区：对标截图的极简主体 ── -->
        <div class="cwp-compose">
          <input
            ref="inputRef"
            v-model="ctai.panelInput"
            class="cwp-input"
            placeholder="问点什么，一起探索"
            spellcheck="false"
            @keydown.enter="send"
          />
          <div class="cwp-bar-row">
            <div class="cwp-tools">
              <button class="cwp-chip" :class="{ on: ctai.panelMode === 'deep' }" @click="toggleDeep">
                <Icon name="ri-brain-line" :size="14" />深度思考
              </button>
              <button class="cwp-chip" :class="{ on: ctai.panelSearch }" @click="toggleSearch">
                <Icon name="ri-global-line" :size="14" />智能搜索
              </button>
              <!-- 对话 / Agent 二选一：工作模式，点哪个切哪个；与模型正交 -->
              <div class="cwp-family" role="group" aria-label="对话或 Agent 模式">
                <button class="cwp-family-i" :class="{ on: !isAgent }" @click="setFamily('chat')">
                  <Icon name="ri-chat-4-line" :size="13" />对话
                </button>
                <button class="cwp-family-i" :class="{ on: isAgent }" @click="setFamily('agent')">
                  <Icon name="ri-robot-line" :size="13" />Agent
                </button>
              </div>
              <!-- 仅在 Agent 模式出现：单击进侧栏工作台，叉号弹「本次/永久关闭」 -->
              <div v-if="ctai.showAgentHint" ref="hintRef" class="cwp-agent-hint">
                <button class="cwp-agent-hint-main" title="打开 Agent 工作台侧边栏" @click="ctai.openAgentSidebar()">
                  <Icon name="ri-robot-line" :size="13" /><span>Agent 工作台</span>
                </button>
                <button class="cwp-agent-hint-x" title="关闭提示" @click.stop="hintMenuOpen = !hintMenuOpen">
                  <Icon name="ri-close-line" :size="12" />
                </button>
                <Transition name="cwpm">
                  <div v-if="hintMenuOpen" class="cwp-hint-menu">
                    <button @click="chooseHint('session')">
                      <Icon name="ri-close-line" :size="13" />本次关闭
                    </button>
                    <button @click="chooseHint('forever')">
                      <Icon name="ri-eye-off-line" :size="13" />永久关闭
                    </button>
                  </div>
                </Transition>
              </div>
            </div>
            <div class="cwp-actions">
              <!-- 右下角：折叠式模型切换，平时只显示当前一个 -->
              <div class="cwp-model-wrap">
                <button class="cwp-model" :class="{ open: modelOpen }" @click="modelOpen = !modelOpen">
                  <Icon :name="current.icon" :size="14" />
                  <span>{{ current.label }}</span>
                  <Icon name="ri-arrow-down-s-line" :size="13" />
                </button>
                <Transition name="cwpm">
                  <div v-if="modelOpen" class="cwp-model-menu">
                    <div class="cwp-model-menu-hd">选择模型 / 模式</div>
                    <button
                      v-for="m in MODELS" :key="m.id"
                      class="cwp-model-item" :class="{ on: ctai.panelMode === m.id }"
                      @click="pickModel(m.id)"
                    >
                      <span class="cwp-mi-ico"><Icon :name="m.icon" :size="16" /></span>
                      <span class="cwp-mi-txt"><b>{{ m.label }}</b><em>{{ m.sub }}</em></span>
                      <Icon v-if="ctai.panelMode === m.id" name="ri-check-line" :size="14" />
                    </button>
                  </div>
                </Transition>
              </div>
              <button class="cwp-send" :disabled="!ctai.panelInput.trim() || ctai.panelBusy" title="发送（Enter）" @click="send">
                <Icon name="ri-arrow-up-line" :size="18" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Transition>
</template>

<style scoped>
.cwp-root { position: fixed; inset: 0; z-index: 9100; pointer-events: none; }
.cwp-backdrop { position: absolute; inset: 0; pointer-events: auto; }

/* 输入框：配色走系统 --c-* 令牌，玻璃复用 LgSheet（三态材质随全站） */
.cwp-panel {
  /* 下移到 Dock 所在位置（Dock 约在 bottom:18px），盖在 Dock 上、占它的位置；
     Dock 缩小后沉在对话框后面当底座，从面板下缘露出一点。z 9100 > dock 9000。 */
  position: absolute; left: 50%; bottom: 30px; transform: translateX(-50%);
  width: min(720px, calc(100vw - 40px));
  display: flex; flex-direction: column;
  pointer-events: auto; overflow: visible;
  border-radius: 24px;
  /* 玻璃档背景交给 LgSheet 采样壁纸，自身只留描边与投影；flat 档由全局
     html[data-glass='flat'] .lg-host 规则给不透明实底（见 cosmic.css）。 */
  background: transparent;
  border: 1px solid var(--c-border-strong, rgba(0, 0, 0, 0.12));
  box-shadow: 0 26px 70px var(--c-shadow, rgba(0, 0, 0, 0.3)), inset 0 1px 0 rgba(255, 255, 255, 0.16);
  color: var(--c-text, #2c2f3a);
  max-height: min(560px, calc(100vh - 130px));
}
/* LgSheet 玻璃层铺满；内容抬到它之上（官方玻璃层 z=0、pointer-events:none）。
   .cwp-tint 例外：它夹在玻璃与内容之间。 */
.cwp-panel > :not(.lg-overlay):not(.lg-flat):not(.glass):not(.og-scope):not(.cwp-tint) {
  position: relative;
  z-index: 1;
}
/* 可读性衬底：主题色的半透明薄雾，压住壁纸保证文字对比度。
   浅色主题（--c-bg 亮）→ 白雾；深色主题 → 黑雾。flat 档已不透明，隐去。 */
.cwp-tint {
  position: absolute; inset: 0; z-index: 0;
  border-radius: inherit; pointer-events: none;
  background: color-mix(in srgb, var(--c-bg, #f4f4f7) 78%, transparent);
}
/* 无玻璃档的覆盖规则见 cosmic.css（scoped :global 会被 lightningcss 删，放全局更稳）：
   面板与 .lg-flat 改用主题化 --c-surface，tint 隐去，避免深底深字 / 白底白字。 */

/* ── 消息流 ── */
.cwp-stream {
  flex: 0 1 auto; min-height: 0; max-height: 360px; overflow-y: auto;
  display: flex; flex-direction: column; gap: 12px;
  padding: 20px 20px 6px;
}
.cwp-stream::-webkit-scrollbar { width: 6px; }
.cwp-stream::-webkit-scrollbar-thumb { background: var(--c-border-strong, #d5d9e8); border-radius: 3px; }
.cwp-msg { display: flex; gap: 9px; align-items: flex-start; }
.cwp-msg.me { flex-direction: row-reverse; }
.cwp-av { flex: none; width: 24px; height: 24px; border-radius: 8px; display: grid; place-items: center; background: var(--c-accent-soft, #e9ecfb); color: var(--c-accent, #4a5fc7); }
.cwp-bubble { max-width: 84%; padding: 10px 13px; border-radius: 14px; font-size: 13px; line-height: 1.62; background: var(--c-surface-2, #f1f3f9); border: 1px solid var(--c-border, #e8ebf4); color: var(--c-text, #333746); }
.cwp-msg.me .cwp-bubble { background: var(--c-accent, #4f6bff); border-color: transparent; color: #fff; }
.cwp-steps { margin-top: 9px; padding-top: 8px; border-top: 1px dashed var(--c-border, #d9deec); display: flex; flex-direction: column; gap: 5px; }
.cwp-step { display: flex; align-items: center; gap: 6px; font-size: 11.5px; color: var(--c-accent, #5668b6); }
.cwp-typing { display: inline-flex; gap: 4px; align-items: center; }
.cwp-typing i { width: 5px; height: 5px; border-radius: 50%; background: var(--c-text-mute, #9aa3c4); animation: cwpb 1.2s infinite; }
.cwp-typing i:nth-child(2) { animation-delay: .2s; } .cwp-typing i:nth-child(3) { animation-delay: .4s; }
@keyframes cwpb { 0%,60%,100% { opacity: .3; transform: translateY(0); } 30% { opacity: 1; transform: translateY(-3px); } }
/* 任务卡 */
.cwp-tasks { display: flex; flex-direction: column; gap: 8px; padding-left: 33px; }
.cwp-task { padding: 10px 12px; border-radius: 12px; background: var(--c-surface, #fff); border: 1px solid var(--c-border, #e4e8f3); box-shadow: 0 2px 8px var(--c-shadow, rgba(30,40,90,.08)); }
.cwp-task.done { border-color: color-mix(in srgb, #2ea36b 45%, var(--c-border)); background: color-mix(in srgb, #2ea36b 8%, var(--c-surface)); }
.cwp-task.canceled { opacity: .55; }
.cwp-task-top { display: flex; align-items: center; gap: 8px; }
.cwp-task-ico { color: var(--c-accent, #5a6fc9); display: grid; place-items: center; }
.cwp-task.done .cwp-task-ico { color: #2ea36b; }
.cwp-task-top b { flex: 1; font-size: 12.5px; font-weight: 600; }
.cwp-task-top em { font-size: 11px; font-style: normal; font-variant-numeric: tabular-nums; color: var(--c-text-mute, #7b8196); }
.cwp-bar { height: 5px; border-radius: 3px; background: var(--c-surface-3, #eceff7); margin: 8px 0 6px; overflow: hidden; }
.cwp-bar i { display: block; height: 100%; border-radius: 3px; background: linear-gradient(90deg, var(--c-accent, #4f6bff), color-mix(in srgb, var(--c-accent, #7d93ff) 65%, #fff)); transition: width .3s ease; }
.cwp-task.done .cwp-bar i { background: linear-gradient(90deg, #2ea36b, #55c98a); }
.cwp-task-foot { font-size: 10px; color: var(--c-text-mute, #9aa0b3); font-family: ui-monospace, monospace; }

/* ── 输入区 ── */
.cwp-compose { padding: 20px 20px 18px; }
.cwp-input {
  width: 100%; height: 44px; padding: 0 4px;
  border: 0; outline: 0; background: transparent;
  font-size: 16px; color: var(--c-text, #2c2f3a);
}
.cwp-input::placeholder { color: var(--c-text-mute, #a3a8b8); }
.cwp-bar-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 4px; }
.cwp-tools, .cwp-actions { display: flex; align-items: center; gap: 8px; }
/* 左下功能开关（双模式按钮）：原位往下挪一点，不拆到新行 */
/* 关：主题面板底 + 次级字 + 描边；开：强调色淡底 + 强调色字 + 强调描边 */
.cwp-chip {
  display: inline-flex; align-items: center; gap: 6px;
  height: 32px; padding: 0 12px; border-radius: 18px; cursor: pointer;
  font-size: 12.5px; color: var(--c-text-dim, #5a6072); background: var(--c-surface, rgba(255,255,255,.85)); border: 1px solid var(--c-border, #dfe2ea);
  /* Agent 提示条挤进来时不许把文案压成两行：禁换行、不参与收缩 */
  white-space: nowrap; flex: none;
  transform: translateY(6px);
  transition: .16s;
}
.cwp-chip:hover { background: var(--c-hover, #f2f4fa); border-color: var(--c-border-strong, #cdd3e2); }
.cwp-chip.on { color: var(--c-accent, #3a54d0); background: var(--c-accent-soft, #e9efff); border-color: color-mix(in srgb, var(--c-accent, #4f6bff) 45%, var(--c-border)); box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--c-accent, #4f6bff) 10%, transparent); }
/* 对话 / Agent 二选一（两个都在，点哪个切哪个）—— 与双模式按钮一起下移 */
.cwp-family { display: inline-flex; align-items: center; gap: 2px; height: 32px; padding: 3px; border-radius: 18px; background: var(--c-surface-2, #eef0f6); border: 1px solid var(--c-border, #e2e6f0); transform: translateY(6px); flex: none; }
.cwp-family-i {
  display: inline-flex; align-items: center; gap: 5px;
  height: 26px; padding: 0 11px; border: 0; border-radius: 14px; cursor: pointer;
  font-size: 12.5px; font-weight: 600; color: var(--c-text-mute, #8b91a4); background: transparent; transition: .16s;
  white-space: nowrap;
}
.cwp-family-i:hover { color: var(--c-accent, #4a5fc7); }
.cwp-family-i.on { color: var(--c-accent, #3450d8); background: var(--c-surface, #fff); box-shadow: 0 1px 4px var(--c-shadow, rgba(30,40,90,.16)); }
/* Agent 工作台提示条：单击进侧栏，叉号弹本次/永久关闭。
   行内空间不足时由它吸收压缩（其余 chips 均 flex:none 不缩），文字省略号。 */
.cwp-agent-hint {
  position: relative;
  display: inline-flex; align-items: center; gap: 2px;
  height: 32px; padding: 3px 3px 3px 10px; border-radius: 18px;
  background: var(--c-accent-soft, #e9efff);
  border: 1px solid color-mix(in srgb, var(--c-accent, #4f6bff) 32%, var(--c-border));
  color: var(--c-accent, #3450d8);
  transform: translateY(6px);
  animation: cwp-hint-in .28s ease both;
  min-width: 0;
}
@keyframes cwp-hint-in { from { opacity: 0; transform: translateY(6px) translateX(-6px); } to { opacity: 1; transform: translateY(6px) translateX(0); } }
.cwp-agent-hint-main {
  display: inline-flex; align-items: center; gap: 5px;
  height: 24px; padding: 0; border: 0; background: transparent; cursor: pointer;
  font-size: 12px; font-weight: 650; color: inherit; white-space: nowrap;
  min-width: 0; overflow: hidden; text-overflow: ellipsis;
}
.cwp-agent-hint-x {
  flex: none; width: 20px; height: 20px; border-radius: 50%; border: 0; cursor: pointer;
  display: grid; place-items: center; color: var(--c-text-mute, #8b91a4);
  background: transparent; transition: .14s;
}
.cwp-agent-hint-x:hover { background: color-mix(in srgb, var(--c-accent, #4f6bff) 14%, transparent); color: var(--c-accent, #3450d8); }
.cwp-hint-menu {
  position: absolute; right: 0; bottom: calc(100% + 8px);
  width: 132px; padding: 6px; border-radius: 12px;
  background: var(--c-surface, #fff); border: 1px solid var(--c-border, #e4e8f3);
  box-shadow: 0 12px 32px var(--c-shadow, rgba(18,22,52,.24));
  z-index: 5;
}
.cwp-hint-menu button {
  width: 100%; display: flex; align-items: center; gap: 8px;
  height: 32px; padding: 0 9px; border: 0; border-radius: 8px; cursor: pointer;
  background: transparent; color: var(--c-text, #2c2f3a); font-size: 12px; text-align: left; transition: .14s;
}
.cwp-hint-menu button:hover { background: var(--c-hover, #f3f5fc); color: var(--c-accent, #3450d8); }
/* 右下折叠式模型切换 */
.cwp-model-wrap { position: relative; }
.cwp-model {
  display: inline-flex; align-items: center; gap: 6px;
  height: 32px; padding: 0 11px; border-radius: 18px; cursor: pointer;
  font-size: 12.5px; color: var(--c-text-dim, #555f78); background: var(--c-surface-2, #f4f6fb); border: 1px solid var(--c-border, #e2e6f0);
  white-space: nowrap; flex: none;
  transition: .16s;
}
.cwp-model:hover, .cwp-model.open { background: var(--c-hover, #eceffa); border-color: var(--c-border-strong, #c9d2ee); }
.cwp-model span { font-weight: 600; }
.cwp-model.open :deep(svg:last-child) { transform: rotate(180deg); }
.cwp-model-menu {
  position: absolute; right: 0; bottom: calc(100% + 10px);
  width: 250px; padding: 8px; border-radius: 16px;
  background: var(--c-surface, #fff); border: 1px solid var(--c-border, #e4e8f3);
  box-shadow: 0 16px 44px var(--c-shadow, rgba(18,22,52,.28)), 0 2px 8px rgba(0,0,0,.06);
}
.cwp-model-menu-hd { font-size: 10.5px; color: var(--c-text-mute, #9aa0b3); padding: 4px 8px 8px; }
.cwp-model-item {
  width: 100%; display: flex; align-items: center; gap: 10px;
  padding: 9px 9px; border: 0; border-radius: 11px; cursor: pointer;
  background: transparent; color: var(--c-text, #2c2f3a); text-align: left; transition: .14s;
}
.cwp-model-item:hover { background: var(--c-hover, #f3f5fc); }
.cwp-model-item.on { background: var(--c-accent-soft, #eef1ff); }
.cwp-mi-ico { flex: none; width: 30px; height: 30px; border-radius: 9px; display: grid; place-items: center; background: var(--c-accent-soft, #e9ecfb); color: var(--c-accent, #4a5fc7); }
.cwp-model-item.on .cwp-mi-ico { background: color-mix(in srgb, var(--c-accent, #4f6bff) 22%, var(--c-surface)); color: var(--c-accent, #3450d8); }
.cwp-mi-txt { flex: 1; display: flex; flex-direction: column; line-height: 1.3; min-width: 0; }
.cwp-mi-txt b { font-size: 12.5px; font-weight: 650; }
.cwp-mi-txt em { font-size: 10.5px; font-style: normal; color: var(--c-text-mute, #9aa0b3); }
.cwp-model-item > :last-child { color: var(--c-accent, #3450d8); }
/* 发送圆钮 */
.cwp-send {
  flex: none; width: 36px; height: 36px; border-radius: 50%; border: 0; cursor: pointer;
  display: grid; place-items: center; color: #fff;
  background: linear-gradient(140deg, color-mix(in srgb, var(--c-accent, #5270ff) 82%, #fff), var(--c-accent, #3450d8));
  box-shadow: 0 4px 12px color-mix(in srgb, var(--c-accent, #3450d8) 38%, transparent);
  transition: filter .15s, transform .15s;
}
.cwp-send:hover { filter: brightness(1.08); transform: translateY(-1px); }
.cwp-send:disabled { opacity: .45; cursor: not-allowed; box-shadow: none; }

/* 出入场：从 Dock 位置弹起 */
.cwp-enter-active { transition: opacity .28s ease; }
.cwp-enter-active .cwp-panel { transition: transform .36s cubic-bezier(.2,.9,.3,1.15), opacity .28s ease; }
.cwp-leave-active { transition: opacity .2s ease; }
.cwp-leave-active .cwp-panel { transition: transform .22s ease, opacity .2s ease; }
.cwp-enter-from { opacity: 0; }
.cwp-enter-from .cwp-panel { transform: translateX(-50%) translateY(34px) scale(.94); opacity: 0; }
.cwp-leave-to { opacity: 0; }
.cwp-leave-to .cwp-panel { transform: translateX(-50%) translateY(20px) scale(.97); opacity: 0; }
/* 模型菜单微动画 */
.cwpm-enter-active, .cwpm-leave-active { transition: opacity .16s ease, transform .16s ease; }
.cwpm-enter-from, .cwpm-leave-to { opacity: 0; transform: translateY(6px); }
</style>
