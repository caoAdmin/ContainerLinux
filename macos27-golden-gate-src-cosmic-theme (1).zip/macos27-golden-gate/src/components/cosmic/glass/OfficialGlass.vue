<script lang="ts">
/**
 * 模块级共享状态（普通 <script>，所有实例共用一份）。
 *
 * ⚠️ 关键性能约定：`<script setup>` 里的顶层代码是**每个组件实例各跑一遍**的，
 * 所以 rAF 调度器若写在 setup 里，12 个玻璃面就是 12 条并行的 60fps 循环，
 * 每帧各自读 getBoundingClientRect、各自扫一遍文档找 svg filter。
 * 放到这里之后全站只有一条循环，文档级维护也只做一次。
 */
type GlassTicker = (frameNo: number) => void

const glassTickers = new Set<GlassTicker>()
const glassMaintenance = new Set<() => void>()
let glassDriver = 0
let glassFrameNo = 0
let glassLastMaintenance = 0

function glassDrive(ts: number) {
  glassFrameNo++
  for (const fn of glassTickers) fn(glassFrameNo)
  // 文档级重活（SVG 滤镜收紧等）：约每 400ms 一次，全站共用
  if (ts - glassLastMaintenance > 400) {
    glassLastMaintenance = ts
    for (const fn of glassMaintenance) fn()
  }
  glassDriver = requestAnimationFrame(glassDrive)
}
function glassStartDriver() {
  if (!glassDriver && glassTickers.size) {
    glassLastMaintenance = 0
    glassDriver = requestAnimationFrame(glassDrive)
  }
}
function glassStopIfIdle() {
  if (glassDriver && !glassTickers.size) {
    cancelAnimationFrame(glassDriver)
    glassDriver = 0
  }
}

/** 官方 SVG 滤镜区域收紧（见下方原注释）。文档级操作，全局只留一份。 */
let glassTightened = 0
function tightenFiltersGlobal() {
  const list = document.querySelectorAll('svg filter[id]')
  if (list.length === glassTightened) return
  list.forEach((f) => {
    if (f.getAttribute('data-og-tight') === '1') return
    f.setAttribute('data-og-tight', '1')
    f.setAttribute('x', '0%')
    f.setAttribute('y', '0%')
    f.setAttribute('width', '100%')
    f.setAttribute('height', '100%')
  })
  glassTightened = list.length
}
</script>

<script setup lang="ts">
/**
 * OfficialGlass —— 官方 @wxperia/liquid-glass-vue / LiquidGlass 的宿主适配层。
 *
 * 算法 100% 来自官方库（SVG 位移滤镜 + backdrop-filter 公式 + sheen + 弹性），
 * 这里只做两件适配，不改写任何滤镜：
 *  1) 定位：fixed 浮窗（中央卡，官方原味 translate(-50%,-50%) 居中）
 *          或 fill 模式（跟随宿主 rect 铺满，用于 Dock / 灵动岛 / 顶栏 pill）；
 *  2) 背景：把桌面壁纸元素原样克隆一份，插到官方 .glass 内 warp 之前。
 *     官方 demo 的背景图与卡片同处一个 Backdrop Root；本项目壁纸在 .dd-root、
 *     玻璃在 .cd-root（fixed + stage transform 会截断 Backdrop Root），
 *     warp 的 backdrop-filter 采样为空 → 玻璃变「透明塑料」。补回这层背景
 *     由浏览器自己算 cover，天然与桌面严格对齐。
 *
 * 全站统一参数（勿散改）：
 *   Displacement 99 · Blur 0.12 (官方公式 4+0.12*32 = 7.84px) · Saturation 140
 *   · Aberration 2 · Elasticity 0 · Corner Radius 32。
 *
 * 旧的自研实现（GlassSheet.vue WebGL）保留备用，不再挂载。
 */
import { onMounted, onBeforeUnmount, ref, computed, watch } from 'vue'
import { LiquidGlass } from '@wxperia/liquid-glass-vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { wallpaperKey } from '@/utils/wallpapers'

const props = withDefaults(
  defineProps<{
    top?: string
    left?: string
    className?: string
    /** true: 跟随宿主 rect 铺满（全站玻璃面）；false: 官方浮窗居中（中央演示卡） */
    fill?: boolean
    radius?: number
  }>(),
  { top: '50%', left: '50%', className: '', fill: false, radius: 32 }
)

const sys = useCosmicSystemStore()
const anchor = ref<HTMLElement | null>(null)

let hostEl: HTMLElement | null = null
let glassEl: HTMLElement | null = null
let cloneEl: HTMLElement | null = null
let ro: ResizeObserver | null = null
let mo: MutationObserver | null = null

/* fill 模式用 absolute 铺满宿主：自动跟随宿主，且不受祖先 transform
   （.dock-wrap 的居中位移会让 position:fixed 相对它定位，产生 2 倍偏移）。
   浮窗模式保留官方原味的 fixed + translate(-50%,-50%) 居中。 */
const glassStyle = computed(() =>
  props.fill
    ? {
        position: 'absolute' as const,
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        zIndex: 0,
        pointerEvents: 'none' as const
      }
    : { position: 'fixed' as const, top: props.top, left: props.left }
)

/* 全站共用一个 rAF 调度器（实现见文件顶部的普通 <script> 块）。 */

/* 官方 SVG 滤镜区域默认 x/y=-35%、width/height=170%，是为了让边缘折射
   有额外采样空间。但 backdrop-filter 的输出会画满整个滤镜区域，且 Chromium
   不会用 overflow/clip-path/contain 裁掉溢出的那一圈 —— 本项目为了让玻璃
   能采样到壁纸而克隆了一层 .og-wall-clone，溢出区域就把「模糊+增饱和后的
   壁纸」盖到了玻璃外面，形成可见的矩形块与贯穿长弧线。
   把滤镜区域收紧到元素本身（0/0/100%/100%）即可根治；位移/色散链一行未改。
   （实现已提升到模块级 tightenFiltersGlobal，全站共用一次扫描。） */

/**
 * 宿主标记必须用 data-* 属性，绝不能用 class。
 *
 * 顶栏 pill / 灵动岛 / Dock 都带动态 :class 绑定（pill-right--on、
 * island--open、island--expanded…）。点击功能组件时 Vue 重新 patch class，
 * 会整体重写 className —— 我们 onMounted 里 classList.add('og-scope'/'og-fill')
 * 加的两个标记被一并抹掉，于是所有依赖这两个 class 的锁定 CSS 立刻失效：
 *   官方根 div 回到 position:relative + translate 居中 → .glass 塌缩成 2x2；
 *   sheen 层恢复 translate(-50%,-50%) 与内容测量尺寸 → 描边跑到屏幕外，
 *   在灵动岛上表现为横穿图标的水平细线，在状态胶囊上表现为 U 形大弧线。
 * 这正是「初始正常、只有点击之后才出现框移位」的原因。
 *
 * data-* 属性不参与 Vue 的 class patch，稳定存在。另用 MutationObserver
 * 监听宿主 class / 直接子节点变化，随时补标记，防止官方重渲染替换 sheen 节点。
 */
function ensureMarks() {
  const h = hostEl
  if (!h) return
  if (!h.hasAttribute('data-og-scope')) h.setAttribute('data-og-scope', '')
  if (props.fill && !h.hasAttribute('data-og-fill')) h.setAttribute('data-og-fill', '')
  h.querySelectorAll(':scope > span:not(.og-anchor)').forEach((sp) => {
    if (sp.hasAttribute('data-og-sheen')) return
    const blend = getComputedStyle(sp).mixBlendMode
    if (blend === 'screen' || blend === 'overlay') sp.setAttribute('data-og-sheen', '')
  })
}

/* 官方 LiquidGlass 只在 mount 与 window.resize 时测量 glassSize（库里没有
   ResizeObserver）。宿主变形后 —— 灵动岛从 260×44 展开成 326×169 的播放器 ——
   SVG 位移贴图仍按旧尺寸生成，backdrop-filter 的输出会画成一块旧尺寸的矩形，
   实测表现为展开态文字区出现一块突兀的深蓝色块。
   这里检测宿主尺寸变化，debounce 后派发一次 resize 让官方重新测量。 */
let lastHostSize = ''
let sizeTimer = 0
let svgTimer = 0
let lastNear1 = true
function syncOfficialSize() {
  const h = hostEl
  if (!h) return
  /* 用 offsetWidth/offsetHeight（布局尺寸）而不是 rect：rect 含 transform，
     槽位下沉时卡片是 scaleX(0.93)，rect 每帧都在变，会不停派发 resize 去
     重跑位移贴图（很贵），而布局其实一帧都没变。
     顺手把布局尺寸缓存下来：读 offsetWidth 会强制拍平一次布局，每帧读
     十几次就是整段动画掉帧，所以只在低频分支里读。 */
  layoutW = h.offsetWidth
  layoutH = h.offsetHeight
  const key = `${layoutW}x${layoutH}`
  /* 卡片从 mid/low 槽升到顶槽时布局尺寸没变，但视觉尺寸回到了 = 布局尺寸，
     这是官方唯一能测对 glassSize 的时刻。捕获这个「刚归位」的瞬间补测一次，
     否则那张位移贴图会一直停在挂载时量到的偏小尺寸上（卡片里透着一条竖线）。 */
  const ratio = layoutW ? h.getBoundingClientRect().width / layoutW : 1
  const near1 = Math.abs(ratio - 1) < 0.012
  const justRested = near1 && !lastNear1
  lastNear1 = near1
  if (key === lastHostSize && !justRested) return
  lastHostSize = key
  /* 官方每次收到 resize 都会重跑 generateShaderDisplacementMap（异步生成
     位移贴图，很贵），所以这里只能 debounce：壳体 width/height 过渡期间
     会不断触发，等它停下来再派发一次即可。 */
  window.clearTimeout(sizeTimer)
  sizeTimer = window.setTimeout(() => {
    window.dispatchEvent(new Event('resize'))
    // 贴图重做之后再对齐一次尺寸（官方会把 style 写回它量到的视觉值）
    window.clearTimeout(svgTimer)
    svgTimer = window.setTimeout(syncSvgSize, 160)
  }, 140)
}

/* 官方用 getBoundingClientRect 测 glassSize —— 那是**含 transform** 的视觉
   尺寸。卡片下沉时外层是 scaleX(0.93/0.84)，官方于是把 sheen 描边层做成
   249px 宽，再被同一层 scaleX 缩一遍：玻璃比卡片窄一圈，右边缘在卡片里
   露出半透明的一条 —— 这就是「框移位」在槽位动画里的复现。
   这里把描边层按布局尺寸（offsetWidth，不含 transform）重新对齐，让它与
   卡片严丝合缝；值没变时不写 style，静止时零开销。 */
let layoutW = 0
let layoutH = 0
let sheenEls: HTMLElement[] = []

function syncSheenSize() {
  const h = hostEl
  if (!h) return
  const w = layoutW
  const ht = layoutH
  if (!w || !ht) return
  if (!sheenEls.length || sheenEls.some((el) => !el.isConnected)) {
    sheenEls = Array.from(h.querySelectorAll(':scope > span[data-og-sheen]')) as HTMLElement[]
  }
  // 只跟内联值做字符串比较，不读任何布局属性（每帧调用也不能触发重排）。
  // 必须每帧看：官方每次收到 resize 都会按视觉尺寸把它改回去。
  for (const sp of sheenEls) {
    if (Math.abs(parseFloat(sp.style.width) - w) > 0.5) sp.style.width = `${w}px`
    if (Math.abs(parseFloat(sp.style.height) - ht) > 0.5) sp.style.height = `${ht}px`
  }
}

/* 位移贴图那张 svg 的尺寸同样来自 glassSize（官方用 rect 量的视觉尺寸）。
   卡片首次挂载时若正在 mid/low 槽（scaleX 0.93/0.84），测到的就是个偏小的
   值，之后卡片升到顶槽也不会重测 —— 那张 svg 于是永远比卡片窄一截，右边缘
   落在卡片内部，透出一条竖直的分界线（就是折叠态里那条"框内框"）。
   这里按布局尺寸把它撑满（官方把尺寸写在 style 上，改 attr 无效）。

   ⚠️ 必须低频：改 svg 尺寸会让它内部的 feDisplacementMap 整张重绘，
   展开卡 328×168 每帧改一次 = 整段动画掉到 30fps（实测长帧 14→ 更多）。
   槽位/尺寸静止后一致就够了，动画途中差几像素看不出来。 */
function syncSvgSize() {
  const h = hostEl
  if (!h) return
  const svg = h.querySelector<SVGSVGElement>('div.relative > svg')
  if (!svg) return
  const sw = `${layoutW}px`
  const sh = `${layoutH}px`
  if (svg.style.width !== sw) svg.style.width = sw
  if (svg.style.height !== sh) svg.style.height = sh
}

let lastOffset = ''
/* 壁纸样式按「壁纸 key」缓存：收放动画期间 syncBackdrop 会每帧跑，
   而 getComputedStyle(wall) 会强制一次样式计算 —— 12 个玻璃实例 × 60fps
   就是每秒几百次，足够把主线程压出长帧。壁纸没换就复用上次读到的值。 */
let wallStyleKey = ''
let wallStyle: Record<string, string> | null = null
function readWallStyle(wall: HTMLElement) {
  const k = wallpaperKey(sys.wallpapers)
  if (k !== wallStyleKey || !wallStyle) {
    const cs = getComputedStyle(wall)
    wallStyle = {
      filter: cs.filter,
      backgroundImage: cs.backgroundImage,
      backgroundColor: cs.backgroundColor,
      backgroundSize: cs.backgroundSize,
      backgroundPosition: cs.backgroundPosition,
      backgroundRepeat: cs.backgroundRepeat
    }
    wallStyleKey = k
  }
  return wallStyle
}

/* 舞台 / 壁纸元素缓存：这两个 querySelector 原本每帧每个实例各跑一次，
   加上 12 个实例就是每秒 1400+ 次文档查询。元素不换就不必重复找。 */
let stageEl: HTMLElement | null = null
let wallEl: HTMLElement | null = null
function ensureStageEls() {
  if (!stageEl || !stageEl.isConnected) stageEl = document.querySelector('.stage-canvas')
  if (!wallEl || !wallEl.isConnected) wallEl = document.querySelector('.dd-wallpaper')
}

function syncBackdrop() {
  const host = hostEl
  if (!host) return
  const glass = (glassEl?.isConnected ? glassEl : host.querySelector('.glass')) as HTMLElement | null
  if (!glass) return
  glassEl = glass

  ensureStageEls()
  const wall = wallEl
  const stage = stageEl
  if (!wall || !stage) return

  if (!cloneEl || !cloneEl.isConnected) {
    const c = wall.cloneNode(true) as HTMLElement
    c.classList.add('og-wall-clone')
    c.removeAttribute('style')
    // 挂在 warp 之前：backdrop-filter 采样的是「绘制在它之前」的内容
    glass.insertBefore(c, glass.firstChild)
    cloneEl = c
  }
  const c = cloneEl
  const sr = stage.getBoundingClientRect()
  const scale = sr.width / (stage.offsetWidth || 1) || 1
  /* 用宿主 rect 作基准：官方根 div 带 transition/居中 transform，
     读 .glass 自身会拿到过渡中间态；宿主 rect 稳定且与之完全重合。 */
  const gr = (props.fill && hostEl ? hostEl : glass).getBoundingClientRect()
  const wr = wall.getBoundingClientRect()
  const offX = (wr.left - gr.left) / scale
  const offY = (wr.top - gr.top) / scale
  // scale 也进 key：舞台缩放变化时 clone 的宽高要跟着重算
  const offset = `${offX.toFixed(1)},${offY.toFixed(1)},${scale.toFixed(3)}`
  // 位置没变就别反复写 style（rAF 轮询时避免无谓的重排）
  if (offset === lastOffset && c.isConnected && c.dataset.sized === '1') return
  lastOffset = offset
  const cs = readWallStyle(wall)
  c.dataset.sized = '1'
  c.style.position = 'absolute'
  c.style.zIndex = '0'
  c.style.pointerEvents = 'none'
  c.style.margin = '0'
  c.style.inset = 'auto'
  c.style.transform = 'none'
  c.style.filter = cs.filter
  c.style.backgroundImage = cs.backgroundImage
  c.style.backgroundColor = cs.backgroundColor
  c.style.backgroundSize = cs.backgroundSize
  c.style.backgroundPosition = cs.backgroundPosition
  c.style.backgroundRepeat = cs.backgroundRepeat
  c.style.width = `${wr.width / scale}px`
  c.style.height = `${wr.height / scale}px`
  c.style.left = `${(wr.left - gr.left) / scale}px`
  c.style.top = `${(wr.top - gr.top) / scale}px`
}

let lastKey = ''
let lastHostRect = ''
/* 空闲闸门：玻璃静止时不需要 60fps 的逐帧测量。
   宿主 rect 一变（展开 / 收起 / 槽位下沉 / 窗口缩放）就打开 1.2s 的高频窗口，
   窗口内逐帧跟（壁纸克隆与描边必须严丝合缝）；窗口之外降到 ~4Hz 抽查。
   真机上每帧 9 次 getBoundingClientRect 会强制拍平布局，这是静止态持续
   掉帧的主因之一。 */
let activeUntil = 0
let idleFrame = 0

function tick(frameNo = 0) {
  const h = hostEl
  if (!h) return
  const now = performance.now()
  if (now > activeUntil && ++idleFrame % 15 !== 0) return

  /* 宿主 rect 每帧比一次（只读布局，无写入）：
     灵动岛收放时壳体每帧都在变，壁纸克隆的偏移若落后一帧，克隆边缘就会
     落在卡片里 —— 一条竖直的错位亮线，也就是「回收时框移位」。
     只在真的变化时才写 style，静止时零开销。 */
  const r = h.getBoundingClientRect()
  const rk = `${r.left.toFixed(1)},${r.top.toFixed(1)},${r.width.toFixed(1)},${r.height.toFixed(1)}`
  if (rk !== lastHostRect) {
    lastHostRect = rk
    activeUntil = now + 1200
    syncBackdrop()
  }
  /* 其余重活降到 ~0.4s 一次（60fps 下每 24 帧）：标记补齐 / 官方尺寸重测。
     文档级的 SVG 滤镜收紧由模块级调度器统一做，不在这里各扫一遍。 */
  if (frameNo % 24 === 0) { ensureMarks(); syncOfficialSize() }
  // 描边层对齐要跟每一帧：槽位下沉是被 scaleX 压着的，官方随时可能按
  // 视觉尺寸把它改回去（每次 resize / 重渲染都会），慢一拍就露出一条边。
  syncSheenSize()
  const key = wallpaperKey(sys.wallpapers)
  if (key !== lastKey) { lastKey = key; lastOffset = ''; lastHostRect = ''; syncBackdrop() }
}

onMounted(() => {
  document.documentElement.dataset.glass = 'webgl'
  requestAnimationFrame(() => {
    hostEl = anchor.value?.parentElement ?? null
    // 全部标记改为 data-* 属性（详见 ensureMarks 注释）：Vue 的 :class patch
    // 不会动 data-*，点击功能组件后锁定规则依旧命中。
    ensureMarks()
    tightenFiltersGlobal()
    if (props.fill) {
      if (hostEl) {
        layoutW = hostEl.offsetWidth
        layoutH = hostEl.offsetHeight
        lastHostSize = `${layoutW}x${layoutH}`
      }
      syncSheenSize()
      syncSvgSize()
      glassTickers.add(tick)
      glassMaintenance.add(tightenFiltersGlobal)
      glassStartDriver()
    }
    // 即时兜底：Vue 重写 className、或官方替换 sheen 节点时立刻补标记。
    // attributeFilter 只盯 class，不会因我们自己写 data-* 造成回环。
    if (hostEl) {
      mo = new MutationObserver(() => ensureMarks())
      mo.observe(hostEl, {
        attributes: true,
        attributeFilter: ['class'],
        childList: true
      })
    }
    const target = glassEl ?? hostEl
    if (target) {
      ro = new ResizeObserver(() => { lastOffset = ''; syncBackdrop(); ensureMarks(); syncOfficialSize() })
      ro.observe(target)
      if (hostEl && hostEl !== target) ro.observe(hostEl)
    }
    window.addEventListener('resize', syncBackdrop)
  })
})

watch(() => wallpaperKey(sys.wallpapers), () => { lastOffset = ''; syncBackdrop() })

/* 卸载 ≠ 消失。
   Vue 的 <Transition> 先卸载组件（触发 onBeforeUnmount），再给残留的元素挂
   leave 类跑 0.52s 的 width/height 过渡。以前这里立刻撤掉 data-og-fill、
   壁纸克隆和帧循环，后果是整条链路在离场第一帧就断了：
     · 官方根 div 退回默认的「fixed 浮窗 + translate(-50%,-50%)」定位，
       sheen 描边层尺寸停在被卸载那一刻（实测固定 326×166、位置不动）
     · .glass 失去 100% 锁定，塌成 2×2
   于是屏幕上留着一个固定不动的玻璃框，卡片在它内部收缩，框的右/下边缘
   横切在胶囊中间 —— 这就是反复出现的「回收时框移位」。
   现在把清理挂到「宿主真正离开文档」这一事件上（逐帧查 isConnected），
   而不是猜一个时长：离场过渡跑多久，锁定就维持多久。 */
let teardownRaf = 0
onBeforeUnmount(() => {
  const host = hostEl
  const clone = cloneEl
  window.clearTimeout(sizeTimer)
  window.removeEventListener('resize', syncBackdrop)
  mo?.disconnect()

  const cleanup = () => {
    glassTickers.delete(tick)
    glassMaintenance.delete(tightenFiltersGlobal)
    glassStopIfIdle()
    ro?.disconnect()
    clone?.remove()
    /* 属性只在宿主确实离开文档后才撤：若元素被 Vue 复用（收起动画没播完
       就再次展开），新实例会重新 ensureMarks，这里撤掉反而会让它掉锁。 */
    if (host && !host.isConnected) {
      host.removeAttribute('data-og-fill')
      host.removeAttribute('data-og-scope')
    }
  }
  if (!host) { cleanup(); return }
  let guard = 0
  const watch = () => {
    if (!host.isConnected || ++guard > 900) { cleanup(); return }
    teardownRaf = requestAnimationFrame(watch)
  }
  cancelAnimationFrame(teardownRaf)
  teardownRaf = requestAnimationFrame(watch)
})
</script>

<template>
  <span ref="anchor" class="og-anchor" aria-hidden="true" />
  <!-- data-og-glass 是首帧就存在的静态标记：官方库的 .glass 会吃到 global.css
       的通用 .glass 样式（浅色 root 下是近白色实底 + 白色 ::before 高光）。
       data-og-scope 要等 onMounted 的 rAF 才由 JS 补上，中间那一帧会闪白 ——
       选中窗口 / 切换 AppBar 时偶发的「白条」就是它。这里用模板直出的 attribute
       从第一次绘制就锁死，JS 标记仍保留给 sheen / 尺寸对齐逻辑。 -->
  <LiquidGlass
    :class-name="className"
    data-og-glass=""
    :displacement-scale="99"
    :blur-amount="0.12"
    :saturation="140"
    :aberration-intensity="2"
    :elasticity="0"
    :corner-radius="radius"
    :padding="'0px'"
    :style="glassStyle"
  >
    <slot />
  </LiquidGlass>
</template>
