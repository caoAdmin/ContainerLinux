<script setup lang="ts">
/**
 * CtAgentSidebar —— 对话 / Agent 切换到 Agent 后，从提示条进入的「Agent 任务工作台」侧边栏
 *
 * 右侧滑入，占桌面可用区宽度 1/5（20vw，配 240~340px 上下限）。
 * 它把「对话」直接带进工作台：消息流 + 输入框 + 发送都在侧栏里，和底部对话框
 * 共享同一会话（ctai.panelMsgs / panelInput / sendPanel）；另有大馒头概览、
 * 可操作的小馒头任务卡（单个取消）、派活记录（可清空）、快捷派活按钮。
 * z 9200：高于 Dock(9000)/对话框(9100)，低于控制中心(9500)/通知中心(9550)。
 *
 * 形状：右侧两角填满（贴屏幕右边缘、方角），左侧两角圆角 —— 成为「屏幕新的边框」。
 * 圆角靠 border-radius 继承链传给玻璃层（不能用 overflow/clip-path 裁，会破坏壁纸采样）。
 *
 * 配色走 --c-* 令牌随深浅主题，玻璃复用 <LgSheet liquid /> 随全站三态；
 * flat 档的实底覆盖在全局 cosmic.css（scoped :global 会被 lightningcss 删）。
 */
import { computed, nextTick, ref, watch } from 'vue'
import { useCtAIStore, type CtPanelMode } from '@/stores/ctai'
import Icon from '@/components/common/Icon.vue'
import LgSheet from './LgSheet.vue'

const ctai = useCtAIStore()

/** 对话框收起后，模型 / 双模配置搬到这里 —— 两个本地模型，Agent 沿用当前选中模型 */
const MODELS: Array<{ id: CtPanelMode; label: string; sub: string; icon: string }> = [
  { id: 'chat', label: 'Qwen3-0.6B', sub: '轻量对话 · 400MB', icon: 'ri-chat-4-line' },
  { id: 'deep', label: 'Qwen3-1.5B', sub: '深度思考 · 1.5GB', icon: 'ri-brain-line' }
]
const current = computed(() => MODELS.find((m) => m.id === ctai.panelMode)!)
const modelOpen = ref(false)
function pickModel(id: CtPanelMode) {
  modelOpen.value = false
  ctai.setPanelMode(id)
}
function toggleDeep() { pickModel(ctai.panelMode === 'deep' ? 'chat' : 'deep') }
function toggleSearch() {
  const next = !ctai.panelSearch
  ctai.panelSearch = next
  ctai.setTier(next ? 'glm-flash' : 'local')
}

/** 当前模型名（Agent 沿用选中的 chat/deep 模型，无独立 Agent 模型） */
const modelName = computed(() => (ctai.panelMode === 'deep' ? 'Qwen3-1.5B' : 'Qwen3-0.6B'))
/** 平均进度 */
const avgProgress = computed(() => {
  if (!ctai.tasks.length) return 0
  return Math.round(ctai.tasks.reduce((s, t) => s + t.progress, 0) / ctai.tasks.length)
})
/** 派活记录倒序（最新在上） */
const reversedLog = computed(() => [...ctai.agentLog].reverse())
/** 快捷派活预设（点一下直接派给大馒头） */
const QUICK = [
  { icon: 'ri-file-search-line', text: '检索本机相关文件' },
  { icon: 'ri-file-list-3-line', text: '汇总结果并生成草稿' }
]

const inputRef = ref<HTMLInputElement | null>(null)
const bodyRef = ref<HTMLElement | null>(null)
function scrollBottom() {
  nextTick(() => { if (bodyRef.value) bodyRef.value.scrollTop = bodyRef.value.scrollHeight })
}
watch(() => [ctai.panelMsgs.length, ctai.tasks.length], scrollBottom)
watch(() => ctai.panelAgentSidebarOpen, (v) => { if (v) nextTick(() => inputRef.value?.focus()) })

/** 发送：与底部对话框共用 sendPanel，侧栏输入框即会话输入框 */
function send() {
  ctai.sendPanel()
}
/** 快捷派活：直接带文本发 */
function quickSend(text: string) {
  ctai.sendPanel(text)
}
function stateLabel(state: string): string {
  return state === 'done' ? '已完成' : state === 'canceled' ? '已取消' : '执行中'
}
</script>

<template>
  <Transition name="cas-slide">
    <aside
      v-if="ctai.panelAgentSidebarOpen"
      class="cas-panel lg-host"
      :class="{ 'cas-float': ctai.agentFloat }"
      aria-label="Agent 任务工作台"
    >
      <!-- 玻璃层 + 可读性薄雾（与控制中心 / 唤醒对话框同一套） -->
      <LgSheet liquid />
      <div class="cas-tint" aria-hidden="true" />
      <!-- 左缘外展翼：仅接管模式（包围屏幕）显示；后台模式是普通悬浮卡片，无翼。
           模式切换时淡入淡出，与面板位置/圆角过渡同步。 -->
      <Transition name="cas-fade">
        <svg v-if="!ctai.agentFloat" class="cas-flare cas-flare-top" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <path d="M0 0 H100 V100 A100 100 0 0 0 0 0 Z" />
        </svg>
      </Transition>
      <Transition name="cas-fade">
        <svg v-if="!ctai.agentFloat" class="cas-flare cas-flare-bottom" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <path d="M0 100 H100 V0 A100 100 0 0 1 0 100 Z" />
        </svg>
      </Transition>

      <!-- ── 头部 ── -->
      <header class="cas-head">
        <div class="cas-head-ico"><Icon name="ri-robot-line" :size="18" /></div>
        <div class="cas-head-txt">
          <b>Agent 工作台</b>
          <em>{{ modelName }} · 大馒头调度</em>
        </div>
        <button
          class="cas-mode" :title="ctai.agentFloat ? '切换为接管模式（包围屏幕）' : '切换为后台模式（悬浮）'"
          @click="ctai.toggleAgentFloat()"
        >
          <Icon :name="ctai.agentFloat ? 'ri-fullscreen-line' : 'ri-picture-in-picture-line'" :size="14" />
        </button>
        <button class="cas-back" title="返回对话" @click="ctai.backToChat()">
          <Icon name="ri-chat-4-line" :size="14" />
        </button>
        <button class="cas-close" title="关闭工作台" @click="ctai.closeAgentSidebar()">
          <Icon name="ri-close-line" :size="15" />
        </button>
      </header>

      <!-- ── 可滚动主体：对话 + 任务 + 记录 ── -->
      <div ref="bodyRef" class="cas-body">
        <!-- 对话流：直接把会话带进工作台（与底部对话框共享 panelMsgs） -->
        <section class="cas-section cas-chat-sec">
          <div class="cas-sec-hd"><Icon name="ri-chat-4-line" :size="13" />对话</div>
          <div class="cas-msg-list">
            <div v-for="(m, i) in ctai.panelMsgs" :key="i" class="cas-msg" :class="m.role">
              <div v-if="m.role === 'bot'" class="cas-av"><Icon name="ri-sparkling-2-line" :size="11" /></div>
              <div class="cas-bubble">
                <div class="cas-txt">{{ m.text }}</div>
                <div v-if="m.steps" class="cas-steps">
                  <div v-for="(s, si) in m.steps" :key="si" class="cas-step"><Icon name="ri-check-line" :size="9" />{{ s }}</div>
                </div>
              </div>
            </div>
            <div v-if="ctai.panelBusy" class="cas-msg bot">
              <div class="cas-av"><Icon name="ri-sparkling-2-line" :size="11" /></div>
              <div class="cas-bubble cas-typing"><i /><i /><i /></div>
            </div>
          </div>
        </section>

        <!-- 大馒头概览 -->
        <section v-if="ctai.tasks.length" class="cas-overview">
          <div class="cas-ov-top">
            <span class="cas-ov-ico"><Icon name="ri-node-tree" :size="14" /></span>
            <div class="cas-ov-title">
              <b>{{ ctai.tasks[0].parent }}</b>
              <em>调度主脑 · origin: agent:{{ ctai.tasks[0].parent }}</em>
            </div>
            <button class="cas-ov-cancel" title="取消全部小馒头" @click="ctai.cancelAgent()">
              <Icon name="ri-stop-circle-line" :size="14" />
            </button>
          </div>
          <div class="cas-ov-stats">
            <div><b>{{ ctai.runningCount }}</b><span>执行中</span></div>
            <div><b>{{ ctai.tasks.filter((t) => t.state === 'done').length }}</b><span>已完成</span></div>
            <div :class="{ warn: ctai.needsAttention }"><b>{{ avgProgress }}%</b><span>平均进度</span></div>
          </div>
        </section>

        <!-- 小馒头任务卡（可操作：单个取消） -->
        <section class="cas-section">
          <div class="cas-sec-hd"><Icon name="ri-stack-line" :size="13" />小馒头子任务</div>
          <div v-if="ctai.tasks.length" class="cas-tasks">
            <div
              v-for="(t, i) in ctai.tasks" :key="t.id" class="cas-task"
              :class="{ done: t.state === 'done', canceled: t.state === 'canceled' }"
            >
              <div class="cas-task-top">
                <span class="cas-task-ico"><Icon :name="t.state === 'done' ? 'ri-check-line' : t.state === 'canceled' ? 'ri-close-line' : 'ri-loader-4-line'" :size="12" /></span>
                <b>{{ t.name }}</b>
                <button
                  v-if="t.state === 'running'" class="cas-task-x" title="取消该任务"
                  @click="ctai.cancelTask(t.id)"
                ><Icon name="ri-close-line" :size="11" /></button>
                <em v-else>{{ stateLabel(t.state) }}</em>
              </div>
              <div class="cas-bar"><i :style="{ width: t.progress + '%' }" /></div>
              <div class="cas-task-foot">小馒头 #{{ i + 1 }} · {{ t.progress }}%</div>
            </div>
          </div>
          <div v-else class="cas-empty">
            <Icon name="ri-robot-line" :size="22" />
            <p>还没有派活</p>
            <span>在下方输入一件事，大馒头会拆给小馒头并行执行。</span>
          </div>
        </section>

        <!-- 派活记录（可清空） -->
        <section class="cas-section cas-log-sec">
          <div class="cas-sec-hd">
            <Icon name="ri-history-line" :size="13" />派活记录
            <button v-if="ctai.agentLog.length" class="cas-log-clear" title="清空记录" @click="ctai.clearAgentLog()">清空</button>
          </div>
          <div v-if="reversedLog.length" class="cas-log">
            <div v-for="(l, i) in reversedLog" :key="i" class="cas-log-i">
              <span class="cas-log-dot" />
              <span class="cas-log-time">{{ l.time }}</span>
              <span class="cas-log-text">{{ l.text }}</span>
            </div>
          </div>
          <div v-else class="cas-log-empty">暂无记录</div>
        </section>
      </div>

      <!-- ── 配置条（下移）：对话框收起后，模型 / 双模在底部输入区上方操作 ── -->
      <div class="cas-config">
        <button class="cas-chip" :class="{ on: ctai.panelMode === 'deep' }" @click="toggleDeep">
          <Icon name="ri-brain-line" :size="13" />深度思考
        </button>
        <button class="cas-chip" :class="{ on: ctai.panelSearch }" @click="toggleSearch">
          <Icon name="ri-global-line" :size="13" />智能搜索
        </button>
        <div class="cas-model-wrap">
          <button class="cas-model" :class="{ open: modelOpen }" @click="modelOpen = !modelOpen">
            <Icon :name="current.icon" :size="13" /><span>{{ current.label }}</span>
            <Icon name="ri-arrow-up-s-line" :size="12" />
          </button>
          <Transition name="cwpm">
            <div v-if="modelOpen" class="cas-model-menu">
              <div class="cas-model-menu-hd">选择模型 / 模式</div>
              <button
                v-for="m in MODELS" :key="m.id" class="cas-model-item"
                :class="{ on: ctai.panelMode === m.id }" @click="pickModel(m.id)"
              >
                <span class="cas-mi-ico"><Icon :name="m.icon" :size="15" /></span>
                <span class="cas-mi-txt"><b>{{ m.label }}</b><em>{{ m.sub }}</em></span>
                <Icon v-if="ctai.panelMode === m.id" name="ri-check-line" :size="13" />
              </button>
            </div>
          </Transition>
        </div>
      </div>

      <!-- ── 输入区：把对话能力带进工作台 ── -->
      <div class="cas-compose">
        <div class="cas-quick">
          <button v-for="q in QUICK" :key="q.text" :disabled="ctai.panelBusy" @click="quickSend(q.text)">
            <Icon :name="q.icon" :size="12" />{{ q.text }}
          </button>
        </div>
        <div class="cas-input-row">
          <input
            ref="inputRef" v-model="ctai.panelInput" class="cas-input"
            placeholder="派个活给大馒头…" spellcheck="false" @keydown.enter="send"
          />
          <button class="cas-send" :disabled="!ctai.panelInput.trim() || ctai.panelBusy" title="发送（Enter）" @click="send">
            <Icon name="ri-arrow-up-line" :size="16" />
          </button>
        </div>
      </div>
    </aside>
  </Transition>
</template>

<style scoped>
.cas-panel {
  position: fixed; top: 0; right: 0; bottom: 0;
  width: 20vw; min-width: 240px; max-width: 340px;
  z-index: 9200;
  /* .cd-root 是 pointer-events:none，侧栏必须显式开启，否则整棵子树点不动 */
  pointer-events: auto;
  display: flex; flex-direction: column;
  /* 左缘不是直边：由 .cas-bulge 弧翼向外鼓出，故去掉 border-left / 负向投影，
     避免一条直线切穿弧线。仅保留向下的柔光投影衬托面板浮起。 */
  box-shadow: -6px 0 46px var(--c-shadow, rgba(0, 0, 0, 0.28));
  background: transparent;
  color: var(--c-text, #2c2f3a);
  /* 接管 ↔ 后台模式切换动画：位置 / 圆角 / 阴影平滑过渡（圆角值来自
     cosmic.css 的 !important 规则，computed 值变化照样参与 transition） */
  transition:
    top .42s cubic-bezier(.25, .9, .3, 1),
    right .42s cubic-bezier(.25, .9, .3, 1),
    bottom .42s cubic-bezier(.25, .9, .3, 1),
    border-radius .42s cubic-bezier(.25, .9, .3, 1),
    box-shadow .42s ease;
}
/* 玻璃层铺满；可读性薄雾夹在玻璃与内容之间；内容抬到 z=1。
   圆角靠继承链（宿主 → .lg-overlay/.lg-flat → .glass），不能用 overflow 裁切。
   .cas-bulge 是背景弧翼，压到 z=0，不参与内容层级。 */
.cas-panel > :not(.lg-overlay):not(.lg-flat):not(.glass):not(.og-scope):not(.cas-tint):not(.cas-flare) {
  position: relative; z-index: 1;
}
.cas-tint {
  position: absolute; inset: 0; z-index: 0; pointer-events: none;
  border-radius: inherit;
  background: color-mix(in srgb, var(--c-bg, #f4f4f7) 84%, transparent);
}
/* ── 左缘外展翼（接管模式专用，弧度已按用户反馈调小） ──
   顶翼：顶边向左伸出 --flare-w，尖端处弧线与顶边相切、向下弯，落到主体左缘时
   与左缘相切 —— 翼从尖端向面板逐渐变厚，中间左缘保持笔直。
   path: M0,0 H100 V100 A100,100 0 0 0 0,0 Z（凹弧圆心在左下角 (0,100)）。
   底翼垂直镜像（弧圆心在左上角）。填充与 .cas-tint 同色，与面板无缝衔接。 */
.cas-flare {
  --flare-w: clamp(26px, 2.8vw, 40px);
  --flare-h: clamp(38px, 6vh, 60px);
  position: absolute; left: calc(-1 * var(--flare-w));
  width: var(--flare-w); height: var(--flare-h);
  z-index: 0; pointer-events: none;
  fill: color-mix(in srgb, var(--c-bg, #f4f4f7) 84%, transparent);
}
.cas-flare-top { top: 0; }
.cas-flare-bottom { bottom: 0; }
/* flat 档覆盖见 cosmic.css 全局规则 */

/* ── 后台模式（悬浮卡片）：不贴屏幕边、四角圆角、无外展翼。
   圆角在 cosmic.css 用三重类名 + !important 压过 .lg-host 的 32px 与接管模式的 0。 */
.cas-float {
  top: 52px; right: 12px; bottom: 84px;
  box-shadow: 0 18px 60px var(--c-shadow, rgba(0, 0, 0, 0.35));
}

/* ── 头部 ── */
.cas-head {
  flex: none; display: flex; align-items: center; gap: 10px;
  padding: 18px 16px 14px;
  border-bottom: 1px solid var(--c-border, rgba(0, 0, 0, 0.08));
}
.cas-head-ico {
  flex: none; width: 34px; height: 34px; border-radius: 10px;
  display: grid; place-items: center;
  background: var(--c-accent-soft, #e9efff); color: var(--c-accent, #4a5fc7);
}
.cas-head-txt { flex: 1; min-width: 0; display: flex; flex-direction: column; line-height: 1.35; }
.cas-head-txt b { font-size: 14px; font-weight: 700; }
.cas-head-txt em { font-size: 11px; font-style: normal; color: var(--c-text-mute, #8b91a4); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cas-mode, .cas-back, .cas-close {
  flex: none; width: 28px; height: 28px; border-radius: 50%; border: 0; cursor: pointer;
  display: grid; place-items: center;
  color: var(--c-text-dim, #5a6072); background: var(--c-surface-2, #eef0f6); transition: .14s;
}
.cas-mode:hover, .cas-back:hover, .cas-close:hover { background: var(--c-hover, #e6ebfb); color: var(--c-accent, #3450d8); }

/* ── 配置条（底部）：深度思考 / 智能搜索 / 模型在这里操作，紧贴在输入区上方 ── */
.cas-config {
  flex: none; display: flex; align-items: center; gap: 6px;
  padding: 9px 14px;
  border-top: 1px solid var(--c-border, rgba(0,0,0,.08));
  background: color-mix(in srgb, var(--c-surface, #fff) 32%, transparent);
  overflow: visible;
  /* 高于 .cas-body：否则同为 z-index:1 时前面的对话区会盖住下拉菜单，点不到模型/双模。
     !important 压过 .cas-panel > :not(...) 那条高特异性通用规则。 */
  z-index: 5 !important;
}
.cas-chip {
  display: inline-flex; align-items: center; gap: 4px;
  height: 28px; padding: 0 9px; border-radius: 14px; cursor: pointer;
  font-size: 11px; white-space: nowrap;
  color: var(--c-text-dim, #5a6072); background: var(--c-surface-2, #eef0f6);
  border: 1px solid var(--c-border, #e2e6f0); transition: .16s;
}
.cas-chip:hover { background: var(--c-hover, #eceffa); }
.cas-chip.on {
  color: var(--c-accent, #3450d8); background: var(--c-accent-soft, #e9efff);
  border-color: color-mix(in srgb, var(--c-accent, #4f6bff) 42%, var(--c-border));
}
.cas-model-wrap { position: relative; margin-left: auto; }
.cas-model {
  display: inline-flex; align-items: center; gap: 4px;
  height: 28px; padding: 0 8px; border-radius: 14px; cursor: pointer;
  font-size: 11px; font-weight: 600; color: var(--c-text-dim, #555f78);
  background: var(--c-surface-2, #f4f6fb); border: 1px solid var(--c-border, #e2e6f0); transition: .16s;
}
.cas-model:hover, .cas-model.open { background: var(--c-hover, #eceffa); }
.cas-model-menu {
  /* 配置条在底部，菜单向上弹，避免被视口底边裁掉 */
  position: absolute; right: 0; bottom: calc(100% + 8px);
  width: 226px; padding: 8px; border-radius: 13px; z-index: 20;
  background: var(--c-surface, #fff); border: 1px solid var(--c-border, #e4e8f3);
  box-shadow: 0 14px 38px var(--c-shadow, rgba(18,22,52,.28));
}
.cas-model-menu-hd { font-size: 10px; color: var(--c-text-mute, #9aa0b3); padding: 3px 6px 7px; }
.cas-model-item {
  width: 100%; display: flex; align-items: center; gap: 8px;
  padding: 7px 7px; border: 0; border-radius: 9px; cursor: pointer;
  background: transparent; color: var(--c-text, #2c2f3a); text-align: left; transition: .14s;
}
.cas-model-item:hover { background: var(--c-hover, #f3f5fc); }
.cas-model-item.on { background: var(--c-accent-soft, #eef1ff); }
.cas-mi-ico { flex: none; width: 26px; height: 26px; border-radius: 8px; display: grid; place-items: center; background: var(--c-accent-soft, #e9ecfb); color: var(--c-accent, #4a5fc7); }
.cas-mi-txt { flex: 1; display: flex; flex-direction: column; line-height: 1.3; min-width: 0; }
.cas-mi-txt b { font-size: 11.5px; font-weight: 650; }
.cas-mi-txt em { font-size: 9.5px; font-style: normal; color: var(--c-text-mute, #9aa0b3); }
.cas-model-item > :last-child { color: var(--c-accent, #3450d8); }

/* ── 可滚动主体 ── */
.cas-body { flex: 1 1 auto; min-height: 0; overflow-y: auto; padding-bottom: 10px; }
.cas-body::-webkit-scrollbar { width: 5px; }
.cas-body::-webkit-scrollbar-thumb { background: var(--c-border-strong, #d5d9e8); border-radius: 3px; }

/* ── 分区 ── */
.cas-section { padding: 14px 14px 0; }
.cas-sec-hd {
  display: flex; align-items: center; gap: 6px;
  font-size: 11px; font-weight: 650; letter-spacing: .02em;
  color: var(--c-text-dim, #5a6072); margin-bottom: 9px;
}

/* ── 对话流 ── */
.cas-msg-list { display: flex; flex-direction: column; gap: 10px; }
.cas-msg { display: flex; gap: 7px; align-items: flex-start; }
.cas-msg.me { flex-direction: row-reverse; }
.cas-av { flex: none; width: 20px; height: 20px; border-radius: 7px; display: grid; place-items: center; background: var(--c-accent-soft, #e9ecfb); color: var(--c-accent, #4a5fc7); }
.cas-bubble {
  max-width: 88%; padding: 8px 10px; border-radius: 11px;
  font-size: 11.5px; line-height: 1.56;
  background: var(--c-surface-2, #f1f3f9); border: 1px solid var(--c-border, #e8ebf4);
  color: var(--c-text, #333746);
}
.cas-msg.me .cas-bubble { background: var(--c-accent, #4f6bff); border-color: transparent; color: #fff; }
.cas-steps { margin-top: 7px; padding-top: 6px; border-top: 1px dashed var(--c-border, #d9deec); display: flex; flex-direction: column; gap: 4px; }
.cas-step { display: flex; align-items: center; gap: 5px; font-size: 10px; color: var(--c-accent, #5668b6); }
.cas-typing { display: inline-flex; gap: 3px; align-items: center; }
.cas-typing i { width: 4px; height: 4px; border-radius: 50%; background: var(--c-text-mute, #9aa3c4); animation: cast 1.2s infinite; }
@keyframes cast { 0%,60%,100% { opacity: .35; } 30% { opacity: 1; } }

/* ── 概览 ── */
.cas-overview { margin: 14px 14px 0; padding: 12px; border-radius: 14px; background: var(--c-surface-2, #f1f3f9); border: 1px solid var(--c-border, #e8ebf4); }
.cas-ov-top { display: flex; align-items: center; gap: 9px; }
.cas-ov-ico { flex: none; width: 26px; height: 26px; border-radius: 8px; display: grid; place-items: center; background: var(--c-accent-soft, #e9ecfb); color: var(--c-accent, #4a5fc7); }
.cas-ov-title { flex: 1; min-width: 0; display: flex; flex-direction: column; line-height: 1.3; }
.cas-ov-title b { font-size: 12.5px; font-weight: 650; }
.cas-ov-title em { font-size: 10px; font-style: normal; color: var(--c-text-mute, #9aa0b3); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cas-ov-cancel { flex: none; width: 24px; height: 24px; border-radius: 7px; border: 0; cursor: pointer; display: grid; place-items: center; background: var(--c-surface, #fff); color: var(--c-text-mute, #8b91a4); transition: .14s; }
.cas-ov-cancel:hover { background: color-mix(in srgb, #e0483d 14%, var(--c-surface)); color: #d04338; }
.cas-ov-stats { display: flex; gap: 6px; margin-top: 12px; }
.cas-ov-stats > div { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 2px; padding: 8px 4px; border-radius: 10px; background: var(--c-surface, #fff); border: 1px solid var(--c-border, #e4e8f3); }
.cas-ov-stats b { font-size: 15px; font-weight: 700; color: var(--c-accent, #3450d8); font-variant-numeric: tabular-nums; }
.cas-ov-stats span { font-size: 10px; color: var(--c-text-mute, #8b91a4); }
.cas-ov-stats > div.warn b { color: #d08a2e; }

/* ── 任务卡 ── */
.cas-tasks { display: flex; flex-direction: column; gap: 8px; }
.cas-task { padding: 9px 10px; border-radius: 11px; background: var(--c-surface-2, #f1f3f9); border: 1px solid var(--c-border, #e8ebf4); }
.cas-task.done { border-color: color-mix(in srgb, #2ea36b 45%, var(--c-border)); background: color-mix(in srgb, #2ea36b 8%, var(--c-surface)); }
.cas-task.canceled { opacity: .55; }
.cas-task-top { display: flex; align-items: center; gap: 7px; }
.cas-task-ico { flex: none; color: var(--c-accent, #5a6fc9); display: grid; place-items: center; }
.cas-task.done .cas-task-ico { color: #2ea36b; }
.cas-task-top b { flex: 1; min-width: 0; font-size: 11.5px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cas-task-top em { font-size: 10px; font-style: normal; color: var(--c-text-mute, #7b8196); white-space: nowrap; }
.cas-task-x { flex: none; width: 18px; height: 18px; border-radius: 50%; border: 0; cursor: pointer; display: grid; place-items: center; background: var(--c-surface, #fff); color: var(--c-text-mute, #8b91a4); transition: .14s; }
.cas-task-x:hover { background: color-mix(in srgb, #e0483d 14%, var(--c-surface)); color: #d04338; }
.cas-bar { height: 4px; border-radius: 2px; background: var(--c-border, #eceff7); margin: 7px 0 5px; overflow: hidden; }
.cas-bar i { display: block; height: 100%; border-radius: 2px; background: var(--c-accent, #4f6bff); transition: width .3s ease; }
.cas-task.done .cas-bar i { background: #2ea36b; }
.cas-task-foot { font-size: 9.5px; color: var(--c-text-mute, #9aa0b3); font-family: ui-monospace, monospace; }

/* ── 空状态 ── */
.cas-empty { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 22px 14px; border-radius: 12px; background: var(--c-surface-2, #f1f3f9); border: 1px dashed var(--c-border-strong, #d5d9e8); color: var(--c-text-mute, #9aa0b3); text-align: center; }
.cas-empty p { margin: 0; font-size: 12px; font-weight: 650; color: var(--c-text-dim, #5a6072); }
.cas-empty span { font-size: 10.5px; line-height: 1.5; }

/* ── 派活记录 ── */
.cas-log-clear { margin-left: auto; border: 0; background: transparent; cursor: pointer; font-size: 10px; color: var(--c-text-mute, #9aa0b3); padding: 0 2px; }
.cas-log-clear:hover { color: var(--c-accent, #3450d8); }
.cas-log { display: flex; flex-direction: column; }
.cas-log-i { display: flex; align-items: flex-start; gap: 7px; padding: 7px 2px; border-bottom: 1px solid var(--c-border, rgba(0,0,0,.06)); }
.cas-log-dot { flex: none; width: 6px; height: 6px; border-radius: 50%; margin-top: 5px; background: var(--c-accent, #4f6bff); }
.cas-log-time { flex: none; font-size: 10px; color: var(--c-text-mute, #9aa0b3); font-variant-numeric: tabular-nums; }
.cas-log-text { flex: 1; font-size: 11px; line-height: 1.45; color: var(--c-text-dim, #5a6072); }
.cas-log-empty { font-size: 11px; color: var(--c-text-mute, #9aa0b3); padding: 8px 2px; }

/* ── 输入区 ── */
.cas-compose { flex: none; padding: 12px 14px 16px; border-top: 1px solid var(--c-border, rgba(0,0,0,.08)); background: color-mix(in srgb, var(--c-surface, #fff) 32%, transparent); }
.cas-quick { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 9px; }
.cas-quick button { display: inline-flex; align-items: center; gap: 4px; height: 25px; padding: 0 8px; border-radius: 13px; cursor: pointer; font-size: 10.5px; color: var(--c-accent, #3450d8); background: var(--c-accent-soft, #e9efff); border: 1px solid color-mix(in srgb, var(--c-accent, #4f6bff) 24%, var(--c-border)); transition: .14s; }
.cas-quick button:hover:not(:disabled) { background: color-mix(in srgb, var(--c-accent, #4f6bff) 18%, var(--c-surface)); }
.cas-quick button:disabled { opacity: .5; cursor: default; }
.cas-input-row { display: flex; align-items: center; gap: 7px; padding: 4px 4px 4px 12px; border-radius: 16px; background: var(--c-surface, #fff); border: 1px solid var(--c-border, #dfe2ea); }
.cas-input { flex: 1; min-width: 0; height: 32px; border: 0; outline: 0; background: transparent; font-size: 12px; color: var(--c-text, #2c2f3a); }
.cas-input::placeholder { color: var(--c-text-mute, #a3a8b8); }
.cas-send { flex: none; width: 30px; height: 30px; border-radius: 50%; border: 0; cursor: pointer; display: grid; place-items: center; color: #fff; background: var(--c-accent, #4f6bff); box-shadow: 0 3px 10px color-mix(in srgb, var(--c-accent, #3450d8) 38%, transparent); transition: filter .15s; }
.cas-send:hover:not(:disabled) { filter: brightness(1.08); }
.cas-send:disabled { opacity: .45; cursor: default; }

/* ── 滑入动画（照 NotificationCenter.nc-slide）── */
.cas-slide-enter-active, .cas-slide-leave-active { transition: transform .38s cubic-bezier(.2,.9,.3,1), opacity .3s ease; }
.cas-slide-enter-from, .cas-slide-leave-to { transform: translateX(100%); opacity: .3; }

/* ── 翼淡入淡出（模式切换时）── */
.cas-fade-enter-active, .cas-fade-leave-active { transition: opacity .34s ease; }
.cas-fade-enter-from, .cas-fade-leave-to { opacity: 0; }
</style>
