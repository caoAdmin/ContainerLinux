<script setup lang="ts">
/**
 * LgSheet —— 统一液态玻璃层（v2：裸 warp + 自建 SVG 滤镜链）
 *
 * ⚠️ 为什么不再用 @wxperia/liquid-glass-vue 的组件：
 *   库的包装结构（.glass overflow:hidden + 内联 filter:url(#实例滤镜) + 幽灵层）
 *   在 Chrome 144 下会让 backdrop-filter 整条失效（实测 blur/invert 均不渲染），
 *   而同样的 backdrop-filter 值放在裸 div 上完全正常（消融实验证实）。
 *   因此只保留库的滤镜设计，DOM 结构自己写。
 *
 * 滤镜链与库逐项一致（standard 模式）：
 *   位移贴图 → 边缘强度 → RGB 三通道位移（-99 / -108.9 / -118.8，产生色散）
 *   → screen 合成 → 0.3 微模糊 → 与中心干净层 over 合成。
 *
 * 用法与旧版完全一致：放在 position:relative 的宿主容器里，自身绝对定位
 * 铺满宿主、pointer-events 全关，宿主内容照常布局与交互。
 *
 * 全站统一参数（勿散改）：
 *   Displacement Scale 99 · Blur Amount 0.12(→7.84px) · Saturation 140%
 *   Aberration Intensity 2 · Elasticity 0 · Corner Radius 32px
 *
 * liquid=true 时改挂官方 OfficialGlass（fill 模式），走官方 SVG 位移算法；
 * liquid=false 时保留本文件的裸 warp 纯磨砂（窗口内面板背后不是壁纸，
 * 官方组件采样会穿帮，故保持磨砂但模糊参数与全站一致）。
 */

const DISPLACEMENT = 99
const ABERRATION = 2
/* blur/saturate 在 cosmic.css 的 .lg-warp 里（blur 7.84px = 4 + 0.12*32，saturate 140%）。
   standard 模式 scale = -1（库源码）。 */
const SCALE = -1

/* 库内置的标准位移贴图（standard 模式 getMap 返回值，jpeg dataURI） */
const MAP = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAZABkAAD/2wCEAAQDAwMDAwQDAwQGBAMEBgcFBAQFBwgHBwcHBwgLCAkJCQkICwsMDAwMDAsNDQ4ODQ0SEhISEhQUFBQUFBQUFBQBBQUFCAgIEAsLEBQODg4UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/CABEIAQABAAMBEQACEQEDEQH/xAAxAAEBAQEBAQAAAAAAAAAAAAADAgQIAQYBAQEBAQEBAQAAAAAAAAAAAAMCBAEACAf/2gAMAwEAAhADEAAAAPjPor6kOgOiKhKgKhKgOhKhOhKxKgKhOgKhKhKgKxOhKhOgKhKhKgKwKhKgKgKwG841nns9J/nn2KVCdCdCVAVCVCVAdCVCdiVAVidCVAVCVAdiVCVCdAVCVCVAVCVAVAViVZxsBrPPY6R/NvsY6E6ErEqAqE6ErAqE6E7E7ErA0ErArAqAqEuiVAXRLol0S6J0JUBWBUI0BXnG88djpH81+xjoToSoSoCoTsSoYQTsTsTQSsCsCsCsCsCoC6A0JeAuiXSLwn0SoioCoCoBsBrPFH0j+a/Yx0J0JUJUJ2BUMIR2MIRoBoJIBXnJAK840BUA0BdAegXhLpF4S8R+IuiVgVANAV546fSH5r9jHRHQFQlYxYnZQgnYwhQokgEgEmckzjecazlYD3OPQHoD0S8JcI/EXiPxF0SoSvONBFF0j+a/YxdI7EqA6KLGEKEKEGFI0AlA0AUzimYbzjecazjWce5w6BdEeCXhPhFwz8R+MuiVgVAdF0j+a/Yp0RUJ0MWUIUWUIUKUIJqBoArnJM4pmBMw3nCsw1mCs4+AegPBLxHwi4Z8KPGXSPojYH0ukfzX7FOiKhiyiylDiylDhBNRNQJAJcwpnBMopmC84XlCswdzj3OPQHwlwS8R8M+HHDPxl0ioDoukfzT7GOhOyiimzmzhDlShBNBNBJc4rmFMwJlBMwXlC82esoVmHucOgXgHxH4j4Zyccg/GfiOiKh6R/NPsY6GLOKObOUObOUI0KEAlEkzimYFygmUEyheXPeULzZ6yhWce5x8BeEuGfCj0HyI5EdM/EdD0h+a/Yx0U0cUflxNnNnCHCCdgSiSZgTMK5c6ZQvLnTLnvJnvKFZgrMHc5dAeiXijhn445E8g/RHTPpdI/mn2KdlFR5RzcTUTZxZwglYGgCmcEzAuUEyZ0y57yZ0yZ7yheUKzh3OPc5dEvEfij0RyI9E+iPGfT6T/NPsQ6OKiKmajy4ijmyOyKwNAFM4JlBMudMmdMue8mdMme8me8wVmGsw0A9A+kfjjxx6J9EememfT6W/MvsMqOamKiamKmKOKM7ErErAUzAmYLyZ0y50yZ0yZkyZ7yBeULzBeYazl0T6R9KPRPYj0T2J9B9Ppj8x+wjo4qY7M9iKmKg6MrIrErALzBeYEyZ0y50yZkyZ7x50yheXPeUbzjWcqA6I+lHYnsT6J7E9iOx0z+YfYBUc1MdmexHZjsHRlRBRDYBecEzZ7yAmXNeTOmTOmPOmXOmULyjeYbzlYnQxRx057E9mexPYij6a/L/r86OOzPpjsR6Y7B9MqIaILDPYZ7zZ0y57y50yZ0x5kyAmXPeUEyjeYUznQnYnRTUTUT2JqJ7EUfTn5d9fFRx2Z9EdmPTHjLsF0h6I2OegzXmzJmzplz3lzJjzpkBMudMoplBM5JnOwOyiimzmomomonsHRdO/l318VFHYj0x6I9McgumXiHpDQ56DPebMmbNebMmXMmQEy50yguQEzCmYkA7GLGEKaObibiaOKOKPp38s+vCsj7EeiPTHIP0Hwx6ReMKDP0M95895syZ815cy5c6ZQTKCZRXMKZiQDQYQYsps5uJs5qIsjounvyz68KyLpx4z9Mcg+GXoLxl4g6IUGes+a8+e82ZM2dMuZMoJmBcwrlJM5IBoMKMoUWc2c3E0cWRUXT/wCV/XQ2R0RdiPQfDPkFwy9BeIOiHQz0Ges+e82dM2ZM2dMwLmBcwpmJc5qBoMIUIUoU2c2cWZ0R0PT/AOV/XQ2RUJdM+wfDL0Hwy5A+EfEHQz0AUGe8+dM2e82dcwJnFcwrnJc5IEKUIMIUoUWc2cWRUJ0PT/5V9dFYjZFRF0z8ZeM+QPDLxD4Q6OfoBQhefPeYEz50ziucUzCoEuclCEKFGUKEKLOLI7E6EqHqD8o+uhsRsisSoi6ZeM+QPiHhj0R8IUIdALALzgmcEzimcVAlzioGomgyhQgwhRZHZFQHQlQ9Qfk/10NiVkNiNiVGXiPxj4x8Q9IfCFCPRCwC84oA3nFQFM5KBKJIMKEIUWRoUUJWJUJ0BUPUH5L9dDZFYigjYjZHRF0x8Q9IvEHRHojQjQhecUAUAkEkziomgGgkoxZGgxZFQFQlYnQHRdPfj/10KCSCKESCNiVkViPSLpD0h6I0Q0I0A2IoBWBIJIBKBIJoJIJ2R2J0JWBUJ0JUB0XTv479dFZDYiglYigkhEgjZFQjRFQjRFQjQigFYigHYigmgEgmglYlYnQlQlYlQHQlQnQ9P/kf1yVkNiNCNkNiVENiNiViNEViNkVCVgKCViViViSCViSCVgdCViVCViVCdgVCVCdD1D+U/XBWQ2I0I2Q2JUQ2I0JWQ0I2JUQ2JUI2JUI2J0JWJWJWA2R0BWJ0I2JUJ2BUJUJ0P//EABkQAQEBAQEBAAAAAAAAAAAAAAECABEDEP/aAAgBAQABAgB1atWrVq1atWrVq1atWrVq1atWrVq1atWrVq+OrVq1atWrVq1atWrVq1atWrVq1atWrVq1atXxVppppppdWrVq1atWrVq1NNNNNNNNNNNPVWmmmmms6tWrVq1atWpppppppppppppp6q0000uc51atWrVq1ammmmmmmmmmmmmt1Vpppc5znVq1atWrVqaaaaaaaaaaaaaeqtNLnOc51atWrVq1ammmmmmmmmmmmmnqrS5znOc6tWrVq16222mmmmmmlVppp6tKuc5znOrVq1a9TbbbbTTTTTSq000qtLnOc5zq1atWrW0222200000qqqtKqrnOc5zq1atTbbbbbbbbTTTSqqqqqq5znOc6tTTTbbbbbbbbTTTSqqqqrlVznOctNNNtttttttttNNNNKqqqrqznKqrTTTTbbbbbbbbbTTTSqqqqrqznOc5aaaabbbbbbbbbaaaaVVVVVdWc5znVq1NNttttttttttNNKqqqqudWc5znVq16tbbbbbbbbbbTTSqqqq5XVnOc6tWrVrb1tttttttttNNKqqqqrWrK5VWmmm2230bbbbbbaaaXOc5zlVa1KuVVppptttt9G22222mmlzlVznK6tWVVWmmmm2222222222mlznOc5znLWppVVWmmm22222229bTWrOc5znOcq1qaaVpWmm222222229erVqznOc5znKtatStK0rTbTTbbbberXr1as5znOc5aVpppppWlabaabbbb1ta9WrVnOc5znU0rTTTTTTTTTbTTbbbTWvVq1as5znOdTTStNNNNNNNNNtNNtttN6tWvVq1ZznOrU00rTTTTTTTTTTTTTbTWvVq1atWrOc6tTTTStNNNNNNNNNNtNNtNa9WrVq1Z1Z1NNNNNK1q1NNNNNNNNNNNtNatWrVq1atWrU00000rWrVq1atWrVq1alaaa1atWrVq1NNNammmmla1atWrVq1aterVq16tWrVnVqa1NK1qaaaVX/xAAWEAADAAAAAAAAAAAAAAAAAAAhgJD/2gAIAQEAAz8AaExf/8QAGhEBAQEBAQEBAAAAAAAAAAAAAQISEQADEP/aAAgBAgEBAgDx48ePHjx48ePHjx48ePHjx48ePHjx48ePHj86IiIiIiInjx48ePHjx48IiIiIj0oooooooooRERER73ve60UUUUUUVrWiiiiiihERERER73ve97ooooorRWiiiiihKERERER73ve973RRRRWtFFFFFFCIiIiIiPe973ve60UUVrRRRRRRQiIlCIiI973ve973pRRWiiiiiiiiiiiiiiihEe973ve973RRWtFFFFFFFFFFFFFFFFFFa13ve973WitaKKKKKKKKKKKKKKKKKK1rWtd1rutFa1oooooooooooosssooorWta1rWta1rRRRRRRRRRRZZZZZZZZZWta1rWta1rRRRRRRRRZZZZZZZZZZZZe9a1rWta1rWitaKLLLLLLLLLLLLLLLLL3rWta1rWtFbLLLLLLLLLLLLLLLLLLLL3vWta1rWita1ssssssss+hZZZZZZZZe961rWta0Vre97LLLLLLLLLLLPoWWWWWXrWta1oorWta3ssss+hZZZZ9Cyyyyyyyyiita1orWta1ve9llllllllllllllllFFa0VorWta1ve9llllllllllllllllllFFFaK1rWta1rWiyyyyyyyyyyyyiiiiiiitFFa1rWta1oosoosssssoooosoooorRRRWta1rWta0UUUUUWUUUUUUUUUUUVoooorWta1rWtaKKKKKKmiiiiiiiiiiiiiiitd73ve61oSiiipoqaKKKKKKKKKK0UUUVrve973vREREZoSihEooooorRRRRWtd73ve9EREREREoSiiiiitFllllla73ve9ERERERESiiiiiitH0PoWWWWVrXe96IiIiMoiJRRRRRRWjwlFFllllFFd6IiIiIlCUUUUUUUUUePHjx48ePCIiIiIiIiUUUUUUUUUUUePHjx48ePHjx48ePHjx48IiUUUUUUJRRRX//xAAWEQADAAAAAAAAAAAAAAAAAAABYJD/2gAIAQIBAz8AtEV7/8QAFxEBAQEBAAAAAAAAAAAAAAAAAAECEP/aAAgBAwEBAgCtNNNNNNNNNNNNNNNNNNNNNNNNNNNNNcrTTTTTTTTTTTTTTTTTTTTTTTTTTTTTXKrTTTTTTTU000000000000000000001FVpppppqampqaaaaaaaaaaaaaaaaaaaa5Vaaaaampqampqammmmmmmmmmmlaaaaaaiq0001NTU1NTU1NTTTTTTTTTTSqqtNNNcqtNNSyzU1LNTU1NTTTTTTTTTSqqq001ytNLLLLNTU1NTU1NTbbbTTTTTSqqq001ytNLLLLLNTU1NTU3NttttNNNNNKqq001KrSyyyyyzU1NTU3Nzc02220000qqqqrSqqyyyyyzU1NTU3Nzc3NttttNNNKqqqqqqssssss1NTU3Nzc3NzbbbbTTTSqqqqqqrLLLLLNTU1Nzc3Nzc22220000qqqqqqqqssss1NTU3Nzc3NzbbbbbTTSqqqqqqqqqqzU1NTc3Nzc3Nzbc22000qqqqqqqqqqqtTU3Nzc3Nzc3NtzbTTSqqqqrKqqqqqtNNzc23Nzc3Nzc3NTU1KqqqrKqqqqqtNNNNttzc3Nzc3NzU1NLLLLLKqqqqqqqq0022223Nzc3NzU1NSyyyyyyqqqqqqqrTTbbbbc3Nzc3NTU1LLLLLLKsqqqqqqrTTTTbbbc3Nzc1NTUsssssssqqqqqqrTTTTTbbbTc3NTU1NTUsssssqqqqqqqq0000222023NTU1NTUsssssqqqqqqqq000000003NTU1NTU1LLLLLNKrTSqqqqtNNNNNNtNNTU1NSzUssss00qq0qqqqrTTTTTTTTTU1NTUs1LLLNNNKrTTTSqqq00000000001NTU1LNTU0000qtNNNKqqqtNNNNNNNNTU1NTUs1NNNNNKss1NNNK00qtK0000001NNTU0s000000qq000001NKrStNNNNK1NNNNStNNNNNKqtNNNNNNNK0000000rU0000rTTTTTSq00000rTTTTTTTTTTTTTTTTStNNNNKr/xAAUEQEAAAAAAAAAAAAAAAAAAACg/9oACAEDAQM/AAAf/9k='

function ensureFilter() {
  if (document.getElementById('lg-glass-filter')) return
  const NS = 'http://www.w3.org/2000/svg'
  const svg = document.createElementNS(NS, 'svg')
  svg.setAttribute('width', '0')
  svg.setAttribute('height', '0')
  svg.style.position = 'absolute'
  const f = document.createElementNS(NS, 'filter')
  f.setAttribute('id', 'lg-glass-filter')
  f.setAttribute('x', '-35%')
  f.setAttribute('y', '-35%')
  f.setAttribute('width', '170%')
  f.setAttribute('height', '170%')
  f.setAttribute('color-interpolation-filters', 'sRGB')
  const s = DISPLACEMENT * SCALE
  f.innerHTML = [
    `<feImage x="0" y="0" width="100%" height="100%" result="DISPLACEMENT_MAP" href="${MAP}" preserveAspectRatio="xMidYMid slice"/>`,
    `<feColorMatrix in="DISPLACEMENT_MAP" type="matrix" values="0.3 0.3 0.3 0 0 0.3 0.3 0.3 0 0 0.3 0.3 0.3 0 0 0 0 0 1 0" result="EDGE_INTENSITY"/>`,
    `<feComponentTransfer in="EDGE_INTENSITY" result="EDGE_MASK"><feFuncA type="discrete" tableValues="0 ${ABERRATION * 0.05} 1"/></feComponentTransfer>`,
    `<feOffset in="SourceGraphic" dx="0" dy="0" result="CENTER_ORIGINAL"/>`,
    `<feDisplacementMap in="SourceGraphic" in2="DISPLACEMENT_MAP" scale="${s}" xChannelSelector="R" yChannelSelector="B" result="RED_DISPLACED"/>`,
    `<feColorMatrix in="RED_DISPLACED" type="matrix" values="1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" result="RED_CHANNEL"/>`,
    `<feDisplacementMap in="SourceGraphic" in2="DISPLACEMENT_MAP" scale="${s - ABERRATION * 0.05}" xChannelSelector="R" yChannelSelector="B" result="GREEN_DISPLACED"/>`,
    `<feColorMatrix in="GREEN_DISPLACED" type="matrix" values="0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 1 0" result="GREEN_CHANNEL"/>`,
    `<feDisplacementMap in="SourceGraphic" in2="DISPLACEMENT_MAP" scale="${s - ABERRATION * 0.1}" xChannelSelector="R" yChannelSelector="B" result="BLUE_DISPLACED"/>`,
    `<feColorMatrix in="BLUE_DISPLACED" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 1 0" result="BLUE_CHANNEL"/>`,
    `<feBlend in="GREEN_CHANNEL" in2="BLUE_CHANNEL" mode="screen" result="GB_COMBINED"/>`,
    `<feBlend in="RED_CHANNEL" in2="GB_COMBINED" mode="screen" result="RGB_COMBINED"/>`,
    `<feGaussianBlur in="RGB_COMBINED" stdDeviation="${Math.max(0.1, 0.5 - ABERRATION * 0.1)}" result="ABERRATED_BLURRED"/>`,
    `<feComposite in="ABERRATED_BLURRED" in2="EDGE_MASK" operator="in" result="EDGE_ABERRATION"/>`,
    `<feComponentTransfer in="EDGE_MASK" result="INVERTED_MASK"><feFuncA type="table" tableValues="1 0"/></feComponentTransfer>`,
    `<feComposite in="CENTER_ORIGINAL" in2="INVERTED_MASK" operator="in" result="CENTER_CLEAN"/>`,
    `<feComposite in="EDGE_ABERRATION" in2="CENTER_CLEAN" operator="over"/>`
  ].join('')
  svg.appendChild(f)
  document.body.appendChild(svg)
}

import { computed, onMounted, watch } from 'vue'
import OfficialGlass from './OfficialGlass.vue'
import { useCosmicStore } from '@/stores/cosmic'
import { perfTier } from '@/utils/perfTier'

/* liquid=true：改挂官方 LiquidGlass 组件（fill 模式跟随宿主铺满），
   位移/色散/模糊全部由官方算法生成。
   只给"浮在壁纸之上"的宿主开启（灵动岛、Dock、顶栏 pill）；
   窗口内部的面板背后是窗口内容而非壁纸，开启会采样到壁纸而穿帮。

   ⚠️ 省电档（data-perf=low，手机 / 小窗）不挂：
   官方算法 = 壁纸克隆（全屏大图）+ 每个面一条 SVG 位移滤镜链
   （feImage + 3×feDisplacementMap + 3×feColorMatrix + 2×feBlend）。
   在 transform: scale(0.3) 的舞台里，这些离屏缓冲按**缩放前**的逻辑尺寸
   分配，Android Chrome 上 9 个面叠起来直接掉到个位数帧。
   省电档统一回落裸 warp：单层 blur + tint + 描边高光，观感差别远小于代价。 */
const props = withDefaults(defineProps<{ liquid?: boolean }>(), { liquid: false })

const store = useCosmicStore()
/** 无玻璃模式：不渲染任何玻璃层，宿主自己用不透明实心底（见 cosmic.css 的 flat 令牌） */
const flat = computed(() => store.settings.glassMode === 'flat')

/** 磨砂档：仍挂官方组件（它自带壁纸克隆，玻璃才有「背后内容」），
 *  只把 feDisplacementMap 色散链换成更强的 backdrop blur（见 cosmic.css 的
 *  html[data-lg='frosted'] 规则）。
 *  ⚠️ 不能像早期那样回落到裸 warp：灵动岛 / Dock 上的宿主自带
 *  transform + isolation，本身就是 backdrop root，裸 warp 的 backdrop-filter
 *  采样不到壁纸 —— 玻璃退化成一块纯色半透明黑板，也就是用户看到的
 *  「黑色透明塑料」。裸 warp 只留给窗口内面板（背后是窗口内容，同 root 可采样）。 */
const glassActive = computed(
  () =>
    props.liquid &&
    store.settings.glassMode !== 'flat' &&
    perfTier.value === 'high'
)

/* data-glass 是三态开关，不是布尔：
   'webgl' → 宿主背景转透明，材质交给玻璃层（液态 / 磨砂）
   'flat'  → 无玻璃：宿主恢复不透明实心底，全站关闭 backdrop 采样
   多个 LgSheet 实例写同一个值，天然一致；切换时由 watch 统一同步。 */
function syncGlassDataset() {
  document.documentElement.dataset.glass = flat.value ? 'flat' : 'webgl'
  document.documentElement.dataset.lg = store.settings.glassMode
}

onMounted(() => {
  syncGlassDataset()
  ensureFilter()
  ensureWarpStyle()
})
watch(flat, syncGlassDataset)
watch(() => store.settings.glassMode, syncGlassDataset)

/* 运行时注入滤镜（不能写进 cosmic.css：lightningcss 构建期会合并/改写声明，
   破坏回退语义）：
   - .lg-warp：纯 blur+saturate，任何内核都保证雾面（此前用户 Edge 上
     "blur+url 整条链被绘制期丢弃 → 玻璃变透明塑料"的根治手段）；
   - .lg-warp2：单独承载 url() 位移折射 —— 支持的内核获得边缘折射，
     不支持的内核该层静默无效，绝不拖累下层模糊（双层隔离）。 */
function ensureWarpStyle() {
  if (document.getElementById('lg-warp-style')) return
  const el = document.createElement('style')
  el.id = 'lg-warp-style'
  el.textContent = `
.lg-overlay .lg-warp {
  -webkit-backdrop-filter: blur(7.84px) saturate(140%) brightness(1.12);
  backdrop-filter: blur(7.84px) saturate(140%) brightness(1.12);
}
.lg-overlay .lg-warp2 {
  -webkit-backdrop-filter: url("#lg-glass-filter");
  backdrop-filter: url("#lg-glass-filter");
}`
  document.head.appendChild(el)
}
</script>

<template>
  <!-- 壁纸之上的玻璃面：官方 LiquidGlass 算法（位移 + 色散 + 磨砂）。
       磨砂档也走这里（只关色散），否则灵动岛里采不到壁纸 → 纯色塑料。 -->
  <OfficialGlass v-if="glassActive" fill><slot /></OfficialGlass>
  <!-- 无玻璃：连 warp 层都不建，自己铺一层不透明实心底。
       走这一层而不是依赖宿主背景 —— 有些宿主（中央演示卡）本身没有背景，
       flat 下若只留 slot，文字会直接浮在壁纸上。 -->
  <template v-else-if="flat">
    <div class="lg-flat" aria-hidden="true"></div>
    <slot />
  </template>
  <!-- 纯磨砂：裸 warp，模糊参数与全站一致（窗口内面板 / 全局磨砂模式 / 省电档） -->
  <template v-else>
    <div class="lg-overlay" aria-hidden="true">
      <div class="lg-warp"></div>
      <!-- 第二层只承载 SVG 位移折射：省电档不建这个节点，连规则都不参与匹配 -->
      <div v-if="perfTier === 'high'" class="lg-warp2"></div>
    </div>
    <slot />
  </template>
</template>
