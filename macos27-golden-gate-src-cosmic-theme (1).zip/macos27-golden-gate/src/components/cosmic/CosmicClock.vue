<script setup lang="ts">
/**
 * CosmicClock —— 桌面大时钟 / 灵动岛里的小时钟
 *
 * 单独立出来是为了性能：原来 `now` 挂在 CosmicDesktop 上，每秒 tick 一次就会
 * 让整个桌面（连同所有窗口的 slot）重渲染一遍 —— 开 9 个应用时每秒白白花掉
 * 上百毫秒的样式重算。现在定时器只活在这个小组件里，到点只 patch 两个文本节点。
 *
 * 定位 / 状态类（--behind / --off）留在父组件的 scoped 样式里，
 * 这里只管文字排版。
 */
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'

defineProps<{ mode: 'desk' | 'island' }>()

const sys = useCosmicSystemStore()
const now = ref(new Date())
let timer = 0
const pad = (n: number) => String(n).padStart(2, '0')

const clockText = computed(() => {
  const d = now.value
  const sec = sys.time.showSeconds ? `:${pad(d.getSeconds())}` : ''
  if (sys.time.format === '12h') {
    const h = d.getHours() % 12 || 12
    return `${h}:${pad(d.getMinutes())}${sec} ${d.getHours() < 12 ? 'AM' : 'PM'}`
  }
  return `${pad(d.getHours())}:${pad(d.getMinutes())}${sec}`
})

const dateText = computed(() => {
  const d = now.value
  return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())}`
})

onMounted(() => {
  timer = window.setInterval(() => (now.value = new Date()), 1000)
})
onUnmounted(() => window.clearInterval(timer))
</script>

<template>
  <div v-if="mode === 'desk'" class="desk-clock">
    <b>{{ clockText }}</b>
    <span>{{ dateText }}</span>
  </div>
  <span v-else class="island-clock">{{ clockText }}</span>
</template>

<style scoped>
/* 视觉规格移植自 HighOS_Desktop 的 components/desktop/Clock.tsx
   （原版：text-7xl font-bold tracking-tight + text-lg font-medium tracking-widest） */
.desk-clock {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.desk-clock b {
  font-size: 72px;
  font-weight: 700;
  line-height: 1;
  letter-spacing: -0.025em;
  color: #fff;
  font-variant-numeric: tabular-nums;
  text-shadow: 0 8px 44px rgba(0, 0, 0, 0.5);
}
.desk-clock span {
  margin-top: 8px;
  font-size: 18px;
  font-weight: 500;
  letter-spacing: 0.1em;
  color: rgba(255, 255, 255, 0.8);
  text-shadow: 0 2px 14px rgba(0, 0, 0, 0.45);
}
</style>
