<script setup lang="ts">
/**
 * HighNotification —— 通知条流（v6）
 *
 * 改版要点：
 *   1) 取消「承载通知条的通知框」：容器只是一层透明定位壳；
 *   2) 每条通知独立成一条横向胶囊横幅，自身即一块官方 LiquidGlass 液态玻璃面
 *      （LgSheet liquid），与灵动岛 / Dock / 顶栏 pill 走同一套官方算法；
 *   3) 全中性白玻璃描边 + 白色文字，无绿色装饰；
 *   4) 打开通知时，各条以 stagger 延迟「接连从屏幕左侧滑入」；
 *   5) 容器层级低于应用窗口层，通知条显示时可被应用窗口覆盖；
 *   6) hover 交互（v6 重做）：操作按钮平时**藏在通知条右端背后**（z 轴在玻璃
 *      之下、位置缩进条内 34px，opacity 0 + 模糊 + 缩小）。hover 时通知条整体
 *      向左移开，两个按钮一边从玻璃后面滑出到通知条**右外侧**、一边溶出
 *      （blur→0 / scale→1 / opacity→1，错峰延迟）。按钮不再叠在条内文字上，
 *      所以文字区不需要收窄，右箭头也保持常驻。
 *   7) 「更多 ⋯」不再展开消息详情，改为弹出通知操作菜单：
 *      「通知管理」「屏蔽此类通知」「关闭此通知」，均为可执行动作。
 *
 * 层级：.cd-notif(90) < .cd-windows(100)，通知及其菜单可被应用窗口覆盖。
 */
import { ref, onBeforeUnmount } from 'vue'
import Icon from '@/components/common/Icon.vue'
import LgSheet from '@/components/cosmic/glass/LgSheet.vue'
import { useCosmicStore } from '@/stores/cosmic'

interface Notice {
  id: number
  /** remixicon 类名；留空则用 iconText 渲染字母 */
  icon: string
  iconText?: string
  /** 通知来源，用于「屏蔽此类通知」按来源批量屏蔽 */
  source: string
  title: string
  content: string
  time: string
}

const items = ref<Notice[]>([
  {
    id: 1,
    icon: '',
    iconText: 'H',
    source: 'HighOS',
    title: '欢迎使用 HighOS!',
    content: '欢迎使用激动人心的 HighOS 3.0 概念版！',
    time: '凌晨 3:01'
  },
  {
    id: 2,
    icon: 'ri-chat-3-line',
    source: '信息',
    title: 'Peter Pan',
    content: '[10条] 测试',
    time: '上午 10:15'
  },
  {
    id: 3,
    icon: 'ri-rocket-2-line',
    source: '信息',
    title: '飞虎工作室',
    content: '[999+条] 所以这就是你们的成果？',
    time: '上午 10:35'
  },
  {
    id: 4,
    icon: 'ri-calendar-line',
    source: '日历',
    title: '日历提醒',
    content: '今天是 云海与鲸 的生日。',
    time: '上午 10:50'
  }
])

const store = useCosmicStore()
const expandedId = ref<number | null>(null)
const menuId = ref<number | null>(null)
const toast = ref('')
const blocked = new Set<string>()
let toastTimer: ReturnType<typeof setTimeout> | undefined

function showToast(text: string) {
  toast.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (toast.value = ''), 2400)
}
onBeforeUnmount(() => clearTimeout(toastTimer))

function removeNotice(id: number) {
  items.value = items.value.filter((n) => n.id !== id)
  if (expandedId.value === id) expandedId.value = null
  if (menuId.value === id) menuId.value = null
}

/** 点击整条通知：展开 / 收起该条完整内容（菜单开着时先收菜单） */
function toggleDetail(id: number) {
  if (menuId.value) {
    menuId.value = null
    return
  }
  expandedId.value = expandedId.value === id ? null : id
}

function toggleMenu(id: number) {
  menuId.value = menuId.value === id ? null : id
}

/** 指针离开这一条（含它的操作菜单）时收起菜单，避免菜单悬在半空 */
function onItemLeave(id: number) {
  if (menuId.value === id) menuId.value = null
}

/** 「通知管理」：打开系统设置的「通知」分页，并保持通知条可被窗口覆盖 */
function openManager() {
  menuId.value = null
  store.openWithPayload('settings', { page: 'notifications' })
  showToast('已打开通知管理')
}

/** 「屏蔽此类通知」：按来源批量移除，之后不再显示 */
function blockSource(n: Notice) {
  blocked.add(n.source)
  items.value = items.value.filter((x) => x.source !== n.source)
  menuId.value = null
  showToast(`已屏蔽来自「${n.source}」的通知`)
}

function closeThis(n: Notice) {
  removeNotice(n.id)
  showToast('已关闭此通知')
}
</script>

<template>
  <div class="nt">
    <!-- TransitionGroup：通知条关闭 / 屏蔽时平滑收回（左滑 + 高度塌缩），其余条上移补位 -->
    <TransitionGroup name="nt-list">
    <div
      v-for="(n, i) in items"
      :key="n.id"
      class="nt-item"
      :class="{ 'nt-item--open': expandedId === n.id, 'nt-item--menu': menuId === n.id }"
      :style="{ '--i': i }"
      @mouseleave="onItemLeave(n.id)"
    >
      <!-- 操作按钮组：藏在通知条右端「后面」（z-index 低于玻璃），
           hover 时通知条左移，按钮从玻璃背后滑出到通知条右「外侧」并溶出。
           容器左缘伸进通知条 30px 形成连续的 hover 命中桥，避免鼠标跨过
           通知条右边缘时 :hover 丢失导致回弹。 -->
      <div class="nt-actions">
        <button
          class="nt-act nt-act--more"
          title="更多操作"
          aria-label="更多操作"
          @click.stop="toggleMenu(n.id)"
        >
          <span class="nt-dots" aria-hidden="true"><i></i><i></i><i></i></span>
        </button>
        <button
          class="nt-act nt-act--del"
          title="删除"
          aria-label="删除"
          @click.stop="removeNotice(n.id)"
        >
          <Icon name="ri-close-line" :size="14" color="#f5f7fa" />
        </button>
      </div>

      <!-- 通知条本体：自身即一块官方液态玻璃（fill 模式铺满宿主） -->
      <div class="nt-card" @click="toggleDetail(n.id)">
        <LgSheet liquid />
        <!-- 中性玻璃外壳：单层白描边 + 极淡深色 tint。放在玻璃之上，
             避免被 backdrop-filter 采样进去而把壁纸糊成纯色 -->
        <div class="nt-face" aria-hidden="true" />
        <div class="nt-body">
          <div class="nt-ico">
            <span v-if="n.iconText" class="nt-letter">{{ n.iconText }}</span>
            <Icon v-else :name="n.icon" :size="21" color="#f5f7fa" />
          </div>
          <div class="nt-txt">
            <div class="nt-title">{{ n.title }}</div>
            <div class="nt-sub">{{ n.content }}</div>
            <div v-if="expandedId === n.id" class="nt-detail">
              {{ n.content }}<span class="nt-detail-time">{{ n.time }}</span>
            </div>
          </div>
          <span class="nt-arrow"><Icon name="ri-arrow-right-s-line" :size="21" color="rgba(245,247,250,.6)" /></span>
        </div>
      </div>

      <!-- 「更多」操作菜单：管理类动作，不展示消息内容 -->
      <div v-if="menuId === n.id" class="nt-menu" @click.stop>
        <div class="nt-menu-hd">通知操作</div>
        <button class="nt-menu-item" @click="openManager">
          <Icon name="ri-settings-3-line" :size="16" color="rgba(245,247,250,.86)" />
          <span>通知管理</span>
          <Icon class="nt-menu-chev" name="ri-arrow-right-s-line" :size="16" color="rgba(245,247,250,.5)" />
        </button>
        <button class="nt-menu-item" @click="blockSource(n)">
          <Icon name="ri-notification-off-line" :size="16" color="rgba(245,247,250,.86)" />
          <span>屏蔽此类通知</span>
        </button>
        <div class="nt-menu-sep" />
        <button class="nt-menu-item" @click="closeThis(n)">
          <Icon name="ri-close-circle-line" :size="16" color="rgba(245,247,250,.7)" />
          <span>关闭此通知</span>
        </button>
      </div>
    </div>
    </TransitionGroup>

    <div v-if="items.length === 0" class="nt-empty">暂无通知</div>

    <Transition name="nt-toast">
      <div v-if="toast" :key="toast" class="nt-toast">{{ toast }}</div>
    </Transition>
  </div>
</template>

<style scoped>
.nt {
  position: relative;
  display: flex;
  flex-direction: column;
  /* 间距放在 .nt-item 的 margin-bottom 上：收回动画时可以一起塌缩到 0 */
  pointer-events: none;
}

/* ── 通知条收回动画：左滑溶出 + 高度塌缩，其余条平滑上移补位 ── */
.nt-list-leave-active {
  transition:
    opacity 0.32s ease,
    transform 0.32s cubic-bezier(0.4, 0, 0.2, 1),
    max-height 0.32s cubic-bezier(0.4, 0, 0.2, 1),
    min-height 0.32s cubic-bezier(0.4, 0, 0.2, 1),
    margin-bottom 0.32s ease;
  max-height: 220px;
  overflow: hidden;
}
.nt-list-leave-to {
  opacity: 0;
  transform: translateX(-64px) scale(0.94);
  max-height: 0;
  min-height: 0;
  margin-bottom: 0;
}
/* 被移除条的下一条平滑上移 */
.nt-list-move {
  transition: transform 0.32s cubic-bezier(0.22, 1, 0.36, 1);
}

/* ── 单条通知的外壳：只做定位、入场动画与 hover 判定 ──
   不画任何框，也不承载玻璃；玻璃在内部的 .nt-card 上。
   z-index 逐条递增：打开操作菜单的那一条要能盖住它下面相邻的通知条。 */
.nt-item {
  position: relative;
  z-index: 1;
  width: 384px;
  min-height: 76px;
  margin-bottom: 12px;
  isolation: isolate;
  pointer-events: auto;
  /* 接连从屏幕左侧滑入：用独立的 translate / scale 属性做入场，
     不占用 transform，避免与 .nt-card 的 hover 位移打架。
     backwards：delay 期间保持 from 态，动画结束后不残留 transform context。 */
  animation: nt-in 0.5s cubic-bezier(0.22, 1, 0.36, 1) backwards;
  animation-delay: calc(var(--i) * 175ms);
}
.nt-item--menu {
  z-index: 20;
}
@keyframes nt-in {
  from { opacity: 0; translate: calc(-100% - 48px) 0; scale: 0.94; }
  to   { opacity: 1; translate: 0 0; scale: 1; }
}

/* ── 通知条本体（官方液态玻璃宿主）──
   hover 时整条向左移开，把右端背后藏着的操作按钮让出来。 */
.nt-card {
  position: relative;
  z-index: 2;
  width: 100%;
  min-height: 76px;
  border-radius: 38px;
  cursor: pointer;
  isolation: isolate;
  transition: transform 0.3s cubic-bezier(0.22, 1, 0.36, 1);
}
.nt-item:hover .nt-card,
.nt-item--menu .nt-card {
  transform: translateX(-18px);
}

/* 官方 sheen 层自带 0.5px 白色 inset 描边环；本组件还要画一圈中性玻璃描边，
   两层叠一起会变成「内外双框」。这里只中和那个白色环，
   保留 sheen 的渐变高光与投影（液态玻璃质感仍在）。 */
.nt-card :deep(span[data-og-sheen]) {
  box-shadow:
    inset 0 1px 3px rgba(255, 255, 255, 0.22),
    0 1px 4px rgba(0, 0, 0, 0.35) !important;
}

/* ── 外壳：唯一一层中性白描边 + 极淡深色 tint ── */
.nt-face {
  position: absolute;
  inset: 0;
  z-index: 2;
  border-radius: inherit;
  pointer-events: none;
  background: rgba(20, 22, 26, 0.14);
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.32),
    0 14px 34px rgba(0, 0, 0, 0.34);
}

.nt-body {
  position: relative;
  z-index: 3;
  display: flex;
  align-items: center;
  gap: 14px;
  min-height: 76px;
  padding: 0 24px 0 22px;
}
.nt-ico {
  width: 44px;
  height: 44px;
  flex: none;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: rgba(255, 255, 255, 0.16);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.28), 0 3px 10px rgba(0, 0, 0, 0.3);
}
.nt-letter {
  font-size: 20px;
  font-weight: 700;
  color: #f5f7fa;
}
.nt-txt {
  flex: 1;
  min-width: 0;
}
.nt-title {
  font-size: 15px;
  font-weight: 600;
  line-height: 1.3;
  color: rgba(255, 255, 255, 0.96);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.nt-sub {
  margin-top: 3px;
  font-size: 12px;
  line-height: 1.35;
  color: rgba(255, 255, 255, 0.62);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.nt-detail {
  margin-top: 10px;
  padding-top: 9px;
  font-size: 12px;
  line-height: 1.5;
  color: rgba(255, 255, 255, 0.86);
  border-top: 1px solid rgba(255, 255, 255, 0.16);
  display: flex;
  justify-content: space-between;
  gap: 12px;
}
.nt-detail-time {
  flex: none;
  color: rgba(255, 255, 255, 0.5);
}

/* 常驻右箭头：按钮在外面，不再需要淡出让位 */
.nt-arrow {
  flex: none;
  display: grid;
  place-items: center;
  opacity: 0.85;
  transition: transform 0.25s ease;
}
.nt-item--open .nt-arrow {
  transform: rotate(90deg);
}

/* ── 藏在通知条「后面」、溶出到「外面」的两个操作按钮 ──
   容器：left 从通知条右端往里 30px 起（连续 hover 桥），
   padding-left 30px 让按钮实际从 100%（通知条右边缘）开始排。
   z-index 1 < .nt-card 的 2 → 按钮确实在玻璃后面。
   按钮默认缩进 34px 藏进条内 + 溶解态；hover 时归位到条外并澄清。 */
.nt-actions {
  position: absolute;
  top: 0;
  height: 76px;
  left: calc(100% - 30px);
  padding-left: 30px;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: 8px;
  pointer-events: auto;
}
.nt-act {
  width: 32px;
  height: 32px;
  flex: none;
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  /* 刻意不加 backdrop-filter：整条通知已是官方液态玻璃，再给两个小按钮
     各起一层 backdrop 会显著拖慢合成，hover 首帧出现可感知的迟滞。 */
  background: rgba(255, 255, 255, 0.2);
  color: #f5f7fa;
  display: grid;
  place-items: center;
  cursor: pointer;
  /* 溶入态：缩进藏在通知条背后 */
  opacity: 0;
  scale: 0.45;
  filter: blur(5px);
  translate: -34px 0;
  pointer-events: none;
  transition:
    opacity 0.26s ease,
    scale 0.34s cubic-bezier(0.22, 1, 0.36, 1),
    filter 0.26s ease,
    translate 0.34s cubic-bezier(0.22, 1, 0.36, 1),
    background 0.18s ease;
}
.nt-item:hover .nt-act,
.nt-item--menu .nt-act,
.nt-item:focus-within .nt-act {
  opacity: 1;
  scale: 1;
  filter: blur(0);
  translate: 0 0;
  pointer-events: auto;
}
/* 错峰：靠左的「更多」先从玻璃后溶出，靠右的「删除」随后 */
.nt-item:hover .nt-act--more,
.nt-item--menu .nt-act--more,
.nt-item:focus-within .nt-act--more {
  transition-delay: 20ms;
}
.nt-item:hover .nt-act--del,
.nt-item--menu .nt-act--del,
.nt-item:focus-within .nt-act--del {
  transition-delay: 90ms;
}
.nt-act:hover {
  background: rgba(255, 255, 255, 0.3);
}
.nt-act:focus-visible {
  outline: 2px solid rgba(255, 255, 255, 0.7);
  outline-offset: 2px;
}
.nt-dots {
  display: flex;
  align-items: center;
  gap: 3px;
}
.nt-dots i {
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: currentColor;
}

/* ── 「更多」通知操作菜单 ──
   锚点：溶出后的「更多」按钮在通知条右边缘外侧（.nt-actions 内容起点 = 100%）。
   菜单从按钮下方贴着弹出、整体落在通知条右侧外面，不会掉到条下方，
   也不会压住下一条通知（.nt-item--menu 抬高层级）。
   小浮层用纯 CSS 磨砂 + 中性白描边：不额外挂官方位移滤镜链，
   避免与通知条的官方玻璃叠加造成首帧迟滞；配色与全站一致（无绿）。 */
.nt-menu {
  position: absolute;
  top: 58px;
  left: calc(100% + 4px);
  width: 208px;
  z-index: 30;
  padding: 6px;
  border-radius: 16px;
  background: rgba(24, 26, 31, 0.8);
  -webkit-backdrop-filter: blur(22px) saturate(140%);
  backdrop-filter: blur(22px) saturate(140%);
  border: 1px solid rgba(255, 255, 255, 0.22);
  box-shadow:
    0 18px 40px rgba(0, 0, 0, 0.5),
    inset 0 1px 0 rgba(255, 255, 255, 0.12);
  pointer-events: auto;
  transform-origin: top left;
  animation: nt-menu-in 0.2s cubic-bezier(0.22, 1, 0.36, 1) both;
}
@keyframes nt-menu-in {
  from { opacity: 0; translate: 0 -8px; scale: 0.96; }
  to   { opacity: 1; translate: 0 0; scale: 1; }
}
.nt-menu-hd {
  padding: 6px 10px 8px;
  font-size: 11px;
  letter-spacing: 0.04em;
  color: rgba(255, 255, 255, 0.45);
}
.nt-menu-item {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 10px;
  border-radius: 10px;
  font-size: 13px;
  line-height: 1.2;
  text-align: left;
  color: rgba(255, 255, 255, 0.92);
  transition: background 0.15s ease;
}
.nt-menu-item:hover {
  background: rgba(255, 255, 255, 0.12);
}
.nt-menu-item:focus-visible {
  outline: 1px solid rgba(255, 255, 255, 0.6);
  outline-offset: -1px;
}
.nt-menu-chev {
  margin-left: auto;
  opacity: 0.55;
}
.nt-menu-sep {
  height: 1px;
  margin: 5px 8px;
  background: rgba(255, 255, 255, 0.14);
}

/* 动作反馈：不占布局，浮在通知流下方 */
.nt-toast {
  position: absolute;
  top: calc(100% + 12px);
  left: 0;
  z-index: 40;
  padding: 8px 16px;
  border-radius: 999px;
  font-size: 12px;
  white-space: nowrap;
  color: rgba(255, 255, 255, 0.92);
  background: rgba(24, 26, 31, 0.82);
  -webkit-backdrop-filter: blur(18px) saturate(140%);
  backdrop-filter: blur(18px) saturate(140%);
  border: 1px solid rgba(255, 255, 255, 0.22);
  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.4);
  pointer-events: none;
}
.nt-toast-enter-active,
.nt-toast-leave-active {
  transition: opacity 0.2s ease, translate 0.2s ease;
}
.nt-toast-enter-from,
.nt-toast-leave-to {
  opacity: 0;
  translate: 0 -6px;
}

.nt-empty {
  width: 384px;
  padding: 18px 0;
  text-align: center;
  font-size: 13px;
  color: rgba(255, 255, 255, 0.6);
  pointer-events: auto;
}
</style>
