<script setup lang="ts">
/**
 * HighControlCenter —— 控制中心（本地化改造版 · 第三期）
 *
 * 本地化改造四条原则见上版注释。本版交互重排：
 *   · 顶部只保留一条状态条（电池 + 外观 + 全屏），由原底部上移；
 *     原顶部的「电源与电池 / 显示与亮度」两个入口已删除。
 *   · 四大件 2×2：Wi‑Fi / 蓝牙 / 数据接力 / 电源模式。
 *     隔空投送 → 数据接力（点开是分享·通信子菜单）；专注模式在快捷开关；
 *     电源模式点开是三档子菜单（省电 / 均衡 / 高性能）。
 *   · 数据接力子菜单合并「分享 + 通信」：网络分享 / 无线投屏 / 手机互联 / 通话接力
 *     （手机互联、通话接力不再单独占网格位）。
 *   · 快捷开关 3×2：飞行模式 / 专注模式 / 深色模式 / 网络分享↓ / 无线投屏↓。
 *   · 四大件「按下」只染图标：卡片本体保持中性，仅图标圆底取皮肤强调蓝。
 */
import { computed, ref } from 'vue'
import Icon from '@/components/common/Icon.vue'
import LgSheet from '@/components/cosmic/glass/LgSheet.vue'
import { useSystemStore } from '@/stores/system'
import { useCosmicStore } from '@/stores/cosmic'

const emit = defineEmits<{ (e: 'close'): void }>()
const sys = useSystemStore()
const cosmic = useCosmicStore()

/* ═════ 四大件：2×2 连接与接力 ═════ */
/* 数据接力子菜单里的「分享 + 通信」聚合项：网络分享 / 无线投屏 / 手机互联 / 通话接力。
   这些本地 flag 同时被快捷开关里的网络分享·无线投屏读取，子菜单与网格双向同步。 */
const localFlags = ref<Record<string, boolean>>({
  airplane: false, hotspot: false, project: false, phone: false, call: false
})
function flip(id: string) { localFlags.value[id] = !localFlags.value[id] }

const relayItems = computed(() => [
  { id: 'hotspot', label: '网络分享', icon: 'ri-share-line', on: localFlags.value.hotspot, toggle: () => flip('hotspot') },
  { id: 'project', label: '无线投屏', icon: 'ri-computer-line', on: localFlags.value.project, toggle: () => flip('project') },
  { id: 'phone', label: '手机互联', icon: 'ri-smartphone-line', on: localFlags.value.phone, toggle: () => flip('phone') },
  { id: 'call', label: '通话接力', icon: 'ri-phone-line', on: localFlags.value.call, toggle: () => flip('call') }
])
const relayOn = computed(() => relayItems.value.some((x) => x.on))
const relayOpen = ref(false)

/* 电源模式：三档，本地状态（系统暂无对应字段）；点开是子菜单 */
type PowerLevel = 'low' | 'balance' | 'high'
const powerMode = ref<PowerLevel>('balance')
const powerOpen = ref(false)
function powerLabel(): string {
  return powerLevels.find((l) => l.id === powerMode.value)?.label ?? ''
}
const powerItems = computed(() =>
  powerLevels.map((lv) => ({
    ...lv,
    on: powerMode.value === lv.id,
    select: () => { powerMode.value = lv.id }
  }))
)

/* 电源模式档位定义 */
const powerLevels: { id: PowerLevel; label: string }[] = [
  { id: 'low', label: '省电' },
  { id: 'balance', label: '均衡' },
  { id: 'high', label: '高性能' }
]

/* 四大件卡片：Wi‑Fi / 蓝牙 / 数据接力 / 电源模式 */
const cards = computed(() => [
  {
    id: 'wifi', label: 'Wi‑Fi', icon: 'ri-wifi-line',
    on: sys.settings.wifiEnabled,
    hint: sys.settings.wifiEnabled ? '已连接 · 5G' : '已关闭',
    toggle: () => sys.toggle('wifiEnabled')
  },
  {
    id: 'bluetooth', label: '蓝牙', icon: 'ri-bluetooth-line',
    on: sys.settings.bluetoothEnabled,
    hint: sys.settings.bluetoothEnabled ? '已开启 · 2 台' : '已关闭',
    toggle: () => sys.toggle('bluetoothEnabled')
  },
  {
    id: 'relay', label: '数据接力', icon: 'ri-global-line',
    on: relayOn.value, submenu: 'relay'
  },
  {
    id: 'power', label: '电源模式', icon: 'ri-battery-charge-line',
    hint: powerLabel(), submenu: 'power'
  }
])

/* ═════ 快捷开关：3×2 圆形钮 ═════ */
/* 专注模式：从四大件下移到这里（落网络分享·无线投屏原处）。
   网络分享 / 无线投屏：保留为快捷钮但下移到第二排；手机互联 / 通话接力已并入数据接力子菜单。 */
const extras = computed(() => [
  { id: 'airplane', label: '飞行模式', icon: 'ri-flight-takeoff-line', active: localFlags.value.airplane, toggle: () => flip('airplane') },
  { id: 'focus', label: '专注模式', icon: 'ri-moon-foggy-line', active: sys.settings.focusEnabled, toggle: () => sys.toggle('focusEnabled') },
  { id: 'dark', label: '深色模式', icon: 'ri-moon-line', active: sys.settings.darkMode, toggle: () => sys.toggleDarkMode() },
  { id: 'hotspot', label: '网络分享', icon: 'ri-share-line', active: localFlags.value.hotspot, toggle: () => flip('hotspot') },
  { id: 'project', label: '无线投屏', icon: 'ri-computer-line', active: localFlags.value.project, toggle: () => flip('project') }
])

/* ═════ 亮度 / 音量：0~100 ↔ store 的 0~1 ═════ */
const brightness = computed({
  get: () => Math.round(sys.settings.brightness * 100),
  set: (v: number) => sys.setBrightness(v / 100)
})
const volume = computed({
  get: () => Math.round(sys.settings.volume * 100),
  set: (v: number) => sys.setVolume(v / 100)
})
function trackStyle(value: number) {
  return {
    background: `linear-gradient(to right, var(--ih-accent, #8ab4f8) 0%, var(--ih-accent, #8ab4f8) ${value}%, var(--ih-card, rgba(255,255,255,.08)) ${value}%, var(--ih-card, rgba(255,255,255,.08)) 100%)`
  }
}

/* 任一子菜单是否展开（用于背景点击回退 + 压退态） */
const anySub = computed(() => relayOpen.value || powerOpen.value)
/* 点击子菜单之外的暗化父面板区域 → 直接回退（无需每个组件都带关闭按钮） */
function closeSub() { relayOpen.value = false; powerOpen.value = false }

/* ═════ 交互 ═════ */
function onCard(c: (typeof cards.value)[number]) {
  if (c.submenu === 'relay') { relayOpen.value = true; return }
  if (c.submenu === 'power') { powerOpen.value = true; return }
  if (c.toggle) c.toggle()
}
function openSettings(page: string) {
  cosmic.closePanels()
  cosmic.openWithPayload('settings', { page })
}
async function toggleFullscreen() {
  try {
    if (document.fullscreenElement) await document.exitFullscreen()
    else await document.documentElement.requestFullscreen()
  } catch { /* 无权限 / 内嵌环境：静默 */ }
}
</script>

<template>
  <section class="hc lg-host">
    <!-- 与灵动岛 / 顶栏 pill / Dock 同一块官方液态玻璃 -->
    <LgSheet liquid />
    <!-- 皮肤色相层 -->
    <div class="hc-tone" aria-hidden="true" />
    <!-- 可读性衬底 -->
    <div class="hc-tint" aria-hidden="true" />

    <div class="hc-inner" :class="{ 'hc-recede': relayOpen || powerOpen }">
      <!-- 顶部状态条：原底部电池 / 外观 / 全屏上移 -->
      <header class="hc-top">
        <div class="hc-battery">
          <Icon name="ri-battery-line" :size="17" color="var(--ih-accent, #8ab4f8)" />
          <b>25%</b><i>电池 · 约剩余 2 小时</i>
        </div>
        <div class="hc-foot-btns">
          <button class="hc-icon-btn" title="外观设置" @click="openSettings('appearance')">
            <Icon name="ri-settings-3-line" :size="15" color="currentColor" />
          </button>
          <button class="hc-icon-btn" title="全屏" @click="toggleFullscreen">
            <Icon name="ri-fullscreen-line" :size="15" color="currentColor" />
          </button>
        </div>
      </header>

      <!-- 连接与接力 -->
      <div class="hc-label">连接与接力</div>
      <div class="hc-cards">
        <button
          v-for="c in cards"
          :key="c.id"
          class="hc-card"
          :class="{ 'hc-card--on': c.on }"
          :title="c.label"
          @click="onCard(c)"
        >
          <span class="hc-card-ico"><Icon :name="c.icon" :size="18" color="currentColor" /></span>
          <span class="hc-card-txt"><b>{{ c.label }}</b><i v-if="c.hint">{{ c.hint }}</i></span>
          <span v-if="c.submenu" class="hc-card-chev"><Icon name="ri-arrow-right-s-line" :size="16" color="currentColor" /></span>
        </button>
      </div>

      <!-- 快捷开关 -->
      <div class="hc-label">快捷开关</div>
      <div class="hc-extras">
        <button
          v-for="x in extras"
          :key="x.id"
          class="hc-extra"
          :class="{ 'hc-extra--on': x.active }"
          :title="x.label"
          @click="x.toggle()"
        >
          <span class="hc-extra-ico"><Icon :name="x.icon" :size="17" color="currentColor" /></span>
          <span class="hc-extra-label">{{ x.label }}</span>
        </button>
      </div>

      <!-- 亮度 / 音量 -->
      <div class="hc-slider">
        <span class="hc-slider-ico"><Icon name="ri-sun-line" :size="16" color="currentColor" /></span>
        <input v-model.number="brightness" class="hc-range" type="range" min="0" max="100" title="亮度" :style="trackStyle(brightness)" />
        <span class="hc-slider-val">{{ brightness }}%</span>
      </div>
      <div class="hc-slider">
        <span class="hc-slider-ico"><Icon name="ri-volume-up-line" :size="16" color="currentColor" /></span>
        <input v-model.number="volume" class="hc-range" type="range" min="0" max="100" title="音量" :style="trackStyle(volume)" />
        <span class="hc-slider-val">{{ volume }}%</span>
      </div>
    </div>

    <!-- 点击子菜单之外的暗化父面板区域 → 直接回退 -->
    <transition name="hc-fade">
      <div v-if="anySub" class="hc-sub-back" aria-hidden="true" @click="closeSub" />
    </transition>

    <!-- 数据接力子菜单：分享 + 通信 -->
    <transition name="hc-sub">
      <div v-if="relayOpen" class="hc-sub">
        <header class="hc-sub-head">
          <b>数据接力</b>
        </header>
        <div class="hc-sub-list">
          <button
            v-for="it in relayItems"
            :key="it.id"
            class="hc-sub-row"
            :class="{ 'hc-sub-row--on': it.on }"
            @click="it.toggle()"
          >
            <span class="hc-card-ico"><Icon :name="it.icon" :size="17" color="currentColor" /></span>
            <span class="hc-sub-label">{{ it.label }}</span>
            <span class="hc-sub-switch" :class="{ on: it.on }"><i /></span>
          </button>
        </div>
      </div>
    </transition>

    <!-- 电源模式子菜单：三档 -->
    <transition name="hc-sub">
      <div v-if="powerOpen" class="hc-sub">
        <header class="hc-sub-head">
          <b>电源模式</b>
        </header>
        <div class="hc-sub-list">
          <button
            v-for="it in powerItems"
            :key="it.id"
            class="hc-sub-row"
            :class="{ 'hc-sub-row--on': it.on }"
            @click="it.select()"
          >
            <span class="hc-card-ico"><Icon name="ri-battery-charge-line" :size="17" color="currentColor" /></span>
            <span class="hc-sub-label">{{ it.label }}</span>
            <span v-if="it.on" class="hc-sub-check"><Icon name="ri-check-line" :size="15" color="currentColor" /></span>
          </button>
        </div>
      </div>
    </transition>
  </section>
</template>

<style scoped>
.hc {
  position: relative;
  width: 340px;
  padding: 18px;
  border-radius: 32px;
  border: 1px solid var(--ih-shell-line, rgba(255, 255, 255, 0.09));
  background: var(--ih-shell-glass, rgba(8, 8, 10, 0.12));
  color: #fff;
  box-shadow: var(--ih-shadow, 0 24px 70px rgba(0, 0, 0, 0.62));
  font: inherit;
  --hc-on: color-mix(in srgb, var(--ih-accent, #8ab4f8) 72%, #06070a);
}
.hc-tone {
  position: absolute; inset: 0;
  border-radius: inherit;
  background: var(--ih-shell-tint, transparent);
  mix-blend-mode: color;
  pointer-events: none;
  z-index: 0;
}
.hc-tint {
  position: absolute; inset: 0;
  border-radius: inherit;
  background: linear-gradient(180deg,
    color-mix(in srgb, var(--ih-bg, #0d0f13) 22%, transparent) 0%,
    color-mix(in srgb, var(--ih-bg, #0d0f13) 50%, transparent) 100%);
  pointer-events: none;
  z-index: 0;
}
.hc-inner { position: relative; z-index: 1; display: flex; flex-direction: column; gap: 10px; transition: opacity 0.24s ease, filter 0.24s ease, transform 0.24s ease; }
/* 子菜单展开时父面板压退：可见但后退一层（参考图的做法） */
.hc-recede { opacity: 0.55; filter: blur(3px) saturate(0.95); transform: scale(0.985); pointer-events: none; }

/* ── 顶部状态条（原底部上移） ── */
.hc-top {
  display: flex; align-items: center; justify-content: space-between;
  padding: 2px 2px 4px;
}

/* ── 分区标题 ── */
.hc-label {
  font-size: 10px; letter-spacing: 0.06em;
  color: rgba(255, 255, 255, .52);
  padding: 2px 2px 0;
}

/* ── 2×2 连接大卡（四大件） ── */
.hc-cards { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; align-items: stretch; }
.hc-card {
  display: flex; align-items: center; gap: 9px;
  min-width: 0; height: 60px; padding: 0 10px;
  border: 1px solid var(--ih-line, rgba(255,255,255,.09));
  border-radius: 18px;
  background: var(--ih-card, rgba(255,255,255,.055));
  color: #fff;
  font: inherit; text-align: left; cursor: pointer;
  transition: background 0.2s ease, border-color 0.2s ease, transform 0.2s ease;
}
.hc-card:hover { background: var(--ih-card-hover, rgba(255,255,255,.1)); transform: translateY(-1px); }
.hc-card-ico {
  width: 32px; height: 32px; flex: none;
  border-radius: 999px;
  display: inline-flex; align-items: center; justify-content: center;
  background: var(--ih-card-hover, rgba(255,255,255,.1));
  color: rgba(255, 255, 255, .72);
  transition: background 0.2s ease, color 0.2s ease;
}
.hc-card-txt { display: flex; flex-direction: column; gap: 3px; min-width: 0; flex: 1; }
.hc-card-txt b { font-size: 12px; font-weight: 600; line-height: 1.1; }
.hc-card-txt i { font-size: 9.5px; font-style: normal; color: rgba(255, 255, 255, .52); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 96px; }
.hc-card-chev { color: rgba(255,255,255,.4); flex: none; }

/* 四大件「按下」只染图标：卡片本体保持中性，仅图标圆底取强调蓝 */
.hc-card--on { background: var(--ih-card, rgba(255,255,255,.055)); border-color: var(--ih-line, rgba(255,255,255,.09)); }
.hc-card--on .hc-card-ico { background: var(--ih-accent, #8ab4f8); color: #fff; }
.hc-card--on .hc-card-txt b { color: #fff; }
.hc-card--on .hc-card-txt i { color: rgba(255,255,255,.78); }
.hc-card--on:hover { background: var(--ih-card-hover, rgba(255,255,255,.1)); }

/* ── 3×2 圆形快捷钮 ── */
.hc-extras { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
.hc-extra {
  display: flex; flex-direction: column; align-items: center; gap: 5px;
  padding: 6px 2px 5px;
  border: none; border-radius: 16px;
  background: transparent; color: inherit; font: inherit; cursor: pointer;
  transition: background 0.18s ease;
}
.hc-extra:hover { background: var(--ih-card, rgba(255,255,255,.055)); }
.hc-extra-ico {
  width: 40px; height: 40px;
  border-radius: 999px;
  display: inline-flex; align-items: center; justify-content: center;
  background: var(--ih-card, rgba(255,255,255,.055));
  border: 1px solid var(--ih-line, rgba(255,255,255,.09));
  color: rgba(255, 255, 255, .72);
  transition: background 0.2s ease, color 0.2s ease, transform 0.2s ease, border-color 0.2s ease;
}
.hc-extra:hover .hc-extra-ico { transform: scale(1.06); }
.hc-extra-label { font-size: 10px; color: rgba(255, 255, 255, .52); white-space: nowrap; }
.hc-extra--on .hc-extra-ico {
  background: var(--hc-on); border-color: transparent; color: #fff;
  box-shadow: 0 6px 16px color-mix(in srgb, var(--ih-accent, #8ab4f8) 34%, transparent);
}
.hc-extra--on .hc-extra-label { color: #fff; }

/* ── 亮度 / 音量 ── */
.hc-slider { display: flex; align-items: center; gap: 10px; padding: 0 2px; }
.hc-slider-ico {
  width: 28px; height: 28px; flex: none;
  border-radius: 999px;
  display: inline-flex; align-items: center; justify-content: center;
  background: var(--ih-card, rgba(255,255,255,.055));
  color: rgba(255, 255, 255, .72);
}
.hc-range {
  flex: 1; height: 8px; border-radius: 999px;
  appearance: none; -webkit-appearance: none; outline: none; cursor: pointer;
}
.hc-range::-webkit-slider-thumb {
  appearance: none; -webkit-appearance: none;
  width: 16px; height: 16px; border-radius: 50%;
  background: #fff; border: none;
  box-shadow: 0 2px 8px rgba(0,0,0,.45);
  cursor: pointer;
}
.hc-range::-moz-range-thumb {
  width: 16px; height: 16px; border-radius: 50%;
  background: #fff; border: none;
  box-shadow: 0 2px 8px rgba(0,0,0,.45);
  cursor: pointer;
}
.hc-slider-val { width: 34px; flex: none; text-align: right; font-size: 11px; font-variant-numeric: tabular-nums; color: rgba(255, 255, 255, .72); }

/* ── 底部状态条已上移为顶部；此处不再需要 ── */

/* ── 子菜单选中勾 ── */
.hc-sub-check {
  width: 20px; height: 20px; flex: none;
  display: inline-flex; align-items: center; justify-content: center;
  border-radius: 999px;
  background: var(--ih-accent, #8ab4f8); color: #fff;
}
.hc-battery { display: flex; align-items: center; gap: 7px; }
.hc-battery b { font-size: 12px; font-weight: 600; }
.hc-battery i { font-size: 10px; font-style: normal; color: rgba(255, 255, 255, .52); }
.hc-foot-btns { display: flex; gap: 6px; }

/* ── 圆形图标按钮（返回 / 外观 / 全屏） ── */
.hc-icon-btn {
  width: 26px; height: 26px; flex: none;
  display: inline-flex; align-items: center; justify-content: center;
  border: 1px solid var(--ih-line, rgba(255,255,255,.09));
  border-radius: 999px;
  background: var(--ih-card, rgba(255,255,255,.055));
  color: rgba(255, 255, 255, .72);
  cursor: pointer;
  transition: background 0.18s ease, color 0.18s ease, transform 0.18s ease;
}
.hc-icon-btn:hover { background: var(--ih-card-hover, rgba(255,255,255,.1)); color: #fff; transform: scale(1.06); }

/* ── 子菜单：中部局部卡片（参考图做法） ──
   不再整块铺满，而是叠在面板中部的一张卡片；父面板在后面压退可见。
   进出场：从上往下弹出（参考图），非侧滑。 */
.hc-sub {
  position: absolute; z-index: 2;
  left: 12px; right: 12px; top: 60px; bottom: auto;
  border-radius: 26px;
  display: flex; flex-direction: column; gap: 8px;
  padding: 16px;
  background: color-mix(in srgb, var(--ih-bg, #0d0f13) 22%, var(--ih-shell-glass, rgba(8,8,10,.42)));
  border: 1px solid var(--ih-shell-line, rgba(255,255,255,.14));
  box-shadow: 0 24px 60px rgba(0,0,0,.5);
  backdrop-filter: blur(26px) saturate(150%);
}
.hc-sub-head { display: flex; align-items: center; gap: 10px; padding: 0 0 4px; }
.hc-sub-head b { font-size: 14px; font-weight: 600; flex: 1; }
.hc-sub-list { display: flex; flex-direction: column; gap: 6px; margin-top: 2px; }
.hc-sub-row {
  display: flex; align-items: center; gap: 10px;
  height: 44px; padding: 0 12px;
  border: 1px solid var(--ih-line, rgba(255,255,255,.09));
  border-radius: 14px;
  background: var(--ih-card, rgba(255,255,255,.055));
  color: #fff; font: inherit; cursor: pointer;
  transition: background 0.18s ease;
}
.hc-sub-row:hover { background: var(--ih-card-hover, rgba(255,255,255,.1)); }
.hc-sub-label { flex: 1; text-align: left; font-size: 12px; font-weight: 500; }
/* 子菜单开关：iOS 风格胶囊 */
.hc-sub-switch {
  width: 38px; height: 22px; border-radius: 999px; flex: none;
  background: rgba(255,255,255,.18); position: relative;
  transition: background 0.2s ease;
}
.hc-sub-switch i {
  position: absolute; top: 2px; left: 2px;
  width: 18px; height: 18px; border-radius: 50%;
  background: #fff; transition: transform 0.2s ease;
}
.hc-sub-switch.on { background: var(--ih-accent, #8ab4f8); }
.hc-sub-switch.on i { transform: translateX(16px); }

/* 子菜单背景点击层（点此直接回退，无需关闭按钮） */
.hc-sub-back {
  position: absolute; inset: 0; z-index: 1;
  border-radius: inherit; cursor: default;
}
/* 子菜单进出场：从上往下弹出（参考图），非侧滑 */
.hc-sub-enter-active, .hc-sub-leave-active { transition: opacity 0.24s ease, transform 0.24s cubic-bezier(.2,.8,.2,1); }
.hc-sub-enter-from, .hc-sub-leave-to { opacity: 0; transform: translateY(-14px); }
.hc-fade-enter-active, .hc-fade-leave-active { transition: opacity 0.24s ease; }
.hc-fade-enter-from, .hc-fade-leave-to { opacity: 0; }
</style>
