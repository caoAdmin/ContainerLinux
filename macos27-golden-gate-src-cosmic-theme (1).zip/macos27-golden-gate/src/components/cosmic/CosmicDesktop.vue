<script setup lang="ts">
/**
 * CosmicDesktop —— COSMIC 应用层 + 桌面外壳
 *
 * 外壳三件套：
 *   1. 顶部「音乐灵动岛」：平时只显示正在播放，有应用覆盖时展开并收进时钟
 *   2. 桌面居中大时钟：没有应用覆盖时悬浮在屏幕正中
 *   3. 底部停靠栏（三段式）：应用图标组 / AI Search / Disk 状态卡
 *
 * 应用全屏（最大化）时，顶栏与 Dock 自动缩回，鼠标移到屏幕边缘可临时唤出。
 */
import { computed, defineAsyncComponent, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { useCosmicStore } from '@/stores/cosmic'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { useLayoutStore } from '@/stores/layout'
import { useIslandHubStore } from '@/stores/islandHub'
import { useCtAIStore } from '@/stores/ctai'
import { cosmicApps } from '@/utils/cosmicApps'
import { paletteOf, motionTokens, shapeFactor, googleFontHref, fontFamilyOf } from '@/utils/m3eTheme'
import { resolveTheme, themeToVars, COSMIC_DARK, COSMIC_LIGHT, type ThemeBuilderOptions } from '@/utils/cosmicTheme'
import CosmicWindow from './CosmicWindow.vue'
import CosmicClock from './CosmicClock.vue'
import CosmicAppIcon from './CosmicAppIcon.vue'
import LgSheet from './glass/LgSheet.vue'
import CtWakePanel from './glass/CtWakePanel.vue'
import CtAgentSidebar from './glass/CtAgentSidebar.vue'
import HighNotification from './panels/HighNotification.vue'
import HighControlCenter from './panels/HighControlCenter.vue'
import IslandStack from './island/IslandStack.vue'
import Icon from '@/components/common/Icon.vue'
import { useDockMagnify } from '@/composables/useDockMagnify'

const store = useCosmicStore()
const sys = useCosmicSystemStore()
const layout = useLayoutStore()
const islandHub = useIslandHubStore()
const ctai = useCtAIStore()

/** 时钟「飞进灵动岛」的位移量：从居中位置飞到头部的胶囊处 */
const CLOCK_TOP = 0.44
const clockFlyY = computed(() => -(layout.canvasH * CLOCK_TOP - 35))

/* ── 应用组件表 ── */
const appComponents: Record<string, ReturnType<typeof defineAsyncComponent>> = {
  CosmicFiles: defineAsyncComponent(() => import('./apps/CosmicFiles.vue')),
  CosmicTerminal: defineAsyncComponent(() => import('./apps/CosmicTerminal.vue')),
  CosmicEdit: defineAsyncComponent(() => import('./apps/CosmicEdit.vue')),
  CosmicStore: defineAsyncComponent(() => import('./apps/CosmicStore.vue')),
  CosmicSettings: defineAsyncComponent(() => import('./apps/CosmicSettings.vue')),
  CosmicPlayer: defineAsyncComponent(() => import('./apps/CosmicPlayer.vue')),
  CosmicViewer: defineAsyncComponent(() => import('./apps/CosmicViewer.vue')),
  CosmicMonitor: defineAsyncComponent(() => import('./apps/CosmicMonitor.vue')),
  CosmicScreenshot: defineAsyncComponent(() => import('./apps/CosmicScreenshot.vue')),
  CosmicCalculator: defineAsyncComponent(() => import('./apps/CosmicCalculator.vue')),
  CosmicCamera: defineAsyncComponent(() => import('./apps/CosmicCamera.vue')),
  CosmicLogs: defineAsyncComponent(() => import('./apps/CosmicLogs.vue')),
  CosmicDisks: defineAsyncComponent(() => import('./apps/CosmicDisks.vue')),
  CosmicFonts: defineAsyncComponent(() => import('./apps/CosmicFonts.vue')),
  CosmicIsland: defineAsyncComponent(() => import('./apps/CosmicIsland.vue')),
  CtApp: defineAsyncComponent(() => import('./apps/CtApp.vue'))
}

/* ── 设计令牌 ── */
/** COSMIC ThemeBuilder 覆盖项（上游 builder override 语义）：
 *  用户强调色永远生效；M3E 启用时其色板同时接管三级容器底色，
 *  容器组件色/文字色/交互态仍由 ThemeBuilder 从底色阶梯自动派生。 */
function themeOverrides(dark: boolean): ThemeBuilderOptions {
  const s = store.settings
  const o: ThemeBuilderOptions = {
    palette: dark ? COSMIC_DARK : COSMIC_LIGHT,
    isDark: dark,
    accent: s.accent,
    // 用户圆角设置映射到 COSMIC Roundness 预设（<8 方正 / <12 微圆 / 其余全圆）
    roundness: s.radius < 8 ? 'square' : s.radius < 12 ? 'slightlyRound' : 'round'
  }
  if (s.m3eEnabled) {
    const p = paletteOf(s.m3e, dark)
    o.bgColor = p.surface
    o.primaryContainerBg = p.surfaceContainerLow
    o.secondaryContainerBg = p.surfaceContainerHigh
    o.accent = p.primary
    o.destructive = p.error
  }
  return o
}

/* M3E 字体轴：Google Fonts 按需加载 + 根字体切换 */
watch(
  () => (store.settings.m3eEnabled ? store.settings.m3e.font : null),
  async (fk) => {
    const id = 'm3e-font-link'
    document.getElementById(id)?.remove()
    if (!fk) return
    const href = googleFontHref(fk)
    if (href) {
      const link = document.createElement('link')
      link.id = id
      link.rel = 'stylesheet'
      link.href = href
      link.onerror = () => link.remove() // 字体加载失败静默回落 system-ui
      document.head.appendChild(link)
    }
    document.documentElement.style.fontFamily = fontFamilyOf(fk)
  },
  { immediate: true }
)

/* ── COSMIC ThemeProvider：整桌面的唯一取色来源 ──
 * 上游 libcosmic 的每个 widget 样式函数都从 theme.cosmic() 取色；
 * 这里等价于把 resolveTheme 出的完整 Theme 铺成 --c-* 变量族，
 * 所有组件（窗口/面板/岛/CT 应用）只认变量，不认写死的色值。 */
const theme = computed(() => {
  const s = store.settings
  const dark = s.mode === 'dark'
  return resolveTheme(s.cosmicTheme, dark ? 'dark' : 'light', themeOverrides(dark))
})

const tokens = computed(() => {
  const s = store.settings
  // M3E 形状轴仍然以缩放系数参与圆角（square 0.35 / full 1.6）
  const userRadius = Math.round(s.radius * (s.m3eEnabled ? shapeFactor(s.m3e.shape) : 1))
  const vars = themeToVars(theme.value, userRadius)
  // 动效轴（M3E 移植件，独立于 COSMIC 色彩引擎）：始终注入，供组件曲线取用
  const motion = motionTokens(s.m3eEnabled ? s.m3e.motion : 'standard')
  vars['--m3e-ease'] = motion.ease
  vars['--m3e-dur'] = motion.dur
  vars['--m3e-dur-long'] = motion.durLong
  // M3E 扩展角色（CT 应用等直接取用）
  if (s.m3eEnabled) {
    const p = paletteOf(s.m3e, s.mode === 'dark')
    vars['--m3e-primary'] = p.primary
    vars['--m3e-on-primary'] = p.onPrimary
    vars['--m3e-primary-container'] = p.primaryContainer
    vars['--m3e-on-primary-container'] = p.onPrimaryContainer
    vars['--m3e-secondary-container'] = p.secondaryContainer
    vars['--m3e-on-secondary-container'] = p.onSecondaryContainer
    vars['--m3e-error'] = p.error
  }
  return vars
})

/* ── 时钟（交给 CosmicClock 自己跑，桌面不参与每秒重渲染）── */
let lyricTimer = 0

/** 灵动岛是否展开为音乐播放器（收起时是一条胶囊） */
const lyricsOpen = ref(false)
/** 点音乐胶囊：把它放回整摞顶层，再展开播放器 */
function openMusic() {
  islandHub.goTop('music')
  lyricsOpen.value = true
}

/** 岛根元素：展开时点击岛外任意区域收回 */
const islandEl = ref<HTMLElement | null>(null)
function onDocPointerDown(e: PointerEvent) {
  if (islandEl.value && !islandEl.value.contains(e.target as Node)) lyricsOpen.value = false
}
watch(lyricsOpen, (v) => {
  if (v) {
    document.addEventListener('pointerdown', onDocPointerDown, true)
    islandHub.closeStack()
  } else document.removeEventListener('pointerdown', onDocPointerDown, true)
})
/* 同一摞岛里两个展开态互斥：信息岛工作台展开时收起音乐播放器 */
watch(() => islandHub.stackOpen, (v) => { if (v) lyricsOpen.value = false })
onUnmounted(() => document.removeEventListener('pointerdown', onDocPointerDown, true))

/** 胶囊收起时显示当前这句歌词 */
const currentLyric = computed(() => store.lyrics[store.lyricIndex]?.jp ?? store.nowPlaying.artist)

/* ── 展开态播放器的本地状态 ── */
const liked = ref(false)
const airplayOn = ref(false)
/** 曲目总长（秒）：4:21。progress 是百分比，用来换算 1:23 / -2:58 这类时间显示。 */
const TRACK_LEN = 261
const mmss = (sec: number) => {
  const s = Math.max(0, Math.floor(sec))
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}
const elapsedSec = computed(() => Math.floor((store.nowPlaying.progress / 100) * TRACK_LEN))
const elapsedText = computed(() => mmss(elapsedSec.value))
const remainText = computed(() => '-' + mmss(TRACK_LEN - elapsedSec.value))
/** 点击进度条跳转 */
function seekProgress(e: MouseEvent) {
  const r = (e.currentTarget as HTMLElement).getBoundingClientRect()
  if (!r.width) return
  store.nowPlaying.progress = Math.min(100, Math.max(0, Math.round(((e.clientX - r.left) / r.width) * 100)))
}

/* 顶栏左右两组恢复后，胶囊要避开它们：测量右药丸左边缘，算出可用的中间宽度 */
const barRightStart = ref(0)
/** 左侧「琥珀快捷钮」结束位置（工作区切换已移除，药丸回到 left:16px） */
const BAR_LEFT_END = 152
function measureBar() {
  const el = document.querySelector('.pill-right')
  if (el) barRightStart.value = el.getBoundingClientRect().left / layout.scaleX
}

/** 灵动岛可用最大宽度（不会压到左右两组） */
const maxIslandWidth = computed(() => {
  const half = layout.canvasW / 2
  const byLeft = layout.canvasW - BAR_LEFT_END * 2
  const byRight = barRightStart.value ? 2 * (barRightStart.value - 24 - half) : 9999
  return Math.max(230, Math.min(byLeft, byRight))
})

/** 处于最大化的窗口 —— 它的应用标识会并进灵动岛（全屏独占时外壳已缩回，不算） */
const maxedWindow = computed(() => {
  if (store.exclusiveId) return null
  return store.openWindows.find((w) => w.maximized && !w.minimized) ?? null
})
const maxedApp = computed(() =>
  maxedWindow.value ? cosmicApps.find((a) => a.id === maxedWindow.value?.appId) ?? null : null
)

/** 灵动岛宽度 = 各内容段的紧凑宽度之和，最后被左右顶栏夹住。
 *
 * 这里必须是「内容自然宽度」，不能拍一个整数：island-bar 里所有元素都是
 * flex:none 的固定宽度，撑不满容器；多出来的宽度会被 .island-clock 的
 * margin-left:auto 全部吸到按钮与时钟之间，变成「有玻璃却没内容」的空缺。
 * 历史上出现过三次同源空缺：
 *   - 展开歌词时写死 344（内容只要 262）→ 右上角空 82px；
 *   - 时钟回缩进岛时写死 380（内容只要 328）→ 中间空 52px；
 *   - 均因宽度与实际内容脱钩。
 * 现在按段累加（实测值）；展开态换成一整块「内容铺满」的播放器，
 * 宽度单独取紧凑值，与窗口 / 时钟 / 应用标识无关，同样不留空缺。 */
const ISLAND_BASE = 262 // 封面27 + 文字104 + 3×按钮26 + 4×gap9 + 内边距
const ISLAND_CLOCK = 66 // 有窗口时并进来的时钟 57 + gap 9
const ISLAND_APP = 177 // 最大化时并进来的应用标识 168 + gap 9（少算 gap 会溢出）
const ISLAND_EXPANDED = 328 // 展开播放器：封面56 + 文本 + 波形 + 进度条 + 5 个控制钮
const islandWidth = computed(() => {
  if (lyricsOpen.value) return Math.round(Math.min(ISLAND_EXPANDED, maxIslandWidth.value))
  let w = ISLAND_BASE
  if (store.hasWindows) w += ISLAND_CLOCK
  if (maxedWindow.value) w += ISLAND_APP
  return Math.round(Math.min(w, maxIslandWidth.value))
})

/** 岛高度：胶囊 44px ⇄ 展开播放器（头部 56 + 进度 + 控制钮 + 内边距 ≈ 168），与宽度同曲线过渡 */
const ISLAND_EXPANDED_H = 168
const islandHeight = computed(() => (lyricsOpen.value ? ISLAND_EXPANDED_H : 44))

/* ── 外壳可见性 ── */
/** 有应用全屏 → 顶栏与 Dock 缩回 */
const chromeRetracted = computed(() => store.isFullscreen)
const topPeek = ref(false)
const bottomPeek = ref(false)
let topPeekTimer = 0
let bottomPeekTimer = 0

function peekTop(hold = 2400) {
  window.clearTimeout(topPeekTimer)
  topPeek.value = true
  topPeekTimer = window.setTimeout(() => (topPeek.value = false), hold)
}
function peekBottom(hold = 2600) {
  window.clearTimeout(bottomPeekTimer)
  bottomPeek.value = true
  bottomPeekTimer = window.setTimeout(() => (bottomPeek.value = false), hold)
}

const islandVisible = computed(() => !chromeRetracted.value || topPeek.value)
/** 音乐胶囊在当前环形牌堆里的槽位：top / mid / low / offUp / offDown。
    与信息卡读同一个环视图，槽位几何也一一对应 —— 换卡时它和信息卡
    在同一条 transform 曲线上一起移动，不存在「谁瞬移、谁消失」。 */
const musicSlot = computed(() => islandHub.musicSlot)
const dockVisible = computed(
  () => (!chromeRetracted.value || bottomPeek.value) && store.settings.showDock
)

/* ── Dock ── */
const dockVertical = computed(() => store.settings.dockPosition !== 'bottom')

/* 中央玻璃演示卡开关（用于核对材质效果）
   —— 这是全屏最大的一块 backdrop-filter 面（620×380），常驻时持续占用合成/光栅。
   关闭后记住选择（localStorage），下次进入不再自动出现，需要时可从设置再打开。 */
const GLASS_DEMO_KEY = 'gg.glassDemoHidden'
const glassDemo = ref(localStorage.getItem(GLASS_DEMO_KEY) !== '1')
watch(glassDemo, (v) => {
  try {
    localStorage.setItem(GLASS_DEMO_KEY, v ? '0' : '1')
  } catch {
    /* ignore */
  }
})
const glassDemoTitle = computed(
  () =>
    ({ liquid: 'Liquid Glass', frosted: 'Frosted Glass', flat: 'No Glass' } as const)[
      store.settings.glassMode
    ]
)
const glassDemoSub = computed(
  () =>
    ({
      liquid: 'Displacement 99 · Blur 0.12 · Saturation 140% · Aberration 2',
      frosted: 'Blur 7.84px · Saturation 140% · No Refraction',
      flat: 'Opaque Surface · No Backdrop Sampling'
    } as const)[store.settings.glassMode]
)
/** 图标尺寸：50px 高的分栏里，图标居中后下方还要留出运行指示点的位置，
 *  所以「大」从 44 收到 40（小 / 中 维持原样）。 */
const dockIconSize = computed(() => ({ S: 32, M: 38, L: 40 })[store.settings.dockSize])

/* ── Dock 悬停放大（移植自 puruvj/macos-web）──
   放大走 transform 而非改图标真实宽度：`.dock-group` 是官方 LiquidGlass 的
   宿主，宽度一变玻璃就会重算壁纸副本并滞后（历史上反复踩过的「玻璃和容器
   对不上」）。transform 方案下宿主宽度恒定 → 玻璃零风险。 */
const magnify = useDockMagnify({
  position: computed(() => store.settings.dockPosition),
  iconSize: dockIconSize,
  enabled: computed(() => store.settings.dockMagnify),
  max: computed(() => store.settings.dockMagnifyMax),
  range: computed(() => store.settings.dockMagnifyRange),
  speed: computed(() => store.settings.dockMagnifySpeed),
  damping: computed(() => store.settings.dockMagnifyDamping),
  neighbor: computed(() => store.settings.dockMagnifyNeighbor / 100),
  lift: computed(() => store.settings.dockMagnifyLift),
  animations: computed(() => store.settings.animations)
})

/** 弹跳动画结束后移除对应图标的弹跳态（时长由 CSS 变量决定，不再写死 680ms） */
function onDockAnimEnd(e: AnimationEvent) {
  if (e.animationName !== 'dockBounce') return
  const el = e.target as HTMLElement | null
  const app = el?.closest?.('[data-dock-app]') as HTMLElement | null
  const id = app?.dataset?.dockApp
  if (id) store.clearBounce(id)
}

/** 弹跳参数写成 CSS 变量，整条 Dock 只写一次 */
const dockBounceVars = computed(() => ({
  '--dock-bounce-h': `${store.settings.dockBounceHeight}px`,
  '--dock-bounce-dur': `${store.settings.dockBounceDuration}ms`
}))

const dockWrapStyle = computed(() => {
  const p = store.settings.dockPosition
  // 底部波幅已移除，Dock 继续下压到更贴近屏幕底部
  if (p === 'bottom') return { left: '50%', bottom: '18px', transform: 'translateX(-50%)' }
  if (p === 'left') return { left: '18px', top: '50%', transform: 'translateY(-50%)' }
  return { right: '18px', top: '50%', transform: 'translateY(-50%)' }
})

const openAppIds = computed(() => new Set(store.windows.filter((w) => !w.closing).map((w) => w.appId)))

/* ── 磁盘状态卡 ── */
const disk = computed(() => sys.storage.disk1)
const diskPct = computed(() => Math.round((disk.value.usedGB / disk.value.totalGB) * 100))

/* ── 启动器 ── */
const query = ref('')
const category = ref('全部')
/** 分类由注册表自动派生：原有 COSMIC 分类 + 6 个 ContainerLinux 分组 */
const categories = ['全部', ...Array.from(new Set(cosmicApps.map((a) => a.category)))]
/** Dock 只放常用应用；48 个 ContainerLinux 系统应用仅在启动台出现，避免挤爆 Dock */
const dockApps = computed(() => cosmicApps.filter((a) => a.dock !== false))

const filteredApps = computed(() => {
  const k = query.value.trim().toLowerCase()
  return cosmicApps.filter((a) => {
    const okCat = category.value === '全部' || a.category === category.value
    const okKw = !k || a.name.toLowerCase().includes(k) || a.description.toLowerCase().includes(k)
    return okCat && okKw
  })
})

function launch(appId: string) {
  store.openApp(appId)
  query.value = ''
}

/* ── 启动台双模式：悬浮（原布局）/ 全屏（苹果 Launchpad） ── */
function setView(v: 'float' | 'fullscreen') {
  store.setLauncherView(v)
  fullPage.value = 0
  // 全屏没有分类栏，切过去时清掉悬浮模式选中的分类
  if (v === 'fullscreen') category.value = '全部'
  nextTick(() => searchInput.value?.focus())
}

/** 全屏模式：7 列 × 3 行分页，沿用搜索结果 */
const FULL_PER_PAGE = 21
const fullPage = ref(0)
const fullPageCount = computed(() => Math.max(1, Math.ceil(filteredApps.value.length / FULL_PER_PAGE)))
const fullPageApps = computed(() =>
  filteredApps.value.slice(fullPage.value * FULL_PER_PAGE, (fullPage.value + 1) * FULL_PER_PAGE)
)
watch([query, category, () => store.launcherView], () => (fullPage.value = 0))

/** 全屏模式：鼠标滚轮 / 触控板滑动切换分页（一挡 = 一页，带冷却防惯性连翻） */
let wheelLockAt = 0
function onLpWheel(e: WheelEvent) {
  if (fullPageCount.value <= 1) return
  const now = Date.now()
  if (now < wheelLockAt) return
  const d = e.deltaY + e.deltaX
  if (Math.abs(d) < 6) return
  wheelLockAt = now + 420
  fullPage.value = Math.min(fullPageCount.value - 1, Math.max(0, fullPage.value + (d > 0 ? 1 : -1)))
}

/** Dock 启动：已在运行 → 聚焦 / 最小化切换；没开 → 新开一个窗口 */
function launchFromDock(appId: string, e: MouseEvent) {
  ;(e.currentTarget as HTMLElement)?.blur()
  if (!store.cycleOrMinimize(appId)) store.openApp(appId)
}

/** 开始按钮（第一栏左侧）：打开应用库，看全部应用 */
function launchStart(e: MouseEvent) {
  ;(e.currentTarget as HTMLElement)?.blur()
  query.value = ''
  store.openLauncher('apps')
}

/** AI Search（第二栏）：打开启动器并直接聚焦搜索框 */
function openSearch(e: MouseEvent) {
  ;(e.currentTarget as HTMLElement)?.blur()
  query.value = ''
  store.openLauncher('search')
}

/** AI Search 打开时自动聚焦输入框 */
const searchInput = ref<HTMLInputElement | null>(null)
watch(
  () => store.launcherOpen,
  (open) => {
    if (open && store.launcherMode === 'search') {
      nextTick(() => searchInput.value?.focus())
    }
  }
)

function toggleDock() {
  store.settings.showDock = !store.settings.showDock
}

/* ── 快捷键 ── */
/** 文本输入态判定：输入框 / textarea / select / contenteditable 内长按空格不唤醒 */
function isTextInput(el: EventTarget | null): boolean {
  const n = el as HTMLElement | null
  if (!n) return false
  const tag = n.tagName
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' ||
    !!n.isContentEditable || !!n.closest?.('[contenteditable],input,textarea,select')
}

/** CTclaw 长按空格 1s 唤醒（§12.2#6 的全局手势契约演示）
 *  满 1s → 在 Dock 原位置弹出「CTclaw 系统对话框」（对话框叠在 Dock 上，Dock 缩小沉后）。 */
let spaceTimer = 0
const WAKE_HOLD_MS = 1000
function onKeydown(e: KeyboardEvent) {
  if ((e.metaKey || e.ctrlKey) && e.code === 'Space') {
    e.preventDefault()
    store.toggleLauncher()
  } else if (e.key === 'Escape') {
    // 先关 Agent 侧栏，再关对话框，最后关启动器（逐层退出）
    if (ctai.panelAgentSidebarOpen) ctai.closeAgentSidebar()
    else if (ctai.panelOpen) ctai.closePanel()   // 关面板 = 释放模型进程
    else if (store.launcherOpen) store.launcherOpen = false
  } else if (
    e.code === 'Space' &&
    !e.metaKey && !e.ctrlKey && !e.altKey &&
    !e.repeat &&
    !isTextInput(e.target) &&
    !spaceTimer &&
    !ctai.panelOpen
  ) {
    // 纯空格：起 1s 计时；不 preventDefault，保留按钮激活 / 页面滚动
    ctai.startWake()
    spaceTimer = window.setTimeout(() => {
      spaceTimer = 0
      ctai.wakeUp()
      ctai.openPanel('chat')
      store.closePanels()
    }, WAKE_HOLD_MS)
  }
}
function onKeyUp(e: KeyboardEvent) {
  if (e.code !== 'Space' || !spaceTimer) return
  window.clearTimeout(spaceTimer)
  spaceTimer = 0
  ctai.cancelWake() // 未满 1s，重置进度
}

onMounted(() => {
  // 歌词按播放状态滚动
  lyricTimer = window.setInterval(() => {
    if (store.nowPlaying.playing) store.nextLyric()
  }, 3400)
  window.addEventListener('keydown', onKeydown)
  window.addEventListener('keyup', onKeyUp)
  window.addEventListener('resize', measureBar)
  nextTick(measureBar)
})
onUnmounted(() => {
  window.clearInterval(lyricTimer)
  window.clearTimeout(topPeekTimer)
  window.clearTimeout(bottomPeekTimer)
  window.clearTimeout(spaceTimer)
  window.removeEventListener('keydown', onKeydown)
  window.removeEventListener('keyup', onKeyUp)
  window.removeEventListener('resize', measureBar)
})
</script>

<template>
  <div
    class="cd-root"
    :class="{ 'cd-no-anim': !store.settings.animations, 'ct-wake': ctai.panelOpen }"
    :data-ct-wake="ctai.panelOpen ? '1' : undefined"
    :style="[tokens, { '--fly-y': clockFlyY + 'px', '--cd-island-w': islandWidth + 'px' }]"
  >
    <!-- 壁纸暗化（设置里可调） -->
    <div class="cd-dim" :style="{ opacity: store.settings.wallpaperDim }" />

    <!-- ═══ 桌面中央玻璃演示卡 ═══
         走统一的 LgSheet：液态模式挂官方 LiquidGlass，磨砂模式回落到裸 warp，
         与「设置 → 外观 → 玻璃材质」全局同步。内容通过 slot 透传，
         两种模式下都是同一份 DOM，不会出现材质切换后内容丢失。 -->
    <div v-if="glassDemo" class="cd-glass-demo">
      <LgSheet liquid>
        <div class="glass-demo-inner">
          <div class="glass-demo-body">
            <p class="glass-demo-title">{{ glassDemoTitle }}</p>
            <p class="glass-demo-sub">{{ glassDemoSub }}</p>
          </div>
          <button class="glass-demo-close" title="关闭" @click="glassDemo = false">
            <i class="ri-close-line" />
          </button>
        </div>
      </LgSheet>
    </div>

    <!-- ═══ 窗口层 ═══ -->
    <!-- 最小化的窗口不再用 v-show 摘掉，而是留在 DOM 里飞向 Dock（便于做收放动画） -->
    <div class="cd-windows">
      <CosmicWindow v-for="w in store.windows" v-show="store.isVisible(w)" :key="w.id" :win="w">
        <component :is="appComponents[cosmicApps.find((a) => a.id === w.appId)?.component ?? '']" />
      </CosmicWindow>
    </div>

    <!-- ═══ 边缘感应区（全屏时唤出外壳）═══ -->
    <div v-if="chromeRetracted" class="cd-edge cd-edge--top" @mouseenter="peekTop()" />
    <div v-if="chromeRetracted" class="cd-edge cd-edge--bottom" @mouseenter="peekBottom()" />

    <!-- ═══ 通知条流：每条独立液态玻璃，从屏幕左侧接连滑入；
         这里只做定位，不再是承载通知条的「通知框」。
         整个面板收起时走逐条错峰左滑淡出（见下方 .cd-notif-leave-*），
         leave 期间冻结官方液态玻璃层（见下方 CSS），消除逐条位移时的错位；
         入场不做容器过渡（交给子组件 stagger），离场靠根元素占位动画
         的 animationend 自动卸载 DOM。 ═══ -->
    <Transition name="cd-notif" :duration="{ enter: 0, leave: 580 }">
      <div v-if="store.notifOpen" class="cd-notif">
        <HighNotification />
      </div>
    </Transition>
    <Transition name="cd-panel">
      <div v-if="store.ccOpen" class="cd-panel cd-panel--right">
        <HighControlCenter />
      </div>
    </Transition>

    <!-- ═══ 桌面「信息岛」：与音乐灵动岛是同一摞 ═══
         音乐胶囊是最上层清晰主卡（下方 .island），这里只渲染压在它下面、
         逐层错位虚化的信息卡；两者共用 <html> 上的 --ih-* 全岛配色令牌。
         点击任意信息卡直接展开工作台；音乐播放器展开时下层自动让位。 ═══ -->
    <IslandStack :music-open="lyricsOpen" />

    <!-- ═══ 桌面居中大时钟 ═══ -->
    <Transition name="clock-fly">
      <CosmicClock
        v-if="!store.hasWindows"
        mode="desk"
        class="desk-clock"
        :class="{ 'desk-clock--behind': store.launcherOpen, 'desk-clock--off': !islandVisible }"
      />
    </Transition>

    <!-- ═══ 音乐灵动岛：收起为胶囊，展开为玻璃化播放器 ═══ -->
    <div
      ref="islandEl"
      class="island lg-host"
      :class="{
        'island--open': store.hasWindows,
        'island--off': !islandVisible,
        'island--expanded': lyricsOpen,
        'island--slot-mid': musicSlot === 'mid' && !lyricsOpen && islandVisible,
        'island--slot-low': musicSlot === 'low' && !lyricsOpen && islandVisible,
        'island--slot-offUp': musicSlot === 'offUp' && !lyricsOpen && islandVisible,
        'island--slot-offDown': musicSlot === 'offDown' && !lyricsOpen && islandVisible
      }"
      :style="{ width: islandWidth + 'px', height: islandHeight + 'px' }"
      @mouseenter="chromeRetracted && peekTop()"
    >
      <LgSheet liquid />
      <!-- 展开 / 收起：胶囊与播放器同框交叉过渡（胶囊缩回封面 + 播放器从封面放大），
           壳体宽高由 .island 的 width/height 过渡承载 -->
      <Transition name="island-body">
      <!-- 收起态：一条胶囊（点击任意位置直接展开播放器） -->
      <div v-if="!lyricsOpen" key="bar" class="island-bar" @click.stop="openMusic()">
        <span
          class="island-art"
          :style="{ background: `linear-gradient(140deg, ${store.nowPlaying.from}, ${store.nowPlaying.to})` }"
        >
          <Icon name="ri-music-2-fill" :size="13" color="#fff" />
        </span>
        <span class="island-text">
          <b>{{ store.nowPlaying.title }}</b>
          <i>{{ currentLyric }}</i>
        </span>

        <!-- 窗口最大化时，应用标识并进灵动岛（应用栏那边就不再重复一块） -->
        <Transition name="island-app">
          <span v-if="maxedWindow && maxedApp" class="island-app">
            <span class="island-app-in">
              <i class="island-app-sep" />
              <span
                class="island-app-icon"
                :style="{ background: `linear-gradient(140deg, ${maxedApp.from}, ${maxedApp.to})` }"
              >
                <Icon :name="maxedApp.icon" :size="11" color="#fff" />
              </span>
              <b>{{ maxedWindow.title }}</b>
            </span>
          </span>
        </Transition>

        <button class="island-btn" title="上一首" @click.stop="store.islandPrev()">
          <Icon name="ri-skip-back-fill" :size="14" color="#fff" />
        </button>
        <button class="island-btn" title="播放 / 暂停" @click.stop="store.islandToggle()">
          <Icon :name="store.nowPlaying.playing ? 'ri-pause-fill' : 'ri-play-fill'" :size="14" color="#fff" />
        </button>
        <button class="island-btn" title="下一首" @click.stop="store.islandNext()">
          <Icon name="ri-skip-forward-fill" :size="14" color="#fff" />
        </button>

        <!-- 有应用覆盖时，时钟收进这里 -->
        <Transition name="island-clock">
          <CosmicClock v-if="store.hasWindows" mode="island" />
        </Transition>
      </div>

      <!-- 展开态：玻璃化音乐播放器（布局不变）。
           点击播放器空白处收回（按钮 / 进度条自身已 stop 冒泡） -->
      <div v-else class="island-player" @click.stop="lyricsOpen = false">
        <div class="ip-head">
          <span
            class="ip-art"
            :style="{ background: `linear-gradient(140deg, ${store.nowPlaying.from}, ${store.nowPlaying.to})` }"
          >
            <Icon name="ri-music-2-fill" :size="19" color="rgba(255,255,255,0.92)" />
            <i class="ip-art-label">NOW<br />PLAYING</i>
          </span>
          <span class="ip-meta">
            <b>{{ store.nowPlaying.title }}</b>
            <i>{{ store.nowPlaying.artist }}</i>
          </span>
          <span class="ip-wave" :class="{ playing: store.nowPlaying.playing }" aria-hidden="true">
            <i v-for="n in 5" :key="n" />
          </span>
          <CosmicClock v-if="store.hasWindows" mode="island" class="ip-clock" />
        </div>

        <div class="ip-progress">
          <span class="ip-time">{{ elapsedText }}</span>
          <span class="ip-track" title="点击跳转播放进度" @click.stop="seekProgress($event)">
            <span
              class="ip-fill"
              :style="{
                width: store.nowPlaying.progress + '%',
                background: `linear-gradient(90deg, ${store.nowPlaying.from}, ${store.nowPlaying.to})`,
                '--comet-glow': store.nowPlaying.to
              }"
            />
          </span>
          <span class="ip-time ip-time--right">{{ remainText }}</span>
        </div>

        <div class="ip-controls">
          <button class="ip-btn" :class="{ on: liked }" title="收藏" @click.stop="liked = !liked">
            <Icon :name="liked ? 'ri-star-fill' : 'ri-star-line'" :size="20" :color="liked ? '#ffd25e' : '#fff'" />
          </button>
          <button class="ip-btn" title="上一首" @click.stop="store.islandPrev()">
            <Icon name="ri-skip-back-fill" :size="21" color="#fff" />
          </button>
          <button
            class="ip-btn ip-btn--main"
            :title="store.nowPlaying.playing ? '暂停' : '播放'"
            @click.stop="store.islandToggle()"
          >
            <Icon :name="store.nowPlaying.playing ? 'ri-pause-fill' : 'ri-play-fill'" :size="22" color="#fff" />
          </button>
          <button class="ip-btn" title="下一首" @click.stop="store.islandNext()">
            <Icon name="ri-skip-forward-fill" :size="21" color="#fff" />
          </button>
          <button class="ip-btn" :class="{ on: airplayOn }" title="隔空播放" @click.stop="airplayOn = !airplayOn">
            <Icon name="ri-airplay-line" :size="20" :color="airplayOn ? '#ffd25e' : '#fff'" />
          </button>
        </div>
      </div>
      </Transition>
    </div>

    <!-- ═══ 停靠栏 ═══ -->
    <div
      v-if="store.settings.showDock"
      class="dock-wrap"
      :style="dockWrapStyle"
      @mouseenter="peekBottom()"
    >
      <div
        class="dock"
        :class="{
          'dock--off': !dockVisible,
          'dock--vertical': dockVertical,
          'dock--v-left': store.settings.dockPosition === 'left',
          'dock--v-right': store.settings.dockPosition === 'right'
        }"
      >
        <!-- 第一栏：应用图标 -->
        <div
          :ref="(el: any) => (magnify.groupRef.value = el as HTMLElement | null)"
          class="dock-group lg-host"
          :style="dockBounceVars"
          @animationend="onDockAnimEnd"
        >
          <LgSheet liquid />
          <button
            v-for="(app, ai) in dockApps"
            :key="app.id"
            class="dock-app"
            :class="{ 'dock-app--bounce': store.bouncing.includes(app.id) }"
            :data-dock-app="app.id"
            :title="app.name"
            @click="launchFromDock(app.id, $event)"
          >
            <!-- 放大层：transform 只加在这一层，与 tile 自身的 hover / 弹跳
                 transform 天然相乘叠加，三者互不覆盖 -->
            <span
              :ref="(el: any) => magnify.registerIco(el as HTMLElement | null, ai)"
              class="dock-app-ico"
            >
              <CosmicAppIcon class="dock-app-tile" :app="app" :size="dockIconSize" />
            </span>
            <i class="dock-dot" :class="{ on: openAppIds.has(app.id) }" />
          </button>
        </div>

        <!-- 第二栏：开始按钮 + AI Search（同一个框里的两个独立按钮） -->
        <div class="dock-search-group lg-host">
          <LgSheet liquid />
          <button class="dock-start" title="开始 · 应用库" @click="launchStart($event)">
            <span class="dock-start-tile">
              <Icon name="ri-planet-fill" :size="17" color="#fff" />
            </span>
          </button>

          <span class="dock-divider" />

          <button class="dock-search" title="AI Search" @click="openSearch($event)">
            <Icon name="ri-search-line" :size="16" color="rgba(255,255,255,0.78)" />
            <span>AI Search</span>
          </button>
        </div>

        <!-- 磁盘状态卡 -->
        <div class="dock-stat lg-host">
          <LgSheet liquid />
          <div class="dock-stat-top">
            <Icon name="ri-hard-drive-2-line" :size="14" color="rgba(255,255,255,0.72)" />
            <b>{{ disk.label }}</b>
            <em>{{ diskPct }}%</em>
          </div>
          <div class="dock-stat-bar"><i :style="{ width: diskPct + '%' }" /></div>
        </div>

        <!-- 收起 Dock -->
        <button class="dock-hide lg-host" title="隐藏 Dock" @click="toggleDock">
          <LgSheet liquid />
          <Icon name="ri-arrow-down-double-line" :size="15" color="rgba(255,255,255,0.6)" />
        </button>
      </div>
    </div>

    <!-- Dock 隐藏后的小抓手 -->
    <button v-else class="dock-handle" title="显示 Dock" @click="toggleDock">
      <Icon name="ri-arrow-up-double-line" :size="15" />
    </button>

    <!-- ═══ App Library 启动器（双模式：悬浮 / 全屏） ═══ -->
    <Transition name="cd-launch">
      <div
        v-if="store.launcherOpen"
        class="cd-launcher"
        :class="{ 'cd-launcher--full': store.launcherView === 'fullscreen' }"
        @click.self="store.launcherOpen = false"
      >
        <!-- ① 悬浮模式：原来的布局（自适应网格 + 应用描述 + 分类玻璃滑块） -->
        <div v-if="store.launcherView === 'float'" class="cd-launcher-panel lg-host">
          <LgSheet />
          <div class="cd-launcher-head">
            <div class="cd-search">
              <Icon name="ri-search-line" :size="17" color="var(--c-text-dim)" />
              <input
                ref="searchInput"
                v-model="query"
                :placeholder="store.launcherMode === 'search' ? '搜索应用、命令…' : '搜索应用…'"
                spellcheck="false"
              />
              <kbd>Esc</kbd>
            </div>
          </div>

          <div class="cd-cats">
            <button
              v-for="c in categories"
              :key="c"
              class="cd-cat"
              :class="{ active: category === c, 'lg-host': category === c }"
              @click="category = c"
            >
              <!-- 选中态：白色 tint 的高透玻璃滑块 -->
              <LgSheet v-if="category === c" />
              <span class="cd-cat-label">{{ c }}</span>
            </button>

            <div class="cd-view-switch">
              <button class="on" title="悬浮模式" @click="setView('float')">悬浮</button>
              <button title="全屏模式" @click="setView('fullscreen')">全屏</button>
            </div>
          </div>

          <div class="cd-grid">
            <button
              v-for="(app, i) in filteredApps"
              :key="app.id"
              class="cd-app"
              :style="{ '--i': i }"
              @click="launch(app.id)"
            >
              <CosmicAppIcon class="cd-app-icon" :app="app" :size="62" />
              <b>{{ app.name.replace('COSMIC ', '') }}</b>
              <i>{{ app.description }}</i>
            </button>
          </div>

          <div v-if="!filteredApps.length" class="cd-empty">没有匹配的应用</div>
        </div>

        <!-- ② 全屏模式：苹果 Launchpad（全屏模糊 + 7 列大图标 + 分页圆点 + 滚轮翻页） -->
        <div v-else class="cd-lp" @click.self="store.launcherOpen = false" @wheel.prevent="onLpWheel">
          <div class="cd-lp-head">
            <div class="cd-lp-search">
              <Icon name="ri-search-line" :size="15" color="rgba(255,255,255,0.7)" />
              <input ref="searchInput" v-model="query" placeholder="搜索" spellcheck="false" />
            </div>
            <div class="cd-view-switch cd-view-switch--lp">
              <button title="悬浮模式" @click="setView('float')">悬浮</button>
              <button class="on" title="全屏模式" @click="setView('fullscreen')">全屏</button>
            </div>
          </div>

          <div class="cd-lp-grid">
            <button
              v-for="(app, i) in fullPageApps"
              :key="app.id"
              class="cd-lp-app"
              :style="{ '--i': i }"
              @click="launch(app.id)"
            >
              <CosmicAppIcon :app="app" :size="84" />
              <b>{{ app.name.replace('COSMIC ', '') }}</b>
            </button>
            <div v-if="!filteredApps.length" class="cd-lp-empty">没有匹配的应用</div>
          </div>

          <div class="cd-lp-dots">
            <button
              v-for="p in fullPageCount"
              :key="p"
              class="cd-lp-dot"
              :class="{ on: fullPage === p - 1 }"
              :aria-label="`第 ${p} 页`"
              @click="fullPage = p - 1"
            />
          </div>
        </div>
      </div>
    </Transition>

    <!-- ═══ CTclaw 唤醒对话框：长按空格 1s 弹出，叠在 Dock 原位置上 ═══
         对话框（z 9100）盖住 Dock，Dock 缩小变暗沉在它后面当底座（见下方 CSS）。
         两个本地模型（Qwen3-0.6B / 1.5B）+ 对话/Agent 工作模式都是真实界面。 ═══ -->
    <CtWakePanel />
    <!-- ═══ Agent 任务工作台侧边栏：从提示条进入，右侧滑入占桌面宽 1/5 ═══
         增量视图，底部对话框保持可用；z 9200，低于控制中心/通知中心。 ═══ -->
    <CtAgentSidebar />
  </div>
</template>

<style scoped>
.cd-root {
  position: fixed;
  inset: 0;
  pointer-events: none;
  font-family: 'Inter', 'Noto Sans CJK SC', system-ui, sans-serif;
  color: var(--c-text);
}

/* 壁纸暗化 */
.cd-dim {
  position: absolute;
  inset: 0;
  background: #000;
  pointer-events: none;
  z-index: 1;
  transition: opacity 0.18s ease;
}

/* 窗口层 */
.cd-windows {
  position: absolute;
  inset: 0;
  z-index: 100;
  pointer-events: none;
}
.cd-windows :deep(.cw:not(.cw--min)) {
  pointer-events: auto;
}

/* ═══════ 中央液态玻璃演示卡 ═══════
   官方 LiquidGlass 自己是 fixed 浮窗（top/left 50% + 官方内部 translate 居中），
   这里只做层级占位，不再包 absolute 背景层、不再改它的定位。 */
/* 与 Dock / 灵动岛一样走 fill 模式：宿主本身就是精确的一块玻璃，
   官方 sheen 描边才能 100% 对齐，不再出现「内外两层框」。 */
.cd-glass-demo {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: min(620px, 46vw);
  height: 380px;
  border-radius: 32px;
  z-index: 55;
  pointer-events: none;
}
/* 撑开官方 .glass（inline-flex 由内容决定尺寸），并恢复交互 */
.glass-demo-inner {
  position: relative;
  z-index: 1; /* 磨砂模式下压过兄弟节点 .lg-overlay */
  width: 100%;
  height: 100%;
  border-radius: inherit;
  pointer-events: auto;
}
.glass-demo-body {
  position: absolute;
  left: 32px;
  right: 32px;
  bottom: 28px;
  color: #fff;
  text-shadow: 0 1px 10px rgba(0, 0, 0, 0.45);
}
.glass-demo-title {
  margin: 0 0 6px;
  font: 600 26px/1.2 system-ui;
  letter-spacing: 0.5px;
}
.glass-demo-sub {
  margin: 0;
  font: 400 12px/1.5 'JetBrains Mono', Consolas, monospace;
  opacity: 0.85;
}
.glass-demo-close {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border: none;
  border-radius: 9px;
  background: rgba(255, 255, 255, 0.16);
  color: #fff;
  font-size: 17px;
  display: grid;
  place-items: center;
  cursor: pointer;
  transition: background 0.15s ease;
}
.glass-demo-close:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* ═══════ 通知条流：只做定位，不画任何承载框。
   每条通知条自身是液态玻璃，由 HighNotification 内部的 stagger 动画
   接连从屏幕左侧滑入。pointer-events 交给通知条自己接管。
   层级刻意低于 .cd-windows(100)：通知条显示时可以被应用窗口覆盖，
   不再浮在所有窗口之上。控制中心 / 启动器等仍保持 9500。 ═══════ */
.cd-notif {
  position: absolute;
  top: 92px;
  left: 24px;
  z-index: 90;
  pointer-events: none;
}

/* ═══ 整个通知面板收回：逐条错峰左滑淡出 ═══
   ⚠️ 每条通知的液态玻璃（OfficialGlass）内部有克隆整张壁纸的
   .og-wall-clone 层 + SVG 位移 backdrop-filter，由 rAF 每 6 帧按宿主
   rect 同步偏移。父元素一旦做 transform/clip-path 动画，克隆层与
   backdrop 采样溢出就会露出矩形边界、圆角描边脱节（实测错位）。
   解法：收回期间把官方玻璃整层隐藏，用一条纯 CSS 磨砂底衬顶替
   （无 backdrop-filter、无克隆层），transform 只作用在普通合成层上。
   离场总时长 = 0.4s 动画 + 最大 165ms 错峰，:duration 给 580ms 兜底。 */
.cd-notif-leave-active {
  pointer-events: none;
}
/* 隐藏整块官方玻璃产物：两个 bg-black 黑色 mask、玻璃根 div.relative
   （内含 .og-wall-clone 壁纸克隆）、sheen 描边、锚点 —— 只保留
   .nt-face / .nt-body 两个内容层。
   ⚠️ 必须用 display:none 而非 visibility:hidden：官方组件运行时会给这些
   层写内联 visibility，祖先 hidden 会被子节点重新 visible 覆盖（实测
   离场帧里两个 bg-black 仍 visible，盖住文字留下一个空的圆角黑框）。 */
.cd-notif-leave-active :deep(.nt-card > :not(.nt-face):not(.nt-body)) {
  display: none !important;
}
/* 纯 CSS 磨砂替身：稳定、不采样背景、位移时绝无错位。
   !important 压过 webgl 模式下 [data-og-fill] 的 border/shadow 清空规则 */
.cd-notif-leave-active :deep(.nt-card) {
  background: rgba(30, 34, 42, 0.82) !important;
  border: 1px solid rgba(255, 255, 255, 0.28) !important;
  box-shadow: 0 14px 34px rgba(0, 0, 0, 0.34) !important;
}
.cd-notif-leave-active :deep(.nt-item) {
  pointer-events: none;
  animation: cd-notif-out 0.4s cubic-bezier(0.4, 0, 1, 1) both;
  /* 反向错峰：--i 越大（越靠下）越先走 */
  animation-delay: calc((3 - var(--i, 0)) * 55ms);
}
@keyframes cd-notif-out {
  from { transform: translateX(0) scale(1); opacity: 1; }
  to   { transform: translateX(calc(-100% - 40px)) scale(0.92); opacity: 0; }
}

/* ═══════ 控制中心浮层（仍保留带过渡的面板容器）═══════ */
.cd-panel {
  position: absolute;
  top: 68px;
  z-index: 9500;
  pointer-events: auto;
}
.cd-panel--right {
  right: 20px;
}
.cd-panel-enter-active,
.cd-panel-leave-active {
  transition: opacity 0.18s ease, transform 0.18s ease;
}
.cd-panel-enter-from,
.cd-panel-leave-to {
  opacity: 0;
  transform: translateY(-6px);
}

/* ═══════ 边缘感应区 ═══════ */
.cd-edge {
  position: absolute;
  left: 0;
  right: 0;
  height: 7px;
  z-index: 8990;
  pointer-events: auto;
}
.cd-edge--top {
  top: 0;
}
.cd-edge--bottom {
  bottom: 0;
}

/* ═══════ 音乐灵动岛 ═══════ */
.island {
  position: absolute;
  top: 13px;
  left: 50%;
  display: flex;
  flex-direction: column;
  border-radius: 22px;
  /* 壳体底衬 / 描边读全岛 --ih-* 令牌：与信息胶囊、展开卡同一套值与换肤行为，
     音乐胶囊不再有专属配色。液态玻璃仍由 LgSheet liquid 提供，不铺实色罩。 */
  background: var(--ih-shell, #08080a);
  border: 1px solid var(--ih-shell-line, rgba(255, 255, 255, 0.07));
  box-shadow:
    0 12px 34px rgba(0, 0, 0, 0.52),
    inset 0 1px 0 rgba(255, 255, 255, 0.05);
  overflow: hidden;
  pointer-events: auto;
  isolation: isolate;
  z-index: 9455;   /* 顶槽：与信息卡顶槽 9450 同层、DOM 靠后稳定在上 */
  transform: translateX(-50%);
  /* 与信息卡共用同一条换槽曲线：transform 0.5s、opacity 0.4s。
     换卡时两者在同一时间轴上滑动，谁都不会「瞬移」或「凭空消失」。 */
  transition:
    width 0.52s cubic-bezier(0.32, 0.72, 0, 1),
    height 0.52s cubic-bezier(0.32, 0.72, 0, 1),
    transform 0.5s cubic-bezier(0.4, 0, 0.2, 1),
    opacity 0.4s ease;
}
/* ═══ 槽位：与信息卡 5 个槽位一一对应的几何 ═══
   位移 + scaleX 全部合进同一条 transform（只跑合成器、零布局重排），
   所以「下沉」和「收窄」是同一个插值，途中就在变窄、到位即定型。
   「虚」只落在内容子元素上：卡片本体若带 filter，内部液态玻璃的
   backdrop 采样会失效，整块退化成灰。 */
.island.island--slot-mid {
  --s: var(--ih-s2, 0.985);
  transform: translateX(-50%) translateY(var(--ih-y2, 6px)) scaleX(var(--s));
  opacity: 1;
  z-index: 9420;   /* 中槽：顶卡(9450)盖它、它盖底卡(9390)，牌堆夹心 */
}
.island.island--slot-low {
  --s: var(--ih-s3, 0.96);
  transform: translateX(-50%) translateY(var(--ih-y3, 13px)) scaleX(var(--s));
  opacity: 1;
  z-index: 9390;   /* 底槽：被中槽卡盖住顶部，只露出下半截 */
}
/* off 槽：移出可见区但元素常驻 —— 滚出/滚入都是真实位移，不是卸载重挂。
   这里写短过渡：CSS 过渡取「目标状态」的时长，所以只让滚出利落，
   落入仍走 top 槽的 0.5s 长过渡。 */
.island.island--slot-offUp {
  --s: var(--ih-s3, 0.96);
  transform: translateX(-50%) translateY(-76px) scaleX(var(--s));
  opacity: 0;
  pointer-events: none;
  z-index: 9380;
  transition:
    transform 0.34s cubic-bezier(0.4, 0, 0.2, 1),
    opacity 0.24s ease;
}
.island.island--slot-offDown {
  --s: var(--ih-s3, 0.96);
  transform: translateX(-50%) translateY(calc(var(--ih-y3, 13px) + 51px)) scaleX(var(--s));
  opacity: 0;
  pointer-events: none;
  z-index: 9370;
  transition:
    transform 0.34s cubic-bezier(0.4, 0, 0.2, 1),
    opacity 0.24s ease;
}
/* 内容反向 scaleX，抵消胶囊收窄的横向压扁（与信息卡同理）。
   歌词展开态的 transform 过渡与此互斥（堆叠态时歌词必收起），无冲突。 */
.island--slot-mid .island-bar,
.island--slot-low .island-bar {
  transform: scaleX(calc(1 / var(--s)));
  transform-origin: center;
}
.island--slot-mid .island-bar > * { filter: blur(0.6px) brightness(0.92); }
.island--slot-low .island-bar > * { filter: blur(1.2px) brightness(0.84); }
/* 折叠态：音乐胶囊缩在下面只露一条底边，歌词 / 歌名会透过顶卡玻璃形成重影，
   跟着折叠状态一起藏（展开时 0.28s 淡回，不会「滑到位才突然出现」）。 */
.island--slot-mid .island-bar > *,
.island--slot-low .island-bar > * {
  opacity: var(--ih-peek-content, 0);
  transition: opacity 0.28s ease, filter 0.4s ease;
}
/* 收窄后让歌名区可压缩（已有 ellipsis），播放按钮保持完整，
   不会被 overflow:hidden 裁出一个缺口。 */
.island--slot-mid .island-text,
.island--slot-low .island-text { width: auto; flex: 1 1 auto; }
/* 整机「自动收回」态：优先级必须高于上面的槽位规则（同为双类、靠后生效），
   否则收回时胶囊还在按槽位下沉、不会整体上移淡出。 */
.island.island--off {
  transform: translateX(-50%) translateY(-140%);
  opacity: 0;
  pointer-events: none;
}
/* 有 WebGL 玻璃层时，底衬只留极薄一层。
   ⚠️ 必须 !important：cosmic.css 的 html[data-glass=webgl] .lg-host 会把
   所有 .lg-host 宿主背景强制透明。音乐胶囊恰好带 .lg-host，若被清空，
   收起态就会与信息胶囊的 --ih-shell-glass 差一层底色，换肤时立刻分家。
   压过它，让全岛收起态读同一个令牌、同一个值。 */
html[data-glass='webgl'] .island {
  background: var(--ih-shell-glass, rgba(8, 8, 10, 0.12)) !important;
  border-color: transparent;
  box-shadow: none;
}
/* 内容抬到玻璃层之上 */
.island > *:not(.glass-sheet) {
  position: relative;
  z-index: 1;
}

/* 胶囊主体这一行 */
.island-bar {
  flex: none;
  height: 44px;
  padding: 0 8px 0 9px;
  display: flex;
  align-items: center;
  gap: 9px;
}

.island-art {
  width: 27px;
  height: 27px;
  border-radius: 9px;
  flex: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.45);
}
.island-text {
  display: flex;
  flex-direction: column;
  gap: 1px;
  width: 104px;
  flex: none;
  min-width: 0;
}
.island-text b {
  font-size: 11.5px;
  font-weight: 600;
  color: #f2f2f5;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.island-text i {
  font-style: normal;
  font-size: 10px;
  color: rgba(255, 255, 255, 0.5);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 窗口最大化时并进来的应用标识 —— 从音乐信息「下面」滑出并展开：
   外层宽度 0 → 168（与 islandWidth 里预留的 168 同节奏，所以不会挤到后面的按钮），
   内层向左偏移 + 模糊 → 归位，形成从应用栏那一侧滑进来的错觉。 */
.island-app {
  display: block;
  flex: none;
  width: 168px;
  overflow: hidden;
}
.island-app-in {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  white-space: nowrap;
}

/* 收放：外层宽度与胶囊宽度同一条曲线、同一时长（0.52s / 0.32,0.72,0,1） */
.island-app-enter-active,
.island-app-leave-active {
  transition:
    width 0.52s cubic-bezier(0.32, 0.72, 0, 1),
    opacity 0.34s ease;
  will-change: width, opacity;
}
.island-app-enter-from,
.island-app-leave-to {
  width: 0;
  opacity: 0;
}

/* 内层：整体从左侧滑入，模糊随之消散 */
.island-app-enter-active .island-app-in,
.island-app-leave-active .island-app-in {
  transition:
    transform 0.52s cubic-bezier(0.22, 1, 0.36, 1),
    filter 0.4s ease;
}
.island-app-enter-from .island-app-in,
.island-app-leave-to .island-app-in {
  transform: translateX(-18px);
  filter: blur(3px);
}

/* 分隔线先「长出来」，图标再弹一下，名称最后落位 —— 一点点错峰，动感更顺 */
.island-app-enter-active .island-app-sep,
.island-app-leave-active .island-app-sep {
  transition:
    transform 0.44s cubic-bezier(0.22, 1, 0.36, 1),
    opacity 0.3s ease;
}
.island-app-enter-from .island-app-sep,
.island-app-leave-to .island-app-sep {
  transform: scaleY(0);
  opacity: 0;
}
.island-app-enter-active .island-app-icon,
.island-app-leave-active .island-app-icon {
  transition:
    transform 0.46s cubic-bezier(0.34, 1.5, 0.64, 1) 0.05s,
    opacity 0.32s ease;
}
.island-app-enter-from .island-app-icon,
.island-app-leave-to .island-app-icon {
  transform: scale(0.4) rotate(-14deg);
  opacity: 0;
}

.island-app-sep {
  width: 1px;
  height: 18px;
  flex: none;
  margin-right: 2px;
  background: rgba(255, 255, 255, 0.18);
}
.island-app-icon {
  width: 20px;
  height: 20px;
  flex: none;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
.island-app b {
  max-width: 168px;
  font-size: 12.5px;
  font-weight: 650;
  color: #fff;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.island-btn {
  width: 26px;
  height: 26px;
  flex: none;
  border: none;
  border-radius: 8px;
  background: transparent;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.14s ease;
}
.island-btn:hover {
  background: rgba(255, 255, 255, 0.12);
}
.island-btn--on {
  background: rgba(255, 255, 255, 0.18);
}

/* ═══ 灵动岛展开 / 收起过渡：内容与壳体严格同比例缩放 ═══
   播放器固定 168px 高，scale 起点 0.262 = 胶囊高 44 / 168；
   transform 过渡与壳体 height 过渡用同一时长、同一曲线 →
   内容底边每一帧都与壳体底边重合，下方组件跟着壳体一起
   长大 / 收拢，不会突然出现、也不会先缩完再冒出来。 */
.island-player.island-body-enter-active {
  transition:
    transform 0.52s cubic-bezier(0.32, 0.72, 0, 1),
    opacity 0.24s ease;
}
.island-player.island-body-leave-active {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  transition:
    transform 0.52s cubic-bezier(0.32, 0.72, 0, 1),
    opacity 0.3s ease;
}
.island-player.island-body-enter-from,
.island-player.island-body-leave-to {
  opacity: 0;
  transform: scale(0.262);
  transform-origin: 22px 0;
}
/* 胶囊：交叉过渡的另一半。展开时快速淡出（播放器在长出来）；
   收回时稍稍提前淡入 —— 壳体还在收拢时胶囊内容已经在位，
   避免「先缩成空壳、组件再冒出来」的割裂感 */
.island-bar.island-body-enter-active {
  transition: opacity 0.26s ease 0.06s;
}
.island-bar.island-body-leave-active {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  transition: opacity 0.18s ease;
}
.island-bar.island-body-enter-from,
.island-bar.island-body-leave-to {
  opacity: 0;
}

/* ═══ 展开态：玻璃化音乐播放器 ═══
   宿主仍是同一块 LgSheet 玻璃（液态 / 磨砂跟随全局切换），
   这里只叠一层深色半透明底衬，保证白字在浅色壁纸上也读得清，
   同时仍能看到玻璃后面的模糊与折射 —— 不是纯黑卡片。 */
/* 圆角沿用全局 .lg-host 的 32px（与官方 corner-radius 一致），不另设 */
html[data-glass='webgl'] .island.island--expanded {
  background: var(--ih-shell-expanded, rgba(9, 10, 13, 0.42)) !important;
}
.island-player {
  padding: 14px 15px 13px;
  display: flex;
  flex-direction: column;
  /* 固定高度（= ISLAND_EXPANDED_H），不用 100%：
     展开过渡时壳体高度在动画中，100% 会跟着变，导致内容缩放
     与壳体高度无法按比例对齐（底边组件会被裁到突然出现） */
  height: 168px;
  flex: none;
  box-sizing: border-box;
}

/* 第一行：专辑封面 / 曲目信息 / 波形 / 时钟 / 收起 */
.ip-head {
  display: flex;
  align-items: center;
  gap: 10px;
}
.ip-art {
  width: 56px;
  height: 56px;
  flex: none;
  border-radius: 14px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.25);
}
.ip-art-label {
  font: 600 6px/1.15 system-ui;
  letter-spacing: 0.1em;
  font-style: normal;
  text-align: center;
  color: rgba(255, 255, 255, 0.72);
}
.ip-meta {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.ip-meta b {
  font-size: 14px;
  font-weight: 650;
  color: #fff;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ip-meta i {
  font-style: normal;
  font-size: 11.5px;
  color: rgba(255, 255, 255, 0.55);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
/* 音频波形：播放时起伏，暂停时定格 */
.ip-wave {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  height: 26px;
  flex: none;
}
.ip-wave i {
  width: 3px;
  height: 10px;
  border-radius: 2px;
  background: linear-gradient(180deg, #ffd25e, #ff8a3d);
  animation: ip-wave 0.9s ease-in-out infinite alternate;
  animation-play-state: paused;
}
.ip-wave.playing i { animation-play-state: running; }
.ip-wave i:nth-child(2) { height: 18px; animation-delay: 0.15s; }
.ip-wave i:nth-child(3) { height: 24px; animation-delay: 0.3s; }
.ip-wave i:nth-child(4) { height: 15px; animation-delay: 0.45s; }
.ip-wave i:nth-child(5) { height: 11px; animation-delay: 0.6s; }
@keyframes ip-wave {
  from { transform: scaleY(0.42); }
  to { transform: scaleY(1); }
}
/* 展开态里收进来的时钟：小号淡字，不抢播放器主体 */
.island-player .island-clock {
  flex: none;
  padding-left: 0;
  margin-left: 0;
  border-left: none;
  font-size: 11px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.62);
}
.ip-fold {
  display: none;
}

/* 第二行：进度条（可点击跳转） */
.ip-progress {
  display: flex;
  align-items: center;
  gap: 9px;
  margin-top: 15px;
}
.ip-time {
  flex: none;
  width: 34px;
  font-size: 10.5px;
  color: rgba(255, 255, 255, 0.66);
  font-variant-numeric: tabular-nums;
}
.ip-time--right { width: 40px; text-align: right; }
.ip-track {
  flex: 1;
  height: 8px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.18);
  cursor: pointer;
}
.ip-fill {
  position: relative;
  display: block;
  height: 100%;
  border-radius: 999px;
  /* 进度条与专辑封面同主题色（inline 绑定 from→to 渐变）；
     整段带一层同色辉光，像被彗星头照亮 */
  box-shadow: 0 0 10px 1px color-mix(in srgb, var(--comet-glow, #fff) 55%, transparent);
  transition: width 0.18s ease;
}
/* 彗尾：条身后半段平滑渐白 —— 参考图就是颜色条逐渐变亮成白头，
   过渡要长而缓，绝不能出现可感知的边界 */
.ip-fill::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: linear-gradient(
    90deg,
    transparent 30%,
    rgba(255, 255, 255, 0.18) 52%,
    rgba(255, 255, 255, 0.45) 72%,
    rgba(255, 255, 255, 0.78) 88%,
    rgba(255, 255, 255, 0.96) 97%,
    #fff 100%
  );
  pointer-events: none;
}
/* 彗星光晕：单层低透明度径向渐变 + 大半径模糊 + 普通混合。
   不用 screen/plus-lighter（会在白色区域饱和削平、暴露元素矩形边界），
   透明度压在 0.5 以下保证从中心到边缘永远平滑衰减 */
/* 彗星光晕（拖尾）：单层径向渐变 + 普通混合，靠渐变自身平滑衰减到 0
   来保证无边界。中心亮度给足（参考图的拖尾很抢眼），主体偏头部左侧
   形成向左拖尾，右侧衰减快 */
.ip-fill::after {
  content: '';
  position: absolute;
  right: -22px;
  top: 50%;
  width: 170px;
  height: 40px;
  transform: translateY(-50%);
  background: radial-gradient(
    50% 50% at 68% 50%,
    rgba(255, 255, 255, 0.95) 0%,
    rgba(255, 255, 255, 0.75) 18%,
    color-mix(in srgb, var(--comet-glow, #fff) 75%, rgba(255, 255, 255, 0.5)) 36%,
    color-mix(in srgb, var(--comet-glow, #fff) 52%, transparent) 58%,
    color-mix(in srgb, var(--comet-glow, #fff) 22%, transparent) 80%,
    transparent 100%
  );
  filter: blur(8px);
  opacity: 1;
  animation: comet-pulse 2.4s ease-in-out infinite;
  pointer-events: none;
}
@keyframes comet-pulse {
  0%, 100% { opacity: 0.85; }
  50% { opacity: 1; }
}

/* 第三行：五个播放控制 */
.ip-controls {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 14px;
  padding: 0 2px;
}
.ip-btn {
  width: 34px;
  height: 34px;
  flex: none;
  border: none;
  border-radius: 50%;
  background: transparent;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.15s ease, transform 0.15s ease;
}
.ip-btn:hover { background: rgba(255, 255, 255, 0.12); transform: scale(1.08); }
.ip-btn--main { width: 40px; height: 40px; }

/* 收进灵动岛的时钟 */
/* 不用 margin-left:auto：它会把 island 富余的宽度全部吸到「按钮 ↔ 时钟」
   之间，形成一块有玻璃却没内容的空缺。岛宽已按内容紧凑累加，这里只靠
   flex gap 排布；万一有 1~2px 偏差也只会落在右侧内边距，不会拉出空白。 */
.island-clock {
  flex: none;
  margin-left: 0;
  padding-left: 11px;
  border-left: 1px solid rgba(255, 255, 255, 0.12);
  font-size: 16px;
  font-weight: 600;
  color: #ffffff;
  letter-spacing: 0.4px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.island-clock-enter-active {
  transition: all 0.46s cubic-bezier(0.32, 0.72, 0, 1) 0.14s;
}
.island-clock-leave-active {
  transition: all 0.22s ease;
}
.island-clock-enter-from {
  opacity: 0;
  transform: translateY(16px) scale(0.62);
  filter: blur(3px);
}
.island-clock-leave-to {
  opacity: 0;
  transform: translateY(8px) scale(0.8);
}

/* ═══════ 桌面居中大时钟 ═══════ */
.desk-clock {
  position: absolute;
  left: 50%;
  top: 44%;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  z-index: 60;
  pointer-events: none;
  transition: opacity 0.3s ease, filter 0.3s ease;
}
/* 文字排版在 CosmicClock 内部（scoped），这里只管定位与状态 */
.desk-clock--behind {
  opacity: 0.16;
  filter: blur(7px);
}
.desk-clock--off {
  opacity: 0;
}

/* 时钟「飞进灵动岛」 */
.clock-fly-leave-active {
  transition: all 0.58s cubic-bezier(0.32, 0.72, 0, 1);
}
.clock-fly-leave-to {
  opacity: 0;
  transform: translate(-50%, -50%) translateY(var(--fly-y, -440px)) scale(0.13);
  filter: blur(4px);
}
.clock-fly-enter-active {
  transition: all 0.6s cubic-bezier(0.32, 0.72, 0, 1);
}
.clock-fly-enter-from {
  opacity: 0;
  transform: translate(-50%, -50%) translateY(var(--fly-y, -440px)) scale(0.13);
  filter: blur(4px);
}

/* ═══════ 停靠栏 ═══════ */
.dock-wrap {
  position: absolute;
  z-index: 9000;
  pointer-events: auto;
  transition: transform 0.42s cubic-bezier(0.32, 0.72, 0, 1);
}
.dock {
  /* 所有分栏共用同一高度，保证四个块上下齐平（基准取「开始/AI Search」栏） */
  --dock-h: 50px;
  display: flex;
  align-items: center;
  gap: 10px;
  transition:
    opacity 0.3s ease,
    transform 0.42s cubic-bezier(0.32, 0.72, 0, 1);
}
.dock--vertical {
  flex-direction: column;
}
/* 三段各自独立成块（Dock 不再是一整条，只有内部三个分区） */
.dock-group,
.dock-search-group,
.dock-stat,
.dock-hide {
  position: relative;
  isolation: isolate;
  background-color: rgba(18, 18, 20, 0.62);
  background-image: radial-gradient(240px 240px at var(--lg-hx, 50%) var(--lg-hy, 50%), rgba(255, 255, 255, 0.14), rgba(255, 255, 255, 0) 70%);
  /* 默认：纯 GPU blur 材质（普通手机稳 60fps）。
     折射是「实验开关」——body.glass-refract 时由 global.css 换成 SVG 位移链。 */
  backdrop-filter: blur(24px) saturate(150%);
  border: 1px solid rgba(255, 255, 255, 0.09);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.5);
}
/* 有 WebGL 玻璃层时：撤掉 CSS blur 与厚底衬，只留极薄一层 —— 避免和 GPU 折射重复开销 */
html[data-glass='webgl'] .dock-group,
html[data-glass='webgl'] .dock-search-group,
html[data-glass='webgl'] .dock-stat,
html[data-glass='webgl'] .dock-hide {
  background-color: rgba(18, 18, 20, 0.12);
  backdrop-filter: none;
  /* 投影交给玻璃层自己（跟随圆角、单层）；容器再叠一层会压成黑边 */
  box-shadow: none;
}
/* 内容抬到玻璃层之上 */
.dock-group > *:not(.glass-sheet),
.dock-search-group > *:not(.glass-sheet),
.dock-stat > *:not(.glass-sheet),
.dock-hide > *:not(.glass-sheet) {
  position: relative;
  z-index: 1;
}
.dock--off {
  opacity: 0;
  pointer-events: none;  transform: translateY(130%);
}
.dock--vertical.dock--off {
  transform: translateY(0);
}
.dock--v-left.dock--off {
  transform: translateX(-130%);
}
.dock--v-right.dock--off {
  transform: translateX(130%);
}

/* ═══ CTclaw 唤醒：对话框叠在 Dock 上、占它的位置，Dock 缩小沉在对话框后面 ═══
   对话框（.cwp-panel，z 9100，bottom:30px）盖住 Dock；Dock（.dock-wrap，z 9000）
   整体缩小、变暗，从对话框下缘后面露出一点当底座。不做任何假背板堆叠 ——
   那既会糊成黑边，也不是「对话框叠在 Dock 上」的叠压关系。 ═══ */
.ct-wake .dock {
  position: relative;
  flex-direction: row !important;
  transform: scale(0.5) !important;
  transform-origin: bottom center;
  opacity: 0.9;
  filter: brightness(0.92);
  transition: transform 0.42s cubic-bezier(0.2, 0.9, 0.3, 1.1), opacity 0.3s ease !important;
}
/* 第一栏：应用图标（独立块）—— 高度与其他分栏对齐 */
.dock-group {
  display: flex;
  align-items: center;
  gap: 6px;
  height: var(--dock-h);
  padding: 0 8px;
  border-radius: 16px;
  /* 弹跳参数（幅度 / 时长）由设置项写入，整条 Dock 只写一次 */
  --dock-bounce-h: 13px;
  --dock-bounce-dur: 680ms;
}
.dock--vertical .dock-group {
  flex-direction: column;
  width: var(--dock-h);
  height: auto;
  padding: 8px 0;
}
.dock-app {
  position: relative;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  /* 图标在整块里垂直居中；运行指示点用绝对定位贴底，不参与撑高/偏移 */
  justify-content: center;
  padding: 0;
  background: transparent;
  border: none;
  cursor: pointer;
}
.dock--vertical .dock-app {
  height: auto;
  padding: 0;
}

/* ── 放大层 ──
   transform 只加在这一层（transform 层级最外），于是：
     · 放大 scale(k)
     · tile 自身的 hover（translateY(-4px) scale(1.08)）
     · 弹跳 keyframes（含 scale）
   三者的 transform 天然相乘叠加，互不覆盖。
   transform-origin 决定「从哪边长出来」：
     底部 Dock → 底边锚定，向上凸出胶囊；左侧 → 左边；右侧 → 右边。 */
.dock-app-ico {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transform-origin: 50% 100%;
}
/* 只在指针进入 Dock 时才提升为合成层：14 个图标常驻 will-change 会多出
   14 个合成层，白白吃内存。标记由 useDockMagnify 挂在 .dock-group 上。 */
.dock-group.dock-magnify-on .dock-app-ico {
  will-change: transform;
}
.dock--vertical.dock--v-left .dock-app-ico {
  transform-origin: 0% 50%;
}
.dock--vertical.dock--v-right .dock-app-ico {
  transform-origin: 100% 50%;
}

.dock-app-tile {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 30%;
  transition: transform 0.16s ease, filter 0.16s ease;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.34);
}
.dock-app:hover .dock-app-tile {
  transform: translateY(-4px) scale(1.08);
  filter: brightness(1.12);
}
/* 打开 / 最小化 / 还原时的图标回弹（幅度与时长可调） */
.dock-app--bounce .dock-app-tile {
  animation: dockBounce var(--dock-bounce-dur, 680ms) cubic-bezier(0.32, 0.72, 0, 1);
}
@keyframes dockBounce {
  0% { transform: translateY(0) scale(1); }
  28% { transform: translateY(calc(var(--dock-bounce-h, 13px) * -1)) scale(1.07); }
  52% { transform: translateY(calc(var(--dock-bounce-h, 13px) * 0.23)) scale(0.96); }
  74% { transform: translateY(calc(var(--dock-bounce-h, 13px) * -0.38)) scale(1.02); }
  100% { transform: translateY(0) scale(1); }
}

/* 第二栏：开始按钮 + AI Search 共用一个框，但彼此是独立按钮 */
.dock-search-group {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: var(--dock-h);
  padding: 0 8px 0 7px;
  border-radius: 16px;
}
.dock--vertical .dock-search-group {
  flex-direction: column;
  width: var(--dock-h);
  height: auto;
  gap: 6px;
  padding: 8px 0;
}
/* 竖排时宽度只有 56px，收成方形图标按钮 */
.dock--vertical .dock-search {
  width: 38px;
  height: 38px;
  padding: 0;
  gap: 0;
  justify-content: center;
}
.dock--vertical .dock-search span {
  display: none;
}

/* 开始按钮 */
.dock-start {
  width: 38px;
  height: 38px;
  flex: none;
  border: none;
  background: transparent;
  padding: 0;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.14s ease;
}
.dock-start:hover {
  background: rgba(255, 255, 255, 0.11);
}
.dock-start-tile {
  width: 30px;
  height: 30px;
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(140deg, #7b5cf0, #a48bf8);
  box-shadow:
    0 2px 9px rgba(123, 92, 240, 0.45),
    inset 0 0 0 1px rgba(255, 255, 255, 0.2);
}

/* 框内分隔线：开始按钮 ｜ AI Search */
.dock-divider {
  width: 1px;
  height: 24px;
  flex: none;
  margin: 0 3px;
  background: rgba(255, 255, 255, 0.16);
}
.dock--vertical .dock-divider {
  width: 24px;
  height: 1px;
  margin: 3px 0;
}
.dock-dot {
  position: absolute;
  left: 50%;
  /* 贴到分栏底内缘，正好落在居中图标下方的余量里 */
  bottom: 0;
  transform: translateX(-50%);
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: transparent;
  transition: background 0.16s ease;
}
.dock--vertical .dock-dot {
  position: static;
  transform: none;
  margin-top: 3px;
}
.dock-dot.on {
  background: rgba(255, 255, 255, 0.85);
}

/* AI 搜索（在第二栏框内，与开始按钮并列） */
.dock-search {
  display: inline-flex;
  align-items: center;
  gap: 9px;
  height: 38px;
  padding: 0 14px 0 10px;
  border-radius: 12px;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.72);
  font: inherit;
  font-size: 13.5px;
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.14s ease, color 0.14s ease;
}
.dock-search:hover {
  background: rgba(255, 255, 255, 0.11);
  color: #fff;
}

/* 磁盘状态卡 */
.dock-stat {
  width: 168px;
  height: var(--dock-h);
  padding: 0 13px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 7px;
  border-radius: 16px;
}
.dock--vertical .dock-stat {
  width: var(--dock-h);
  height: 100px;
  padding: 12px 0;
  gap: 8px;
}
/* 竖排太窄，只保留图标 + 百分比 + 进度条 */
.dock--vertical .dock-stat-top {
  flex-direction: column;
  gap: 5px;
  font-size: 11px;
}
.dock--vertical .dock-stat-top b {
  display: none;
}
.dock--vertical .dock-stat-top em {
  margin-left: 0;
}
.dock--vertical .dock-stat-bar {
  width: 28px;
}
.dock-stat-top {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}
.dock-stat-top b {
  font-weight: 600;
}
.dock-stat-top em {
  margin-left: auto;
  font-style: normal;
  font-size: 11.5px;
  color: rgba(255, 255, 255, 0.62);
  font-variant-numeric: tabular-nums;
}
.dock-stat-bar {
  height: 4px;
  border-radius: 2px;
  background: rgba(255, 255, 255, 0.14);
  overflow: hidden;
}
.dock-stat-bar i {
  display: block;
  height: 100%;
  border-radius: 2px;
  background: #7ddc8a;
  transition: width 0.3s ease;
}

/* 收起按钮 */
.dock-hide {
  width: 30px;
  height: var(--dock-h);
  border-radius: 16px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.14s ease;
}
.dock-hide:hover {
  background: rgba(255, 255, 255, 0.14);
}
/* 玻璃层会盖住底衬，hover 反馈改由微微提亮玻璃本身表达 */
html[data-glass='webgl'] .dock-hide:hover {
  background: transparent;
}
html[data-glass='webgl'] .dock-hide:hover .glass-sheet {
  filter: brightness(1.2);
}
.dock--vertical .dock-hide {
  width: var(--dock-h);
  height: 30px;
}

.dock-handle {
  position: absolute;
  left: 50%;
  bottom: 18px;
  transform: translateX(-50%);
  z-index: 9000;
  pointer-events: auto;
  width: 68px;
  height: 13px;
  border-radius: 8px;
  border: 1px solid var(--c-border-strong);
  background: color-mix(in srgb, var(--c-surface) 70%, transparent);
  backdrop-filter: blur(14px);
  color: var(--c-text-dim);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ═══════ 启动器 ═══════ */
.cd-launcher {
  position: absolute;
  inset: 0;
  z-index: 9500;
  pointer-events: auto;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 6vh 0;
  /* 悬浮模式：只留轻纱让面板聚焦，背景不模糊（壁纸保持清晰） */
  background: color-mix(in srgb, var(--c-bg) 38%, transparent);
  backdrop-filter: none;
}
.cd-launcher-panel {
  width: min(880px, 86vw);
  max-height: 74vh;
  display: flex;
  flex-direction: column;
  padding: 20px 22px 24px;
  /* 四角更圆润 */
  border-radius: calc(var(--c-radius) + 18px);
  position: relative;
  isolation: isolate;
  background: color-mix(in srgb, var(--c-surface) 92%, transparent);
  border: 1px solid var(--c-border-strong);
  box-shadow: 0 30px 80px var(--c-shadow);
}
html[data-glass='webgl'] .cd-launcher-panel {
  /* 稍加实底：应用描述是 11px 灰字，太透会糊在壁纸上 */
  background: color-mix(in srgb, var(--c-surface) 42%, transparent);
}
.cd-launcher-panel > *:not(.glass-sheet) {
  position: relative;
  z-index: 1;
}
.cd-launcher-head {
  position: relative;
  display: flex;
  align-items: center;
}
.cd-search {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 10px;
  height: 46px;
  padding: 0 14px;
  border-radius: 14px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border);
}
.cd-search input {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  color: var(--c-text);
  font-size: 15px;
  font-family: inherit;
}
.cd-search input::placeholder { color: var(--c-text-mute); }
.cd-search kbd {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 6px;
  background: var(--c-surface-3);
  color: var(--c-text-dim);
  border: 1px solid var(--c-border);
}

/* 双模式切换：悬浮 / 全屏 */
.cd-view-switch {
  margin-left: auto;
  display: flex;
  gap: 2px;
  padding: 3px;
  border-radius: 11px;
  background: var(--c-surface-2);
  border: 1px solid var(--c-border);
}
.cd-view-switch button {
  padding: 4px 12px;
  border-radius: 8px;
  border: 0;
  background: transparent;
  color: var(--c-text-dim);
  font-size: 12px;
  font-family: inherit;
  cursor: pointer;
  transition: all 0.14s ease;
  white-space: nowrap;
}
.cd-view-switch button:hover { color: var(--c-text); }
.cd-view-switch button.on {
  background: var(--c-accent);
  color: #fff;
}

.cd-cats {
  flex: none;
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 16px 0 14px;
  /* 11 个分类横向滚动，滚动条隐藏 */
  overflow-x: auto;
  scrollbar-width: none;
  padding-bottom: 2px;
}
.cd-cats::-webkit-scrollbar { display: none; }
.cd-cat {
  flex: none;
  position: relative;
  isolation: isolate;
  height: 30px;
  padding: 0 14px;
  border-radius: 15px;
  border: 1px solid var(--c-border);
  background: transparent;
  color: var(--c-text-dim);
  font-size: 13px;
  font-family: inherit;
  cursor: pointer;
  transition: all 0.14s ease;
}
.cd-cat > .cd-cat-label { position: relative; z-index: 1; }
.cd-cat:hover { background: var(--c-hover); color: var(--c-text); }
.cd-cat.active {
  /* 选中态由内部 GlassSheet 玻璃滑块负责，这里不叠实底 */
  background: transparent;
  border-color: transparent;
  color: var(--c-text);
}

.cd-grid {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(132px, 1fr));
  /* 固定行高：默认只露出 3 行，其余滚动查看 */
  grid-auto-rows: 156px;
  max-height: calc(156px * 3 + 12px * 2);
  gap: 12px;
  padding-right: 4px;
}
.cd-grid::-webkit-scrollbar { width: 8px; }
.cd-grid::-webkit-scrollbar-track { background: transparent; }
.cd-grid::-webkit-scrollbar-thumb {
  background: color-mix(in srgb, var(--c-text) 22%, transparent);
  border-radius: 4px;
}
.cd-app {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 16px 10px 14px;
  border-radius: 16px;
  border: 1px solid transparent;
  background: transparent;
  cursor: pointer;
  transition: all 0.14s ease;
  font-family: inherit;
}
.cd-app:hover {
  background: var(--c-hover);
  border-color: var(--c-border);
  transform: translateY(-2px);
}
.cd-app-icon {
  width: 62px;
  height: 62px;
  border-radius: 30%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.35);
}
.cd-app b {
  font-size: 13px;
  font-weight: 600;
  color: var(--c-text);
}
.cd-app i {
  font-style: normal;
  font-size: 11px;
  line-height: 1.35;
  color: var(--c-text-dim);
  text-align: center;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.cd-empty {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--c-text-mute);
  font-size: 14px;
}

/* ═══════ 全屏模式：苹果 Launchpad ═══════ */
.cd-launcher--full {
  padding: 0;
  background: rgba(0, 0, 0, 0.3);
  backdrop-filter: blur(40px) saturate(150%);
}
.cd-lp {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 7vh 4vw 4vh;
  color: #fff;
}
.cd-lp-head {
  position: relative;
  width: 100%;
  display: flex;
  justify-content: center;
  margin-bottom: 5vh;
}
.cd-lp-search {
  width: 280px;
  height: 34px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 12px;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.14);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
.cd-lp-search input {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  color: #fff;
  font-size: 13px;
  font-family: inherit;
  text-align: center;
}
.cd-lp-search input::placeholder { color: rgba(255, 255, 255, 0.6); }
.cd-view-switch--lp {
  position: absolute;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  background: rgba(255, 255, 255, 0.12);
  border-color: rgba(255, 255, 255, 0.2);
}
.cd-view-switch--lp button { color: rgba(255, 255, 255, 0.75); }
.cd-view-switch--lp button:hover { color: #fff; }
.cd-view-switch--lp button.on {
  background: rgba(255, 255, 255, 0.92);
  color: #1c1c20;
}
.cd-lp-grid {
  display: grid;
  grid-template-columns: repeat(7, 104px);
  gap: 34px 24px;
  justify-content: center;
  align-content: center;
  flex: 1 1 0;
  width: 100%;
  max-width: 940px;
}
.cd-lp-app {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  border: 0;
  background: transparent;
  cursor: pointer;
  color: #fff;
  font-family: inherit;
  transition: transform 0.16s ease;
  animation: cdItemIn 0.42s cubic-bezier(0.16, 1, 0.3, 1) backwards;
  animation-delay: calc(var(--i, 0) * 22ms);
}
.cd-lp-app:hover { transform: scale(1.08); }
.cd-lp-app b {
  font-size: 13px;
  font-weight: 500;
  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.5);
}
.cd-lp-empty {
  grid-column: 1 / -1;
  text-align: center;
  color: rgba(255, 255, 255, 0.7);
  padding: 40px;
}
.cd-lp-dots {
  margin-top: auto;
  display: flex;
  gap: 8px;
  padding-top: 24px;
}
.cd-lp-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  border: 0;
  padding: 0;
  background: rgba(255, 255, 255, 0.4);
  cursor: pointer;
}
.cd-lp-dot.on { background: #fff; }

/* 全屏层随容器一起淡入 + 轻微缩放 */
.cd-launch-enter-active .cd-lp {
  transition: transform 0.44s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.3s ease;
}
.cd-launch-leave-active .cd-lp {
  transition: transform 0.22s ease, opacity 0.16s ease;
}
.cd-launch-enter-from .cd-lp { opacity: 0; transform: scale(1.05); }
.cd-launch-leave-to .cd-lp { opacity: 0; transform: scale(0.98); }

/* ═══════ 启动器开合动画（点开始按钮 / AI Search 后优雅展开）═══════ */
.cd-launch-enter-active {
  transition: opacity 0.3s ease;
}
.cd-launch-leave-active {
  transition: opacity 0.22s ease;
}
.cd-launch-enter-from,
.cd-launch-leave-to {
  opacity: 0;
}

/* 面板：自上方落下 + 缩放展开 + 去虚化 */
.cd-launch-enter-active .cd-launcher-panel {
  transition:
    transform 0.44s cubic-bezier(0.16, 1, 0.3, 1),
    opacity 0.28s ease,
    filter 0.36s ease;
}
.cd-launch-leave-active .cd-launcher-panel {
  transition:
    transform 0.22s cubic-bezier(0.4, 0, 1, 1),
    opacity 0.16s ease,
    filter 0.2s ease;
}
.cd-launch-enter-from .cd-launcher-panel {
  opacity: 0;
  transform: translateY(-26px) scale(0.93);
  filter: blur(12px);
}
.cd-launch-leave-to .cd-launcher-panel {
  opacity: 0;
  transform: translateY(-14px) scale(0.965);
  filter: blur(6px);
}

/* 应用格子错峰入场（backwards：延迟期间保持起始态，播完不占位，悬停位移照常生效） */
.cd-app {
  animation: cdItemIn 0.42s cubic-bezier(0.16, 1, 0.3, 1) backwards;
  animation-delay: calc(var(--i, 0) * 24ms);
}
@keyframes cdItemIn {
  from {
    opacity: 0;
    transform: translateY(14px) scale(0.94);
  }
}
</style>
