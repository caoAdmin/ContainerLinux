<script setup lang="ts">
/**
 * 真机性能 HUD
 *
 * 只在 `?hud=1` 时挂载（见 App.vue）。桌面 DevTools 的 FPS 面板测的是
 * 桌面 GPU，手机上的瓶颈（backdrop 离屏缓冲 + SVG 滤镜链）根本不在同一量级，
 * 所以把尺子直接放到设备上：实时帧率、最长帧、长任务、玻璃层数、当前档位，
 * 并且能一键在 high / low / off 之间切换，当场看差值。
 */
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { perfTier, setPerfTier } from '@/utils/perfTier'
import type { PerfTier } from '@/utils/perfTier'
import { useCosmicStore } from '@/stores/cosmic'

const fps = ref(0)
const p95 = ref(0)
const worst = ref(0)
const longTasks = ref(0)
const glass = ref(0)
const nodes = ref(0)
const visible = ref(true)

let raf = 0
let frames: number[] = []
let last = 0
let lastPaint = 0

function loop(now: number) {
  if (last) {
    const dt = now - last
    if (dt < 500) frames.push(dt)
  }
  last = now
  if (now - lastPaint > 500) {
    lastPaint = now
    const f = frames
    frames = []
    if (f.length) {
      f.sort((a, b) => a - b)
      const sum = f.reduce((a, b) => a + b, 0)
      fps.value = Math.round((1000 / (sum / f.length)) * 10) / 10
      p95.value = Math.round(f[Math.floor(f.length * 0.95)] ?? 0)
      worst.value = Math.round(f[f.length - 1] ?? 0)
    }
    nodes.value = document.querySelectorAll('*').length
  }
  raf = requestAnimationFrame(loop)
}

let po: PerformanceObserver | null = null

function countGlass() {
  let n = 0
  document.querySelectorAll<HTMLElement>('*').forEach((el) => {
    const cs = getComputedStyle(el)
    const bf = cs.backdropFilter || (cs as unknown as { webkitBackdropFilter?: string }).webkitBackdropFilter
    if (bf && bf !== 'none') n++
  })
  glass.value = n
}

const store = useCosmicStore()
const flatOn = computed(() => store.settings.glassMode === 'flat')

/* 档位与材质是两个维度，但对使用者来说就是同一件事：玻璃怎么画。
   点 flat 切「无玻璃」，点回任何一档就自动恢复磨砂。 */
function pick(t: PerfTier) {
  if (flatOn.value) store.settings.glassMode = 'frosted'
  setPerfTier(t)
}
function toggleFlat() {
  store.settings.glassMode = flatOn.value ? 'frosted' : 'flat'
}

onMounted(() => {
  raf = requestAnimationFrame(loop)
  try {
    po = new PerformanceObserver((list) => {
      longTasks.value += list.getEntries().length
    })
    po.observe({ entryTypes: ['longtask'] })
  } catch {
    /* 部分内核不支持 longtask */
  }
  window.setTimeout(countGlass, 1200)
})

onBeforeUnmount(() => {
  cancelAnimationFrame(raf)
  po?.disconnect()
})
</script>

<template>
  <div v-if="visible" class="gg-hud" @click.stop>
    <div class="gg-hud-row gg-hud-main">
      <b>{{ fps }}</b><span>fps</span>
      <em>p95 {{ p95 }}ms</em>
    </div>
    <div class="gg-hud-row">
      tier {{ perfTier }} · 玻璃 {{ glass }} · 节点 {{ nodes }} · 长任务 {{ longTasks }}
    </div>
    <div class="gg-hud-row gg-hud-btns">
      <button v-for="t in (['high', 'low', 'off'] as PerfTier[])" :key="t"
              :class="{ on: perfTier === t && !flatOn }" @click="pick(t)">{{ t }}</button>
      <button :class="{ on: flatOn }" @click="toggleFlat">flat</button>
      <button @click="countGlass">↻</button>
      <button @click="visible = false">×</button>
    </div>
  </div>
</template>

<style scoped>
.gg-hud {
  position: fixed;
  left: 8px;
  /* 顶部留给状态胶囊，落到底部 Dock 上方 */
  bottom: 96px;
  z-index: 2147483000;
  padding: 7px 9px;
  border-radius: 10px;
  background: rgba(0, 0, 0, 0.72);
  color: #fff;
  font: 11px/1.45 ui-monospace, 'SF Mono', Consolas, monospace;
  backdrop-filter: blur(10px);
  user-select: none;
  pointer-events: auto;
}
.gg-hud-row { display: flex; align-items: baseline; gap: 5px; white-space: nowrap; }
.gg-hud-main b { font-size: 18px; line-height: 1; }
.gg-hud-main em { font-style: normal; opacity: 0.62; font-size: 10px; }
.gg-hud-btns { gap: 4px; margin-top: 5px; }
.gg-hud-btns button {
  padding: 2px 7px;
  border-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.24);
  background: transparent;
  color: #fff;
  font: inherit;
  cursor: pointer;
}
.gg-hud-btns button.on { background: rgba(255, 255, 255, 0.9); color: #000; border-color: transparent; }
</style>
