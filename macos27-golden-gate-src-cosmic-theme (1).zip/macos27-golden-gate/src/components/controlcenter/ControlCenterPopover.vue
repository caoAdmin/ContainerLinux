<script setup lang="ts">
/**
 * 控制中心 Popover
 */
import { ref } from 'vue'
import { useSystemStore } from '@/stores/system'
import Icon from '@/components/common/Icon.vue'

const sys = useSystemStore()
const music = ref({ playing: false, title: 'Golden Hour', artist: 'JVKE', progress: 0.35 })
function togglePlay() { music.value.playing = !music.value.playing }
</script>

<template>
  <div
    class="fixed rounded-[12px] p-3 w-[340px] text-[13px]"
    style="top:28px; right:8px; z-index:9500;"
    :style="{
      background: 'var(--glass-bg)',
      backdropFilter: 'blur(24px) saturate(180%)',
      WebkitBackdropFilter: 'blur(24px) saturate(180%)',
      border: '1px solid var(--glass-border)',
      boxShadow: '0 20px 40px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.35)'
    }"
    @click.stop
  >
    <div class="grid grid-cols-2 gap-2 mb-2">
      <button class="rounded-[10px] p-2 text-left flex items-center gap-2 transition-colors"
        :class="sys.settings.wifiEnabled ? 'bg-[#0A84FF] text-white' : 'bg-white/15 text-current'"
        style="height:56px;" @click="sys.settings.wifiEnabled = !sys.settings.wifiEnabled">
        <Icon name="ri-wifi-line" :size="18" />
        <div class="flex-1 min-w-0">
          <div class="text-[12px] font-medium truncate">Wi‑Fi</div>
          <div class="text-[11px] opacity-80 truncate">{{ sys.settings.wifiEnabled ? '家庭网络' : '关闭' }}</div>
        </div>
      </button>
      <button class="rounded-[10px] p-2 text-left flex items-center gap-2 transition-colors"
        :class="sys.settings.bluetoothEnabled ? 'bg-[#0A84FF] text-white' : 'bg-white/15 text-current'"
        style="height:56px;" @click="sys.settings.bluetoothEnabled = !sys.settings.bluetoothEnabled">
        <Icon name="ri-bluetooth-line" :size="18" />
        <div class="flex-1 min-w-0">
          <div class="text-[12px] font-medium truncate">蓝牙</div>
          <div class="text-[11px] opacity-80 truncate">{{ sys.settings.bluetoothEnabled ? '已打开' : '关闭' }}</div>
        </div>
      </button>
      <button class="rounded-[10px] p-2 text-left flex items-center gap-2 transition-colors"
        :class="sys.settings.airdropEnabled ? 'bg-[#0A84FF] text-white' : 'bg-white/15 text-current'"
        style="height:56px;" @click="sys.settings.airdropEnabled = !sys.settings.airdropEnabled">
        <Icon name="airdrop" :size="18" />
        <div class="flex-1 min-w-0">
          <div class="text-[12px] font-medium truncate">隔空投送</div>
          <div class="text-[11px] opacity-80 truncate">{{ sys.settings.airdropEnabled ? '所有人' : '接收关闭' }}</div>
        </div>
      </button>
      <button class="rounded-[10px] p-2 text-left flex items-center gap-2 transition-colors"
        :class="sys.settings.focusEnabled ? 'bg-[#B560F0] text-white' : 'bg-white/15 text-current'"
        style="height:56px;" @click="sys.settings.focusEnabled = !sys.settings.focusEnabled">
        <Icon name="ri-moon-line" :size="18" />
        <div class="flex-1 min-w-0">
          <div class="text-[12px] font-medium truncate">专注模式</div>
          <div class="text-[11px] opacity-80 truncate">{{ sys.settings.focusEnabled ? '勿扰模式' : '关闭' }}</div>
        </div>
      </button>
    </div>

    <div class="rounded-[10px] p-2 bg-white/15 mb-2 flex items-center gap-2">
      <Icon name="brightness" :size="16" />
      <input type="range" min="0" max="1" step="0.01" v-model.number="sys.settings.brightness" class="gg-slider flex-1" />
    </div>
    <div class="rounded-[10px] p-2 bg-white/15 mb-2 flex items-center gap-2">
      <Icon :name="sys.settings.volume > 0 ? 'volume' : 'volume-muted'" :size="16" />
      <input type="range" min="0" max="1" step="0.01" v-model.number="sys.settings.volume" class="gg-slider flex-1" />
    </div>

    <button class="w-full rounded-[10px] p-2 mb-2 flex items-center gap-2 bg-white/15" style="height:44px;" @click="sys.toggleDarkMode">
      <Icon :name="sys.settings.darkMode ? 'moon' : 'sun'" :size="18" />
      <span class="text-[12px] font-medium">深色模式{{ sys.settings.darkMode ? '已开启' : '已关闭' }}</span>
    </button>

    <div class="rounded-[10px] p-2 bg-white/15">
      <div class="flex items-center gap-2">
        <div class="w-9 h-9 rounded-md flex items-center justify-center text-white" style="background:linear-gradient(135deg,#ff9a5a,#d5542d)">
          <Icon name="ri-music-2-line" :size="16" />
        </div>
        <div class="flex-1 min-w-0">
          <div class="text-[12px] font-medium truncate">{{ music.title }}</div>
          <div class="text-[11px] opacity-70 truncate">{{ music.artist }}</div>
        </div>
        <button class="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center" @click="togglePlay">
          <Icon :name="music.playing ? 'pause' : 'play'" :size="12" />
        </button>
      </div>
      <div class="mt-2 h-1 rounded-full bg-white/20 overflow-hidden">
        <div class="h-full bg-white/70" :style="{ width: music.progress * 100 + '%' }" />
      </div>
    </div>
  </div>
</template>

<style scoped>
.gg-slider{-webkit-appearance:none;appearance:none;height:4px;background:rgba(255,255,255,.3);border-radius:999px;}
.gg-slider::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 2px 6px rgba(0,0,0,.3);cursor:pointer;}
</style>
