<script setup lang="ts">
/**
 * 通知中心（右侧滑入）
 */
import { computed } from 'vue'
import { useUIStore } from '@/stores/ui'
import { formatDateTime } from '@/utils'

const ui = useUIStore()
const now = computed(() => formatDateTime(new Date()))
const notifications = [
  { id: 'n1', app: '邮件', title: '设计周报', summary: '团队发布了本周设计评审纪要', time: '09:24' },
  { id: 'n2', app: '信息', title: '张三', summary: '晚点到，大概 5 分钟', time: '08:51' },
  { id: 'n3', app: '日历', title: '产品评审 · 提醒', summary: '10:30 会议室 A', time: '昨天' }
]
</script>

<template>
  <Transition name="nc-slide">
    <div v-if="ui.notificationCenterOpen" class="fixed top-0 right-0 bottom-0 w-[340px] pt-[28px] px-3 pb-3 overflow-y-auto"
      style="z-index:9550;"
      :style="{
        background:'var(--glass-bg)',
        backdropFilter:'blur(28px) saturate(180%)',
        WebkitBackdropFilter:'blur(28px) saturate(180%)',
        borderLeft:'1px solid var(--glass-border)',
        boxShadow:'-10px 0 40px rgba(0,0,0,0.2)'
      }" @click.stop>
      <div class="px-2 pt-4 pb-3">
        <div class="text-[12px] opacity-70">{{ now.weekday }}</div>
        <div class="text-[32px] font-semibold leading-none">{{ now.month }}{{ now.day }}日</div>
      </div>
      <div class="rounded-[12px] p-3 mb-2 text-white relative overflow-hidden" style="background:linear-gradient(135deg,#5aa9ff,#2f78d6);">
        <div class="flex items-end justify-between">
          <div>
            <div class="text-[12px] opacity-90">济南</div>
            <div class="text-[28px] font-light leading-none mt-1">22°</div>
            <div class="text-[12px] mt-1 opacity-90">晴 · 最高 25° 最低 16°</div>
          </div>
          <div class="text-[28px]">☀️</div>
        </div>
      </div>
      <div class="rounded-[12px] p-3 mb-2" style="background:rgba(255,255,255,0.12); border:1px solid var(--glass-border);">
        <div class="text-[11px] uppercase tracking-wide opacity-60 mb-1">今日日程</div>
        <div class="flex gap-2 py-1 border-t border-white/10 mt-1 pt-2">
          <div class="w-1 h-10 rounded-full" style="background:#0A84FF;" />
          <div class="flex-1"><div class="text-[13px] font-medium">产品评审</div><div class="text-[11px] opacity-70">10:30 - 11:30 · 会议室 A</div></div>
        </div>
        <div class="flex gap-2 py-1">
          <div class="w-1 h-10 rounded-full" style="background:#FF9F0A;" />
          <div class="flex-1"><div class="text-[13px] font-medium">午餐</div><div class="text-[11px] opacity-70">12:00 · 楼下</div></div>
        </div>
      </div>
      <div class="text-[11px] uppercase tracking-wide opacity-60 px-2 mt-2 mb-1">通知</div>
      <div v-for="n in notifications" :key="n.id" class="rounded-[12px] p-3 mb-2" style="background:rgba(255,255,255,0.12); border:1px solid var(--glass-border);">
        <div class="flex items-center gap-2 mb-1">
          <div class="w-5 h-5 rounded bg-[#0A84FF]/80" />
          <div class="text-[11px] opacity-80">{{ n.app }}</div>
          <div class="ml-auto text-[11px] opacity-60">{{ n.time }}</div>
        </div>
        <div class="text-[13px] font-medium">{{ n.title }}</div>
        <div class="text-[12px] opacity-80 mt-0.5">{{ n.summary }}</div>
      </div>
      <button class="w-full text-center text-[12px] opacity-70 py-2 hover:opacity-100" @click="ui.closeAll()">关闭</button>
    </div>
  </Transition>
</template>

<style scoped>
.nc-slide-enter-active,.nc-slide-leave-active{transition:transform .28s cubic-bezier(0.25,.1,.25,1),opacity .28s;}
.nc-slide-enter-from,.nc-slide-leave-to{transform:translateX(100%);opacity:.3;}
</style>
