/**
 * 桌面壁纸 —— Canvas 程序化绘制 Golden Gate Day/Evening
 * - 金橙渐变天空 + 山脊剪影 + 桥塔与悬索
 * - 随时间缓慢变色（傍晚/日间可切换）
 *
 * 性能约定（重要）：
 *  1. canvas 的 width/height 只在窗口尺寸真的变化时赋值 —— 赋值会重新分配
 *     整个绘制缓冲区并清空画布，每帧赋值等于每帧重建一次位图。
 *  2. 场景是静态的，唯一的动画是周期约 16s 的「呼吸」明暗（幅度 0.06，
 *     肉眼几乎不可察）。因此用 ~6fps 的低频定时器重绘，而不是 60fps。
 *  3. 页面不可见 / 用户开启「减少动效」时完全停止重绘。
 */
import { ref, onMounted, onUnmounted, watch } from 'vue'
import { useSystemStore } from '@/stores/system'

const sys = useSystemStore()
const canvasRef = ref<HTMLCanvasElement | null>(null)

let ctx: CanvasRenderingContext2D | null = null
/** 逻辑尺寸（CSS px），只在变化时重建缓冲区 */
let cw = 0
let ch = 0
let t = 0
let lastTs = 0
let timer = 0
let stopped = true

/** 呼吸重绘间隔（ms）。16s 周期的 0.06 幅度，6fps 完全看不出台阶。 */
const FRAME_MS = 160

const reduceMotion =
  typeof window !== 'undefined' &&
  typeof window.matchMedia === 'function' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

function draw() {
  const c = canvasRef.value
  if (!c || !ctx) return
  const w = c.width
  const h = c.height
  if (!w || !h) return

  const isEvening = sys.settings.wallpaper === 'golden-gate-evening'
  // 颜色随时间轻微呼吸（模拟云/光变化）
  const breathe = Math.sin(t * 0.0004) * 0.06

  // 天空渐变
  const sky = ctx.createLinearGradient(0, 0, 0, h)
  if (isEvening) {
    sky.addColorStop(0, `rgb(${255 - breathe * 40}, ${140 + breathe * 30}, ${80})`)
    sky.addColorStop(0.45, `rgb(${255 - breathe * 30}, ${100 + breathe * 40}, ${50})`)
    sky.addColorStop(0.75, `rgb(${180 - breathe * 20}, ${70}, ${90})`)
    sky.addColorStop(1, `rgb(${60}, ${30}, ${60})`)
  } else {
    sky.addColorStop(0, `rgb(${130 + breathe * 20}, ${190}, ${230})`)
    sky.addColorStop(0.6, `rgb(${220 + breathe * 10}, ${200}, ${160})`)
    sky.addColorStop(1, `rgb(${130}, ${100}, ${80})`)
  }
  ctx.fillStyle = sky
  ctx.fillRect(0, 0, w, h)

  // 太阳/光团
  const sunX = w * (isEvening ? 0.55 : 0.7)
  const sunY = h * (isEvening ? 0.55 : 0.3)
  const sunR = Math.min(w, h) * 0.18
  const glow = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, sunR)
  if (isEvening) {
    glow.addColorStop(0, 'rgba(255,220,160,0.9)')
    glow.addColorStop(0.3, 'rgba(255,160,90,0.5)')
    glow.addColorStop(1, 'rgba(255,120,60,0)')
  } else {
    glow.addColorStop(0, 'rgba(255,255,240,0.9)')
    glow.addColorStop(0.4, 'rgba(255,230,180,0.4)')
    glow.addColorStop(1, 'rgba(255,255,255,0)')
  }
  ctx.fillStyle = glow
  ctx.fillRect(0, 0, w, h)

  // 远山（多层剪影）
  const mountain = (yBase: number, amp: number, color: string, layers: number) => {
    if (!ctx) return
    ctx.fillStyle = color
    ctx.beginPath()
    ctx.moveTo(0, h)
    for (let x = 0; x <= w; x += 8) {
      const y =
        yBase +
        Math.sin(x * 0.003 + layers) * amp +
        Math.sin(x * 0.01 + layers * 1.7) * amp * 0.3
      ctx.lineTo(x, y)
    }
    ctx.lineTo(w, h)
    ctx.closePath()
    ctx.fill()
  }
  if (isEvening) {
    mountain(h * 0.7, 60, 'rgba(60,30,50,0.7)', 1)
    mountain(h * 0.75, 50, 'rgba(40,20,40,0.85)', 2)
    mountain(h * 0.82, 40, 'rgba(20,15,30,1)', 3)
  } else {
    mountain(h * 0.65, 70, 'rgba(120,110,100,0.6)', 1)
    mountain(h * 0.75, 60, 'rgba(80,70,70,0.8)', 2)
    mountain(h * 0.84, 40, 'rgba(40,40,50,1)', 3)
  }

  // 金门大桥
  const bridgeY = h * 0.72
  const bridgeLeft = w * 0.1
  const bridgeRight = w * 0.9
  const bridgeW = bridgeRight - bridgeLeft

  // 桥面
  ctx.fillStyle = 'rgba(40,20,20,0.9)'
  ctx.fillRect(bridgeLeft, bridgeY, bridgeW, 8)
  // 桥塔
  const towers = [bridgeLeft + bridgeW * 0.25, bridgeLeft + bridgeW * 0.75]
  towers.forEach((tx) => {
    if (!ctx) return
    ctx.fillStyle = 'rgba(80,25,15,0.95)'
    ctx.fillRect(tx - 10, bridgeY - 180, 20, 188)
    // 横梁
    ctx.fillRect(tx - 18, bridgeY - 150, 36, 8)
    ctx.fillRect(tx - 18, bridgeY - 80, 36, 8)
  })
  // 主悬索
  ctx.strokeStyle = 'rgba(60,20,15,0.9)'
  ctx.lineWidth = 3
  ctx.beginPath()
  ctx.moveTo(bridgeLeft, bridgeY)
  ctx.quadraticCurveTo(bridgeLeft + bridgeW * 0.25, bridgeY - 190, bridgeLeft + bridgeW * 0.5, bridgeY)
  ctx.quadraticCurveTo(bridgeLeft + bridgeW * 0.75, bridgeY - 190, bridgeRight, bridgeY)
  ctx.stroke()
  // 悬索到桥面的垂线
  ctx.strokeStyle = 'rgba(40,15,10,0.7)'
  ctx.lineWidth = 1
  for (let i = 0; i <= 24; i++) {
    const x = bridgeLeft + (bridgeW * i) / 24
    // 近似主索的 y 坐标
    const ratio = i / 24
    const sag = Math.sin(ratio * Math.PI) * 180
    const yTop = bridgeY - sag
    ctx.beginPath()
    ctx.moveTo(x, yTop)
    ctx.lineTo(x, bridgeY)
    ctx.stroke()
  }

  // 水面（仅下半部分，桥以下）
  const water = ctx.createLinearGradient(0, bridgeY + 8, 0, h)
  if (isEvening) {
    water.addColorStop(0, 'rgba(80,30,40,0.9)')
    water.addColorStop(1, 'rgba(20,10,25,1)')
  } else {
    water.addColorStop(0, 'rgba(100,120,150,0.85)')
    water.addColorStop(1, 'rgba(30,50,80,1)')
  }
  ctx.fillStyle = water
  ctx.fillRect(0, bridgeY + 8, w, h - bridgeY)

  // 水面波光
  ctx.strokeStyle = isEvening ? 'rgba(255,180,120,0.25)' : 'rgba(255,240,210,0.4)'
  ctx.lineWidth = 1
  for (let i = 0; i < 20; i++) {
    const y = bridgeY + 20 + i * ((h - bridgeY - 20) / 20)
    const offset = Math.sin(t * 0.001 + i) * 30
    ctx.beginPath()
    ctx.moveTo(w * 0.2 + offset, y)
    ctx.lineTo(w * 0.8 + offset, y)
    ctx.stroke()
  }
}

function resize() {
  const c = canvasRef.value
  if (!c) return
  const w = Math.max(1, window.innerWidth)
  const h = Math.max(1, window.innerHeight)
  // 只有真的变了才重建缓冲区（赋值会清空并重新分配位图）
  if (w !== cw || h !== ch) {
    cw = w
    ch = h
    c.width = w
    c.height = h
    if (!ctx) ctx = c.getContext('2d')
    draw()
  }
}

/** 低频重绘：用真实时间推进呼吸相位，与帧率解耦 */
function loop(ts: number) {
  timer = 0
  if (stopped) return
  if (lastTs) t += Math.min(120, ts - lastTs)
  lastTs = ts
  draw()
  timer = window.setTimeout(() => {
    timer = 0
    requestAnimationFrame(loop)
  }, FRAME_MS)
}

function start() {
  if (stopped && !reduceMotion) {
    stopped = false
    lastTs = 0
    timer = window.setTimeout(() => {
      timer = 0
      requestAnimationFrame(loop)
    }, FRAME_MS)
  }
}

function stop() {
  stopped = true
  if (timer) {
    window.clearTimeout(timer)
    timer = 0
  }
}

function onVisibility() {
  if (document.hidden) stop()
  else start()
}

onMounted(() => {
  const c = canvasRef.value
  if (c) ctx = c.getContext('2d')
  resize()
  start()
  window.addEventListener('resize', resize)
  document.addEventListener('visibilitychange', onVisibility)
})

onUnmounted(() => {
  stop()
  window.removeEventListener('resize', resize)
  document.removeEventListener('visibilitychange', onVisibility)
})

// 切壁纸：立即重画一次静态帧（呼吸相位不受影响）
watch(
  () => sys.settings.wallpaper,
  () => draw()
)
