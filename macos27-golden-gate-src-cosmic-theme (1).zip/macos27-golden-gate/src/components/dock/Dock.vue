<script setup lang="ts">
/**
 * 底部 Dock：
 * - 悬停放大（magnifyScale / magnifyOffset）
 * - 点击打开 App / 启动台 / 废纸篓
 * - 0.45s 弹跳动画
 * - 运行中圆点、名字标签
 * - 自动隐藏（dockAutoHide）
 * - 右键菜单
 * - 长按 0.25s 后可拖拽排序 / 拖出删除
 */
import { ref, computed, onUnmounted } from 'vue'
import { useDockStore } from '@/stores/dock'
import { useWindowStore } from '@/stores/windows'
import { useSystemStore } from '@/stores/system'
import { useUIStore, type ContextMenuItem } from '@/stores/ui'
import { getAppById } from '@/utils/appRegistry'
import { magnifyScale, magnifyOffset } from '@/utils'
import type { DockItem } from '@/types'
import Icon from '@/components/common/Icon.vue'

const dock = useDockStore()
const winStore = useWindowStore()
const sys = useSystemStore()
const ui = useUIStore()

const dockRef = ref<HTMLDivElement | null>(null)
const itemRefs = ref<Array<HTMLDivElement | null>>([])
const mouseInDock = ref(false)
const mouseX = ref(0)
/* 名字标签：位置/显隐直接写 DOM，不参与渲染 —— 原来每次 mousemove 都换一个
   reactive 对象，并且在**渲染函数里**调 dockRef.getBoundingClientRect()（强制布局），
   等于每帧一次「读布局 → 写样式」抖动，是 Dock 悬停掉帧的主因。 */
const tipEl = ref<HTMLElement | null>(null)
const tipName = ref('')
let tipShown = false
let tipX = -999
function syncTip(rect: DOMRect, clientX: number, name: string) {
  const el = tipEl.value
  const show = !!name
  if (el) {
    if (show !== tipShown) {
      tipShown = show
      el.style.display = show ? '' : 'none'
    }
    if (show) {
      if (Math.abs(tipX - clientX) >= 1) { tipX = clientX; el.style.left = clientX + 'px' }
      el.style.top = rect.top - 26 + 'px'
    }
  }
  if (show && name !== tipName.value) tipName.value = name
}
const bouncing = ref<Set<string>>(new Set())

// 长按拖拽排序
const pressTimer = ref<ReturnType<typeof setTimeout> | null>(null)
const dragging = ref<{ fromIdx: number } | null>(null)
const dragMouseY = ref(0)

const baseSize = computed(() => Math.round(sys.settings.dockSize))
const maxScale = computed(() => (sys.settings.dockMagnification ? sys.settings.dockMagnificationLevel : 1))
const influence = computed(() => baseSize.value * 2.4)
const gap = 4
const sidePad = 8

// 计算每个图标中心 X（在 Dock 坐标系内）以及对应 scale/offset
const layout = computed(() => {
  const n = dock.items.length
  // 两阶段布局：先根据近似中心计算 scale，再累计位置
  const sizes = new Array(n).fill(baseSize.value)
  const scales = new Array(n).fill(1)
  if (mouseInDock.value && sys.settings.dockMagnification) {
    // 近似鼠标相对每个槽位中心
    for (let i = 0; i < n; i++) {
      const approxCenter = sidePad + baseSize.value / 2 + i * (baseSize.value + gap)
      scales[i] = magnifyScale(approxCenter, mouseX.value, baseSize.value, maxScale.value, influence.value)
      sizes[i] = baseSize.value * scales[i]
    }
  }
  // 累计真实中心 X
  const centers: number[] = []
  let acc = sidePad
  for (let i = 0; i < n; i++) {
    centers.push(acc + sizes[i] / 2)
    acc += sizes[i] + gap
  }
  const totalWidth = acc - gap + sidePad

  // 若鼠标在场，用真实中心再次修正 scale
  if (mouseInDock.value && sys.settings.dockMagnification) {
    for (let iter = 0; iter < 2; iter++) {
      for (let i = 0; i < n; i++) {
        scales[i] = magnifyScale(centers[i], mouseX.value, baseSize.value, maxScale.value, influence.value)
        sizes[i] = baseSize.value * scales[i]
      }
      let acc2 = sidePad
      for (let i = 0; i < n; i++) {
        centers[i] = acc2 + sizes[i] / 2
        acc2 += sizes[i] + gap
      }
    }
  }
  // translateY：抛物线凸起
  const offsets = new Array(n).fill(0)
  if (mouseInDock.value && sys.settings.dockMagnification) {
    for (let i = 0; i < n; i++) {
      offsets[i] = magnifyOffset(centers[i], mouseX.value, baseSize.value, maxScale.value, influence.value * 0.8)
      const dist = Math.abs(mouseX.value - centers[i])
      if (dist < influence.value) {
        const t = dist / influence.value
        offsets[i] -= (maxScale.value - 1) * baseSize.value * 0.5 * (0.5 * (1 + Math.cos(t * Math.PI)))
      }
    }
  }
  return { scales, sizes, centers, totalWidth, offsets }
})

/* 指针跟随：mousemove 在一帧里可能连发多次（高刷鼠标 / 事件合并），
   每发一次就写一次 mouseX（模板依赖）会让整条 Dock 重排 + 玻璃面重新模糊。
   处理成：
   · rAF 合并 —— 每帧最多一次渲染；
   · 30fps 节流 + 1.5px 量化 —— 放大是连续渐变，配合元素自身 0.15s 过渡，
     视觉上完全看不出台阶，但把「每秒重排+重糊」的次数砍掉一半以上。
   命中检测仍用真实指针坐标，不量化。 */
const MOVE_MIN_MS = 32
const MOVE_MIN_PX = 1.5
let moveRAF = 0
let lastMoveAt = 0
let dropTimer = 0
let pendingMove: { x: number; y: number } | null = null
function onDockMouseMove(e: MouseEvent) {
  pendingMove = { x: e.clientX, y: e.clientY }
  if (!moveRAF) moveRAF = requestAnimationFrame(applyDockMove)
}
function applyDockMove() {
  moveRAF = 0
  const p = pendingMove
  const el = dockRef.value
  if (!p || !el) return
  const rect = el.getBoundingClientRect()
  const rel = p.x - rect.left
  const now = performance.now()
  const gap = now - lastMoveAt
  if (Math.abs(rel - mouseX.value) >= MOVE_MIN_PX) {
    if (gap >= MOVE_MIN_MS) {
      lastMoveAt = now
      mouseX.value = rel
      pendingMove = null
    } else {
      // 节流窗口内：把「最后一帧」补上，避免指针停下后放大值卡在半路
      window.clearTimeout(dropTimer)
      dropTimer = window.setTimeout(() => {
        if (!moveRAF) moveRAF = requestAnimationFrame(applyDockMove)
      }, MOVE_MIN_MS - gap)
    }
  } else {
    pendingMove = null
  }
  dock.setMousePos(p.x, p.y)

  // tooltip 用真实指针坐标，且复用同一份 rect（不再第二次 getBoundingClientRect）
  const hit = findHoverItemAt(rect, p.x)
  const name = hit && hit.appId !== 'divider' ? (getAppById(hit.appId)?.name ?? hit.name) : ''
  syncTip(rect, p.x, name)
}

onUnmounted(() => {
  if (moveRAF) cancelAnimationFrame(moveRAF)
  window.clearTimeout(dropTimer)
})

/** 命中检测：复用调用方已经取到的矩形（少一次强制布局） */
function findHoverItemAt(rect: DOMRect, clientX: number): DockItem | null {
  const relX = clientX - rect.left
  // 粗略查找
  let best: DockItem | null = null
  let bestDist = Infinity
  for (let i = 0; i < dock.items.length; i++) {
    const d = Math.abs(layout.value.centers[i] - relX)
    if (d < layout.value.sizes[i] / 2 && d < bestDist) {
      bestDist = d
      best = dock.items[i]
    }
  }
  return best
}

function onDockEnter() {
  mouseInDock.value = true
}
function onDockLeave() {
  mouseInDock.value = false
  tipShown = false
  if (tipEl.value) tipEl.value.style.display = 'none'
  if (sys.settings.dockAutoHide) {
    // handled by CSS transition via bottom offset
  }
}

function onItemClick(it: DockItem) {
  if (it.appId === 'divider') return
  if (it.appId === 'launchpad') {
    ui.toggleLaunchpad()
    return
  }
  if (it.appId === 'trash') {
    winStore.openWindow({ appId: 'trash' })
    return
  }
  const existing = winStore.findWindowByApp(it.appId)
  if (existing) {
    winStore.activateWindow(existing.id)
    if (existing.minimized) existing.minimized = false
  } else {
    bouncing.value.add(it.appId)
    dock.setRunning(it.appId, true)
    setTimeout(() => {
      winStore.openWindow({ appId: it.appId })
    }, 120)
    setTimeout(() => bouncing.value.delete(it.appId), 600)
  }
}

function onItemMouseDown(e: MouseEvent, it: DockItem, idx: number) {
  if (e.button !== 0) return
  if (it.appId === 'divider' || it.appId === 'trash') return
  dragMouseY.value = e.clientY
  pressTimer.value = setTimeout(() => {
    dragging.value = { fromIdx: idx }
  }, 250)
  window.addEventListener('mousemove', onDragMove)
  window.addEventListener('mouseup', onDragUp)
}

function onDragMove(e: MouseEvent) {
  if (!dragging.value || !dockRef.value) return
  const rect = dockRef.value.getBoundingClientRect()
  const relX = e.clientX - rect.left
  // 找目标位置
  let toIdx = 0
  for (let i = 0; i < dock.items.length; i++) {
    if (relX < layout.value.centers[i]) {
      toIdx = i
      break
    }
    toIdx = i
  }
  if (e.clientY < dragMouseY.value - 180) {
    dock.removeFromDock(dock.items[dragging.value.fromIdx].appId)
    dragging.value = null
    window.removeEventListener('mousemove', onDragMove)
    window.removeEventListener('mouseup', onDragUp)
    return
  }
  if (toIdx !== dragging.value.fromIdx) {
    dock.reorder(dragging.value.fromIdx, toIdx)
    dragging.value.fromIdx = toIdx
  }
}

function onDragUp() {
  if (pressTimer.value) clearTimeout(pressTimer.value)
  pressTimer.value = null
  dragging.value = null
  window.removeEventListener('mousemove', onDragMove)
  window.removeEventListener('mouseup', onDragUp)
}

function onItemContextMenu(e: MouseEvent, it: DockItem) {
  e.preventDefault()
  e.stopPropagation()
  const isRunning = it.isRunning
  const items: ContextMenuItem[] = [
    { id: 'open', label: '打开', action: () => onItemClick(it) },
    { id: 'sep1', label: '', separator: true },
    { id: 'options', label: '选项', submenu: [
      { id: 'keep', label: it.isPersistent ? '在程序坞中保留' : '添加到程序坞',
        action: () => { /* 简易标记 */ } },
      { id: 'login', label: '登录时打开', disabled: true },
      { id: 'sep', label: '', separator: true },
      { id: 'finder', label: '在访达中显示', disabled: true }
    ]},
    { id: 'sep2', label: '', separator: true },
    { id: 'quit', label: '退出', disabled: !isRunning, action: () => {
      const w = winStore.findWindowByApp(it.appId)
      if (w) winStore.closeWindow(w.id)
      dock.setRunning(it.appId, false)
    }}
  ]
  ui.showContextMenu(e.clientX, e.clientY, items)
}

const dockBottom = computed(() => (sys.settings.dockAutoHide && !mouseInDock.value ? -80 : 4))
</script>

<template>
  <div
    ref="dockRef"
    class="fixed left-1/2 flex items-end dock-glass"
    :style="{
      bottom: dockBottom + 'px',
      width: layout.totalWidth + 'px',
      transform: 'translateX(-50%)',
      zIndex: 8000,
      padding: `${sidePad - 4}px ${sidePad}px`,
      borderRadius: '20px',
      transition: 'bottom .28s cubic-bezier(0.25,.1,.25,1)'
    }"
    @mousemove="onDockMouseMove"
    @mouseenter="onDockEnter"
    @mouseleave="onDockLeave"
  >
    <div
      v-for="(it, idx) in dock.items"
      :key="it.id"
      :ref="(el: any) => (itemRefs[idx] = el as HTMLDivElement)"
      class="relative flex items-end justify-center cursor-pointer"
      role="button"
      :aria-label="it.appId === 'divider' ? '分隔线' : it.name"
      :tabindex="it.appId === 'divider' ? -1 : 0"
      :class="bouncing.has(it.appId) ? 'dock-bounce' : ''"
      :style="{
        width: layout.sizes[idx] + 'px',
        height: baseSize + 'px',
        transform: `translateY(${layout.offsets[idx]}px)`,
        transition: mouseInDock ? 'transform .15s ease' : 'transform .25s ease'
      }"
      @click="onItemClick(it)"
      @mousedown="onItemMouseDown($event, it, idx)"
      @contextmenu="onItemContextMenu($event, it)"
    >
      <!-- 运行中圆点 -->
      <span
        v-if="it.isRunning && it.appId !== 'divider'"
        class="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-black/70 dark:bg-white/80"
      />
      <template v-if="it.appId === 'divider'">
        <div class="w-px self-stretch my-1" style="background: rgba(0,0,0,0.25); border-right:1px solid rgba(255,255,255,0.3);" />
      </template>
      <template v-else>
        <Icon :name="it.icon" :size="Math.round(layout.sizes[idx] - 4)" />
      </template>
    </div>

    <!-- 名字标签 -->
    <Teleport to="body">
      <div
        ref="tipEl"
        class="fixed pointer-events-none px-2 py-1 rounded-[6px] text-[12px] text-white z-[8200]"
        style="display:none; transform: translateX(-50%); background: rgba(0,0,0,0.72); backdrop-filter: blur(10px);"
      >{{ tipName }}</div>
    </Teleport>
  </div>
</template>

<style scoped>
@keyframes dock-bounce {
  0% { transform: translateY(0); }
  25% { transform: translateY(-20px); }
  50% { transform: translateY(0); }
  75% { transform: translateY(-20px); }
  100% { transform: translateY(0); }
}
.dock-bounce {
  animation: dock-bounce 0.45s ease;
  transform-origin: bottom center;
}
.dock-glass {
  /* backdrop-filter / background / box-shadow 全部由全局样式提供（含 shuding 边缘折射滤镜） */
}
</style>
