<script setup lang="ts">
/**
 * Launchpad 启动台
 * - 点击 Dock 火箭图标触发：背景变暗模糊，应用网格中心放大
 * - 搜索过滤、分页圆点、键盘方向键、Esc 关闭
 */
import { ref, computed, watch, nextTick, onMounted, onUnmounted } from 'vue'
import { useUIStore } from '@/stores/ui'
import { useDockStore } from '@/stores/dock'
import { useWindowStore } from '@/stores/windows'
import { allApps } from '@/utils/appRegistry'
import Icon from '@/components/common/Icon.vue'

const ui = useUIStore()
const dockStore = useDockStore()
const winStore = useWindowStore()

const searchEl = ref<HTMLInputElement | null>(null)
const query = ref('')
const page = ref(0)
const selectedIdx = ref(0)

const launchApps = computed(() => allApps.filter((a) => a.id !== 'trash'))
const filtered = computed(() => {
  const k = query.value.trim().toLowerCase()
  if (!k) return launchApps.value
  return launchApps.value.filter((a) => a.name.toLowerCase().includes(k) || a.id.includes(k))
})

// 每页 5x8 = 40（简单实现：单页）
const pageCount = computed(() => Math.max(1, Math.ceil(filtered.value.length / 30)))
const pageApps = computed(() => {
  const start = page.value * 30
  return filtered.value.slice(start, start + 30)
})

watch(
  () => ui.launchpadOpen,
  (v) => {
    if (v) {
      query.value = ''; page.value = 0; selectedIdx.value = 0
      nextTick(() => searchEl.value?.focus())
    }
  }
)

function openApp(id: string) {
  ui.closeAll()
  dockStore.setRunning(id, true)
  winStore.openWindow({ appId: id })
}

function onKey(e: KeyboardEvent) {
  if (!ui.launchpadOpen) return
  if (e.key === 'Escape') { ui.closeAll(); return }
  if (e.key === 'ArrowRight') selectedIdx.value = Math.min(selectedIdx.value + 1, pageApps.value.length - 1)
  if (e.key === 'ArrowLeft') selectedIdx.value = Math.max(selectedIdx.value - 1, 0)
  if (e.key === 'ArrowDown') selectedIdx.value = Math.min(selectedIdx.value + 7, pageApps.value.length - 1)
  if (e.key === 'ArrowUp') selectedIdx.value = Math.max(selectedIdx.value - 7, 0)
  if (e.key === 'Enter' && pageApps.value[selectedIdx.value]) {
    openApp(pageApps.value[selectedIdx.value].id)
  }
}

onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <Transition name="lp-fade">
    <div
      v-if="ui.launchpadOpen"
      class="fixed inset-0 z-[9600] flex flex-col items-center pt-20"
      @click.self="ui.closeAll()"
    >
      <div class="absolute inset-0" style="backdrop-filter:blur(40px) saturate(150%); background: rgba(0,0,0,0.2);" />

      <!-- 搜索框 -->
      <div class="relative z-10 mb-6">
        <input
          ref="searchEl"
          v-model="query"
          placeholder="搜索"
          class="w-[280px] h-8 px-3 text-center rounded-[8px] text-[13px] outline-none"
          style="background: rgba(255,255,255,0.15); border:1px solid rgba(255,255,255,0.2); color:#fff;"
        />
      </div>

      <!-- 应用网格 -->
      <div
        class="relative z-10 grid gap-x-8 gap-y-6 px-8"
        style="grid-template-columns: repeat(7, 84px);"
      >
        <button
          v-for="(app, i) in pageApps"
          :key="app.id"
          class="flex flex-col items-center gap-1 text-white/90 text-[12px] group"
          :class="selectedIdx === i ? 'scale-110' : ''"
          @click="openApp(app.id)"
          @mouseenter="selectedIdx = i"
        >
          <div
            class="transition-transform"
            :class="selectedIdx === i ? 'scale-110' : 'group-hover:scale-105'"
          >
            <Icon :name="app.icon" :size="64" />
          </div>
          <span class="drop-shadow">{{ app.name }}</span>
        </button>
      </div>

      <!-- 分页圆点 -->
      <div class="relative z-10 mt-6 flex gap-1.5">
        <div
          v-for="p in pageCount"
          :key="p"
          class="w-1.5 h-1.5 rounded-full transition-colors cursor-pointer"
          :class="page === p - 1 ? 'bg-white' : 'bg-white/40'"
          @click="page = p - 1"
        />
      </div>
    </div>
  </Transition>
</template>

<style scoped>
.lp-fade-enter-active,.lp-fade-leave-active{transition:opacity .28s ease;}
.lp-fade-enter-from,.lp-fade-leave-to{opacity:0;}
.lp-fade-enter-active .relative{animation:lp-pop .3s cubic-bezier(0.25,.1,.25,1);}
@keyframes lp-pop{from{transform:scale(1.05);opacity:0;}to{transform:scale(1);opacity:1;}}
</style>
