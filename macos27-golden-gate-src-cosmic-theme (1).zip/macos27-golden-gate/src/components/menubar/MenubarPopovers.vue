<script setup lang="ts">
/**
 * MenubarPopovers —— 菜单栏下拉小面板
 * 包括电池、Wi-Fi、蓝牙、音量、用户等的快速面板；
 * 控制中心/通知中心用独立组件。
 */
import { useUIStore } from '@/stores/ui'
import { useSystemStore } from '@/stores/system'
import Icon from '@/components/common/Icon.vue'

const ui = useUIStore()
const sys = useSystemStore()
</script>

<template>
  <template v-if="ui.activePanel && ['battery','wifi','bluetooth','volume','user','input'].includes(ui.activePanel)">
    <div
      class="fixed rounded-[10px] p-3 w-[260px] text-[13px]"
      style="top:28px; right:8px; z-index:9500;"
      :style="{
        background: 'var(--glass-bg)',
        backdropFilter: 'blur(24px) saturate(180%)',
        WebkitBackdropFilter: 'blur(24px) saturate(180%)',
        border: '1px solid var(--glass-border)',
        boxShadow: '0 20px 40px rgba(0,0,0,0.28)'
      }"
      @click.stop
    >
      <!-- 电池 -->
      <template v-if="ui.activePanel === 'battery'">
        <div class="flex items-center justify-between mb-2">
          <div class="font-medium">电池</div>
          <div class="text-[12px] opacity-70">82% · 电源适配器</div>
        </div>
        <div class="text-[12px] opacity-80">正在充电，电量充满还需约 35 分钟。</div>
        <label class="flex items-center gap-2 mt-2 text-[12px]">
          <input type="checkbox" checked />
          <span>低电量模式</span>
        </label>
        <label class="flex items-center gap-2 mt-1 text-[12px]">
          <input type="checkbox" checked />
          <span>显示百分比</span>
        </label>
      </template>

      <!-- Wi-Fi -->
      <template v-else-if="ui.activePanel === 'wifi'">
        <div class="flex items-center justify-between mb-2">
          <div class="font-medium">Wi‑Fi</div>
          <label class="inline-flex items-center gap-1 text-[12px]">
            <input type="checkbox" v-model="sys.settings.wifiEnabled" />
          </label>
        </div>
        <div class="space-y-1">
          <div class="flex items-center gap-2 px-2 py-1.5 rounded bg-white/10">
            <Icon name="ri-wifi-line" :size="14" />
            <span class="flex-1">家庭网络</span>
            <span class="text-[11px] opacity-60">✓</span>
          </div>
          <div class="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-white/10 cursor-pointer">
            <Icon name="ri-wifi-line" :size="14" />
            <span class="flex-1">邻居家 WiFi</span>
            <span class="text-[11px] opacity-60">🔒</span>
          </div>
          <div class="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-white/10 cursor-pointer">
            <Icon name="ri-wifi-line" :size="14" />
            <span class="flex-1">Starbucks</span>
          </div>
        </div>
      </template>

      <!-- 蓝牙 -->
      <template v-else-if="ui.activePanel === 'bluetooth'">
        <div class="flex items-center justify-between mb-2">
          <div class="font-medium">蓝牙</div>
          <label class="inline-flex items-center gap-1 text-[12px]">
            <input type="checkbox" v-model="sys.settings.bluetoothEnabled" />
          </label>
        </div>
        <div class="space-y-1 text-[12px]">
          <div class="flex items-center justify-between px-2 py-1 rounded hover:bg-white/10">
            <span>AirPods Pro</span><span class="opacity-60">已连接</span>
          </div>
          <div class="flex items-center justify-between px-2 py-1 rounded hover:bg-white/10">
            <span>Magic Keyboard</span><span class="opacity-60">未连接</span>
          </div>
        </div>
      </template>

      <!-- 音量 -->
      <template v-else-if="ui.activePanel === 'volume'">
        <div class="flex items-center gap-2">
          <Icon name="ri-volume-up-line" :size="16" />
          <input
            type="range" min="0" max="1" step="0.01"
            v-model.number="sys.settings.volume"
            class="gg-slider flex-1"
          />
        </div>
        <div class="text-[11px] opacity-60 mt-2">输出设备：MacBook Pro 扬声器</div>
      </template>

      <!-- 用户 -->
      <template v-else-if="ui.activePanel === 'user'">
        <div class="flex items-center gap-3 mb-2">
          <Icon name="ri-user-line" :size="36" />
          <div>
            <div class="font-medium">当前用户</div>
            <div class="text-[11px] opacity-60">管理员</div>
          </div>
        </div>
        <div class="border-t border-black/10 dark:border-white/10 pt-2 space-y-1 text-[12px]">
          <div class="px-2 py-1 rounded hover:bg-white/10 cursor-pointer">登录项…</div>
          <div class="px-2 py-1 rounded hover:bg-white/10 cursor-pointer">用户与群组设置…</div>
        </div>
      </template>

      <!-- 输入法 -->
      <template v-else-if="ui.activePanel === 'input'">
        <div class="space-y-1 text-[12px]">
          <div class="px-2 py-1 rounded bg-white/10 flex items-center justify-between"><span>拼音</span><span class="opacity-60">✓</span></div>
          <div class="px-2 py-1 rounded hover:bg-white/10 cursor-pointer">ABC</div>
          <div class="px-2 py-1 rounded hover:bg-white/10 cursor-pointer">手写输入</div>
          <div class="border-t border-black/10 dark:border-white/10 pt-1 mt-1 px-2 py-1 rounded hover:bg-white/10 cursor-pointer">打开键盘设置…</div>
        </div>
      </template>
    </div>
  </template>
</template>

<style scoped>
.gg-slider{-webkit-appearance:none;appearance:none;height:4px;background:rgba(0,0,0,0.2);border-radius:999px;outline:none;}
:root.dark .gg-slider{background:rgba(255,255,255,0.3);}
.gg-slider::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 2px 6px rgba(0,0,0,.3);cursor:pointer;}
</style>
