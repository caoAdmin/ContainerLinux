<script setup lang="ts">
/**
 * MenuBar 顶部菜单栏（高 24px）
 * - 左侧 Apple + 当前 App 菜单
 * - 右侧状态栏图标（控制中心、Wi-Fi、电池、蓝牙、音量、Spotlight、Siri、输入法、时间、用户）
 * - 图标过多时自动折叠进收纳格（鼠标靠近展开）
 */
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useUIStore, type ContextMenuItem } from '@/stores/ui'
import type { MenubarPanel } from '@/types'
import { useSystemStore } from '@/stores/system'
import { useWindowStore } from '@/stores/windows'
import { useDockStore } from '@/stores/dock'
import { getAppById } from '@/utils/appRegistry'
import { formatDateTime } from '@/utils'
import Icon from '@/components/common/Icon.vue'

const ui = useUIStore()
const sys = useSystemStore()
const winStore = useWindowStore()
const dockStore = useDockStore()

const menuCollapsed = ref(true)
const now = ref(formatDateTime(new Date()))
/* 顶栏只显示到分钟：对齐到整分再按 60s 走，既不会显示过期时间，
   也把重渲染次数从「每 15s 一次永不停止」降到「每分钟一次」，并在卸载时清理。 */
let clockTimer = 0
function scheduleClock() {
  const delay = 60_000 - (Date.now() % 60_000)
  clockTimer = window.setTimeout(() => {
    now.value = formatDateTime(new Date())
    scheduleClock()
  }, delay)
}
onMounted(scheduleClock)
onUnmounted(() => window.clearTimeout(clockTimer))

// 当前激活 App
const activeApp = computed(() => {
  const w = winStore.windows.find((x) => x.id === winStore.activeWindowId && !x.closed && !x.minimized)
  return w ? getAppById(w.appId) : null
})

function togglePanel(name: MenubarPanel) {
  ui.openPanel(name)
}

function onAppleClick(e: MouseEvent) {
  e.stopPropagation()
  const items: ContextMenuItem[] = [
    { id: 'about', label: '关于本机', action: () => ui.openAbout() },
    { id: 'sep1', label: '', separator: true },
    { id: 'settings', label: '系统设置…', shortcut: '⌘,', action: () => {
        dockStore.setRunning('settings', true)
        winStore.openWindow({ appId: 'settings' })
      } },
    { id: 'sep2', label: '', separator: true },
    { id: 'sleep', label: '睡眠', action: () => {
        document.body.style.transition = 'filter .5s'; document.body.style.filter = 'brightness(0.1)'
        setTimeout(() => { document.body.style.filter = '' }, 1200)
      } },
    { id: 'restart', label: '重新启动…', disabled: true },
    { id: 'shutdown', label: '关机…', disabled: true },
    { id: 'sep3', label: '', separator: true },
    { id: 'lock', label: '锁定屏幕', shortcut: '⌃⌘Q', disabled: true }
  ]
  ui.showContextMenu(e.clientX, e.clientY + 22, items)
}

function onDesktopContext(_e: MouseEvent) {
  // 桌面右键处理在 App.vue
}
</script>

<template>
  <div
    class="fixed top-0 left-0 right-0 h-6 flex items-center justify-between px-3 text-[13px]"
    style="z-index:9000;"
    :style="{
      background: 'var(--menubar-bg)',
      backdropFilter: 'blur(20px) saturate(180%)',
      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      borderBottom: '1px solid var(--glass-border)'
    }"
    @contextmenu.prevent="onDesktopContext"
  >
    <!-- 左侧菜单 -->
    <div class="flex items-center gap-4">
      <button class="hover:bg-black/10 dark:hover:bg-white/10 px-1.5 rounded" aria-label="Apple 菜单" @click="onAppleClick">
        <Icon name="apple" :size="14" />
      </button>
      <span class="font-semibold">{{ activeApp?.name ?? 'Finder' }}</span>
      <span class="opacity-80">文件</span>
      <span class="opacity-80">编辑</span>
      <span class="opacity-80">显示</span>
      <span class="opacity-80">窗口</span>
      <span class="opacity-80">帮助</span>
    </div>

    <!-- 右侧图标 -->
    <div
      class="flex items-center gap-2"
      @mouseenter="menuCollapsed = false"
      @mouseleave="menuCollapsed = true"
    >
      <template v-if="!menuCollapsed">
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="输入法" @click.stop="togglePanel('input')">
          <span class="text-[12px] font-semibold">拼</span>
        </button>
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="电池" @click.stop="togglePanel('battery')">
          <Icon name="ri-battery-line" :size="18" />
        </button>
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="Wi-Fi" @click.stop="togglePanel('wifi')">
          <Icon name="siri" :size="15" />
        </button>
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="蓝牙" @click.stop="togglePanel('bluetooth')">
          <Icon name="ri-bluetooth-line" :size="14" />
        </button>
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="音量" @click.stop="togglePanel('volume')">
          <Icon :name="sys.settings.volume > 0 ? 'volume' : 'volume-muted'" :size="15" />
        </button>
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="Siri" @click.stop="ui.toggleSpotlight(); ui.setSpotlightMode('siri')">
          <Icon name="siri" :size="16" />
        </button>
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="Spotlight 搜索" @click.stop="ui.toggleSpotlight()">
          <Icon name="spotlight" :size="14" />
        </button>
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="控制中心" @click.stop="togglePanel('control-center')">
          <Icon name="control-center" :size="16" />
        </button>
      </template>
      <template v-else>
        <!-- 折叠态：只显示控制中心/时间/用户；其余隐藏，"‹" 收纳暗示 -->
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-60" aria-label="展开菜单栏图标">
          <Icon name="ri-arrow-right-s-line" :size="10" />
        </button>
        <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="控制中心" @click.stop="togglePanel('control-center')">
          <Icon name="control-center" :size="16" />
        </button>
      </template>

      <button class="px-1 hover:bg-black/10 dark:hover:bg-white/10 rounded text-[12px] leading-none" @click.stop="ui.toggleNotificationCenter()">
        <span class="opacity-90">{{ now.weekdayShort }} {{ now.month }}月{{ now.day }}日</span>
        <span class="ml-1 opacity-90">{{ now.hm }}</span>
      </button>
      <button class="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10" aria-label="用户" @click.stop="togglePanel('user')">
        <Icon name="ri-user-line" :size="16" />
      </button>
    </div>
  </div>
</template>
