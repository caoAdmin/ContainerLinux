<script setup lang="ts">
/**
 * DotfilesDesktop —— 复刻 sijin-xb/dotfiles 桌面外观（底层）。
 *
 * 当前保留：顶栏左右两组（中间留给 COSMIC 层的音乐灵动岛）。
 *
 * 已移除（按需求）：
 *   - 顶栏工作区切换长药丸
 *   - 问候卡（Hi, xibei!）、媒体卡（EGOIST / Departures）
 *   - 歌词卡、底部频谱、旧顶栏、时钟岛、迷你播放器
 *   - 右下 5 个玻璃小方块与 30 片飘浮花瓣装饰（纯装饰，与壁纸/玻璃质感冲突）
 *   - 顶栏的中岛改由 COSMIC 层的「音乐灵动岛」承担，时钟由居中大时钟承担
 *
 * 部件用锚点（百分比）定位，可随任意分辨率真正铺开。
 */
import { computed } from 'vue'
import Icon from '@/components/common/Icon.vue'
import { useCosmicStore } from '@/stores/cosmic'
import { useCosmicSystemStore } from '@/stores/cosmicSystem'
import { wallpaperStyle } from '@/utils/wallpapers'
import LgSheet from '@/components/cosmic/glass/LgSheet.vue'

/** 顶栏的消息 / 控制中心按钮要切换 COSMIC 层的浮层，所以这里也接一下 store */
const store = useCosmicStore()
const sys = useCosmicSystemStore()
/** 壁纸样式完全由「设置 → 壁纸」的状态驱动（图片 / 纯色 / 渐变、填充、虚化） */
const wallpaperCss = computed(() => wallpaperStyle(sys.wallpapers))
</script>

<template>
  <div class="dd-root">
    <div class="dd-wallpaper" :style="wallpaperCss" />

    <!-- ═══ 顶栏（左右两组；中间留给音乐灵动岛）═══
         左右两组按 HighOS_Desktop 的 TopBar 重做：
         左 = 消息按钮（带未读徽标）+ 三个快捷图标；右 = 系统状态，点击展开控制中心 -->
    <div class="dd-bar">
      <!-- 左：消息 + 快捷图标 -->
      <div class="pill pillB lg-host">
        <LgSheet liquid />
        <button
          class="ho-btn ho-btn--msg"
          :class="{ 'ho-btn--on': store.notifOpen }"
          title="通知"
          @click="store.togglePanel('notif')"
        >
          <Icon name="ri-message-3-line" :size="15" color="#22d3a6" />
          <span class="ho-badge">2</span>
        </button>
        <span class="ho-sep" />
        <button class="ho-btn" title="显示器"><Icon name="ri-computer-line" :size="15" color="rgba(255,255,255,0.68)" /></button>
        <button class="ho-btn" title="打印机"><Icon name="ri-printer-line" :size="15" color="rgba(255,255,255,0.68)" /></button>
        <button class="ho-btn" title="固定"><Icon name="ri-pushpin-line" :size="15" color="rgba(255,255,255,0.68)" /></button>
      </div>

      <!-- 右：系统状态（点击展开控制中心） -->
      <button
        class="pill pill-right lg-host"
        :class="{ 'pill-right--on': store.ccOpen }"
        title="控制中心"
        @click="store.togglePanel('cc')"
      >
        <LgSheet liquid />
        <Icon name="ri-wifi-line" :size="16" color="#fff" />
        <Icon name="ri-volume-up-line" :size="16" color="#fff" />
        <Icon name="ri-battery-line" :size="16" color="#fff" />
        <Icon name="ri-settings-3-line" :size="16" color="rgba(255,255,255,0.68)" />
      </button>
    </div>

    <!-- 桌面装饰已清理：CPU/RAM/Disk 状态卡、右下玻璃小方块、飘浮花瓣均已移除，
         桌面上只保留壁纸 + 顶栏，其余视觉交给 COSMIC 层的玻璃组件。 -->
  </div>
</template>

<style scoped>
.dd-root {
  position: fixed;
  inset: 0;
  overflow: hidden;
  font-family: "MiSans", -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", "Segoe UI", sans-serif;
  color: #fff;
  user-select: none;
  /* ══ m3e-canvas · Material 3 Expressive · 「Coral」预设（取自 lib/tokens.ts）══ */
  --m3-primary: #984061;
  --m3-primary-container: #ffd9e2;
  --m3-inverse-primary: #ffb0c8;
  --m3-on-primary-container: #3e001d;
  --m3-on-surface: #fff;
  --m3-on-surface-variant: rgba(255, 255, 255, 0.62);
  --m3-pill: rgba(96, 47, 55, 0.55);
}
.dd-wallpaper {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
}

/* ═══════════ 顶栏 ═══════════ */
.dd-bar {
  position: absolute;
  top: 13px;
  left: 0;
  right: 0;
  height: 46px;
  display: flex;
  align-items: center;
  z-index: 40;
  pointer-events: none;
}
.pill {
  pointer-events: auto;
  display: flex;
  align-items: center;
  height: 46px;
  border-radius: 23px;
  position: relative;
  isolation: isolate;
  border-color: color-mix(in srgb, var(--glass-border) 45%, transparent);
  background-color: var(--m3-pill);
  background-image: radial-gradient(240px 240px at var(--lg-hx, 50%) var(--lg-hy, 50%), rgba(255, 255, 255, 0.14), rgba(255, 255, 255, 0) 70%);
  /* 材质由 WebGL 玻璃层提供（GlassSheet），不再叠 CSS blur */
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.14), 0 4px 14px rgba(0, 0, 0, 0.22);
}
/* 左·消息 + 快捷图标（移植自 HighOS_Desktop 的 TopBar 左栏） */
html[data-glass='webgl'] .pill {
  background-color: color-mix(in srgb, var(--m3-pill) 12%, transparent);
  /* 边缘与投影全部交给玻璃层：再叠 CSS 的 1px 边框 + inset 高光，
     会在玻璃亮线外面多出一圈线，看着就是「玻璃比框小一圈」。 */
  border-color: transparent;
  box-shadow: none;
}
.pill > *:not(.glass-sheet) {
  position: relative;
  z-index: 1;
}
.pillB {
  position: absolute;
  left: 16px;
  padding: 0 8px;
  gap: 2px;
}
.ho-btn {
  position: relative;
  width: 32px; height: 32px;
  border: none;
  border-radius: 10px;
  background: transparent;
  display: inline-flex; align-items: center; justify-content: center;
  cursor: pointer;
  transition: background 0.15s ease, transform 0.15s ease;
}
.ho-btn:hover { background: rgba(255, 255, 255, 0.12); transform: scale(1.08); }
.ho-btn--msg { background: rgba(34, 211, 166, 0.2); }
.ho-btn--msg:hover { background: rgba(34, 211, 166, 0.34); }
.ho-btn--on { background: rgba(34, 211, 166, 0.42); }
.ho-badge {
  position: absolute; top: -3px; right: -3px;
  min-width: 14px; height: 14px; padding: 0 4px;
  border-radius: 9999px;
  background: #22d3a6; color: #04110d;
  font-size: 9px; font-weight: 700; line-height: 1;
  display: inline-flex; align-items: center; justify-content: center;
}
.ho-sep {
  width: 1px; height: 18px;
  margin: 0 4px;
  flex: none;
  background: rgba(255, 255, 255, 0.18);
}
/* 右·系统状态 → 控制中心入口（移植自 HighOS 的 TopBar 右栏） */
.pill-right {
  position: absolute;
  right: 16px;
  padding: 0 14px;
  gap: 13px;
  border: none;
  color: inherit;
  font: inherit;
  cursor: pointer;
  transition: background 0.15s ease;
}
.pill-right:hover { background: rgba(255, 255, 255, 0.14); }
.pill-right--on { background: rgba(34, 211, 166, 0.3); }
.app-tile {
  width: 28px; height: 28px;
  border-radius: 8px;
  display: inline-flex; align-items: center; justify-content: center;
}
.app-tile.music { background: linear-gradient(180deg, #56b0f2, #2f7fe0); border-radius: 50%; }
.app-tile.qq { background: transparent; }
.app-tile.green { background: #35c26a; border-radius: 50%; }
.net {
  display: flex; flex-direction: column;
  background: rgba(20, 12, 14, 0.45);
  border-radius: 10px;
  padding: 3px 10px;
  line-height: 1.3;
}
.net-row { display: flex; align-items: center; gap: 4px; }
.net-row i { font-style: normal; font-size: 10px; color: rgba(255, 255, 255, 0.85); font-variant-numeric: tabular-nums; }
.power {
  width: 32px; height: 32px;
  border-radius: 50%;
  background: var(--m3-inverse-primary);
  display: inline-flex; align-items: center; justify-content: center;
  margin-left: 2px;
}

/* 窄屏时收掉右药丸里纯装饰的三个应用磁贴，给中间的灵动岛让出空间 */
@media (max-width: 1600px) {
  .pill-right .app-tile {
    display: none;
  }
}
</style>
