// 自动生成：Fluent symbolic SVG 的 URL 映射（由 build 脚本根据 map.json 生成）
// 使用默认导入（与项目 launchpad-gitcode.svg 同样的 ?url 等价写法）
import accessories_calculator from './accessories-calculator.svg'
import alarm from './alarm.svg'
import application_exit from './application-exit.svg'
import applications_other from './applications-other.svg'
import applications_science from './applications-science.svg'
import archive from './archive.svg'
import audio_headphones from './audio-headphones.svg'
import audio_input_microphone from './audio-input-microphone.svg'
import audio_volume_high from './audio-volume-high.svg'
import audio_volume_low from './audio-volume-low.svg'
import audio_volume_muted from './audio-volume-muted.svg'
import audio_x_generic from './audio-x-generic.svg'
import battery from './battery.svg'
import battery_full_charging from './battery-full-charging.svg'
import bluetooth from './bluetooth.svg'
import bookmark_new from './bookmark-new.svg'
import bug from './bug.svg'
import calculator from './calculator.svg'
import calendar from './calendar.svg'
import camera_disabled from './camera-disabled.svg'
import camera_photo from './camera-photo.svg'
import chat from './chat.svg'
import chat_message_new from './chat-message-new.svg'
import checkbox from './checkbox.svg'
import checkmark from './checkmark.svg'
import clipboard_copy from './clipboard-copy.svg'
import clock_app from './clock-app.svg'
import computer from './computer.svg'
import cpu from './cpu.svg'
import dialog_password from './dialog-password.svg'
import dialog_question from './dialog-question.svg'
import dialog_warning from './dialog-warning.svg'
import document_edit from './document-edit.svg'
import document_new from './document-new.svg'
import document_open_recent from './document-open-recent.svg'
import document_save from './document-save.svg'
import download from './download.svg'
import draw_eraser from './draw-eraser.svg'
import draw_star from './draw-star.svg'
import drive_harddisk from './drive-harddisk.svg'
import drive_removable_media from './drive-removable-media.svg'
import edit from './edit.svg'
import edit_clear from './edit-clear.svg'
import edit_copy from './edit-copy.svg'
import edit_select from './edit-select.svg'
import emblem_favorite from './emblem-favorite.svg'
import emblem_important from './emblem-important.svg'
import emblem_shared from './emblem-shared.svg'
import emblem_symbolic_link from './emblem-symbolic-link.svg'
import envelope from './envelope.svg'
import firefox from './firefox.svg'
import folder from './folder.svg'
import folder_music from './folder-music.svg'
import folder_new from './folder-new.svg'
import folder_open from './folder-open.svg'
import font_size from './font-size.svg'
import github_desktop from './github-desktop.svg'
import globe from './globe.svg'
import go_bottom from './go-bottom.svg'
import go_down from './go-down.svg'
import go_home from './go-home.svg'
import go_next from './go-next.svg'
import go_previous from './go-previous.svg'
import go_top from './go-top.svg'
import go_up from './go-up.svg'
import heart_filled from './heart-filled.svg'
import image_crop from './image-crop.svg'
import image_x_generic from './image-x-generic.svg'
import info from './info.svg'
import input_gaming from './input-gaming.svg'
import input_keyboard from './input-keyboard.svg'
import input_mouse from './input-mouse.svg'
import insert_text from './insert-text.svg'
import laptop from './laptop.svg'
import list_add from './list-add.svg'
import list_remove from './list-remove.svg'
import lock_small from './lock-small.svg'
import mail_app from './mail-app.svg'
import map_marker from './map-marker.svg'
import mark_location from './mark-location.svg'
import media_eject from './media-eject.svg'
import media_flash from './media-flash.svg'
import media_optical from './media-optical.svg'
import media_playback_pause from './media-playback-pause.svg'
import media_playback_start from './media-playback-start.svg'
import media_playback_stop from './media-playback-stop.svg'
import media_playlist_repeat from './media-playlist-repeat.svg'
import media_playlist_shuffle from './media-playlist-shuffle.svg'
import media_record from './media-record.svg'
import media_skip_backward from './media-skip-backward.svg'
import media_skip_forward from './media-skip-forward.svg'
import move from './move.svg'
import network_server from './network-server.svg'
import network_transmit from './network-transmit.svg'
import network_wireless from './network-wireless.svg'
import network_wireless_offline from './network-wireless-offline.svg'
import non_starred from './non-starred.svg'
import notification_disabled from './notification-disabled.svg'
import phone from './phone.svg'
import pin from './pin.svg'
import playlist from './playlist.svg'
import preferences_color from './preferences-color.svg'
import preferences_desktop_locale from './preferences-desktop-locale.svg'
import preferences_system from './preferences-system.svg'
import preview_mode from './preview-mode.svg'
import printer from './printer.svg'
import radio from './radio.svg'
import screenshot_area from './screenshot-area.svg'
import searching from './searching.svg'
import security_high from './security-high.svg'
import security_medium from './security-medium.svg'
import send_to from './send-to.svg'
import shop from './shop.svg'
import smartphone from './smartphone.svg'
import speedometer from './speedometer.svg'
import starred from './starred.svg'
import swap_values from './swap-values.svg'
import system_reboot from './system-reboot.svg'
import system_shutdown from './system-shutdown.svg'
import system_software_install from './system-software-install.svg'
import system_users from './system-users.svg'
import tablet from './tablet.svg'
import tag from './tag.svg'
import task_due from './task-due.svg'
import temperature from './temperature.svg'
import text_markdown from './text-markdown.svg'
import text_x_generic from './text-x-generic.svg'
import text_x_script from './text-x-script.svg'
import top_bar from './top_bar.svg'
import tree from './tree.svg'
import user_available from './user-available.svg'
import user_trash from './user-trash.svg'
import utilities_terminal from './utilities-terminal.svg'
import video_camera from './video-camera.svg'
import video_display from './video-display.svg'
import view_fullscreen from './view-fullscreen.svg'
import view_grid from './view-grid.svg'
import view_list from './view-list.svg'
import view_refresh from './view-refresh.svg'
import weather_clear from './weather-clear.svg'
import weather_clear_night from './weather-clear-night.svg'
import weather_few_clouds from './weather-few-clouds.svg'
import weather_fog from './weather-fog.svg'
import weather_showers from './weather-showers.svg'
import weight from './weight.svg'
import window from './window.svg'
import window_close from './window-close.svg'
import window_new from './window-new.svg'
import x_office_document from './x-office-document.svg'
import zoom_fit_best from './zoom-fit-best.svg'
import zoom_in from './zoom-in.svg'
import zoom_out from './zoom-out.svg'

const m: Record<string, string> = {
  'accessories-calculator': accessories_calculator,
  'alarm': alarm,
  'application-exit': application_exit,
  'applications-other': applications_other,
  'applications-science': applications_science,
  'archive': archive,
  'audio-headphones': audio_headphones,
  'audio-input-microphone': audio_input_microphone,
  'audio-volume-high': audio_volume_high,
  'audio-volume-low': audio_volume_low,
  'audio-volume-muted': audio_volume_muted,
  'audio-x-generic': audio_x_generic,
  'battery': battery,
  'battery-full-charging': battery_full_charging,
  'bluetooth': bluetooth,
  'bookmark-new': bookmark_new,
  'bug': bug,
  'calculator': calculator,
  'calendar': calendar,
  'camera-disabled': camera_disabled,
  'camera-photo': camera_photo,
  'chat': chat,
  'chat-message-new': chat_message_new,
  'checkbox': checkbox,
  'checkmark': checkmark,
  'clipboard-copy': clipboard_copy,
  'clock-app': clock_app,
  'computer': computer,
  'cpu': cpu,
  'dialog-password': dialog_password,
  'dialog-question': dialog_question,
  'dialog-warning': dialog_warning,
  'document-edit': document_edit,
  'document-new': document_new,
  'document-open-recent': document_open_recent,
  'document-save': document_save,
  'download': download,
  'draw-eraser': draw_eraser,
  'draw-star': draw_star,
  'drive-harddisk': drive_harddisk,
  'drive-removable-media': drive_removable_media,
  'edit': edit,
  'edit-clear': edit_clear,
  'edit-copy': edit_copy,
  'edit-select': edit_select,
  'emblem-favorite': emblem_favorite,
  'emblem-important': emblem_important,
  'emblem-shared': emblem_shared,
  'emblem-symbolic-link': emblem_symbolic_link,
  'envelope': envelope,
  'firefox': firefox,
  'folder': folder,
  'folder-music': folder_music,
  'folder-new': folder_new,
  'folder-open': folder_open,
  'font-size': font_size,
  'github-desktop': github_desktop,
  'globe': globe,
  'go-bottom': go_bottom,
  'go-down': go_down,
  'go-home': go_home,
  'go-next': go_next,
  'go-previous': go_previous,
  'go-top': go_top,
  'go-up': go_up,
  'heart-filled': heart_filled,
  'image-crop': image_crop,
  'image-x-generic': image_x_generic,
  'info': info,
  'input-gaming': input_gaming,
  'input-keyboard': input_keyboard,
  'input-mouse': input_mouse,
  'insert-text': insert_text,
  'laptop': laptop,
  'list-add': list_add,
  'list-remove': list_remove,
  'lock-small': lock_small,
  'mail-app': mail_app,
  'map-marker': map_marker,
  'mark-location': mark_location,
  'media-eject': media_eject,
  'media-flash': media_flash,
  'media-optical': media_optical,
  'media-playback-pause': media_playback_pause,
  'media-playback-start': media_playback_start,
  'media-playback-stop': media_playback_stop,
  'media-playlist-repeat': media_playlist_repeat,
  'media-playlist-shuffle': media_playlist_shuffle,
  'media-record': media_record,
  'media-skip-backward': media_skip_backward,
  'media-skip-forward': media_skip_forward,
  'move': move,
  'network-server': network_server,
  'network-transmit': network_transmit,
  'network-wireless': network_wireless,
  'network-wireless-offline': network_wireless_offline,
  'non-starred': non_starred,
  'notification-disabled': notification_disabled,
  'phone': phone,
  'pin': pin,
  'playlist': playlist,
  'preferences-color': preferences_color,
  'preferences-desktop-locale': preferences_desktop_locale,
  'preferences-system': preferences_system,
  'preview-mode': preview_mode,
  'printer': printer,
  'radio': radio,
  'screenshot-area': screenshot_area,
  'searching': searching,
  'security-high': security_high,
  'security-medium': security_medium,
  'send-to': send_to,
  'shop': shop,
  'smartphone': smartphone,
  'speedometer': speedometer,
  'starred': starred,
  'swap-values': swap_values,
  'system-reboot': system_reboot,
  'system-shutdown': system_shutdown,
  'system-software-install': system_software_install,
  'system-users': system_users,
  'tablet': tablet,
  'tag': tag,
  'task-due': task_due,
  'temperature': temperature,
  'text-markdown': text_markdown,
  'text-x-generic': text_x_generic,
  'text-x-script': text_x_script,
  'top_bar': top_bar,
  'tree': tree,
  'user-available': user_available,
  'user-trash': user_trash,
  'utilities-terminal': utilities_terminal,
  'video-camera': video_camera,
  'video-display': video_display,
  'view-fullscreen': view_fullscreen,
  'view-grid': view_grid,
  'view-list': view_list,
  'view-refresh': view_refresh,
  'weather-clear': weather_clear,
  'weather-clear-night': weather_clear_night,
  'weather-few-clouds': weather_few_clouds,
  'weather-fog': weather_fog,
  'weather-showers': weather_showers,
  'weight': weight,
  'window': window,
  'window-close': window_close,
  'window-new': window_new,
  'x-office-document': x_office_document,
  'zoom-fit-best': zoom_fit_best,
  'zoom-in': zoom_in,
  'zoom-out': zoom_out,
}
export default m
