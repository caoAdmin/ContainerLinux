import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import tailwindcss from '@tailwindcss/vite'
import { fileURLToPath, URL } from 'node:url'

/** 部署环境会注入 PORT，本地开发回落到 5173 */
const PORT = Number(process.env.PORT) || 5173

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue(), tailwindcss()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  // 相对路径，便于任意子路径 / 反代下访问
  base: './',
  server: {
    host: '0.0.0.0',
    port: PORT,
    strictPort: false,
    // 允许任意反代域名访问（内网穿透 / 平台部署）
    allowedHosts: true
  },
  preview: {
    host: '0.0.0.0',
    port: PORT,
    strictPort: false,
    allowedHosts: true
  }
})
